const s="/assets/pdf.worker.min-BVPM1tzH.mjs";export{s as default};
