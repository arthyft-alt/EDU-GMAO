from datetime import date, datetime

import pytest

from app import db
from app.models import (
    Atelier,
    BonComposant,
    BonIntervention,
    Commande,
    CommandeLigne,
    Machine,
    Mouvement,
    Piece,
    RealisationPreventive,
    SemaineCalendrier,
    TachePreventive,
    Utilisateur,
)

AUJOURDHUI = date(2026, 11, 16)  # un lundi de l'année scolaire 2026-2027


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: AUJOURDHUI)


@pytest.fixture()
def annee_chargee(app):
    tech, tech2 = (Utilisateur.query.filter_by(login=l).one() for l in ("tech", "tech2"))
    maintenance, fonderie = Atelier.query.filter_by(nom="01. Maintenance").one(), Atelier.query.filter_by(nom="03. Fonderie").one()
    tour = Machine(repere="MAI-01", designation="Tour", atelier=maintenance)
    four = Machine(repere="FON-01", designation="Four", atelier=fonderie)
    bon = dict(demandeur="x", description="x")
    db.session.add_all(
        [
            tour,
            four,
            # Septembre : deux pannes sur le tour, dont une avec arrêt de 3 h
            BonIntervention(numero="BI-1", machine=tour, type_travail="depannage", cree_le=datetime(2026, 9, 8, 8), temps_passe_h=2,
                            techniciens=[tech], machine_arretee=True, remise_en_service=datetime(2026, 9, 8, 11), **bon),
            BonIntervention(numero="BI-2", machine=tour, type_travail="depannage", cree_le=datetime(2026, 9, 21, 8), temps_passe_h=1,
                            techniciens=[tech, tech2], **bon),
            # Octobre : une panne sur le four, une amélioration
            BonIntervention(numero="BI-3", machine=four, type_travail="depannage", cree_le=datetime(2026, 10, 5, 8), temps_passe_h=4,
                            techniciens=[tech2], **bon),
            BonIntervention(numero="BI-4", machine=four, type_travail="amelioration", cree_le=datetime(2026, 10, 6, 8), temps_passe_h=3, **bon),
            # Année scolaire précédente : ignorée
            BonIntervention(numero="BI-0", machine=four, type_travail="depannage", cree_le=datetime(2026, 7, 10, 8), temps_passe_h=9, **bon),
        ]
    )
    db.session.flush()
    db.session.add(BonComposant(bon=BonIntervention.query.filter_by(numero="BI-3").one(), designation="Joint", quantite=2, prix_unitaire=5))
    piece = Piece(reference="00001", designation="Roulement", categorie="Mécanique", prix_unitaire=10, quantite=5)
    db.session.add(piece)
    db.session.flush()
    db.session.add(Mouvement(piece=piece, type="sortie", quantite=-3, stock_apres=2, date=datetime(2026, 9, 9, 8)))
    commande = Commande(numero="BC-2026-001", cree_le=datetime(2026, 10, 12, 8))
    commande.lignes.append(CommandeLigne(designation="Courroie", quantite=4, prix_unitaire=12.5))
    annulee = Commande(numero="BC-2026-002", statut="annulee", cree_le=datetime(2026, 10, 12, 8))
    annulee.lignes.append(CommandeLigne(designation="Rien", quantite=1, prix_unitaire=999))
    db.session.add_all([commande, annulee])
    # Préventif hebdomadaire de 30 min depuis le lundi 2 novembre : 3 échéances passées, 2 réalisées
    tache = TachePreventive(machine=tour, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite="semaine",
                            date_debut=date(2026, 11, 2), temps_estime_min=30)
    db.session.add(tache)
    db.session.flush()
    db.session.add_all([RealisationPreventive(tache=tache, echeance=date(2026, 11, 2)), RealisationPreventive(tache=tache, echeance=date(2026, 11, 9))])
    db.session.add(SemaineCalendrier(lundi=date(2026, 10, 19), type="vacances"))
    db.session.commit()


def test_analyses_par_mois(client, connecter, annee_chargee):
    connecter("tech")
    d = client.get("/api/analyses?annee=2026&pas=mois").get_json()
    assert [p["libelle"] for p in d["periodes"]][:4] == ["août", "sept.", "oct.", "nov."] and len(d["periodes"]) == 12
    assert d["correctif"]["nombre"][:4] == [0, 2, 1, 0] and d["correctif"]["heures"][:4] == [0, 3, 4, 0]
    assert d["par_atelier"] == [{"nom": "03. Fonderie", "nombre": 1, "heures": 4}, {"nom": "01. Maintenance", "nombre": 2, "heures": 3}]
    assert d["par_machine"][0]["nom"] == "FON-01 — Four"
    eleves = {e["nom"]: e for e in d["par_eleve"]}
    assert eleves["Technicien 1 (démo)"] == {"nom": "Technicien 1 (démo)", "nombre": 2, "heures": 3}
    assert eleves["Technicien 2 (démo)"]["heures"] == 5
    assert d["arrets"] == [{"nom": "MAI-01 — Tour", "nombre": 1, "heures": 3}]
    # Préventif : en novembre, 3 échéances passées (2, 9, 16) dont 2 faites ; les mois suivants ne sont pas encore réalisés
    p = d["preventif"]
    assert p["prevues"][3] == 5 and p["realisees"][3] == 2 and p["realisees"][4] is None and p["taux"][4] is None
    assert p["taux"][3] == 67 and p["taux_annee"] == 67  # 2 faites sur 3 arrivées (2, 9 et 16 novembre)
    assert p["echeances_prevues"] == 3 and p["echeances_realisees"] == 2
    types = {t["cle"]: t for t in d["types"]}
    assert types["depannage"]["nombre"] == 3 and types["amelioration"]["heures"] == 3 and types["plan"]["heures"] == 1
    assert d["couts"]["pieces"][1] == 30 and d["couts"]["pieces"][2] == 10  # 3 roulements en sept., 2 joints libres en oct.
    assert d["couts"]["commandes"][2] == 50  # la commande annulée ne compte pas
    assert d["annees"][0] == 2026


def test_analyses_par_semaine_avec_vacances(client, connecter, annee_chargee):
    connecter("admin")
    d = client.get("/api/analyses?annee=2026&pas=semaine").get_json()
    vacances = [p for p in d["periodes"] if p["vacances"]]
    assert [p["debut"] for p in vacances] == ["2026-10-19"] and vacances[0]["libelle"] == "S43"
    assert d["periodes"][0]["debut"] == "2026-07-27"  # semaine du 1er août
    i = next(k for k, p in enumerate(d["periodes"]) if p["debut"] == "2026-11-16")
    assert d["preventif"]["realisees"][i] == 0 and d["preventif"]["taux"][i] == 0 and d["preventif"]["realisees"][i + 1] is None


def test_annee_precedente_et_droits(client, connecter, annee_chargee):
    connecter("tech")
    assert client.get("/api/analyses?annee=2025").get_json()["correctif"]["heures"][11] == 9  # juillet 2026
    assert client.get("/api/analyses?pas=jour").status_code == 400
    assert client.get("/api/analyses?annee=2040").status_code == 400
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get("/api/analyses").status_code == 403


def test_valorisation_du_stock(client, connecter, app):
    from datetime import timedelta

    from app.models import ZoneMagasin, maintenant

    il_y_a_2_ans = maintenant() - timedelta(days=730)
    a1 = ZoneMagasin(etagere="A", etage=1)
    db.session.add_all([
        a1,
        Piece(reference="00001", designation="Roulement", categorie="Mécanique", quantite=10, prix_unitaire=6.5, zone=a1, cree_le=il_y_a_2_ans),
        Piece(reference="00002", designation="Contacteur", categorie="Électrique", quantite=2, prix_unitaire=30, cree_le=il_y_a_2_ans),
        Piece(reference="00003", designation="Fusible", categorie="Électrique", quantite=5, prix_unitaire=None),
        Piece(reference="00004", designation="Épuisée", categorie="Électrique", quantite=0, prix_unitaire=99, cree_le=il_y_a_2_ans),
    ])
    db.session.flush()
    # Le contacteur est sorti récemment : il n'est pas « dormant »
    contacteur = Piece.query.filter_by(reference="00002").one()
    db.session.add(Mouvement(piece=contacteur, type="sortie", quantite=-1, stock_apres=2, date=maintenant() - timedelta(days=10)))
    db.session.commit()
    connecter("tech")
    d = client.get("/api/analyses/stock").get_json()
    assert d["valeur_totale"] == 125 and d["references"] == 3 and d["sans_prix"] == 1
    assert d["par_categorie"] == [{"nom": "Mécanique", "nombre": 1, "valeur": 65}, {"nom": "Électrique", "nombre": 2, "valeur": 60}]
    assert [e["nom"] for e in d["par_etagere"]] == ["Étagère A", "Sans emplacement"]
    assert [p["reference"] for p in d["dormantes"]] == ["00001"]  # le fusible est récent, le contacteur bouge
    assert d["dormantes"][0]["emplacement"] == "A1" and d["valeur_dormante"] == 65
    assert client.get("/api/analyses/stock?mois=3").status_code == 400


def test_couts_dans_le_temps(client, connecter, annee_chargee):
    from app.models import Machine, SaisieIndicateurs

    tour = Machine.query.filter_by(repere="MAI-01").one()
    db.session.add(SaisieIndicateurs(machine=tour, periode="mois", debut=date(2026, 9, 1), cout_pieces=10, cout_main_oeuvre=20, cout_immobilisation=5))
    db.session.commit()
    connecter("tech")
    assert client.get("/api/analyses/couts?annee=2026&source=auto").status_code == 403  # le calcul automatique sert à la correction
    d = client.get("/api/analyses/couts?annee=2026&source=saisies").get_json()
    assert d["natures"]["pieces"][1] == 10 and d["par_type"] is None and d["total"] == 35
    assert d["par_machine"][0] == {"nom": "MAI-01 — Tour", "pieces": 10, "main_oeuvre": 20, "immobilisation": 5, "total": 35}
    client.post("/api/auth/logout")
    connecter("admin")
    d = client.get("/api/analyses/couts?annee=2026&source=auto").get_json()
    # Septembre : 2 pannes (2 h puis 1 h, 1 technicien) au taux de main-d'œuvre par défaut (15 €/h)
    assert d["natures"]["main_oeuvre"][1] == 45 and d["par_type"]["correctif"][1] == 45
    assert d["natures"]["pieces"][2] == 10  # 2 joints à 5 € sur le bon d'octobre
    assert d["par_type"]["amelioration"][2] == 45  # 3 h d'amélioration en octobre
    assert d["par_atelier"][0]["nom"] in ("01. Maintenance", "03. Fonderie")


def test_valeurs_de_depart_du_simulateur(client, connecter, app):
    from datetime import timedelta

    from app.models import Atelier, Machine, maintenant

    m = Machine(repere="SIM-01", designation="Convoyeur", taux_horaire=120, atelier=Atelier.query.first())
    bon = dict(machine=m, demandeur="x", description="x", type_travail="depannage")
    db.session.add_all([
        m,
        BonIntervention(numero="BI-81", cree_le=maintenant() - timedelta(days=30), temps_passe_h=2, effectif=2, machine_arretee=True,
                        remise_en_service=maintenant() - timedelta(days=30) + timedelta(hours=4), **bon),
        BonIntervention(numero="BI-82", cree_le=maintenant() - timedelta(days=60), temps_passe_h=4, effectif=1, **bon),
        BonIntervention(numero="BI-80", cree_le=maintenant() - timedelta(days=500), temps_passe_h=9, **bon),  # plus d'un an
        TachePreventive(machine=m, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite="mois", date_debut=date(2026, 1, 5), temps_estime_min=30),
    ])
    db.session.commit()
    connecter("tech")
    d = client.get(f"/api/analyses/simulateur/machines/{m.id}").get_json()
    assert d["cout_arret_h"] == 120 and d["taux_main_oeuvre"] == 15
    assert d["correctif"] == {"pannes_par_an": 2, "duree_reparation_h": 3, "techniciens": 1.5, "pieces_par_panne": 0, "arret_par_panne_h": 4}
    assert d["preventif"]["interventions_par_an"] == 12 and d["preventif"]["duree_h"] == 0.5
    assert client.get("/api/analyses/simulateur/machines/999").status_code == 404
