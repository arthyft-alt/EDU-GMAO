import pytest

from app import db
from app.models import GroupeEleves, Utilisateur


def uid(login):
    return Utilisateur.query.filter_by(login=login).one().id


def ouvrir(client, type_conv, cible=None):
    reponse = client.post("/api/messagerie/conversations", json={"type": type_conv, "id": cible})
    assert reponse.status_code == 200, reponse.get_json()
    return reponse.get_json()["conversation"]["id"]


def ecrire(client, conv_id, texte):
    return client.post(f"/api/messagerie/conversations/{conv_id}/messages", json={"texte": texte})


def test_operateur_sans_messagerie(client, connecter):
    connecter("operateur")
    assert client.get("/api/messagerie/non-lus").status_code == 403
    assert client.get("/api/messagerie/conversations").status_code == 403


def test_eleve_ecrit_aux_enseignants(client, connecter):
    connecter("tech")
    conv = ouvrir(client, "enseignants")
    assert ecrire(client, conv, "La presse fuit encore").status_code == 201
    assert ecrire(client, conv, "   ").status_code == 400

    connecter("admin")
    assert client.get("/api/messagerie/non-lus").get_json()["total"] == 1
    liste = client.get("/api/messagerie/conversations").get_json()["conversations"]
    assert liste[0]["titre"] == "Technicien 1 (démo)" and liste[0]["non_lus"] == 1
    messages = client.get(f"/api/messagerie/conversations/{conv}/messages").get_json()["messages"]
    assert messages[0]["texte"] == "La presse fuit encore"
    assert client.get("/api/messagerie/non-lus").get_json()["total"] == 0  # lu à l'ouverture
    # L'enseignant qui écrit à l'élève retrouve le même fil
    assert ouvrir(client, "enseignants", uid("tech")) == conv
    ecrire(client, conv, "Je passe voir")

    connecter("tech")
    liste = client.get("/api/messagerie/conversations").get_json()["conversations"]
    assert liste[0]["titre"] == "Enseignants" and liste[0]["non_lus"] == 1


def test_eleves_entre_eux_et_confidentialite(client, connecter, app):
    autre = Utilisateur(login="tech3", nom="Technicien 3", role="technicien")
    autre.definir_mot_de_passe("tech3")
    db.session.add(autre)
    db.session.commit()

    connecter("tech")
    conv = ouvrir(client, "directe", uid("tech2"))
    ecrire(client, conv, "Tu as la clé de 13 ?")
    assert client.post("/api/messagerie/conversations", json={"type": "directe", "id": uid("admin")}).status_code == 400
    assert client.post("/api/messagerie/conversations", json={"type": "classe"}).status_code == 403

    connecter("tech2")
    assert ouvrir(client, "directe", uid("tech")) == conv  # même fil dans l'autre sens
    assert client.get(f"/api/messagerie/conversations/{conv}/messages").status_code == 200

    # Un troisième élève ne voit pas la conversation
    client.post("/api/auth/login", json={"login": "tech3", "password": "tech3"})
    assert client.get(f"/api/messagerie/conversations/{conv}/messages").status_code == 404
    assert ecrire(client, conv, "intrus").status_code == 404


def test_enseignant_ecrit_a_un_groupe_et_a_la_classe(client, connecter):
    groupe = GroupeEleves(nom="A", membres=[Utilisateur.query.filter_by(login="tech").one()])
    db.session.add(groupe)
    db.session.commit()
    connecter("admin")
    conv_groupe = ouvrir(client, "groupe", groupe.id)
    ecrire(client, conv_groupe, "Groupe A : rangement vendredi")
    conv_classe = ouvrir(client, "classe")
    ecrire(client, conv_classe, "Réunion à 14 h")

    connecter("tech")
    titres = {c["titre"] for c in client.get("/api/messagerie/conversations").get_json()["conversations"]}
    assert titres == {"Groupe « A »", "Toute la classe"}
    assert ecrire(client, conv_groupe, "OK").status_code == 201  # les membres répondent

    connecter("tech2")  # pas dans le groupe
    titres = {c["titre"] for c in client.get("/api/messagerie/conversations").get_json()["conversations"]}
    assert titres == {"Toute la classe"}
    assert client.get(f"/api/messagerie/conversations/{conv_groupe}/messages").status_code == 404


def test_nouveaux_messages_seulement(client, connecter):
    connecter("tech")
    conv = ouvrir(client, "enseignants")
    premier = ecrire(client, conv, "un").get_json()["message"]["id"]
    ecrire(client, conv, "deux")
    nouveaux = client.get(f"/api/messagerie/conversations/{conv}/messages?apres={premier}").get_json()["messages"]
    assert [m["texte"] for m in nouveaux] == ["deux"]


@pytest.mark.parametrize("login", ["tech", "tech2"])
def test_seul_l_admin_supprime(client, connecter, login):
    connecter("tech")
    conv = ouvrir(client, "enseignants")
    message = ecrire(client, conv, "message à modérer").get_json()["message"]["id"]
    connecter(login)
    assert client.delete(f"/api/messagerie/messages/{message}").status_code == 403
    connecter("admin")
    assert client.delete(f"/api/messagerie/messages/{message}").status_code == 200
    assert client.get(f"/api/messagerie/conversations/{conv}/messages").get_json()["messages"] == []


def test_destinataires(client, connecter):
    connecter("tech")
    d = client.get("/api/messagerie/destinataires").get_json()
    assert d["collectifs"] == [{"type": "enseignants", "id": None, "nom": "Les enseignants"}]
    assert [p["nom"] for p in d["personnes"]] == ["Technicien 2 (démo)"]
    connecter("admin")
    d = client.get("/api/messagerie/destinataires").get_json()
    assert d["collectifs"][0]["type"] == "classe"
    assert {p["type"] for p in d["personnes"]} == {"enseignants"}  # seul admin de démo : pas d'autre enseignant
