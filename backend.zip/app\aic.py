"""Réunion AIC (AIC-01 à AIC-07) : durée du minuteur et Croix Sécurité."""
from datetime import date, datetime, timedelta

from flask import Blueprint, jsonify, request
from flask_login import current_user, login_required

from . import db
from .auth import erreur, role_required
from .calendrier import annee_scolaire, lundi
from .dates import PARIS
from .models import Parametre, SemaineCalendrier, SemaineSecurite, journaliser

bp = Blueprint("aic", __name__)

EQUIPE = ("admin", "technicien")
COULEURS = ("vert", "orange", "rouge", "gris")


def _parametre(cle, defaut):
    p = db.session.get(Parametre, cle)
    return p.valeur if p and p.valeur not in (None, "") else defaut


def _definir(cle, valeur):
    p = db.session.get(Parametre, cle) or Parametre(cle=cle)
    p.valeur = str(valeur)
    db.session.add(p)


@bp.get("/aic/parametres")
@role_required(*EQUIPE)
def parametres():
    return jsonify(duree_minutes=int(_parametre("duree_aic_minutes", "10")))


@bp.put("/aic/parametres")
@role_required("admin")
def changer_parametres():
    try:
        duree = int((request.get_json(silent=True) or {}).get("duree_minutes"))
    except (TypeError, ValueError):
        return erreur("La durée est un nombre entier de minutes.", 400)
    if not 1 <= duree <= 60:
        return erreur("La durée doit être comprise entre 1 et 60 minutes.", 400)
    _definir("duree_aic_minutes", duree)
    journaliser("modification", details=f"Durée de la réunion AIC : {duree} min")
    db.session.commit()
    return jsonify(duree_minutes=duree)


def compteurs(jusqu_a):
    """Semaines consécutives sans accident jusqu'à la semaine donnée, et record.
    Vert et orange comptent (pas d'accident) ; rouge remet à zéro ; gris et sans couleur ne comptent pas."""
    serie = record = 0
    for s in SemaineSecurite.query.filter(SemaineSecurite.lundi <= jusqu_a).order_by(SemaineSecurite.lundi):
        if s.couleur == "rouge":
            serie = 0
        elif s.couleur in ("vert", "orange"):
            serie += 1
            record = max(record, serie)
    return serie, max(record, int(_parametre("record_croix_securite", "0")))


@bp.get("/aic/croix")
@role_required(*EQUIPE)
def croix():
    """Semaines de l'année scolaire avec leur couleur ; les semaines de vacances non renseignées sont grises."""
    aujourdhui = datetime.now(PARIS).date()
    try:
        debut_annee = int(request.args.get("annee") or annee_scolaire(aujourdhui))
    except ValueError:
        return erreur("Année invalide.", 400)
    premier, dernier = lundi(date(debut_annee, 8, 1)), date(debut_annee + 1, 7, 31)
    couleurs = {s.lundi: s.couleur for s in SemaineSecurite.query.filter(SemaineSecurite.lundi.between(premier, dernier))}
    vacances = {s.lundi for s in SemaineCalendrier.query.filter(SemaineCalendrier.lundi.between(premier, dernier), SemaineCalendrier.type == "vacances")}
    semaines, jour = [], premier
    while jour <= dernier:
        couleur = couleurs.get(jour) or ("gris" if jour in vacances else None)
        semaines.append({"lundi": jour.isoformat(), "numero": jour.isocalendar()[1], "couleur": couleur, "vacances": jour in vacances,
                         "a_venir": jour > lundi(aujourdhui), "en_cours": jour == lundi(aujourdhui)})
        jour += timedelta(days=7)
    serie, record = compteurs(lundi(aujourdhui))
    return jsonify(annee=debut_annee, semaines=semaines, serie=serie, record=record)


@bp.put("/aic/croix")
@role_required(*EQUIPE)
def colorer():
    """Couleur d'une semaine (enregistrement automatique à chaque clic) ; couleur vide = sans couleur."""
    donnees = request.get_json(silent=True) or {}
    try:
        jour = lundi(date.fromisoformat(str(donnees.get("lundi"))))
    except ValueError:
        return erreur("Semaine invalide.", 400)
    couleur = donnees.get("couleur")
    if couleur not in COULEURS + (None, ""):
        return erreur("Couleur inconnue.", 400)
    if jour > lundi(datetime.now(PARIS).date()) and couleur not in (None, "", "gris"):
        return erreur("Une semaine à venir ne peut être que grise (vacances) ou sans couleur.", 400)
    semaine = SemaineSecurite.query.filter_by(lundi=jour).first()
    if not couleur:
        if semaine:
            db.session.delete(semaine)
    elif semaine:
        semaine.couleur, semaine.modifie_par_id = couleur, current_user.id
    else:
        db.session.add(SemaineSecurite(lundi=jour, couleur=couleur, modifie_par_id=current_user.id))
    journaliser("croix_securite", details=f"Semaine du {jour:%d/%m/%Y} : {couleur or 'sans couleur'}")
    db.session.commit()
    serie, record = compteurs(lundi(datetime.now(PARIS).date()))
    return jsonify(serie=serie, record=record)


@bp.get("/aic/performance")
@role_required(*EQUIPE)
def performance():
    """Étape 2 de la réunion : vue « calcul automatique » du mois en cours (parc, ateliers, ?atelier_id= machines).
    Sans code du jour pendant la réunion (choix de Simon) ; les coûts n'y figurent pas."""
    from .indicateurs import bornes, donnees_tableau

    du, au = bornes("mois", datetime.now(PARIS).date())
    return jsonify(donnees_tableau("mois", du, au, avec_couts=False, atelier_id=request.args.get("atelier_id", type=int)))


@bp.get("/securite/semaine")
@login_required
def securite_semaine():
    """Bandeau de l'accueil : couleur de la Croix Sécurité de la semaine en cours (sinon la dernière renseignée)."""
    cette_semaine = lundi(datetime.now(PARIS).date())
    semaine = SemaineSecurite.query.filter(SemaineSecurite.lundi <= cette_semaine).order_by(SemaineSecurite.lundi.desc()).first()
    serie, record = compteurs(cette_semaine)
    return jsonify(
        couleur=semaine.couleur if semaine else None,
        lundi=semaine.lundi.isoformat() if semaine else None,
        semaine_en_cours=bool(semaine and semaine.lundi == cette_semaine),
        serie=serie,
        record=record,
    )


def remettre_croix_a_zero(jour):
    """1er août (AIC-05) : les couleurs de l'année sont effacées ; le record est conservé."""
    _, record = compteurs(jour)
    _definir("record_croix_securite", record)
    return SemaineSecurite.query.delete(synchronize_session=False)
