"""Module Stock, magasin et fournisseurs (STK-01 à STK-10)."""
import io
import re
import unicodedata
from collections import defaultdict
from datetime import date

from flask import Blueprint, Response, jsonify, request
from flask_login import current_user
from sqlalchemy import and_, func, or_
from sqlalchemy.orm import selectinload

from . import db, tableur
from . import referentiels as ref
from .auth import erreur, role_required
from .dates import format_paris
from .reglages import liste
from .models import (
    BonComposant,
    Commande,
    CommandeLigne,
    Element,
    Fournisseur,
    Machine,
    Mouvement,
    PanierLigne,
    Piece,
    PieceMachine,
    TachePiece,
    ZoneMagasin,
    journaliser,
    maintenant,
)

bp = Blueprint("stock", __name__)

EQUIPE = ("admin", "technicien")
CODE_ZONE = re.compile(r"^([A-Za-z])\s*([0-9]{1,2})$")  # étagère (lettre) + étage (chiffre) : A1, B12


class Invalide(Exception):
    pass


class StockInsuffisant(Invalide):
    pass


# ---------- Outils de saisie ----------

def _texte(donnees, cle, libelle, obligatoire=False, longueur=500):
    valeur = str(donnees.get(cle) or "").strip()
    if obligatoire and not valeur:
        raise Invalide(f"Le champ « {libelle} » est obligatoire.")
    if len(valeur) > longueur:
        raise Invalide(f"Le champ « {libelle} » ne doit pas dépasser {longueur} caractères.")
    return valeur or None


def nombre(valeur, libelle, mini=0, maxi=1_000_000, obligatoire=False):
    """Nombre saisi à l'écran (virgule décimale acceptée)."""
    if valeur is None or str(valeur).strip() == "":
        if obligatoire:
            raise Invalide(f"Indiquez « {libelle} ».")
        return None
    try:
        n = float(str(valeur).replace(",", ".").strip())
    except ValueError:
        raise Invalide(f"« {libelle} » doit être un nombre.")
    if not mini <= n <= maxi:
        raise Invalide(f"« {libelle} » doit être compris entre {mini:g} et {maxi:g}.")
    return n


def _normaliser(texte):
    """Pour le contrôle des doublons : minuscules, sans accents ni espaces multiples."""
    sans_accents = unicodedata.normalize("NFKD", texte or "").encode("ascii", "ignore").decode()
    return " ".join(sans_accents.lower().split())


# ---------- Mouvements de stock (utilisés aussi par les interventions) ----------

def mouvementer(piece, type_mouvement, variation, motif=None, bon=None, commande=None):
    """Modifie le stock d'une pièce et trace le mouvement. Refuse un stock négatif."""
    if variation == 0:
        return None
    nouveau = round(piece.quantite + variation, 4)
    if nouveau < 0:
        raise StockInsuffisant(
            f"Stock insuffisant pour « {piece.designation} » ({piece.reference}) : "
            f"{piece.quantite:g} disponible(s). Faites d'abord un inventaire si le stock affiché est faux."
        )
    piece.quantite = nouveau
    m = Mouvement(
        piece=piece,
        type=type_mouvement,
        quantite=variation,
        stock_apres=nouveau,
        motif=motif,
        bon=bon,
        commande=commande,
        utilisateur_id=current_user.id if current_user and current_user.is_authenticated else None,
    )
    db.session.add(m)
    return m


def synchroniser_composants_bon(bon, anciennes_quantites):
    """Après modification des composants d'un bon : sort du stock (ou y remet) la différence par pièce."""
    nouvelles = defaultdict(float)
    for c in bon.composants:
        if c.piece_id:
            nouvelles[c.piece_id] += c.quantite
    for piece_id in set(anciennes_quantites) | set(nouvelles):
        ecart = nouvelles.get(piece_id, 0) - anciennes_quantites.get(piece_id, 0)
        if abs(ecart) < 1e-9:
            continue
        piece = db.session.get(Piece, piece_id)
        if ecart > 0:
            mouvementer(piece, "sortie", -ecart, f"Intervention {bon.numero}", bon=bon)
        else:
            mouvementer(piece, "entree", -ecart, f"Retour en stock (intervention {bon.numero})", bon=bon)


def quantites_par_piece(composants):
    quantites = defaultdict(float)
    for c in composants:
        if c.piece_id:
            quantites[c.piece_id] += c.quantite
    return quantites


# ---------- Fournisseurs ----------

def _appliquer_fournisseur(f, donnees):
    nom = _texte(donnees, "nom", "Nom", obligatoire=True, longueur=120)
    doublon = Fournisseur.query.filter(func.lower(Fournisseur.nom) == nom.lower(), Fournisseur.id != f.id).first()
    if doublon:
        raise Invalide(f"Le fournisseur « {doublon.nom} » existe déjà.")
    site = _texte(donnees, "site_web", "Site web", longueur=300)
    if site and not re.match(r"^https?://", site):
        site = "https://" + site
    f.nom = nom
    f.site_web = site
    f.adresse = _texte(donnees, "adresse", "Adresse", longueur=1000)
    f.telephone = _texte(donnees, "telephone", "Téléphone", longueur=40)
    f.email = _texte(donnees, "email", "E-mail", longueur=160)
    f.contact = _texte(donnees, "contact", "Contact", longueur=120)
    f.remarques = _texte(donnees, "remarques", "Remarques", longueur=5000)


@bp.get("/fournisseurs")
@role_required(*EQUIPE)
def liste_fournisseurs():
    fournisseurs = Fournisseur.query.order_by(Fournisseur.nom).all()
    comptes = dict(db.session.query(Piece.fournisseur_id, func.count(Piece.id)).group_by(Piece.fournisseur_id).all())
    return jsonify(fournisseurs=[{**f.to_dict(), "nb_pieces": comptes.get(f.id, 0)} for f in fournisseurs])


@bp.post("/fournisseurs")
@role_required(*EQUIPE)
def creer_fournisseur():
    f = Fournisseur()
    try:
        _appliquer_fournisseur(f, request.get_json(silent=True) or {})
    except Invalide as e:
        return erreur(str(e), 400)
    db.session.add(f)
    db.session.flush()
    journaliser("creation", f, f.nom)
    db.session.commit()
    return jsonify(fournisseur=f.to_dict()), 201


@bp.put("/fournisseurs/<int:fournisseur_id>")
@role_required(*EQUIPE)
def modifier_fournisseur(fournisseur_id):
    f = db.session.get(Fournisseur, fournisseur_id)
    if not f:
        return erreur("Fournisseur introuvable.", 404)
    try:
        _appliquer_fournisseur(f, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    journaliser("modification", f, f.nom)
    db.session.commit()
    return jsonify(fournisseur=f.to_dict())


@bp.delete("/fournisseurs/<int:fournisseur_id>")
@role_required("admin")
def supprimer_fournisseur(fournisseur_id):
    f = db.session.get(Fournisseur, fournisseur_id)
    if not f:
        return erreur("Fournisseur introuvable.", 404)
    if f.pieces.count() or Commande.query.filter_by(fournisseur_id=f.id).count():
        return erreur("Ce fournisseur a des pièces ou des commandes : il ne peut pas être supprimé.", 409)
    journaliser("suppression", f, f.nom)
    db.session.delete(f)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Pièces ----------

def _nouvelle_reference():
    derniere = db.session.query(func.max(Piece.reference)).scalar()
    suivante = int(derniere) + 1 if derniere else 1
    if suivante > 99999:
        raise Invalide("Plus de référence disponible (99999 atteint).")
    return f"{suivante:05d}"


def _appliquer_piece(piece, donnees):
    designation = _texte(donnees, "designation", "Désignation", obligatoire=True, longueur=160)
    categorie = donnees.get("categorie")
    if categorie not in liste("categories_pieces"):
        raise Invalide("Choisissez la catégorie technique.")
    fournisseur = None
    if donnees.get("fournisseur_id") not in (None, ""):
        try:
            fournisseur = db.session.get(Fournisseur, int(donnees["fournisseur_id"]))
        except (TypeError, ValueError):
            fournisseur = None
        if not fournisseur:
            raise Invalide("Fournisseur introuvable.")
    reference_fournisseur = _texte(donnees, "reference_fournisseur", "Référence fournisseur", longueur=80)
    zone = None
    if donnees.get("zone_id") not in (None, ""):
        try:
            zone = db.session.get(ZoneMagasin, int(donnees["zone_id"]))
        except (TypeError, ValueError):
            zone = None
        if not zone:
            raise Invalide("Zone du magasin introuvable.")

    # Contrôle anti-doublon (STK-03) : même désignation, ou même référence chez le même fournisseur
    for autre in Piece.query.filter(Piece.id != piece.id):
        if _normaliser(autre.designation) == _normaliser(designation):
            raise Invalide(f"Doublon : la pièce {autre.reference} « {autre.designation} » existe déjà.")
        if (
            reference_fournisseur
            and fournisseur
            and autre.fournisseur_id == fournisseur.id
            and _normaliser(autre.reference_fournisseur) == _normaliser(reference_fournisseur)
        ):
            raise Invalide(
                f"Doublon : la référence fournisseur « {reference_fournisseur} » est déjà utilisée par la pièce {autre.reference}."
            )

    piece.designation = designation
    piece.categorie = categorie
    piece.fournisseur = fournisseur
    piece.reference_fournisseur = reference_fournisseur
    lien = _texte(donnees, "lien_commande", "Lien de commande", longueur=500)
    piece.lien_commande = ("https://" + lien) if lien and not re.match(r"^https?://", lien) else lien
    piece.zone = zone
    piece.prix_unitaire = nombre(donnees.get("prix_unitaire"), "Prix unitaire")
    piece.stock_securite = nombre(donnees.get("stock_securite"), "Stock de sécurité")
    piece.quantite_min_commande = nombre(donnees.get("quantite_min_commande"), "Quantité minimale de commande")
    piece.commentaires = _texte(donnees, "commentaires", "Commentaires", longueur=5000)


def _piece_ou_404(piece_id):
    piece = db.session.get(Piece, piece_id)
    if not piece:
        return None, erreur("Pièce introuvable.", 404)
    return piece, None


def _filtrer_pieces(requete):
    args = request.args
    recherche = (args.get("q") or "").strip()
    if recherche:
        motif = f"%{recherche}%"
        conditions = [
            Piece.reference.ilike(motif),
            Piece.designation.ilike(motif),
            Piece.reference_fournisseur.ilike(motif),
            Piece.commentaires.ilike(motif),
            Piece.zone.has(ZoneMagasin.description.ilike(motif)),
            Piece.affectations.any(PieceMachine.repere_schema.ilike(motif)),  # repère de schéma : « KM2 »
        ]
        code = CODE_ZONE.match(recherche)
        if code:  # recherche d'un emplacement : « A2 »
            conditions.append(Piece.zone.has(and_(ZoneMagasin.etagere == code[1].upper(), ZoneMagasin.etage == int(code[2]))))
        requete = requete.filter(or_(*conditions))
    if args.get("categorie"):
        requete = requete.filter(Piece.categorie == args["categorie"])
    if args.get("zone_id") == "aucune":
        requete = requete.filter(Piece.zone_id.is_(None))
    elif args.get("zone_id", type=int):
        requete = requete.filter(Piece.zone_id == args.get("zone_id", type=int))
    if args.get("etagere"):
        requete = requete.filter(Piece.zone.has(ZoneMagasin.etagere == args["etagere"].upper()[:1]))
    if args.get("fournisseur_id", type=int):
        requete = requete.filter(Piece.fournisseur_id == args.get("fournisseur_id", type=int))
    if args.get("machine_id", type=int):
        condition = PieceMachine.machine_id == args.get("machine_id", type=int)
        if args.get("element_id", type=int):
            condition = condition & (PieceMachine.element_id == args.get("element_id", type=int))
        requete = requete.filter(Piece.affectations.any(condition))
    if args.get("alerte") == "1":
        requete = requete.filter(Piece.stock_securite.isnot(None), Piece.quantite <= Piece.stock_securite)
    return requete


@bp.get("/pieces")
@role_required(*EQUIPE)
def liste_pieces():
    pieces = (
        _filtrer_pieces(Piece.query)
        .options(selectinload(Piece.affectations).joinedload(PieceMachine.machine))
        .order_by(Piece.reference)
        .limit(2000)
        .all()
    )
    resultat = []
    for p in pieces:
        d = p.to_dict()
        # Repères de schéma (n° 10) : « MAI-01 : KM1, KM2 » ; avec ?machine_id, celui de cette machine
        d["reperes"] = [
            {"machine_id": a.machine_id, "machine_repere": a.machine.repere, "repere_schema": a.repere_schema} for a in p.affectations if a.repere_schema
        ]
        resultat.append(d)
    return jsonify(pieces=resultat)


def normaliser_reperes(texte):
    """« km1 ; km2  KM1 » → « KM1, KM2 » (majuscules, sans doublon). Lève ValueError si trop long."""
    reperes = []
    for r in re.split(r"[,;\s]+", str(texte or "").upper()):
        if r and r not in reperes:
            reperes.append(r)
    resultat = ", ".join(reperes)
    if len(resultat) > 120:
        raise ValueError("Les repères de schéma ne doivent pas dépasser 120 caractères.")
    return resultat or None


@bp.put("/pieces/<int:piece_id>/machines/<int:machine_id>/repere")
@role_required(*EQUIPE)
def repere_schema(piece_id, machine_id):
    """Repères du schéma de la machine pour cette pièce (saisie depuis l'onglet Pièces détachées de la machine)."""
    lien = PieceMachine.query.filter_by(piece_id=piece_id, machine_id=machine_id).first()
    if not lien:
        return erreur("Cette pièce n'est pas rattachée à cette machine.", 404)
    try:
        lien.repere_schema = normaliser_reperes((request.get_json(silent=True) or {}).get("repere_schema"))
    except ValueError as e:
        return erreur(str(e), 400)
    journaliser("modification", lien.piece, f"Repère de schéma sur {lien.machine.repere} : {lien.repere_schema or 'aucun'}")
    db.session.commit()
    return jsonify(lien=lien.to_dict())


@bp.get("/pieces/<int:piece_id>")
@role_required(*EQUIPE)
def detail_piece(piece_id):
    piece, err = _piece_ou_404(piece_id)
    if err:
        return err
    mouvements = piece.mouvements.order_by(Mouvement.date.desc(), Mouvement.id.desc()).limit(200).all()
    return jsonify(piece=piece.to_dict(details=True), mouvements=[m.to_dict() for m in mouvements])


@bp.get("/pieces/code/<code>")
@role_required(*EQUIPE)
def piece_par_code(code):
    """Recherche par code-barres (douchette) ou numéro de pièce : « 42 » ou « 00042 »."""
    code = code.strip()
    if not code.isdigit() or len(code) > 5:
        return erreur(f"« {code} » n'est pas un numéro de pièce.", 404)
    piece = Piece.query.filter_by(reference=code.zfill(5)).first()
    if not piece:
        return erreur(f"Aucune pièce n° {code.zfill(5)}.", 404)
    return jsonify(piece=piece.to_dict(details=True))


@bp.post("/pieces")
@role_required(*EQUIPE)
def creer_piece():
    donnees = request.get_json(silent=True) or {}
    try:
        piece = Piece(quantite=0, reference=_nouvelle_reference())
        _appliquer_piece(piece, donnees)
        db.session.add(piece)
        db.session.flush()
        initiale = nombre(donnees.get("quantite_initiale"), "Quantité en stock")
        if initiale:
            mouvementer(piece, "inventaire", initiale, "Stock initial")
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    journaliser("creation", piece, f"{piece.reference} — {piece.designation}")
    db.session.commit()
    return jsonify(piece=piece.to_dict(details=True)), 201


@bp.put("/pieces/<int:piece_id>")
@role_required(*EQUIPE)
def modifier_piece(piece_id):
    piece, err = _piece_ou_404(piece_id)
    if err:
        return err
    try:
        _appliquer_piece(piece, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    journaliser("modification", piece, f"{piece.reference} — {piece.designation}")
    db.session.commit()
    return jsonify(piece=piece.to_dict(details=True))


@bp.delete("/pieces/<int:piece_id>")
@role_required("admin")
def supprimer_piece(piece_id):
    piece, err = _piece_ou_404(piece_id)
    if err:
        return err
    if (
        piece.mouvements.count()
        or CommandeLigne.query.filter_by(piece_id=piece.id).count()
        or BonComposant.query.filter_by(piece_id=piece.id).count()
    ):
        return erreur("Cette pièce a un historique (mouvements, commandes ou interventions) : elle ne peut pas être supprimée.", 409)
    PanierLigne.query.filter_by(piece_id=piece.id).delete()
    TachePiece.query.filter_by(piece_id=piece.id).delete()  # retirée des pièces prévues du préventif
    journaliser("suppression", piece, f"{piece.reference} — {piece.designation}")
    db.session.delete(piece)
    db.session.commit()
    return jsonify(ok=True)


@bp.put("/pieces/<int:piece_id>/affectations")
@role_required(*EQUIPE)
def affectations_piece(piece_id):
    """Machines où la pièce est utilisée, avec l'élément de rangement : [{machine_id, element_id}]."""
    piece, err = _piece_ou_404(piece_id)
    if err:
        return err
    lignes = (request.get_json(silent=True) or {}).get("affectations")
    if not isinstance(lignes, list):
        return erreur("Liste des machines invalide.", 400)
    existants = {a.machine_id: a for a in piece.affectations}
    nouvelles, vues = [], set()
    for ligne in lignes:
        try:
            machine = db.session.get(Machine, int(ligne.get("machine_id")))
            element = db.session.get(Element, int(ligne.get("element_id")))
        except (TypeError, ValueError, AttributeError):
            machine = element = None
        if not machine or not element:
            return erreur("Choisissez une machine et un élément pour chaque ligne.", 400)
        if machine.id in vues:
            return erreur(f"La machine {machine.repere} apparaît deux fois.", 400)
        vues.add(machine.id)
        try:
            reperes = normaliser_reperes(ligne.get("repere_schema"))
        except ValueError as e:
            return erreur(str(e), 400)
        # Lien existant mis à jour sur place (le remplacer violerait l'unicité pièce-machine avant la suppression)
        lien = existants.get(machine.id) or PieceMachine(machine=machine)
        lien.element, lien.repere_schema = element, reperes
        nouvelles.append(lien)
    piece.affectations = nouvelles
    journaliser("modification", piece, "Machines d'utilisation : " + (", ".join(a.machine.repere for a in nouvelles) or "aucune"))
    db.session.commit()
    return jsonify(piece=piece.to_dict(details=True))


# ---------- Mouvements ----------

@bp.post("/mouvements")
@role_required(*EQUIPE)
def creer_mouvement():
    """Entrée, sortie ou inventaire (saisie à la douchette ou par numéro de pièce)."""
    donnees = request.get_json(silent=True) or {}
    try:
        piece = db.session.get(Piece, int(donnees.get("piece_id")))
    except (TypeError, ValueError):
        piece = None
    if not piece:
        return erreur("Pièce introuvable.", 404)
    type_mouvement = donnees.get("type")
    motif = str(donnees.get("motif") or "").strip()[:300] or None
    try:
        if type_mouvement == "inventaire":
            compte = nombre(donnees.get("quantite"), "Quantité comptée", obligatoire=True)
            mouvement = mouvementer(piece, "inventaire", compte - piece.quantite, motif or "Inventaire")
        elif type_mouvement in ("entree", "sortie"):
            quantite = nombre(donnees.get("quantite"), "Quantité", mini=0.001, obligatoire=True)
            mouvement = mouvementer(piece, type_mouvement, quantite if type_mouvement == "entree" else -quantite, motif)
        else:
            raise Invalide("Choisissez entrée, sortie ou inventaire.")
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 409 if isinstance(e, StockInsuffisant) else 400)
    db.session.commit()
    return jsonify(piece=piece.to_dict(details=True), mouvement=mouvement.to_dict() if mouvement else None), 201


def _filtrer_mouvements(requete):
    if request.args.get("piece_id", type=int):
        requete = requete.filter(Mouvement.piece_id == request.args.get("piece_id", type=int))
    if request.args.get("type"):
        requete = requete.filter(Mouvement.type == request.args["type"])
    return requete


@bp.get("/mouvements")
@role_required(*EQUIPE)
def liste_mouvements():
    limite = min(request.args.get("limite", 100, type=int), 2000)
    mouvements = _filtrer_mouvements(Mouvement.query).order_by(Mouvement.date.desc(), Mouvement.id.desc()).limit(limite).all()
    return jsonify(mouvements=[m.to_dict() for m in mouvements])


# ---------- Magasin ----------

@bp.get("/zones")
@role_required(*EQUIPE)
def liste_zones():
    """Zones du magasin (étagère + étage), avec leur nombre de références et d'alertes (STK-10)."""
    comptes = defaultdict(lambda: {"nb_references": 0, "nb_alertes": 0})
    for p in Piece.query.filter(Piece.zone_id.isnot(None)):
        comptes[p.zone_id]["nb_references"] += 1
        comptes[p.zone_id]["nb_alertes"] += int(p.en_alerte)
    zones = ZoneMagasin.query.order_by(ZoneMagasin.etagere, ZoneMagasin.etage).all()
    return jsonify(
        zones=[{**z.to_dict(), **comptes[z.id]} for z in zones],
        sans_emplacement=Piece.query.filter(Piece.zone_id.is_(None)).count(),
    )


def _appliquer_zone(zone, donnees):
    etagere = str(donnees.get("etagere") or "").strip().upper()
    if not re.fullmatch(r"[A-Z]", etagere):
        raise Invalide("Étagère : une seule lettre, de A à Z.")
    try:
        etage = int(str(donnees.get("etage")).strip())
    except (TypeError, ValueError):
        raise Invalide("Étage : un nombre entier (1, 2, 3…).")
    if not 0 <= etage <= 99:
        raise Invalide("Étage : un nombre entre 0 et 99.")
    doublon = ZoneMagasin.query.filter_by(etagere=etagere, etage=etage).filter(ZoneMagasin.id != zone.id).first()
    if doublon:
        raise Invalide(f"La zone {doublon.code} existe déjà.")
    zone.etagere, zone.etage = etagere, etage
    zone.description = _texte(donnees, "description", "Description", longueur=160)


@bp.post("/zones")
@role_required("admin")
def creer_zone():
    zone = ZoneMagasin()
    try:
        _appliquer_zone(zone, request.get_json(silent=True) or {})
    except Invalide as e:
        return erreur(str(e), 400)
    db.session.add(zone)
    db.session.flush()
    journaliser("creation", zone, zone.code)
    db.session.commit()
    return jsonify(zone=zone.to_dict()), 201


@bp.put("/zones/<int:zone_id>")
@role_required("admin")
def modifier_zone(zone_id):
    zone = db.session.get(ZoneMagasin, zone_id)
    if not zone:
        return erreur("Zone introuvable.", 404)
    try:
        _appliquer_zone(zone, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    journaliser("modification", zone, zone.code)
    db.session.commit()
    return jsonify(zone=zone.to_dict())


@bp.delete("/zones/<int:zone_id>")
@role_required("admin")
def supprimer_zone(zone_id):
    zone = db.session.get(ZoneMagasin, zone_id)
    if not zone:
        return erreur("Zone introuvable.", 404)
    nb = zone.pieces.count()
    if nb:
        return erreur(f"La zone {zone.code} contient {nb} pièce(s) : déplacez-les d'abord.", 409)
    journaliser("suppression", zone, zone.code)
    db.session.delete(zone)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Panier ----------

@bp.get("/panier")
@role_required(*EQUIPE)
def panier():
    lignes = PanierLigne.query.order_by(PanierLigne.ajoute_le).all()
    return jsonify(lignes=[l.to_dict() for l in lignes])


@bp.post("/panier")
@role_required(*EQUIPE)
def ajouter_au_panier():
    """« Demander à commander » : ajoute la pièce au panier (ou augmente sa quantité)."""
    donnees = request.get_json(silent=True) or {}
    try:
        piece = db.session.get(Piece, int(donnees.get("piece_id")))
    except (TypeError, ValueError):
        piece = None
    if not piece:
        return erreur("Pièce introuvable.", 404)
    try:
        quantite = nombre(donnees.get("quantite"), "Quantité", mini=0.001) or piece.quantite_min_commande or 1
    except Invalide as e:
        return erreur(str(e), 400)
    ligne = PanierLigne.query.filter_by(piece_id=piece.id).first()
    if ligne:
        ligne.quantite += quantite
    else:
        ligne = PanierLigne(piece=piece, quantite=quantite, ajoute_par_id=current_user.id)
        db.session.add(ligne)
    db.session.commit()
    return jsonify(ligne=ligne.to_dict()), 201


@bp.post("/panier/libre")
@role_required(*EQUIPE)
def ajouter_article_libre():
    """Article hors magasin (ex. outillage, consommable ponctuel) : nom, quantité, prix HT, lien, fournisseur
    écrit à la main. Il partira dans le bon de commande « Divers » et n'entrera pas en stock."""
    donnees = request.get_json(silent=True) or {}
    designation = str(donnees.get("designation") or "").strip()
    fournisseur = str(donnees.get("fournisseur") or "").strip()
    lien = str(donnees.get("lien") or "").strip()
    if not designation:
        return erreur("Indiquez le nom de l'article.", 400)
    if not fournisseur:
        return erreur("Indiquez le fournisseur de l'article.", 400)
    if lien and not lien.lower().startswith(("http://", "https://")):
        lien = "https://" + lien
    try:
        quantite = nombre(donnees.get("quantite"), "Quantité", mini=0.001, obligatoire=True)
        prix = nombre(donnees.get("prix_unitaire"), "Prix unitaire HT")
    except Invalide as e:
        return erreur(str(e), 400)
    ligne = PanierLigne(
        designation=designation[:160], fournisseur_libre=fournisseur[:120], lien=lien[:500] or None,
        prix_unitaire=prix, quantite=quantite, ajoute_par_id=current_user.id,
    )
    db.session.add(ligne)
    db.session.commit()
    return jsonify(ligne=ligne.to_dict()), 201


@bp.put("/panier/<int:ligne_id>")
@role_required(*EQUIPE)
def modifier_panier(ligne_id):
    ligne = db.session.get(PanierLigne, ligne_id)
    if not ligne:
        return erreur("Ligne de panier introuvable.", 404)
    try:
        ligne.quantite = nombre((request.get_json(silent=True) or {}).get("quantite"), "Quantité", mini=0.001, obligatoire=True)
    except Invalide as e:
        return erreur(str(e), 400)
    db.session.commit()
    return jsonify(ligne=ligne.to_dict())


@bp.delete("/panier/<int:ligne_id>")
@role_required(*EQUIPE)
def retirer_du_panier(ligne_id):
    ligne = db.session.get(PanierLigne, ligne_id)
    if not ligne:
        return erreur("Ligne de panier introuvable.", 404)
    db.session.delete(ligne)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Commandes ----------

def _nouveau_numero_commande():
    prefixe = f"BC-{maintenant().year}-"
    dernier = Commande.query.filter(Commande.numero.like(f"{prefixe}%")).order_by(Commande.numero.desc()).first()
    suivant = int(dernier.numero.rsplit("-", 1)[1]) + 1 if dernier else 1
    return f"{prefixe}{suivant:03d}"


@bp.post("/commandes")
@role_required(*EQUIPE)
def creer_commandes():
    """Génère un bon de commande par fournisseur à partir des lignes du panier choisies, puis les retire du panier."""
    ids = (request.get_json(silent=True) or {}).get("lignes")
    if not isinstance(ids, list) or not ids:
        return erreur("Sélectionnez au moins une ligne du panier.", 400)
    lignes = PanierLigne.query.filter(PanierLigne.id.in_(ids)).all()
    if len(lignes) != len(set(ids)):
        return erreur("Le panier a changé : rechargez la page.", 409)
    sans_fournisseur = [l.piece.reference for l in lignes if l.piece and not l.piece.fournisseur_id]
    if sans_fournisseur:
        return erreur(f"Indiquez d'abord le fournisseur des pièces : {', '.join(sans_fournisseur)}.", 400)

    # Un bon par fournisseur ; les articles hors magasin vont tous dans un bon « Divers » (sans fournisseur)
    par_fournisseur = defaultdict(list)
    for l in lignes:
        par_fournisseur[l.piece.fournisseur_id if l.piece else None].append(l)
    commandes = []
    for fournisseur_id, groupe in par_fournisseur.items():
        commande = Commande(numero=_nouveau_numero_commande(), fournisseur_id=fournisseur_id, cree_par_id=current_user.id)
        for l in groupe:
            p = l.piece
            if p:
                ligne = CommandeLigne(
                    piece_id=p.id,
                    reference=p.reference,
                    reference_fournisseur=p.reference_fournisseur,
                    designation=p.designation,
                    lien_commande=p.lien_commande,
                    prix_unitaire=p.prix_unitaire,
                    quantite=l.quantite,
                )
            else:
                ligne = CommandeLigne(
                    designation=l.designation, lien_commande=l.lien, prix_unitaire=l.prix_unitaire,
                    quantite=l.quantite, fournisseur_libre=l.fournisseur_libre,
                )
            commande.lignes.append(ligne)
            db.session.delete(l)
        db.session.add(commande)
        db.session.flush()  # le numéro suivant tient compte de ce bon
        journaliser("creation", commande, commande.numero)
        commandes.append(commande)
    db.session.commit()
    return jsonify(commandes=[c.to_dict() for c in commandes]), 201


@bp.get("/commandes")
@role_required(*EQUIPE)
def liste_commandes():
    requete = Commande.query
    if request.args.get("statut") == "ouvertes":
        requete = requete.filter(Commande.statut.in_(("en_commande", "partielle")))
    commandes = requete.order_by(Commande.cree_le.desc()).limit(500).all()
    return jsonify(commandes=[c.to_dict() for c in commandes])


@bp.get("/commandes/<int:commande_id>")
@role_required(*EQUIPE)
def detail_commande(commande_id):
    commande = db.session.get(Commande, commande_id)
    if not commande:
        return erreur("Bon de commande introuvable.", 404)
    return jsonify(commande=commande.to_dict(details=True))


@bp.post("/commandes/<int:commande_id>/reception")
@role_required(*EQUIPE)
def receptionner(commande_id):
    """Contrôle à la réception (STK-09) : quantités reçues par ligne. Les manquants restent « en commande »."""
    commande = db.session.get(Commande, commande_id)
    if not commande:
        return erreur("Bon de commande introuvable.", 404)
    if commande.statut in ("recue", "annulee"):
        return erreur("Ce bon de commande est déjà soldé.", 409)
    recues = (request.get_json(silent=True) or {}).get("lignes")
    if not isinstance(recues, dict):
        return erreur("Quantités reçues invalides.", 400)
    lignes = {str(l.id): l for l in commande.lignes}
    try:
        for ligne_id, valeur in recues.items():
            ligne = lignes.get(str(ligne_id))
            if not ligne:
                raise Invalide("Ligne de commande inconnue.")
            quantite = nombre(valeur, f"Quantité reçue ({ligne.designation})")
            if not quantite:
                continue
            if quantite > ligne.quantite - ligne.quantite_recue + 1e-9:
                raise Invalide(f"{ligne.designation} : vous recevez plus que la quantité restant à recevoir.")
            ligne.quantite_recue += quantite
            if ligne.piece_id:  # un article hors magasin n'entre pas en stock (achat direct)
                mouvementer(db.session.get(Piece, ligne.piece_id), "entree", quantite, f"Réception {commande.numero}", commande=commande)
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    complete = all(l.quantite_recue >= l.quantite - 1e-9 for l in commande.lignes)
    commande.statut = "recue" if complete else ("partielle" if any(l.quantite_recue for l in commande.lignes) else "en_commande")
    if complete:
        commande.recue_le = maintenant()
    journaliser("reception", commande, commande.numero)
    db.session.commit()
    return jsonify(commande=commande.to_dict(details=True))


@bp.post("/commandes/<int:commande_id>/annuler")
@role_required("admin")
def annuler_commande(commande_id):
    commande = db.session.get(Commande, commande_id)
    if not commande:
        return erreur("Bon de commande introuvable.", 404)
    if commande.statut != "en_commande":
        return erreur("Seul un bon de commande sans aucune réception peut être annulé.", 409)
    commande.statut = "annulee"
    journaliser("annulation", commande, commande.numero)
    db.session.commit()
    return jsonify(commande=commande.to_dict(details=True))


@bp.delete("/commandes/<int:commande_id>")
@role_required("admin")
def supprimer_commande(commande_id):
    """Suppression d'un bon de commande par l'administrateur (erreur, doublon). Refusée si des articles ont déjà été
    reçus : les entrées en stock gardent la trace de leur bon de commande (historique)."""
    commande = db.session.get(Commande, commande_id)
    if not commande:
        return erreur("Bon de commande introuvable.", 404)
    if any(l.quantite_recue for l in commande.lignes) or Mouvement.query.filter_by(commande_id=commande.id).first():
        return erreur("Des articles de ce bon ont déjà été reçus : il ne peut plus être supprimé (historique du stock).", 409)
    journaliser("suppression", commande, f"{commande.numero} ({commande.fournisseur.nom if commande.fournisseur else 'Divers'})")
    db.session.delete(commande)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Exports pour Excel ----------

def _decimal(n):
    return "" if n is None else f"{n:.2f}".rstrip("0").rstrip(".").replace(".", ",")


def _csv(nom, entetes, lignes):
    sortie = io.StringIO()
    ecrivain = tableur.ecrivain(sortie)
    ecrivain.writerow(entetes)
    ecrivain.writerows(lignes)
    return Response(
        "﻿" + sortie.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename={nom}-{date.today():%Y-%m-%d}.csv"},
    )


@bp.get("/pieces/export.csv")
@role_required(*EQUIPE)
def export_pieces():
    pieces = _filtrer_pieces(Piece.query).order_by(Piece.reference).all()
    return _csv(
        "inventaire-magasin",
        ["Référence", "Désignation", "Catégorie", "Emplacement", "Quantité", "Stock de sécurité", "Qté min. commande",
         "Prix unitaire HT", "Valeur du stock HT", "Fournisseur", "Réf. fournisseur", "Machines"],
        [
            [p.reference, p.designation, p.categorie, p.zone.code if p.zone else "", _decimal(p.quantite), _decimal(p.stock_securite),
             _decimal(p.quantite_min_commande), _decimal(p.prix_unitaire),
             _decimal(p.quantite * p.prix_unitaire if p.prix_unitaire is not None else None),
             p.fournisseur.nom if p.fournisseur else "", p.reference_fournisseur or "",
             ", ".join(a.machine.repere for a in p.affectations)]
            for p in pieces
        ],
    )


@bp.get("/mouvements/export.csv")
@role_required(*EQUIPE)
def export_mouvements():
    mouvements = _filtrer_mouvements(Mouvement.query).order_by(Mouvement.date.desc()).all()
    types = {"entree": "Entrée", "sortie": "Sortie", "inventaire": "Inventaire"}
    return _csv(
        "mouvements-stock",
        ["Date", "Référence", "Désignation", "Type", "Variation", "Stock après", "Motif", "Intervention", "Commande", "Par"],
        [
            [format_paris(m.date), m.piece.reference, m.piece.designation, types.get(m.type, m.type), _decimal(m.quantite),
             _decimal(m.stock_apres), m.motif or "", m.bon.numero if m.bon else "", m.commande.numero if m.commande else "",
             m.utilisateur.nom if m.utilisateur else ""]
            for m in mouvements
        ],
    )
