"""Envoi d'e-mails par la messagerie de l'hébergeur (SMTP de cPanel), sans dépendance supplémentaire."""
import smtplib
from email.message import EmailMessage

from flask import current_app


def envoi_configure():
    return bool(current_app.config.get("MAIL_SERVER"))


def envoyer(destinataire, sujet, texte):
    config = current_app.config
    message = EmailMessage()
    message["From"] = config["MAIL_FROM"]
    message["To"] = destinataire
    message["Subject"] = sujet
    message.set_content(texte)
    port = config["MAIL_PORT"]
    # Port 465 : connexion chiffrée d'emblée ; 587 : chiffrement négocié (STARTTLS)
    if port == 465:
        serveur = smtplib.SMTP_SSL(config["MAIL_SERVER"], port, timeout=20)
    else:
        serveur = smtplib.SMTP(config["MAIL_SERVER"], port, timeout=20)
        serveur.starttls()
    with serveur:
        if config["MAIL_USERNAME"]:
            serveur.login(config["MAIL_USERNAME"], config["MAIL_PASSWORD"])
        serveur.send_message(message)
