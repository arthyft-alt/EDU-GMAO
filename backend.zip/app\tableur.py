"""Exports CSV pour Excel (séparateur « ; », virgule décimale, BOM UTF-8 ajouté par chaque route).

Protection contre les « formules piégées » : un texte saisi qui commence par =, +, - ou @ serait exécuté
par Excel comme une formule (ex. =LIEN_HYPERTEXTE(…)). On le fait précéder d'une apostrophe, qu'Excel
n'affiche pas. Les nombres négatifs (« -3 », « -1,5 ») restent des nombres.
"""
import csv
import re

DEBUTS_DANGEREUX = ("=", "+", "-", "@", "\t", "\r")
NOMBRE = re.compile(r"^-?\d+(,\d+)?$")


def cellule(valeur):
    if isinstance(valeur, str) and valeur.startswith(DEBUTS_DANGEREUX) and not NOMBRE.match(valeur):
        return "'" + valeur
    return valeur


class _Ecrivain:
    def __init__(self, sortie):
        self._csv = csv.writer(sortie, delimiter=";", lineterminator="\r\n")

    def writerow(self, ligne):
        self._csv.writerow([cellule(v) for v in ligne])

    def writerows(self, lignes):
        for ligne in lignes:
            self.writerow(ligne)


def ecrivain(sortie):
    """Comme csv.writer, réglé pour Excel et protégé contre les formules."""
    return _Ecrivain(sortie)
