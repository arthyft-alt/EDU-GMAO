"""Vacances : aucune échéance préventive n'y tombe, elles ne comptent pas dans les indicateurs."""
from datetime import date

import pytest

from app import db
from app.calendrier import jours_hors_vacances
from app.indicateurs import calcul
from app.models import Atelier, Machine, RealisationPreventive, SemaineCalendrier, TachePreventive
from app.preventif import echeances_entre, etat

TOUSSAINT = (date(2026, 10, 19), date(2026, 10, 26))


@pytest.fixture()
def vacances(app):
    db.session.add_all([SemaineCalendrier(lundi=l, type="vacances") for l in TOUSSAINT])
    db.session.add(SemaineCalendrier(lundi=date(2026, 11, 16), type="apprentissage"))  # pas des vacances
    db.session.commit()


@pytest.fixture()
def machine(app):
    m = Machine(repere="M-01", designation="Tour", atelier=Atelier.query.first(), utilisation_hebdo_h=10)
    db.session.add(m)
    db.session.commit()
    return m


def tache(machine, periodicite, debut):
    t = TachePreventive(machine=machine, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite=periodicite, date_debut=debut)
    db.session.add(t)
    db.session.commit()
    return t


def test_echeances_reportees_a_la_rentree_sans_doublon(vacances, machine):
    t = tache(machine, "semaine", date(2026, 10, 5))
    assert list(echeances_entre(t, date(2026, 10, 1), date(2026, 11, 22))) == [
        date(2026, 10, 5), date(2026, 10, 12), date(2026, 11, 2), date(2026, 11, 9), date(2026, 11, 16)
    ]  # les 2 semaines de vacances fusionnent dans le lundi de la rentrée ; l'apprentissage n'est pas concerné


def test_echeance_d_un_jour_de_vacances(vacances, machine):
    t = tache(machine, "mois", date(2026, 9, 22))  # le 22 octobre tombe pendant les vacances
    assert list(echeances_entre(t, date(2026, 10, 1), date(2026, 11, 30))) == [date(2026, 11, 2), date(2026, 11, 22)]


def test_etat_pendant_les_vacances(vacances, machine):
    t = tache(machine, "semaine", date(2026, 10, 5))
    e = etat(t, date(2026, 10, 27))
    assert (e["echeance_courante"], e["prochaine_echeance"]) == ("2026-10-12", "2026-11-02")
    # Le lundi de la rentrée, l'échéance reportée est à faire
    assert etat(t, date(2026, 11, 2))["statut"] == "a_faire"


def test_realisation_a_la_date_d_origine_vaut_pour_l_echeance_reportee(vacances, machine):
    t = tache(machine, "semaine", date(2026, 10, 5))
    db.session.add(RealisationPreventive(tache=t, echeance=date(2026, 10, 19)))
    db.session.commit()
    assert etat(t, date(2026, 11, 3))["statut"] == "fait"


def test_planning_sans_echeance_pendant_les_vacances(client, connecter, vacances, machine):
    tache(machine, "semaine", date(2026, 10, 5))
    connecter("tech")
    occurrences = client.get("/api/preventif/planning?du=2026-10-01&au=2026-11-10").get_json()["occurrences"]
    dates = [o["echeance"] for o in occurrences]
    assert dates == ["2026-10-05", "2026-10-12", "2026-11-02", "2026-11-09"]


def test_vacances_exclues_du_temps_de_fonctionnement(vacances, machine):
    du, au = date(2026, 10, 5), date(2026, 11, 2)  # 4 semaines dont 2 de vacances
    assert jours_hors_vacances(du, au) == 14
    assert calcul([machine], du, au)["heures_utilisation"] == 20  # 10 h × 2 semaines de cours


def test_performance_sur_la_derniere_semaine_de_cours(client, connecter, vacances, monkeypatch):
    monkeypatch.setattr("app.tableau_de_bord.aujourdhui", lambda: date(2026, 11, 4))
    connecter("admin")
    d = client.get("/api/tableau-de-bord").get_json()
    assert d["performance"]["lundi"] == "2026-10-12"  # les deux semaines de vacances sont sautées
    assert d["performance_avant"]["lundi"] == "2026-10-05"


def test_une_seule_echeance_par_semaine_au_retour_des_vacances(app, machine):
    db.session.add(SemaineCalendrier(lundi=date(2026, 11, 16), type="vacances"))
    db.session.commit()
    t = tache(machine, "semaine", date(2026, 11, 4))  # mercredis ; le 18 tombe pendant les vacances
    echeances = list(echeances_entre(t, date(2026, 11, 9), date(2026, 11, 29)))
    assert echeances == [date(2026, 11, 11), date(2026, 11, 25)]  # le 18 (reporté au 23) se confond avec le 25
    assert etat(t, date(2026, 11, 24))["echeance"] == "2026-11-25"
