import io
import json

import pytest

from app import db
from app.models import Atelier, Document, Element, Machine

PDF = b"%PDF-1.4\n1 0 obj << >> endobj\ntrailer << >>\n%%EOF"
CODE = {"X-Unlock-Password": "1234"}  # code du jour fixé par conftest


@pytest.fixture()
def machines(app):
    atelier = Atelier.query.filter_by(nom="01. Maintenance").one()
    tours = [Machine(repere=f"MAI-0{i}", designation=f"Tour {i}", atelier=atelier) for i in (1, 2, 3)]
    db.session.add_all(tours)
    db.session.commit()
    return tours


def element(nom="23 Convertir"):
    return Element.query.filter_by(nom=nom).one().id


def deposer(client, affectations, contenu=PDF, **champs):
    donnees = {
        "titre": "Notice du tour",
        "categorie": "Notice de maintenance",
        "affectations": json.dumps(affectations),
        "fichier": (io.BytesIO(contenu), "notice.pdf", "application/pdf"),
        **champs,
    }
    return client.post("/api/documents", data=donnees, content_type="multipart/form-data", headers=CODE)


def test_depot_pour_plusieurs_machines(client, connecter, machines, app):
    connecter("tech")
    reponse = deposer(client, [{"machine_id": m.id} for m in machines[:2]] + [{"machine_id": machines[2].id, "element_id": element()}])
    assert reponse.status_code == 201, reponse.get_json()
    doc = reponse.get_json()["document"]
    assert [a["machine_repere"] for a in doc["affectations"]] == ["MAI-01", "MAI-02", "MAI-03"]
    assert doc["affectations"][2]["element"] == "23 Convertir"
    assert doc["depose_par"] == "Technicien 1 (démo)" and doc["taille"] == len(PDF)
    # Lecture dans le navigateur (pas en pièce jointe)
    fichier = client.get(f"/api/documents/{doc['id']}/fichier")
    assert fichier.mimetype == "application/pdf" and fichier.data == PDF
    assert "attachment" not in fichier.headers.get("Content-Disposition", "")
    assert "attachment" in client.get(f"/api/documents/{doc['id']}/fichier?telecharger=1").headers["Content-Disposition"]


@pytest.mark.parametrize(
    "affectations,champs,contenu,message",
    [
        ([], {}, PDF, "au moins une machine"),
        ([{"machine_id": 999}], {}, PDF, "Machine"),
        ("doublon", {}, PDF, "deux fois"),
        ("ok", {"titre": ""}, PDF, "titre"),
        ("ok", {"categorie": "Recette"}, PDF, "catégorie"),
        ("ok", {}, b"\x89PNG image", "PDF"),
    ],
)
def test_depot_refuse(client, connecter, machines, affectations, champs, contenu, message):
    connecter("tech")
    if affectations == "ok":
        affectations = [{"machine_id": machines[0].id}]
    elif affectations == "doublon":
        affectations = [{"machine_id": machines[0].id}, {"machine_id": machines[0].id}]
    reponse = deposer(client, affectations, contenu, **champs)
    assert reponse.status_code == 400 and message in reponse.get_json()["error"]
    assert Document.query.count() == 0


def test_operateur_n_a_pas_acces(client, connecter, machines):
    connecter("tech")
    doc = deposer(client, [{"machine_id": machines[0].id}]).get_json()["document"]
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get("/api/documents").status_code == 403
    assert client.get(f"/api/documents/{doc['id']}/fichier").status_code == 403


def test_filtres(client, connecter, machines):
    connecter("tech")
    deposer(client, [{"machine_id": machines[0].id, "element_id": element()}])
    deposer(client, [{"machine_id": machines[1].id}], titre="Schéma armoire", categorie="Schéma électrique")
    titres = lambda url: [d["titre"] for d in client.get(url).get_json()["documents"]]
    assert titres(f"/api/documents?machine_id={machines[0].id}") == ["Notice du tour"]
    assert titres(f"/api/documents?machine_id={machines[0].id}&element_id={element()}") == ["Notice du tour"]
    assert titres(f"/api/documents?machine_id={machines[0].id}&element_id={element('21 Alimenter')}") == []
    assert titres("/api/documents?categorie=Schéma électrique") == ["Schéma armoire"]
    assert titres("/api/documents?q=armoire") == ["Schéma armoire"]
    assert len(titres(f"/api/documents?atelier_id={machines[0].atelier_id}")) == 2


def test_modification_et_nouvelle_version(client, connecter, machines, app):
    connecter("tech")
    doc = deposer(client, [{"machine_id": machines[0].id}]).get_json()["document"]
    modifie = client.put(f"/api/documents/{doc['id']}", json={"titre": "Notice v2", "categorie": "Notice d'utilisation", "affectations": [{"machine_id": machines[1].id}]}, headers=CODE)
    assert modifie.get_json()["document"]["affectations"][0]["machine_repere"] == "MAI-02"
    ancien = db.session.get(Document, doc["id"]).fichier
    nouveau_pdf = PDF + b"\n% version 2"
    reponse = client.post(f"/api/documents/{doc['id']}/fichier", data={"fichier": (io.BytesIO(nouveau_pdf), "v2.pdf", "application/pdf")}, content_type="multipart/form-data", headers=CODE)
    assert reponse.status_code == 200
    assert client.get(f"/api/documents/{doc['id']}/fichier").data == nouveau_pdf
    assert not (app.config["UPLOAD_DIR"] / "documents" / ancien).exists()


def test_suppression_admin_seulement(client, connecter, machines, app):
    connecter("tech")
    doc = deposer(client, [{"machine_id": machines[0].id}]).get_json()["document"]
    assert client.delete(f"/api/documents/{doc['id']}").status_code == 403
    fichier = app.config["UPLOAD_DIR"] / "documents" / db.session.get(Document, doc["id"]).fichier
    client.post("/api/auth/logout")
    connecter("admin")
    assert client.delete(f"/api/documents/{doc['id']}").status_code == 200
    assert not fichier.exists()


def test_element_et_machine(client, connecter, machines):
    connecter("admin")
    doc = deposer(client, [{"machine_id": machines[0].id, "element_id": element()}, {"machine_id": machines[1].id}]).get_json()["document"]
    assert client.delete(f"/api/admin/elements/{element()}").status_code == 409
    # Supprimer une machine retire seulement son rattachement : le document reste pour les autres
    assert client.delete(f"/api/machines/{machines[1].id}").status_code == 200
    assert [a["machine_repere"] for a in client.get(f"/api/documents/{doc['id']}").get_json()["document"]["affectations"]] == ["MAI-01"]


def test_eleve_sans_code_du_jour_refuse(client, connecter, machines):
    connecter("tech")
    donnees = {"titre": "Notice", "categorie": "Notice d'utilisation", "affectations": "[]", "fichier": (io.BytesIO(PDF), "n.pdf", "application/pdf")}
    reponse = client.post("/api/documents", data=donnees, content_type="multipart/form-data")
    assert reponse.status_code == 403 and "Code du jour" in reponse.get_json()["error"]
