"""Chantiers et To-Do (CHA-01, CHA-02) : tâches libres créées et attribuées par les enseignants.
Mode « équipe » : une seule tâche pour le groupe. Mode « individuel » : chaque élève la termine de son côté."""
from datetime import date

from flask import Blueprint, jsonify, request
from flask_login import current_user

from . import db
from .auth import erreur, role_required
from .models import Chantier, ChantierAffectation, ChantierType, Machine, Utilisateur, journaliser, maintenant

bp = Blueprint("chantiers", __name__)

EQUIPE = ("admin", "technicien")
TYPES = {"amelioration": "Amélioration", "organisation": "Organisation / rangement", "autre": "Autre"}
STATUTS = {"a_faire": "À faire", "en_cours": "En cours", "termine": "Terminé"}


class Invalide(Exception):
    pass


def _chantier_ou_404(chantier_id):
    chantier = db.session.get(Chantier, chantier_id)
    if not chantier:
        return None, erreur("Chantier introuvable.", 404)
    return chantier, None


def _appliquer(chantier, donnees):
    titre = str(donnees.get("titre") or "").strip()
    if not titre:
        raise Invalide("Le titre est obligatoire.")
    if donnees.get("type", "amelioration") not in TYPES:
        raise Invalide("Type de chantier inconnu.")
    if donnees.get("mode", "equipe") not in ("equipe", "individuel"):
        raise Invalide("Mode inconnu (équipe ou individuel).")
    machine = None
    if donnees.get("machine_id") not in (None, ""):
        try:
            machine = db.session.get(Machine, int(donnees["machine_id"]))
        except (TypeError, ValueError):
            machine = None
        if not machine:
            raise Invalide("Machine introuvable.")
    duree = donnees.get("duree_estimee_h")
    try:
        duree = float(str(duree).replace(",", ".")) if duree not in (None, "") else None
    except ValueError:
        raise Invalide("La durée estimée est un nombre d'heures.")
    if duree is not None and not 0 < duree <= 1000:
        raise Invalide("La durée estimée doit être comprise entre 0 et 1000 heures.")
    try:
        echeance = date.fromisoformat(str(donnees["echeance"])) if donnees.get("echeance") else None
    except ValueError:
        raise Invalide("Date d'échéance invalide.")
    chantier.titre = titre[:160]
    chantier.description = str(donnees.get("description") or "").strip() or None
    chantier.type = donnees.get("type", "amelioration")
    chantier.mode = donnees.get("mode", "equipe")
    chantier.machine = machine
    chantier.duree_estimee_h = duree
    chantier.echeance = echeance


def _techniciens(ids):
    if not isinstance(ids, list) or not all(isinstance(i, int) for i in ids):
        raise Invalide("Liste d'élèves invalide.")
    techniciens = Utilisateur.query.filter(Utilisateur.id.in_(ids), Utilisateur.role == "technicien", Utilisateur.actif.is_(True)).all()
    if len(techniciens) != len(set(ids)):
        raise Invalide("Un des élèves choisis n'existe pas ou n'est plus actif.")
    return techniciens


def _mettre_a_jour_statut(chantier):
    """Mode individuel : le chantier est terminé quand chaque élève a terminé sa part."""
    if chantier.mode == "individuel" and chantier.affectations:
        if all(a.termine_le for a in chantier.affectations):
            chantier.statut, chantier.termine_le = "termine", chantier.termine_le or maintenant()
        elif chantier.statut == "termine":
            chantier.statut, chantier.termine_le = "en_cours", None


@bp.get("/chantiers")
@role_required(*EQUIPE)
def liste_chantiers():
    requete = Chantier.query
    if request.args.get("ouverts") == "1":
        requete = requete.filter(Chantier.statut != "termine")
    technicien = request.args.get("technicien_id", type=int)
    if technicien:
        requete = requete.filter(Chantier.affectations.any(ChantierAffectation.utilisateur_id == technicien))
    chantiers = requete.order_by(Chantier.statut == "termine", Chantier.echeance.is_(None), Chantier.echeance, Chantier.cree_le).all()
    return jsonify(chantiers=[c.to_dict() for c in chantiers], types=TYPES, statuts=STATUTS)


@bp.post("/chantiers")
@role_required("admin")
def creer_chantier():
    donnees = request.get_json(silent=True) or {}
    chantier = Chantier(cree_par_id=current_user.id)
    try:
        _appliquer(chantier, donnees)
        techniciens = _techniciens(donnees.get("ids") or [])
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    chantier.affectations = [ChantierAffectation(utilisateur=t) for t in techniciens]
    db.session.add(chantier)
    db.session.flush()
    journaliser("creation", chantier, chantier.titre)
    db.session.commit()
    return jsonify(chantier=chantier.to_dict()), 201


@bp.post("/chantiers/postit")
@role_required(*EQUIPE)
def creer_postit():
    """Post-it de la réunion AIC (étape sécurité ou répartition) : chantier « Autre », écrit aussi par un élève,
    confié à un élève ou laissé « à attribuer »."""
    donnees = request.get_json(silent=True) or {}
    titre = str(donnees.get("titre") or "").strip()
    if not titre:
        return erreur("Écrivez le post-it.", 400)
    chantier = Chantier(cree_par_id=current_user.id, titre=titre[:160], type="autre", mode="equipe")
    try:
        techniciens = _techniciens(donnees.get("ids") or [])
    except Invalide as e:
        return erreur(str(e), 400)
    chantier.affectations = [ChantierAffectation(utilisateur=t) for t in techniciens]
    db.session.add(chantier)
    db.session.flush()
    journaliser("creation", chantier, f"Post-it : {chantier.titre}")
    db.session.commit()
    return jsonify(chantier=chantier.to_dict()), 201


@bp.put("/chantiers/<int:chantier_id>")
@role_required("admin")
def modifier_chantier(chantier_id):
    chantier, err = _chantier_ou_404(chantier_id)
    if err:
        return err
    try:
        _appliquer(chantier, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    _mettre_a_jour_statut(chantier)
    journaliser("modification", chantier, chantier.titre)
    db.session.commit()
    return jsonify(chantier=chantier.to_dict())


@bp.put("/chantiers/<int:chantier_id>/techniciens")
@role_required(*EQUIPE)
def affecter_chantier(chantier_id):
    """Élèves du chantier (glisser-déposer dans la répartition), par un enseignant ou un élève (choix de Simon).
    Les parts déjà terminées sont conservées."""
    chantier, err = _chantier_ou_404(chantier_id)
    if err:
        return err
    try:
        techniciens = _techniciens((request.get_json(silent=True) or {}).get("ids"))
    except Invalide as e:
        return erreur(str(e), 400)
    existantes = {a.utilisateur_id: a for a in chantier.affectations}
    chantier.affectations = [existantes.get(t.id) or ChantierAffectation(utilisateur=t) for t in techniciens]
    _mettre_a_jour_statut(chantier)
    journaliser("affectation", chantier, ", ".join(t.nom for t in techniciens) or "aucun élève")
    db.session.commit()
    return jsonify(chantier=chantier.to_dict())


@bp.post("/chantiers/<int:chantier_id>/statut")
@role_required(*EQUIPE)
def changer_statut(chantier_id):
    """Avancement : un élève fait avancer les chantiers qui lui sont confiés ; l'enseignant, tous."""
    chantier, err = _chantier_ou_404(chantier_id)
    if err:
        return err
    statut = (request.get_json(silent=True) or {}).get("statut")
    if statut not in STATUTS:
        return erreur("Statut inconnu.", 400)
    admin = current_user.role == "admin"
    mienne = next((a for a in chantier.affectations if a.utilisateur_id == current_user.id), None)
    if not admin and not mienne:
        return erreur("Ce chantier ne vous est pas confié.", 403)
    if chantier.mode == "individuel" and not admin:
        # L'élève termine (ou reprend) sa propre part
        mienne.termine_le = maintenant() if statut == "termine" else None
        if statut != "a_faire" and chantier.statut == "a_faire":
            chantier.statut = "en_cours"
        _mettre_a_jour_statut(chantier)
    else:
        chantier.statut = statut
        chantier.termine_le = maintenant() if statut == "termine" else None
        for a in chantier.affectations:
            a.termine_le = chantier.termine_le if statut == "termine" else None
    journaliser("statut", chantier, f"{chantier.titre} : {STATUTS[statut]}")
    db.session.commit()
    return jsonify(chantier=chantier.to_dict())


@bp.delete("/chantiers/<int:chantier_id>")
@role_required("admin")
def supprimer_chantier(chantier_id):
    chantier, err = _chantier_ou_404(chantier_id)
    if err:
        return err
    journaliser("suppression", chantier, chantier.titre)
    db.session.delete(chantier)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Chantiers types (modèles créés par l'administrateur) ----------

@bp.get("/chantiers/types")
@role_required(*EQUIPE)
def liste_types():
    return jsonify(types=[t.to_dict() for t in ChantierType.query.order_by(ChantierType.titre)])


def _appliquer_type(modele, donnees):
    temporaire = Chantier()
    _appliquer(temporaire, {**donnees, "machine_id": None, "echeance": None})  # mêmes contrôles qu'un chantier
    modele.titre = temporaire.titre
    modele.description = temporaire.description
    modele.type = temporaire.type
    modele.mode = temporaire.mode
    modele.duree_estimee_h = temporaire.duree_estimee_h


@bp.post("/chantiers/types")
@role_required("admin")
def creer_type():
    modele = ChantierType()
    try:
        _appliquer_type(modele, request.get_json(silent=True) or {})
    except Invalide as e:
        return erreur(str(e), 400)
    db.session.add(modele)
    db.session.flush()
    journaliser("creation", modele, modele.titre)
    db.session.commit()
    return jsonify(type=modele.to_dict()), 201


@bp.put("/chantiers/types/<int:type_id>")
@role_required("admin")
def modifier_type(type_id):
    modele = db.session.get(ChantierType, type_id)
    if not modele:
        return erreur("Chantier type introuvable.", 404)
    try:
        _appliquer_type(modele, request.get_json(silent=True) or {})
    except Invalide as e:
        return erreur(str(e), 400)
    journaliser("modification", modele, modele.titre)
    db.session.commit()
    return jsonify(type=modele.to_dict())


@bp.delete("/chantiers/types/<int:type_id>")
@role_required("admin")
def supprimer_type(type_id):
    modele = db.session.get(ChantierType, type_id)
    if not modele:
        return erreur("Chantier type introuvable.", 404)
    journaliser("suppression", modele, modele.titre)
    db.session.delete(modele)
    db.session.commit()
    return jsonify(ok=True)
