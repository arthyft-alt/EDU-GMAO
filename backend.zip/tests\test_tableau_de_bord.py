from datetime import date, timedelta

import pytest

from app import db
from app.models import Atelier, BonIntervention, Commande, Fournisseur, Machine, Piece, TachePreventive, Utilisateur


@pytest.fixture()
def atelier_rempli(app):
    atelier = Atelier.query.first()
    m1 = Machine(repere="M-01", designation="Tour", atelier=atelier)
    m2 = Machine(repere="M-02", designation="Fraiseuse", atelier=atelier)
    tech = Utilisateur.query.filter_by(login="tech").one()
    fournisseur = Fournisseur(nom="Brico Pro")
    db.session.add_all([m1, m2])
    db.session.flush()
    db.session.add_all(
        [
            BonIntervention(numero="BI-1", machine=m1, type_travail="depannage", urgence="critique", demandeur="x", description="x", machine_arretee=True),
            BonIntervention(numero="BI-2", machine=m1, type_travail="depannage", urgence="normale", demandeur="x", description="x", statut="a_cloturer"),
            BonIntervention(numero="BI-3", machine=m2, type_travail="autre", urgence="normale", demandeur="x", description="x", statut="termine"),
            Piece(reference="P-1", designation="Courroie", categorie="Mécanique", quantite=1, stock_securite=2),
            Piece(reference="P-2", designation="Vis", categorie="Mécanique", quantite=50, stock_securite=10),
            Commande(numero="BC-1", statut="en_commande", cree_par=tech, fournisseur=fournisseur),
            Commande(numero="BC-2", statut="recue", cree_par=tech, fournisseur=fournisseur),
            # Échéance d'une semaine passée, la suivante dans un mois : en retard quel que soit le jour du test
            TachePreventive(machine=m2, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite="mois",
                            date_debut=date.today() - timedelta(days=date.today().weekday() + 7)),
        ]
    )
    db.session.commit()


def test_chiffres_cles(client, connecter, atelier_rempli):
    connecter("admin")
    c = client.get("/api/tableau-de-bord").get_json()["chiffres"]
    assert c["bons_ouverts"] == 2 and c["bons_critiques"] == 1 and c["bons_a_cloturer"] == 1
    assert c["machines_arretees"] == 1 and c["pieces_sous_seuil"] == 1 and c["commandes_en_attente"] == 1
    assert c["preventif_en_retard"] == 1


@pytest.mark.parametrize("login", ["tech", "operateur"])
def test_chiffres_cles_reserves_a_l_admin(client, connecter, login):
    connecter(login)
    assert client.get("/api/tableau-de-bord").status_code == 403


def test_taux_de_performance_du_preventif(app):
    from app.models import RealisationPreventive
    from app.tableau_de_bord import taux_performance

    lundi = date(2026, 10, 5)
    machine = Machine(repere="M-09", designation="Presse", atelier=Atelier.query.first())
    hebdo = TachePreventive(machine=machine, nom="Nettoyage", niveau=1, type_preventif="Nettoyage", periodicite="semaine", date_debut=lundi)
    autre = TachePreventive(machine=machine, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite="semaine", date_debut=lundi + timedelta(days=2))
    mensuelle = TachePreventive(machine=machine, nom="Contrôle", niveau=3, type_preventif="Inspection", periodicite="mois", date_debut=lundi + timedelta(days=20))
    db.session.add_all([machine, hebdo, autre, mensuelle, RealisationPreventive(tache=hebdo, echeance=lundi)])
    db.session.commit()

    semaine = taux_performance(lundi)
    assert (semaine["prevues"], semaine["realisees"], semaine["taux"]) == (2, 1, 50)
    assert semaine["pastille"] == "danger" and semaine["numero"] == 41
    assert taux_performance(lundi - timedelta(days=7))["taux"] is None  # rien de prévu : pas de taux


def test_tableau_de_bord_renvoie_la_performance(client, connecter):
    connecter("admin")
    d = client.get("/api/tableau-de-bord").get_json()
    assert set(d) == {"chiffres", "performance", "performance_avant"}
    assert d["performance_avant"]["lundi"] < d["performance"]["lundi"]


def test_taux_de_performance_compte_tous_les_post_it(app):
    from datetime import datetime

    from app.models import Chantier, Projet, TacheProjet
    from app.tableau_de_bord import taux_performance

    lundi = date(2026, 10, 5)
    pendant = datetime(2026, 10, 7, 10)  # mercredi de la semaine (UTC)
    avant, apres = datetime(2026, 9, 28, 10), datetime(2026, 10, 14, 10)
    machine = Machine(repere="M-10", designation="Scie", atelier=Atelier.query.first())
    bon = dict(machine=machine, type_travail="depannage", demandeur="x", description="x")
    projet = Projet(nom="Projet", date_debut=lundi)
    db.session.add_all(
        [
            machine,
            BonIntervention(numero="BI-10", cree_le=avant, termine_le=pendant, statut="termine", **bon),  # fait
            BonIntervention(numero="BI-11", cree_le=pendant, **bon),  # à faire, pas fait
            BonIntervention(numero="BI-12", cree_le=avant, termine_le=avant, statut="termine", **bon),  # fini avant : ignoré
            BonIntervention(numero="BI-13", cree_le=apres, **bon),  # créé après : ignoré
            Chantier(titre="Rangement", cree_le=avant, termine_le=pendant, statut="termine"),  # fait
            projet,
            TacheProjet(projet=projet, nom="Inventaire", duree_semaines=1, statut="termine", termine_le=pendant),  # fait
            TacheProjet(projet=projet, nom="Étiquetage", duree_semaines=1, debut_au_plus_tot=lundi + timedelta(days=14)),  # plus tard
        ]
    )
    db.session.commit()

    d = taux_performance(lundi)
    assert d["detail"]["interventions"] == {"prevues": 2, "realisees": 1}
    assert d["detail"]["chantiers"] == {"prevues": 1, "realisees": 1}
    assert d["detail"]["projet"] == {"prevues": 1, "realisees": 1}
    assert (d["prevues"], d["realisees"], d["taux"]) == (4, 3, 75)
