"""Connexion des utilisateurs et contrôle des droits."""
import json
import secrets
from datetime import datetime, timedelta
from functools import wraps

from flask import Blueprint, current_app, jsonify, request
from flask_login import current_user, login_required, login_user, logout_user
from itsdangerous import BadSignature, URLSafeTimedSerializer

from . import db
from .models import Parametre, Utilisateur, journaliser, maintenant
from .referentiels import ROLES, VERROUS

bp = Blueprint("auth", __name__, url_prefix="/auth")


def erreur(message, code):
    return jsonify({"error": message}), code


# ---------- Contrôle des droits ----------

def role_required(*roles):
    """Réserve une route aux profils indiqués, ex. @role_required("admin", "technicien")."""

    def decorateur(vue):
        @wraps(vue)
        @login_required
        def enveloppe(*args, **kwargs):
            if current_user.role not in roles:
                return erreur("Vous n'avez pas les droits pour cette action.", 403)
            return vue(*args, **kwargs)

        return enveloppe

    return decorateur


CLE_CODE_DU_JOUR = "code_du_jour"
MESSAGE_CODE = "Code du jour manquant ou incorrect : demandez-le à un enseignant."


def code_du_jour(renouveler=False):
    """Code à 4 chiffres qui déverrouille les actions sensibles (annexe B : gestion des machines, calcul
    des indicateurs). Un nouveau code est tiré au sort chaque jour (heure de Paris), ou à la demande de
    l'enseignant ; l'ancien ne fonctionne plus. Il est stocké en clair : l'enseignant doit pouvoir le lire."""
    from .preventif import aujourdhui

    jour = aujourdhui().isoformat()
    param = db.session.get(Parametre, CLE_CODE_DU_JOUR)
    try:
        actuel = json.loads(param.valeur) if param and param.valeur else {}
    except ValueError:
        actuel = {}
    if renouveler or actuel.get("jour") != jour or not actuel.get("code"):
        nouveau = actuel.get("code")
        while nouveau == actuel.get("code"):  # jamais deux fois le même code de suite
            nouveau = f"{secrets.randbelow(10000):04d}"
        actuel = {"jour": jour, "code": nouveau}
        param = param or Parametre(cle=CLE_CODE_DU_JOUR)
        param.valeur = json.dumps(actuel)
        db.session.add(param)
        db.session.commit()
    return actuel["code"]


def verifier_code_du_jour(code):
    code = (code or "").strip()
    return bool(code) and secrets.compare_digest(code, code_du_jour())


# ---------- Limitation des essais (code du jour à 4 chiffres, mots de passe) ----------
# Sans limite, un élève pourrait essayer les 10 000 codes en quelques minutes.
# Les compteurs sont gardés en base (Passenger peut lancer plusieurs processus).

ESSAIS_CODE_SUITE, BLOCAGE_CODE_MIN, ESSAIS_CODE_JOUR = 5, 15, 15
ESSAIS_CONNEXION, BLOCAGE_CONNEXION_MIN = 10, 5


def _lire_essais(cle):
    param = db.session.get(Parametre, cle)
    try:
        return json.loads(param.valeur) if param and param.valeur else {}
    except ValueError:
        return {}


def _ecrire_essais(cle, valeurs):
    param = db.session.get(Parametre, cle) or Parametre(cle=cle)
    param.valeur = json.dumps(valeurs) if valeurs else ""
    db.session.add(param)


def _minutes_de_blocage(essais):
    jusqua = essais.get("jusqua")
    if not jusqua or jusqua <= maintenant().isoformat():
        return 0
    return max(1, round((datetime.fromisoformat(jusqua) - maintenant()).total_seconds() / 60))


def _cle_code():
    return f"essais_code_{current_user.id}"


def controler_code_du_jour(code):
    """Message d'erreur (code faux, ou trop d'essais) ; None si le code est bon. Enregistre l'essai."""
    from .preventif import aujourdhui

    cle, jour = _cle_code(), aujourdhui().isoformat()
    essais = _lire_essais(cle)
    if essais.get("jour") != jour:
        essais = {"jour": jour, "jour_n": 0, "suite": 0}
    if essais["jour_n"] >= ESSAIS_CODE_JOUR:
        return "Trop de codes faux aujourd'hui : demandez à un enseignant de faire l'action, ou réessayez demain."
    attente = _minutes_de_blocage(essais)
    if attente:
        return f"Trop de codes faux : réessayez dans {attente} min ou demandez le code à un enseignant."
    if verifier_code_du_jour(code):
        if essais.get("suite"):
            _ecrire_essais(cle, {**essais, "suite": 0, "jusqua": None})
            db.session.commit()
        return None
    essais["jour_n"] += 1
    essais["suite"] += 1
    if essais["suite"] >= ESSAIS_CODE_SUITE:
        essais["suite"] = 0
        essais["jusqua"] = (maintenant() + timedelta(minutes=BLOCAGE_CODE_MIN)).isoformat()
        journaliser("blocage_code_du_jour", current_user, f"{ESSAIS_CODE_SUITE} codes du jour faux de suite")
    _ecrire_essais(cle, essais)
    db.session.commit()
    return MESSAGE_CODE


def unlock_required(verrou):
    """Action sensible protégée par le code du jour (annexe B), transmis dans l'en-tête X-Unlock-Password.
    L'administrateur en est dispensé. « verrou » indique l'action protégée (machines, indicateurs)."""

    def decorateur(vue):
        @wraps(vue)
        @login_required
        def enveloppe(*args, **kwargs):
            if current_user.role != "admin":
                probleme = controler_code_du_jour(request.headers.get("X-Unlock-Password", ""))
                if probleme:
                    return erreur(probleme, 403)
            return vue(*args, **kwargs)

        return enveloppe

    return decorateur


# ---------- Routes ----------

@bp.post("/login")
def login():
    donnees = request.get_json(silent=True) or {}
    identifiant = (donnees.get("login") or "").strip().lower()
    mot_de_passe = donnees.get("password") or ""
    if not identifiant or not mot_de_passe:
        return erreur("Indiquez votre identifiant et votre mot de passe.", 400)

    cle = f"essais_connexion_{identifiant[:40]}"
    essais = _lire_essais(cle)
    attente = _minutes_de_blocage(essais)
    if attente:
        return erreur(f"Trop d'essais pour cet identifiant : réessayez dans {attente} min.", 429)
    utilisateur = Utilisateur.query.filter_by(login=identifiant).first()
    if not utilisateur or not utilisateur.verifier_mot_de_passe(mot_de_passe):
        n = essais.get("n", 0) + 1
        if n >= ESSAIS_CONNEXION:
            essais = {"n": 0, "jusqua": (maintenant() + timedelta(minutes=BLOCAGE_CONNEXION_MIN)).isoformat()}
        else:
            essais = {"n": n}
        _ecrire_essais(cle, essais)
        db.session.commit()
        return erreur("Identifiant ou mot de passe incorrect.", 401)
    if essais:
        _ecrire_essais(cle, {})
    if not utilisateur.actif:
        return erreur("Ce compte est désactivé. Adressez-vous à un enseignant.", 403)

    login_user(utilisateur, remember=bool(donnees.get("remember")))
    journaliser("connexion", utilisateur, utilisateur=utilisateur)
    db.session.commit()
    return jsonify(utilisateur=_moi())


@bp.post("/qr")
def login_qr():
    """Connexion du compte opérateur en scannant son QR code (Administration › Paramètres).
    Le téléphone reste connecté (cookie « se souvenir de moi »)."""
    jeton = str((request.get_json(silent=True) or {}).get("jeton") or "")
    trouve = None
    if jeton:
        for param in Parametre.query.filter(Parametre.cle.like("qr_operateur_%")):
            if param.valeur and secrets.compare_digest(param.valeur, jeton):
                trouve = db.session.get(Utilisateur, int(param.cle.rsplit("_", 1)[1]))
    if not trouve or trouve.role != "operateur":
        return erreur("Ce QR code n'est plus valable. Demandez le nouveau à un enseignant.", 401)
    if not trouve.actif:
        return erreur("Ce compte est désactivé. Adressez-vous à un enseignant.", 403)
    login_user(trouve, remember=True)
    journaliser("connexion", trouve, "Connexion par QR code", utilisateur=trouve)
    db.session.commit()
    return jsonify(utilisateur=_moi())


@bp.post("/logout")
def logout():
    logout_user()
    return jsonify(ok=True)


@bp.get("/me")
def me():
    if not current_user.is_authenticated:
        return jsonify(utilisateur=None)
    return jsonify(utilisateur=_moi())


def _moi():
    from .reglages import longueur_min_mot_de_passe

    return {**current_user.to_dict(), "email": current_user.email, "mdp_min": longueur_min_mot_de_passe(current_user.role)}


@bp.post("/verifier-verrou/<verrou>")
@login_required
def verifier_verrou(verrou):
    """Permet à l'écran de vérifier le code du jour avant d'afficher un formulaire ou le calcul automatique."""
    if verrou not in VERROUS:
        return erreur("Verrou inconnu.", 404)
    if current_user.role == "admin":
        return jsonify(ok=True)
    probleme = controler_code_du_jour((request.get_json(silent=True) or {}).get("password", ""))
    if probleme:
        return erreur("Code du jour incorrect : demandez-le à un enseignant." if probleme == MESSAGE_CODE else probleme, 403)
    return jsonify(ok=True)


@bp.get("/roles")
def roles():
    return jsonify(roles=ROLES)


# ---------- Mon compte ----------

@bp.put("/mot-de-passe")
@login_required
def changer_mon_mot_de_passe():
    """Chacun change son propre mot de passe, en redonnant l'ancien.
    Le compte opérateur est partagé : seul l'administrateur le modifie."""
    from .reglages import controler_mot_de_passe

    if current_user.role == "operateur":
        return erreur("Le compte opérateur est partagé : seul un enseignant peut changer son mot de passe.", 403)
    donnees = request.get_json(silent=True) or {}
    if not current_user.verifier_mot_de_passe(donnees.get("ancien") or ""):
        return erreur("Le mot de passe actuel est incorrect.", 400)
    nouveau = donnees.get("nouveau") or ""
    probleme = controler_mot_de_passe(nouveau, current_user.role)
    if probleme:
        return erreur(probleme, 400)
    current_user.definir_mot_de_passe(nouveau)
    journaliser("modification", current_user, "Mot de passe changé par l'utilisateur")
    db.session.commit()
    # Les autres appareils sont déconnectés ; celui-ci reste connecté avec la nouvelle empreinte
    se_souvenir = request.cookies.get(current_app.config.get("REMEMBER_COOKIE_NAME", "remember_token")) is not None
    login_user(current_user._get_current_object(), remember=se_souvenir)
    return jsonify(ok=True)


@bp.put("/email")
@role_required("admin")
def changer_mon_email():
    from .admin import verifier_email

    email, probleme = verifier_email((request.get_json(silent=True) or {}).get("email"), current_user)
    if probleme:
        return erreur(probleme, 400)
    current_user.email = email
    journaliser("modification", current_user, "Adresse e-mail modifiée")
    db.session.commit()
    return jsonify(utilisateur=_moi())


# ---------- Mot de passe oublié (administrateurs) ----------

DUREE_LIEN = 3600  # le lien reçu par e-mail est valable une heure


def _signeur():
    return URLSafeTimedSerializer(current_app.config["SECRET_KEY"], salt="mot-de-passe-oublie")


def _empreinte(utilisateur):
    # Le lien n'est plus valable dès que le mot de passe a changé : il ne sert qu'une fois
    return utilisateur.mot_de_passe_hash[-16:]


@bp.post("/mot-de-passe-oublie")
def mot_de_passe_oublie():
    from .courriel import envoi_configure, envoyer
    from .reglages import reglage

    if not envoi_configure():
        return erreur(
            "L'envoi d'e-mails n'est pas encore configuré sur ce serveur. "
            "Demandez à un autre administrateur de changer votre mot de passe.",
            503,
        )
    email = str((request.get_json(silent=True) or {}).get("email") or "").strip().lower()
    message = "Si cette adresse correspond à un compte administrateur, un e-mail vient d'être envoyé. Pensez à regarder les courriers indésirables."
    admin = Utilisateur.query.filter_by(email=email, role="admin", actif=True).first() if email else None
    if not admin:
        return jsonify(message=message)

    # Un seul envoi toutes les 2 minutes par compte, pour éviter d'inonder la boîte mail
    cle = f"dernier_mail_mdp_{admin.id}"
    dernier = db.session.get(Parametre, cle)
    if dernier and dernier.valeur and maintenant().isoformat() < dernier.valeur:
        return jsonify(message=message)

    jeton = _signeur().dumps({"id": admin.id, "e": _empreinte(admin)})
    base = (current_app.config.get("PUBLIC_URL") or request.host_url).rstrip("/")
    nom_application = reglage("nom_application")
    try:
        envoyer(
            admin.email,
            f"{nom_application} : nouveau mot de passe",
            f"Bonjour {admin.nom},\n\n"
            f"Pour choisir un nouveau mot de passe sur {nom_application}, ouvrez ce lien (valable une heure) :\n\n"
            f"{base}/?reinitialiser={jeton}\n\n"
            "Si vous n'avez rien demandé, ignorez ce message : votre mot de passe reste inchangé.\n",
        )
    except Exception as e:  # serveur de messagerie injoignable, identifiants faux…
        current_app.logger.exception(e)
        return erreur("L'e-mail n'a pas pu être envoyé. Réessayez plus tard ou demandez à un autre administrateur.", 502)
    dernier = dernier or Parametre(cle=cle)
    dernier.valeur = (maintenant() + timedelta(minutes=2)).isoformat()
    db.session.add(dernier)
    journaliser("mot_de_passe_oublie", admin, "Lien de réinitialisation envoyé par e-mail", utilisateur=admin)
    db.session.commit()
    return jsonify(message=message)


@bp.post("/reinitialiser")
def reinitialiser():
    from .reglages import controler_mot_de_passe

    donnees = request.get_json(silent=True) or {}
    try:
        contenu = _signeur().loads(str(donnees.get("jeton") or ""), max_age=DUREE_LIEN)
    except BadSignature:
        return erreur("Ce lien n'est plus valable (il expire au bout d'une heure). Refaites une demande.", 400)
    admin = db.session.get(Utilisateur, contenu.get("id") or 0)
    if not admin or not admin.actif or admin.role != "admin" or _empreinte(admin) != contenu.get("e"):
        return erreur("Ce lien a déjà servi ou n'est plus valable. Refaites une demande.", 400)
    nouveau = donnees.get("password") or ""
    probleme = controler_mot_de_passe(nouveau, admin.role)
    if probleme:
        return erreur(probleme, 400)
    admin.definir_mot_de_passe(nouveau)
    journaliser("modification", admin, "Mot de passe réinitialisé par lien e-mail", utilisateur=admin)
    db.session.commit()
    return jsonify(ok=True)
