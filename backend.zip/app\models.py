"""Tables de la base de données."""
from datetime import datetime, timezone

from flask_login import UserMixin
from werkzeug.security import check_password_hash, generate_password_hash

from . import db

# pbkdf2 plutôt que scrypt : scrypt dépend de l'OpenSSL du serveur mutualisé
METHODE_HACHAGE = "pbkdf2:sha256"


def maintenant():
    """Date et heure actuelles en UTC, sans fuseau (SQLite et MariaDB ne le conservent pas)."""
    return datetime.now(timezone.utc).replace(tzinfo=None)


def iso(date):
    """Sérialise une date UTC stockée sans fuseau."""
    return date.replace(tzinfo=timezone.utc).isoformat() if date else None


class Utilisateur(UserMixin, db.Model):
    __tablename__ = "utilisateur"

    id = db.Column(db.Integer, primary_key=True)
    login = db.Column(db.String(64), unique=True, nullable=False)
    nom = db.Column(db.String(120), nullable=False)
    role = db.Column(db.String(20), nullable=False)  # admin | technicien | operateur
    email = db.Column(db.String(255), nullable=True)  # obligatoire pour les administrateurs (mot de passe oublié)
    mot_de_passe_hash = db.Column(db.String(255), nullable=False)
    actif = db.Column(db.Boolean, nullable=False, default=True)
    atelier_id = db.Column(db.Integer, db.ForeignKey("atelier.id"), nullable=True)  # compte opérateur partagé d'un atelier
    # Position de l'élève (ADM-05) : atelier où il se trouve, indiqué par lui-même
    position_atelier_id = db.Column(db.Integer, db.ForeignKey("atelier.id"), nullable=True)
    position_le = db.Column(db.DateTime, nullable=True)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)

    atelier = db.relationship("Atelier", foreign_keys=[atelier_id])
    position_atelier = db.relationship("Atelier", foreign_keys=[position_atelier_id])

    def definir_mot_de_passe(self, mot_de_passe):
        self.mot_de_passe_hash = generate_password_hash(mot_de_passe, method=METHODE_HACHAGE)

    def verifier_mot_de_passe(self, mot_de_passe):
        return check_password_hash(self.mot_de_passe_hash, mot_de_passe)

    @property
    def is_active(self):
        return self.actif

    def get_id(self):
        """Identifiant gardé dans le cookie de connexion : numéro du compte + empreinte de son mot de passe
        (et, pour un opérateur, de son QR code). Changer le mot de passe ou renouveler le QR code
        ferme donc toutes les connexions ouvertes avec l'ancien (téléphone perdu, QR code photographié…)."""
        empreinte = self.mot_de_passe_hash[-12:]
        if self.role == "operateur":
            qr = db.session.get(Parametre, f"qr_operateur_{self.id}")
            empreinte += (qr.valeur or "")[-8:] if qr else ""
        return f"{self.id}:{empreinte}"

    def to_dict(self):
        return {
            "id": self.id,
            "login": self.login,
            "nom": self.nom,
            "role": self.role,
            "atelier_id": self.atelier_id,
            "atelier": self.atelier.nom if self.atelier else None,
        }


class Atelier(db.Model):
    __tablename__ = "atelier"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(120), unique=True, nullable=False)
    ordre = db.Column(db.Integer, nullable=False, default=0)

    def to_dict(self):
        return {"id": self.id, "nom": self.nom, "ordre": self.ordre}


class Element(db.Model):
    """Nomenclature des éléments (groupes fonctionnels de la chaîne d'énergie et d'information)."""

    __tablename__ = "element"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(120), unique=True, nullable=False)
    ordre = db.Column(db.Integer, nullable=False, default=0)

    def to_dict(self):
        return {"id": self.id, "nom": self.nom, "ordre": self.ordre}


class Machine(db.Model):
    """Équipement réel d'un atelier (niveau 2 de l'arborescence)."""

    __tablename__ = "machine"

    id = db.Column(db.Integer, primary_key=True)
    repere = db.Column(db.String(20), unique=True, nullable=False)  # ex. FON-03
    designation = db.Column(db.String(160), nullable=False)
    marque = db.Column(db.String(80), nullable=True)
    modele = db.Column(db.String(80), nullable=True)
    atelier_id = db.Column(db.Integer, db.ForeignKey("atelier.id"), nullable=False, index=True)
    numero_serie = db.Column(db.String(80), nullable=True)
    annee_mise_en_service = db.Column(db.Integer, nullable=True)
    compteur_heures = db.Column(db.Float, nullable=True)  # temps de fonctionnement total
    utilisation_hebdo_h = db.Column(db.Float, nullable=True)  # temps moyen d'utilisation par semaine
    taux_horaire = db.Column(db.Float, nullable=True)  # € / h d'immobilisation (FND-02)
    remarques = db.Column(db.Text, nullable=True)
    photo = db.Column(db.String(120), nullable=True)  # nom du fichier dans UPLOAD_DIR/machines
    hors_service = db.Column(db.Boolean, nullable=False, default=False)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    modifie_le = db.Column(db.DateTime, nullable=False, default=maintenant, onupdate=maintenant)

    atelier = db.relationship("Atelier", backref=db.backref("machines", lazy="dynamic"))

    def to_dict(self):
        return {
            "id": self.id,
            "repere": self.repere,
            "designation": self.designation,
            "marque": self.marque,
            "modele": self.modele,
            "atelier_id": self.atelier_id,
            "atelier": self.atelier.nom if self.atelier else None,
            "numero_serie": self.numero_serie,
            "annee_mise_en_service": self.annee_mise_en_service,
            "compteur_heures": self.compteur_heures,
            "utilisation_hebdo_h": self.utilisation_hebdo_h,
            "taux_horaire": self.taux_horaire,
            "remarques": self.remarques,
            "photo": bool(self.photo),
            "hors_service": self.hors_service,
            "cree_le": iso(self.cree_le),
            "modifie_le": iso(self.modifie_le),
        }


bon_technicien = db.Table(
    "bon_technicien",
    db.Column("bon_id", db.Integer, db.ForeignKey("bon_intervention.id", ondelete="CASCADE"), primary_key=True),
    db.Column("utilisateur_id", db.Integer, db.ForeignKey("utilisateur.id"), primary_key=True),
)


class BonIntervention(db.Model):
    """Bon d'intervention (BI) : demande de travail puis compte-rendu."""

    __tablename__ = "bon_intervention"

    id = db.Column(db.Integer, primary_key=True)
    numero = db.Column(db.String(20), unique=True, nullable=False)  # ex. BI-2026-0042
    machine_id = db.Column(db.Integer, db.ForeignKey("machine.id"), nullable=False, index=True)
    type_travail = db.Column(db.String(20), nullable=False)  # code de referentiels.TYPES_TRAVAUX
    urgence = db.Column(db.String(20), nullable=False, default="normale")
    statut = db.Column(db.String(20), nullable=False, default="demande", index=True)
    demandeur = db.Column(db.String(120), nullable=False)
    description = db.Column(db.Text, nullable=False)
    machine_arretee = db.Column(db.Boolean, nullable=False, default=False)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant, index=True)
    cree_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    modifie_le = db.Column(db.DateTime, nullable=False, default=maintenant, onupdate=maintenant)

    # Compte-rendu
    travaux = db.Column(db.Text, nullable=True)
    cause = db.Column(db.Text, nullable=True)
    temps_passe_h = db.Column(db.Float, nullable=True)
    effectif = db.Column(db.Integer, nullable=True)
    remise_en_service = db.Column(db.DateTime, nullable=True)  # fin de l'arrêt machine
    element_id = db.Column(db.Integer, db.ForeignKey("element.id"), nullable=True)  # élément en cause (analyse)
    termine_le = db.Column(db.DateTime, nullable=True)

    # Tâche préventive de niveau 3-4 confiée ponctuellement (PRV-08) : le bon terminé valide l'échéance
    tache_id = db.Column(db.Integer, db.ForeignKey("tache_preventive.id"), nullable=True, index=True)
    echeance = db.Column(db.Date, nullable=True)

    machine = db.relationship("Machine", backref=db.backref("bons", lazy="dynamic"))
    cree_par = db.relationship("Utilisateur", foreign_keys=[cree_par_id])
    element = db.relationship("Element")
    composants = db.relationship(
        "BonComposant", backref="bon", cascade="all, delete-orphan", order_by="BonComposant.id"
    )
    techniciens = db.relationship("Utilisateur", secondary=bon_technicien, order_by="Utilisateur.nom")

    @property
    def duree_arret_h(self):
        """Durée d'arrêt de la machine, de la création du bon à la remise en service."""
        if not self.machine_arretee or not self.remise_en_service:
            return None
        return round(max((self.remise_en_service - self.cree_le).total_seconds(), 0) / 3600, 2)

    @property
    def cout_composants(self):
        return round(sum(c.cout or 0 for c in self.composants), 2)

    def to_dict(self):
        return {
            "id": self.id,
            "numero": self.numero,
            "machine": {
                "id": self.machine.id,
                "repere": self.machine.repere,
                "designation": self.machine.designation,
                "atelier": self.machine.atelier.nom,
            },
            "type_travail": self.type_travail,
            "urgence": self.urgence,
            "statut": self.statut,
            "demandeur": self.demandeur,
            "description": self.description,
            "machine_arretee": self.machine_arretee,
            "cree_le": iso(self.cree_le),
            "cree_par": self.cree_par.nom if self.cree_par else None,
            "modifie_le": iso(self.modifie_le),
            "travaux": self.travaux,
            "cause": self.cause,
            "temps_passe_h": self.temps_passe_h,
            "effectif": self.effectif,
            "remise_en_service": iso(self.remise_en_service),
            "duree_arret_h": self.duree_arret_h,
            "termine_le": iso(self.termine_le),
            "techniciens": [{"id": u.id, "nom": u.nom} for u in self.techniciens],
            "composants": [c.to_dict() for c in self.composants],
            "cout_composants": self.cout_composants,
            "element_id": self.element_id,
            "element": self.element.nom if self.element else None,
            "tache_id": self.tache_id,
            "echeance": self.echeance.isoformat() if self.echeance else None,
        }


class BonComposant(db.Model):
    """Composant utilisé lors d'une intervention, compté dans les coûts.
    Avec une pièce du magasin (piece_id), il est sorti du stock ; sinon c'est une ligne libre (achat ponctuel)."""

    __tablename__ = "bon_composant"

    id = db.Column(db.Integer, primary_key=True)
    bon_id = db.Column(db.Integer, db.ForeignKey("bon_intervention.id", ondelete="CASCADE"), nullable=False, index=True)
    piece_id = db.Column(db.Integer, db.ForeignKey("piece.id"), nullable=True, index=True)  # vide = ligne libre (hors magasin)
    designation = db.Column(db.String(160), nullable=False)
    reference = db.Column(db.String(80), nullable=True)
    quantite = db.Column(db.Float, nullable=False, default=1)
    prix_unitaire = db.Column(db.Float, nullable=True)  # € HT

    @property
    def cout(self):
        return round(self.quantite * self.prix_unitaire, 2) if self.prix_unitaire is not None else None

    def to_dict(self):
        return {
            "id": self.id,
            "piece_id": self.piece_id,
            "designation": self.designation,
            "reference": self.reference,
            "quantite": self.quantite,
            "prix_unitaire": self.prix_unitaire,
            "cout": self.cout,
        }


class Fournisseur(db.Model):
    __tablename__ = "fournisseur"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(120), unique=True, nullable=False)
    site_web = db.Column(db.String(300), nullable=True)
    adresse = db.Column(db.Text, nullable=True)
    telephone = db.Column(db.String(40), nullable=True)
    email = db.Column(db.String(160), nullable=True)
    contact = db.Column(db.String(120), nullable=True)
    remarques = db.Column(db.Text, nullable=True)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)

    def to_dict(self):
        return {
            "id": self.id,
            "nom": self.nom,
            "site_web": self.site_web,
            "adresse": self.adresse,
            "telephone": self.telephone,
            "email": self.email,
            "contact": self.contact,
            "remarques": self.remarques,
        }


class ZoneMagasin(db.Model):
    """Zone du magasin : une étagère (lettre) et un étage (chiffre), ex. A2 (STK-10, FND-06)."""

    __tablename__ = "zone_magasin"
    __table_args__ = (db.UniqueConstraint("etagere", "etage", name="uq_zone_etagere_etage"),)

    id = db.Column(db.Integer, primary_key=True)
    etagere = db.Column(db.String(1), nullable=False)  # A, B, C…
    etage = db.Column(db.Integer, nullable=False)  # 1, 2, 3…
    description = db.Column(db.String(160), nullable=True)

    @property
    def code(self):
        return f"{self.etagere}{self.etage}"

    def to_dict(self):
        return {"id": self.id, "code": self.code, "etagere": self.etagere, "etage": self.etage, "description": self.description}


class Piece(db.Model):
    """Pièce détachée ou consommable du magasin (STK-02)."""

    __tablename__ = "piece"

    id = db.Column(db.Integer, primary_key=True)
    reference = db.Column(db.String(5), unique=True, nullable=False)  # 00001, 00002… (c'est aussi le code-barres)
    designation = db.Column(db.String(160), nullable=False)
    commentaires = db.Column(db.Text, nullable=True)
    categorie = db.Column(db.String(40), nullable=False)
    fournisseur_id = db.Column(db.Integer, db.ForeignKey("fournisseur.id"), nullable=True, index=True)
    reference_fournisseur = db.Column(db.String(80), nullable=True)
    lien_commande = db.Column(db.String(500), nullable=True)
    zone_id = db.Column(db.Integer, db.ForeignKey("zone_magasin.id"), nullable=True, index=True)  # emplacement au magasin
    prix_unitaire = db.Column(db.Float, nullable=True)  # € HT
    quantite = db.Column(db.Float, nullable=False, default=0)
    stock_securite = db.Column(db.Float, nullable=True)  # saisi par les élèves, remis à zéro le 1er août
    quantite_min_commande = db.Column(db.Float, nullable=True)  # idem
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    modifie_le = db.Column(db.DateTime, nullable=False, default=maintenant, onupdate=maintenant)

    fournisseur = db.relationship("Fournisseur", backref=db.backref("pieces", lazy="dynamic"))
    zone = db.relationship("ZoneMagasin", backref=db.backref("pieces", lazy="dynamic"))
    affectations = db.relationship("PieceMachine", backref="piece", cascade="all, delete-orphan")

    @property
    def en_alerte(self):
        return self.stock_securite is not None and self.quantite <= self.stock_securite

    @property
    def quantite_en_commande(self):
        lignes = CommandeLigne.query.join(Commande).filter(
            CommandeLigne.piece_id == self.id, Commande.statut.in_(("en_commande", "partielle"))
        )
        return sum(max(l.quantite - l.quantite_recue, 0) for l in lignes)

    def to_dict(self, details=False):
        d = {
            "id": self.id,
            "reference": self.reference,
            "designation": self.designation,
            "categorie": self.categorie,
            "fournisseur_id": self.fournisseur_id,
            "fournisseur": self.fournisseur.nom if self.fournisseur else None,
            "reference_fournisseur": self.reference_fournisseur,
            "lien_commande": self.lien_commande,
            "zone_id": self.zone_id,
            "emplacement": self.zone.code if self.zone else None,
            "zone_description": self.zone.description if self.zone else None,
            "prix_unitaire": self.prix_unitaire,
            "quantite": self.quantite,
            "stock_securite": self.stock_securite,
            "quantite_min_commande": self.quantite_min_commande,
            "en_alerte": self.en_alerte,
            "commentaires": self.commentaires,
            "modifie_le": iso(self.modifie_le),
        }
        if details:
            d["quantite_en_commande"] = self.quantite_en_commande
            d["affectations"] = [a.to_dict() for a in self.affectations]
        return d


class PieceMachine(db.Model):
    """Machine sur laquelle une pièce est utilisée, et élément (chaîne fonctionnelle) où elle est rangée."""

    __tablename__ = "piece_machine"
    __table_args__ = (db.UniqueConstraint("piece_id", "machine_id", name="uq_piece_machine"),)

    id = db.Column(db.Integer, primary_key=True)
    piece_id = db.Column(db.Integer, db.ForeignKey("piece.id", ondelete="CASCADE"), nullable=False, index=True)
    machine_id = db.Column(db.Integer, db.ForeignKey("machine.id", ondelete="CASCADE"), nullable=False, index=True)
    element_id = db.Column(db.Integer, db.ForeignKey("element.id"), nullable=False)
    repere_schema = db.Column(db.String(120), nullable=True)  # repères du schéma de la machine : « KM1, KM2 » (n° 10)

    machine = db.relationship("Machine")
    element = db.relationship("Element")

    def to_dict(self):
        return {
            "machine_id": self.machine_id,
            "machine_repere": self.machine.repere,
            "machine": self.machine.designation,
            "element_id": self.element_id,
            "element": self.element.nom,
            "repere_schema": self.repere_schema,
        }


class Mouvement(db.Model):
    """Entrée, sortie ou inventaire d'une pièce (STK-05) : qui, quoi, quand, combien."""

    __tablename__ = "mouvement"

    id = db.Column(db.Integer, primary_key=True)
    piece_id = db.Column(db.Integer, db.ForeignKey("piece.id"), nullable=False, index=True)
    date = db.Column(db.DateTime, nullable=False, default=maintenant, index=True)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    type = db.Column(db.String(20), nullable=False)  # entree | sortie | inventaire
    quantite = db.Column(db.Float, nullable=False)  # variation du stock (+ ou -)
    stock_apres = db.Column(db.Float, nullable=False)
    motif = db.Column(db.String(300), nullable=True)
    bon_id = db.Column(db.Integer, db.ForeignKey("bon_intervention.id"), nullable=True, index=True)
    commande_id = db.Column(db.Integer, db.ForeignKey("commande.id"), nullable=True)

    piece = db.relationship("Piece", backref=db.backref("mouvements", lazy="dynamic"))
    utilisateur = db.relationship("Utilisateur")
    bon = db.relationship("BonIntervention")
    commande = db.relationship("Commande")

    def to_dict(self):
        return {
            "id": self.id,
            "date": iso(self.date),
            "piece": {"id": self.piece.id, "reference": self.piece.reference, "designation": self.piece.designation},
            "utilisateur": self.utilisateur.nom if self.utilisateur else None,
            "type": self.type,
            "quantite": self.quantite,
            "stock_apres": self.stock_apres,
            "motif": self.motif,
            "bon": {"id": self.bon.id, "numero": self.bon.numero} if self.bon else None,
            "commande": {"id": self.commande.id, "numero": self.commande.numero} if self.commande else None,
        }


class PanierLigne(db.Model):
    """Panier du magasin, commun à tous (STK-08) : pièces à commander, ou article hors magasin
    (piece vide : désignation, prix HT, lien et fournisseur saisis à la main ; il part dans un bon « Divers »)."""

    __tablename__ = "panier_ligne"

    id = db.Column(db.Integer, primary_key=True)
    piece_id = db.Column(db.Integer, db.ForeignKey("piece.id", ondelete="CASCADE"), unique=True, nullable=True)
    quantite = db.Column(db.Float, nullable=False, default=1)
    ajoute_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    ajoute_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    designation = db.Column(db.String(160), nullable=True)  # article hors magasin
    prix_unitaire = db.Column(db.Float, nullable=True)  # € HT, article hors magasin
    lien = db.Column(db.String(500), nullable=True)
    fournisseur_libre = db.Column(db.String(120), nullable=True)

    piece = db.relationship("Piece")
    ajoute_par = db.relationship("Utilisateur")

    def to_dict(self):
        return {
            "id": self.id,
            "piece": self.piece.to_dict() if self.piece else None,
            "libre": None
            if self.piece
            else {"designation": self.designation, "prix_unitaire": self.prix_unitaire, "lien": self.lien, "fournisseur": self.fournisseur_libre},
            "quantite": self.quantite,
            "ajoute_par": self.ajoute_par.nom if self.ajoute_par else None,
            "ajoute_le": iso(self.ajoute_le),
        }


DIVERS = "Divers (articles hors magasin)"


class Commande(db.Model):
    """Bon de commande, un par fournisseur (STK-08, STK-09) ; sans fournisseur : bon « Divers » des articles hors magasin."""

    __tablename__ = "commande"

    id = db.Column(db.Integer, primary_key=True)
    numero = db.Column(db.String(20), unique=True, nullable=False)  # BC-2026-001
    fournisseur_id = db.Column(db.Integer, db.ForeignKey("fournisseur.id"), nullable=True)
    statut = db.Column(db.String(20), nullable=False, default="en_commande")  # en_commande | partielle | recue | annulee
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    cree_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    recue_le = db.Column(db.DateTime, nullable=True)

    fournisseur = db.relationship("Fournisseur")
    cree_par = db.relationship("Utilisateur")
    lignes = db.relationship("CommandeLigne", backref="commande", cascade="all, delete-orphan", order_by="CommandeLigne.id")

    @property
    def total(self):
        return round(sum(l.quantite * (l.prix_unitaire or 0) for l in self.lignes), 2)

    def to_dict(self, details=False):
        d = {
            "id": self.id,
            "numero": self.numero,
            "fournisseur": {"id": self.fournisseur.id, "nom": self.fournisseur.nom} if self.fournisseur else {"id": None, "nom": DIVERS},
            "statut": self.statut,
            "cree_le": iso(self.cree_le),
            "cree_par": self.cree_par.nom if self.cree_par else None,
            "recue_le": iso(self.recue_le),
            "total": self.total,
            "nb_lignes": len(self.lignes),
        }
        if details:
            d["fournisseur"] = self.fournisseur.to_dict() if self.fournisseur else {"id": None, "nom": DIVERS}
            d["lignes"] = [l.to_dict() for l in self.lignes]
        return d


class CommandeLigne(db.Model):
    """Ligne d'un bon de commande. Les informations de la pièce sont recopiées au moment de la commande."""

    __tablename__ = "commande_ligne"

    id = db.Column(db.Integer, primary_key=True)
    commande_id = db.Column(db.Integer, db.ForeignKey("commande.id", ondelete="CASCADE"), nullable=False, index=True)
    piece_id = db.Column(db.Integer, db.ForeignKey("piece.id"), nullable=True, index=True)  # vide : article hors magasin
    reference = db.Column(db.String(5), nullable=True)
    reference_fournisseur = db.Column(db.String(80), nullable=True)
    designation = db.Column(db.String(160), nullable=False)
    lien_commande = db.Column(db.String(500), nullable=True)
    prix_unitaire = db.Column(db.Float, nullable=True)
    quantite = db.Column(db.Float, nullable=False)
    quantite_recue = db.Column(db.Float, nullable=False, default=0)
    fournisseur_libre = db.Column(db.String(120), nullable=True)  # article hors magasin

    def to_dict(self):
        return {
            "id": self.id,
            "piece_id": self.piece_id,
            "fournisseur_libre": self.fournisseur_libre,
            "reference": self.reference,
            "reference_fournisseur": self.reference_fournisseur,
            "designation": self.designation,
            "lien_commande": self.lien_commande,
            "prix_unitaire": self.prix_unitaire,
            "quantite": self.quantite,
            "quantite_recue": self.quantite_recue,
            "manquant": max(self.quantite - self.quantite_recue, 0),
        }


tache_pictogramme = db.Table(
    "tache_pictogramme",
    db.Column("tache_id", db.Integer, db.ForeignKey("tache_preventive.id", ondelete="CASCADE"), primary_key=True),
    db.Column("pictogramme_id", db.Integer, db.ForeignKey("pictogramme.id"), primary_key=True),
)


class Pictogramme(db.Model):
    """Pictogramme de sécurité (EPI, danger, interdiction) : intégré (code) ou ajouté par l'admin (image)."""

    __tablename__ = "pictogramme"

    id = db.Column(db.Integer, primary_key=True)
    code = db.Column(db.String(40), unique=True, nullable=True)  # pictogramme intégré ; vide = image de l'admin
    nom = db.Column(db.String(120), nullable=False)
    categorie = db.Column(db.String(20), nullable=False)  # obligation | danger | interdiction
    image = db.Column(db.String(120), nullable=True)

    def to_dict(self):
        return {"id": self.id, "code": self.code, "nom": self.nom, "categorie": self.categorie, "image": bool(self.image)}


class TachePreventive(db.Model):
    """Tâche du plan de maintenance d'une machine, avec sa fiche mode opératoire (PRV-01, PRV-02)."""

    __tablename__ = "tache_preventive"

    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey("machine.id"), nullable=False, index=True)
    nom = db.Column(db.String(160), nullable=False)
    niveau = db.Column(db.Integer, nullable=False)  # niveau AFNOR 1 à 5
    type_preventif = db.Column(db.String(60), nullable=False)
    periodicite = db.Column(db.String(20), nullable=False)  # code de referentiels.PERIODICITES
    date_debut = db.Column(db.Date, nullable=False)  # première échéance ; les suivantes sont à dates fixes
    temps_estime_min = db.Column(db.Integer, nullable=True)
    consignes = db.Column(db.Text, nullable=True)
    operations = db.Column(db.Text, nullable=True)  # une opération par ligne
    moyens = db.Column(db.Text, nullable=True)  # outillage, consommables, EPI : un par ligne
    redacteur = db.Column(db.String(120), nullable=True)
    date_redaction = db.Column(db.Date, nullable=True)
    actif = db.Column(db.Boolean, nullable=False, default=True)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    modifie_le = db.Column(db.DateTime, nullable=False, default=maintenant, onupdate=maintenant)

    machine = db.relationship("Machine", backref=db.backref("taches_preventives", lazy="dynamic"))
    pictogrammes = db.relationship("Pictogramme", secondary=tache_pictogramme, order_by="Pictogramme.categorie")
    photos = db.relationship("TachePhoto", backref="tache", cascade="all, delete-orphan", order_by="TachePhoto.id")
    pieces_prevues = db.relationship("TachePiece", backref="tache", cascade="all, delete-orphan", order_by="TachePiece.id")
    realisations = db.relationship(
        "RealisationPreventive", backref="tache", cascade="all, delete-orphan", lazy="dynamic"
    )


class TachePhoto(db.Model):
    __tablename__ = "tache_photo"

    id = db.Column(db.Integer, primary_key=True)
    tache_id = db.Column(db.Integer, db.ForeignKey("tache_preventive.id", ondelete="CASCADE"), nullable=False, index=True)
    fichier = db.Column(db.String(120), nullable=False)
    legende = db.Column(db.String(160), nullable=True)

    def to_dict(self):
        return {"id": self.id, "legende": self.legende}


class TachePiece(db.Model):
    """Pièce du magasin prévue pour une tâche préventive (n° 6, choix de Simon) : sortie du stock au « Fait »."""

    __tablename__ = "tache_piece"
    __table_args__ = (db.UniqueConstraint("tache_id", "piece_id", name="uq_tache_piece"),)

    id = db.Column(db.Integer, primary_key=True)
    tache_id = db.Column(db.Integer, db.ForeignKey("tache_preventive.id", name="fk_tache_piece_tache", ondelete="CASCADE"), nullable=False, index=True)
    piece_id = db.Column(db.Integer, db.ForeignKey("piece.id", name="fk_tache_piece_piece", ondelete="CASCADE"), nullable=False)
    quantite = db.Column(db.Float, nullable=False, default=1)

    piece = db.relationship("Piece", lazy="joined")

    def to_dict(self):
        return {
            "piece_id": self.piece_id,
            "reference": self.piece.reference,
            "designation": self.piece.designation,
            "quantite": self.quantite,
            "stock": self.piece.quantite,
            "emplacement": self.piece.zone.code if self.piece.zone else None,
        }


class RealisationPreventive(db.Model):
    """Échéance réalisée d'une tâche préventive (une seule par échéance : pas de cumul)."""

    __tablename__ = "realisation_preventive"
    __table_args__ = (db.UniqueConstraint("tache_id", "echeance", name="uq_realisation_tache_echeance"),)

    id = db.Column(db.Integer, primary_key=True)
    tache_id = db.Column(db.Integer, db.ForeignKey("tache_preventive.id", ondelete="CASCADE"), nullable=False, index=True)
    echeance = db.Column(db.Date, nullable=False)
    realise_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    bon_id = db.Column(db.Integer, db.ForeignKey("bon_intervention.id"), nullable=True)

    par = db.relationship("Utilisateur")
    bon = db.relationship("BonIntervention", foreign_keys=[bon_id])

    def to_dict(self):
        return {
            "id": self.id,
            "echeance": self.echeance.isoformat(),
            "realise_le": iso(self.realise_le),
            "par": self.par.nom if self.par else None,
            "bon": {"id": self.bon.id, "numero": self.bon.numero} if self.bon else None,
        }


class Document(db.Model):
    """Document technique (PDF) rattaché à une ou plusieurs machines (DOC-01, DOC-02)."""

    __tablename__ = "document"

    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(200), nullable=False)
    categorie = db.Column(db.String(60), nullable=False)
    remarques = db.Column(db.Text, nullable=True)
    fichier = db.Column(db.String(120), nullable=False)  # nom du fichier dans UPLOAD_DIR/documents
    nom_original = db.Column(db.String(255), nullable=False)
    taille = db.Column(db.Integer, nullable=False)  # octets
    depose_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    depose_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    modifie_le = db.Column(db.DateTime, nullable=False, default=maintenant, onupdate=maintenant)

    depose_par = db.relationship("Utilisateur")
    affectations = db.relationship("DocumentMachine", backref="document", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "titre": self.titre,
            "categorie": self.categorie,
            "remarques": self.remarques,
            "nom_original": self.nom_original,
            "taille": self.taille,
            "depose_le": iso(self.depose_le),
            "depose_par": self.depose_par.nom if self.depose_par else None,
            "modifie_le": iso(self.modifie_le),
            "affectations": [a.to_dict() for a in self.affectations],
        }


class DocumentMachine(db.Model):
    """Machine concernée par un document, avec l'élément (chaîne fonctionnelle) facultatif."""

    __tablename__ = "document_machine"
    __table_args__ = (db.UniqueConstraint("document_id", "machine_id", name="uq_document_machine"),)

    id = db.Column(db.Integer, primary_key=True)
    document_id = db.Column(db.Integer, db.ForeignKey("document.id", ondelete="CASCADE"), nullable=False, index=True)
    machine_id = db.Column(db.Integer, db.ForeignKey("machine.id", ondelete="CASCADE"), nullable=False, index=True)
    element_id = db.Column(db.Integer, db.ForeignKey("element.id"), nullable=True)

    machine = db.relationship("Machine")
    element = db.relationship("Element")

    def to_dict(self):
        return {
            "machine_id": self.machine_id,
            "machine_repere": self.machine.repere,
            "machine": self.machine.designation,
            "atelier": self.machine.atelier.nom,
            "element_id": self.element_id,
            "element": self.element.nom if self.element else None,
        }


class SaisieIndicateurs(db.Model):
    """Indicateurs et coûts calculés par les élèves pour une machine et une période (mode manuel, ANA-02)."""

    __tablename__ = "saisie_indicateurs"
    __table_args__ = (db.UniqueConstraint("machine_id", "periode", "debut", name="uq_saisie_machine_periode"),)

    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey("machine.id"), nullable=False, index=True)
    periode = db.Column(db.String(20), nullable=False)  # semaine | mois | trimestre | annee
    debut = db.Column(db.Date, nullable=False)
    mtbf_h = db.Column(db.Float, nullable=True)
    mttr_h = db.Column(db.Float, nullable=True)
    disponibilite = db.Column(db.Float, nullable=True)  # en %
    cout_pieces = db.Column(db.Float, nullable=True)
    cout_main_oeuvre = db.Column(db.Float, nullable=True)
    cout_immobilisation = db.Column(db.Float, nullable=True)
    commentaire = db.Column(db.Text, nullable=True)
    saisi_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    saisi_le = db.Column(db.DateTime, nullable=False, default=maintenant, onupdate=maintenant)

    machine = db.relationship("Machine")
    saisi_par = db.relationship("Utilisateur")

    @property
    def cout_total(self):
        couts = [self.cout_pieces, self.cout_main_oeuvre, self.cout_immobilisation]
        return None if all(c is None for c in couts) else round(sum(c or 0 for c in couts), 2)

    def to_dict(self):
        return {
            "id": self.id,
            "machine": {"id": self.machine.id, "repere": self.machine.repere, "designation": self.machine.designation, "atelier_id": self.machine.atelier_id},
            "periode": self.periode,
            "debut": self.debut.isoformat(),
            "mtbf_h": self.mtbf_h,
            "mttr_h": self.mttr_h,
            "disponibilite": self.disponibilite,
            "cout_pieces": self.cout_pieces,
            "cout_main_oeuvre": self.cout_main_oeuvre,
            "cout_immobilisation": self.cout_immobilisation,
            "cout_total": self.cout_total,
            "commentaire": self.commentaire,
            "saisi_par": self.saisi_par.nom if self.saisi_par else None,
            "saisi_le": iso(self.saisi_le),
        }


class ReleveConditionnel(db.Model):
    """Relevé de maintenance conditionnelle (ANA-04) : thermographie, analyse d'huile, analyse vibratoire."""

    __tablename__ = "releve_conditionnel"

    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey("machine.id"), nullable=False, index=True)
    date = db.Column(db.Date, nullable=False)
    type = db.Column(db.String(20), nullable=False)  # thermique | huile | vibratoire
    resultat = db.Column(db.String(30), nullable=False)  # état, classe NAS ou défaut
    commentaire = db.Column(db.Text, nullable=True)
    par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)

    machine = db.relationship("Machine")
    par = db.relationship("Utilisateur")


class SemaineCalendrier(db.Model):
    """Semaine particulière du calendrier scolaire (FND-04) : vacances ou apprentissage (élèves en entreprise).
    Les semaines absentes de la table sont des semaines de cours."""

    __tablename__ = "semaine_calendrier"

    id = db.Column(db.Integer, primary_key=True)
    lundi = db.Column(db.Date, unique=True, nullable=False)
    type = db.Column(db.String(20), nullable=False)  # vacances | apprentissage


class EvenementCalendrier(db.Model):
    """Date d'examen, de formation… ajoutée par l'enseignant, affichée sur les diagrammes de Gantt."""

    __tablename__ = "evenement_calendrier"

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.Date, nullable=False, index=True)
    titre = db.Column(db.String(160), nullable=False)
    type = db.Column(db.String(20), nullable=False)  # examen | formation | autre

    def to_dict(self):
        return {"id": self.id, "date": self.date.isoformat(), "titre": self.titre, "type": self.type}


class Chantier(db.Model):
    """Tâche libre (amélioration, organisation…) attribuée à un ou plusieurs élèves (CHA-01, CHA-02)."""

    __tablename__ = "chantier"

    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(160), nullable=False)
    description = db.Column(db.Text, nullable=True)
    type = db.Column(db.String(20), nullable=False, default="amelioration")  # amelioration | organisation | autre
    machine_id = db.Column(db.Integer, db.ForeignKey("machine.id"), nullable=True)
    mode = db.Column(db.String(20), nullable=False, default="equipe")  # equipe | individuel
    duree_estimee_h = db.Column(db.Float, nullable=True)
    echeance = db.Column(db.Date, nullable=True)
    statut = db.Column(db.String(20), nullable=False, default="a_faire")  # a_faire | en_cours | termine
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    cree_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    termine_le = db.Column(db.DateTime, nullable=True)

    machine = db.relationship("Machine")
    cree_par = db.relationship("Utilisateur")
    affectations = db.relationship("ChantierAffectation", backref="chantier", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "titre": self.titre,
            "description": self.description,
            "type": self.type,
            "machine": {"id": self.machine.id, "repere": self.machine.repere, "designation": self.machine.designation} if self.machine else None,
            "mode": self.mode,
            "duree_estimee_h": self.duree_estimee_h,
            "echeance": self.echeance.isoformat() if self.echeance else None,
            "statut": self.statut,
            "cree_le": iso(self.cree_le),
            "termine_le": iso(self.termine_le),
            "techniciens": [
                {"id": a.utilisateur.id, "nom": a.utilisateur.nom, "termine_le": iso(a.termine_le)} for a in self.affectations
            ],
        }


class ChantierAffectation(db.Model):
    """Élève affecté à un chantier ; en mode individuel, chacun le termine de son côté."""

    __tablename__ = "chantier_affectation"

    chantier_id = db.Column(db.Integer, db.ForeignKey("chantier.id", ondelete="CASCADE"), primary_key=True)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), primary_key=True)
    termine_le = db.Column(db.DateTime, nullable=True)

    utilisateur = db.relationship("Utilisateur")


projet_membre = db.Table(
    "projet_membre",
    db.Column("projet_id", db.Integer, db.ForeignKey("projet.id", ondelete="CASCADE"), primary_key=True),
    db.Column("utilisateur_id", db.Integer, db.ForeignKey("utilisateur.id"), primary_key=True),
)

tache_projet_predecesseur = db.Table(
    "tache_projet_predecesseur",
    db.Column("tache_id", db.Integer, db.ForeignKey("tache_projet.id", ondelete="CASCADE"), primary_key=True),
    db.Column("predecesseur_id", db.Integer, db.ForeignKey("tache_projet.id", ondelete="CASCADE"), primary_key=True),
)

tache_projet_technicien = db.Table(
    "tache_projet_technicien",
    db.Column("tache_id", db.Integer, db.ForeignKey("tache_projet.id", ondelete="CASCADE"), primary_key=True),
    db.Column("utilisateur_id", db.Integer, db.ForeignKey("utilisateur.id"), primary_key=True),
)


groupe_membre = db.Table(
    "groupe_membre",
    db.Column("groupe_id", db.Integer, db.ForeignKey("groupe_eleves.id", ondelete="CASCADE"), primary_key=True),
    db.Column("utilisateur_id", db.Integer, db.ForeignKey("utilisateur.id"), primary_key=True),
)


class GroupeEleves(db.Model):
    """Groupe d'élèves (ex. « Groupe A ») : sélectionner un groupe ajoute ses membres à une tâche ou un projet."""

    __tablename__ = "groupe_eleves"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(80), unique=True, nullable=False)
    membres = db.relationship("Utilisateur", secondary=groupe_membre, order_by="Utilisateur.nom")

    def to_dict(self):
        return {"id": self.id, "nom": self.nom, "membres": [{"id": u.id, "nom": u.nom} for u in self.membres if u.actif]}


class ChantierType(db.Model):
    """Modèle de chantier réutilisable, créé par l'administrateur."""

    __tablename__ = "chantier_type"

    id = db.Column(db.Integer, primary_key=True)
    titre = db.Column(db.String(160), nullable=False)
    description = db.Column(db.Text, nullable=True)
    type = db.Column(db.String(20), nullable=False, default="amelioration")
    mode = db.Column(db.String(20), nullable=False, default="equipe")
    duree_estimee_h = db.Column(db.Float, nullable=True)

    def to_dict(self):
        return {"id": self.id, "titre": self.titre, "description": self.description, "type": self.type, "mode": self.mode, "duree_estimee_h": self.duree_estimee_h}


class Projet(db.Model):
    """Projet de mise en place de la maintenance (CHA-03), mené par un groupe d'élèves. Archivé le 1er août.
    Le projet « principal » (Déploiement de la GMAO) est unique par année et concerne toute la classe."""

    __tablename__ = "projet"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(160), nullable=False)
    description = db.Column(db.Text, nullable=True)
    date_debut = db.Column(db.Date, nullable=False)  # semaine de départ du Gantt
    actif = db.Column(db.Boolean, nullable=False, default=True)
    principal = db.Column(db.Boolean, nullable=False, default=False)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)

    membres = db.relationship("Utilisateur", secondary=projet_membre, order_by="Utilisateur.nom")
    taches = db.relationship("TacheProjet", backref="projet", cascade="all, delete-orphan", order_by="TacheProjet.ordre")


class TacheProjet(db.Model):
    """Tâche du projet (CHA-03 à CHA-05) : durée en semaines de cours, prédécesseurs, « bon de travail » répartissable."""

    __tablename__ = "tache_projet"

    id = db.Column(db.Integer, primary_key=True)
    projet_id = db.Column(db.Integer, db.ForeignKey("projet.id", ondelete="CASCADE"), nullable=False, index=True)
    nom = db.Column(db.String(160), nullable=False)
    description = db.Column(db.Text, nullable=True)
    ordre = db.Column(db.Integer, nullable=False, default=0)
    duree_semaines = db.Column(db.Integer, nullable=False, default=1)
    debut_au_plus_tot = db.Column(db.Date, nullable=True)
    avancement = db.Column(db.Integer, nullable=False, default=0)  # %
    statut = db.Column(db.String(20), nullable=False, default="a_faire")  # a_faire | en_cours | termine
    termine_le = db.Column(db.DateTime, nullable=True)  # pour le taux de performance de la semaine
    jalon = db.Column(db.Boolean, nullable=False, default=False)

    predecesseurs = db.relationship(
        "TacheProjet",
        secondary=tache_projet_predecesseur,
        primaryjoin=lambda: TacheProjet.id == tache_projet_predecesseur.c.tache_id,
        secondaryjoin=lambda: TacheProjet.id == tache_projet_predecesseur.c.predecesseur_id,
    )
    techniciens = db.relationship("Utilisateur", secondary=tache_projet_technicien, order_by="Utilisateur.nom")


class SemaineSecurite(db.Model):
    """Croix Sécurité (AIC-04) : couleur d'une semaine. Absente de la table = sans couleur (non renseignée / à venir)."""

    __tablename__ = "semaine_securite"

    id = db.Column(db.Integer, primary_key=True)
    lundi = db.Column(db.Date, unique=True, nullable=False)
    couleur = db.Column(db.String(10), nullable=False)  # vert | orange | rouge | gris
    modifie_le = db.Column(db.DateTime, nullable=False, default=maintenant, onupdate=maintenant)
    modifie_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)


conversation_participant = db.Table(
    "conversation_participant",
    db.Column("conversation_id", db.Integer, db.ForeignKey("conversation.id", name="fk_participant_conversation", ondelete="CASCADE"), primary_key=True),
    db.Column("utilisateur_id", db.Integer, db.ForeignKey("utilisateur.id", name="fk_participant_utilisateur"), primary_key=True),
)


class Conversation(db.Model):
    """Fil de messagerie (ADM-04). Types :
    directe (deux personnes), enseignants (un élève et tous les administrateurs),
    groupe (un groupe d'élèves et les administrateurs), classe (tous les élèves et les administrateurs)."""

    __tablename__ = "conversation"

    id = db.Column(db.Integer, primary_key=True)
    type = db.Column(db.String(20), nullable=False)
    eleve_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_conversation_eleve"), nullable=True, index=True)
    groupe_id = db.Column(db.Integer, db.ForeignKey("groupe_eleves.id", name="fk_conversation_groupe", ondelete="CASCADE"), nullable=True)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    dernier_message_le = db.Column(db.DateTime, nullable=True, index=True)

    eleve = db.relationship("Utilisateur", foreign_keys=[eleve_id])
    groupe = db.relationship("GroupeEleves")
    participants = db.relationship("Utilisateur", secondary=conversation_participant)
    messages = db.relationship("Message", backref="conversation", cascade="all, delete-orphan", lazy="dynamic")


class Message(db.Model):
    __tablename__ = "message"

    id = db.Column(db.Integer, primary_key=True)
    conversation_id = db.Column(db.Integer, db.ForeignKey("conversation.id", name="fk_message_conversation", ondelete="CASCADE"), nullable=False, index=True)
    auteur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_message_auteur"), nullable=False)
    texte = db.Column(db.Text, nullable=False)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)

    auteur = db.relationship("Utilisateur")

    def to_dict(self):
        return {
            "id": self.id,
            "auteur": {"id": self.auteur.id, "nom": self.auteur.nom, "role": self.auteur.role},
            "texte": self.texte,
            "cree_le": iso(self.cree_le),
        }


class LectureConversation(db.Model):
    """Dernier message lu par une personne dans une conversation (pour compter les non-lus)."""

    __tablename__ = "lecture_conversation"

    conversation_id = db.Column(db.Integer, db.ForeignKey("conversation.id", name="fk_lecture_conversation", ondelete="CASCADE"), primary_key=True)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_lecture_utilisateur"), primary_key=True)
    dernier_lu_id = db.Column(db.Integer, nullable=False, default=0)


bon_preventif_technicien = db.Table(
    "bon_preventif_technicien",
    db.Column("bon_id", db.Integer, db.ForeignKey("bon_preventif.id", name="fk_bp_technicien_bon", ondelete="CASCADE"), primary_key=True),
    db.Column("utilisateur_id", db.Integer, db.ForeignKey("utilisateur.id", name="fk_bp_technicien_utilisateur"), primary_key=True),
)


class BonPreventif(db.Model):
    """Bon de préventif : une échéance d'une tâche du plan de maintenance confiée à des élèves.
    Différent d'un bon d'intervention (correctif) : pas de compte-rendu, on consulte le mode opératoire
    et on valide « Fait » en un clic (l'échéance est alors cochée)."""

    __tablename__ = "bon_preventif"
    __table_args__ = (db.UniqueConstraint("tache_id", "echeance", name="uq_bon_preventif_tache_echeance"),)

    id = db.Column(db.Integer, primary_key=True)
    tache_id = db.Column(db.Integer, db.ForeignKey("tache_preventive.id", name="fk_bp_tache", ondelete="CASCADE"), nullable=False, index=True)
    echeance = db.Column(db.Date, nullable=False)
    cree_le = db.Column(db.DateTime, nullable=False, default=maintenant)
    cree_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_bp_cree_par"), nullable=True)
    termine_le = db.Column(db.DateTime, nullable=True)
    termine_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_bp_termine_par"), nullable=True)

    tache = db.relationship("TachePreventive")
    techniciens = db.relationship("Utilisateur", secondary=bon_preventif_technicien, order_by="Utilisateur.nom")
    cree_par = db.relationship("Utilisateur", foreign_keys=[cree_par_id])
    termine_par = db.relationship("Utilisateur", foreign_keys=[termine_par_id])

    def to_dict(self):
        t, m = self.tache, self.tache.machine
        return {
            "id": self.id,
            "tache": {"id": t.id, "nom": t.nom, "niveau": t.niveau, "type_preventif": t.type_preventif, "temps_estime_min": t.temps_estime_min},
            "machine": {"id": m.id, "repere": m.repere, "designation": m.designation, "atelier": m.atelier.nom},
            "echeance": self.echeance.isoformat(),
            "techniciens": [{"id": u.id, "nom": u.nom} for u in self.techniciens],
            "cree_le": iso(self.cree_le),
            "cree_par": self.cree_par.nom if self.cree_par else None,
            "termine_le": iso(self.termine_le),
            "termine_par": self.termine_par.nom if self.termine_par else None,
        }


ips_pictogramme = db.Table(
    "ips_pictogramme",
    db.Column("ips_id", db.Integer, db.ForeignKey("ips_machine.id", name="fk_ips_picto_ips", ondelete="CASCADE"), primary_key=True),
    db.Column("pictogramme_id", db.Integer, db.ForeignKey("pictogramme.id", name="fk_ips_picto_picto"), primary_key=True),
)


class IpsMachine(db.Model):
    """Instruction Permanente de Sécurité d'une machine (circulaire 96-294, BOEN n° 47 du 26/12/96).
    Toute modification retire le visa : l'IPS est alors « à revalider » par un enseignant.
    Le jeton forme l'adresse publique (QR code) de la fiche, lisible sans connexion une fois validée."""

    __tablename__ = "ips_machine"

    id = db.Column(db.Integer, primary_key=True)
    machine_id = db.Column(db.Integer, db.ForeignKey("machine.id", name="fk_ips_machine", ondelete="CASCADE"), unique=True, nullable=False)
    conformite = db.Column(db.String(20), nullable=True)  # oui | non | en_cours (décret 93-40)
    accessibilite = db.Column(db.String(30), nullable=True)
    risques = db.Column(db.Text, nullable=True)  # un risque par ligne
    consignes = db.Column(db.Text, nullable=True)  # une consigne par ligne
    modifie_le = db.Column(db.DateTime, nullable=True)
    modifie_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_ips_modifie_par"), nullable=True)
    valide_le = db.Column(db.DateTime, nullable=True)
    valide_par_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_ips_valide_par"), nullable=True)
    jeton = db.Column(db.String(64), unique=True, nullable=False)

    machine = db.relationship("Machine", backref=db.backref("ips", uselist=False, cascade="all, delete-orphan"))
    modifie_par = db.relationship("Utilisateur", foreign_keys=[modifie_par_id])
    valide_par = db.relationship("Utilisateur", foreign_keys=[valide_par_id])
    pictogrammes = db.relationship("Pictogramme", secondary=ips_pictogramme, order_by="Pictogramme.categorie")


class Role(db.Model):
    """Rôle confié aux élèves (option facultative, demande de Simon du 29/10/2026) : Magasinier, Préparateur,
    Responsable sécurité… Un rôle peut porter sur un atelier (responsable d'atelier : ses bons et son préventif mis en avant)."""

    __tablename__ = "role"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(80), unique=True, nullable=False)
    description = db.Column(db.String(300), nullable=True)
    atelier_id = db.Column(db.Integer, db.ForeignKey("atelier.id", name="fk_role_atelier"), nullable=True)
    ordre = db.Column(db.Integer, nullable=False, default=0)

    atelier = db.relationship("Atelier")
    attributions = db.relationship("RoleAttribution", backref="role", cascade="all, delete-orphan")

    def to_dict(self):
        return {
            "id": self.id,
            "nom": self.nom,
            "description": self.description,
            "atelier_id": self.atelier_id,
            "atelier": self.atelier.nom if self.atelier else None,
            "fixe": [a.to_dict() for a in self.attributions],
        }


class RoleAttribution(db.Model):
    """Rôle fixe (pour l'année) : confié à un élève ou à un groupe, sans rotation."""

    __tablename__ = "role_attribution"

    id = db.Column(db.Integer, primary_key=True)
    role_id = db.Column(db.Integer, db.ForeignKey("role.id", name="fk_attribution_role", ondelete="CASCADE"), nullable=False, index=True)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_attribution_utilisateur"), nullable=True)
    groupe_id = db.Column(db.Integer, db.ForeignKey("groupe_eleves.id", name="fk_attribution_groupe", ondelete="CASCADE"), nullable=True)

    utilisateur = db.relationship("Utilisateur")
    groupe = db.relationship("GroupeEleves")

    def to_dict(self):
        return {
            "id": self.id,
            "utilisateur": {"id": self.utilisateur.id, "nom": self.utilisateur.nom} if self.utilisateur else None,
            "groupe": {"id": self.groupe.id, "nom": self.groupe.nom} if self.groupe else None,
        }


class Roue(db.Model):
    """Roue des rôles : chaque lundi (hors vacances), chaque rôle passe à l'élève suivant de la classe ou d'un groupe."""

    __tablename__ = "roue"

    id = db.Column(db.Integer, primary_key=True)
    nom = db.Column(db.String(80), nullable=False)
    groupe_id = db.Column(db.Integer, db.ForeignKey("groupe_eleves.id", name="fk_roue_groupe", ondelete="CASCADE"), nullable=True)  # vide : toute la classe
    date_debut = db.Column(db.Date, nullable=False)  # lundi de la première semaine

    groupe = db.relationship("GroupeEleves")
    roles = db.relationship("RoueRole", backref="roue", cascade="all, delete-orphan", order_by="RoueRole.ordre")
    echanges = db.relationship("RoueEchange", backref="roue", cascade="all, delete-orphan")


class RoueRole(db.Model):
    __tablename__ = "roue_role"

    roue_id = db.Column(db.Integer, db.ForeignKey("roue.id", name="fk_roue_role_roue", ondelete="CASCADE"), primary_key=True)
    role_id = db.Column(db.Integer, db.ForeignKey("role.id", name="fk_roue_role_role", ondelete="CASCADE"), primary_key=True)
    ordre = db.Column(db.Integer, nullable=False, default=0)

    role = db.relationship("Role")


class RoueEchange(db.Model):
    """Échange forcé pour une semaine (ex. élève absent) : les rôles des deux élèves sont inversés cette semaine-là."""

    __tablename__ = "roue_echange"

    id = db.Column(db.Integer, primary_key=True)
    roue_id = db.Column(db.Integer, db.ForeignKey("roue.id", name="fk_echange_roue", ondelete="CASCADE"), nullable=False, index=True)
    lundi = db.Column(db.Date, nullable=False)
    eleve_a_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_echange_eleve_a"), nullable=False)
    eleve_b_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_echange_eleve_b"), nullable=False)


class AbsenceEleve(db.Model):
    """Jour d'absence d'un élève : noté en réunion AIC (élève décoché) ou par l'enseignant sur le bilan de la semaine."""

    __tablename__ = "absence_eleve"
    __table_args__ = (db.UniqueConstraint("utilisateur_id", "jour", name="uq_absence_eleve_jour"),)

    id = db.Column(db.Integer, primary_key=True)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id", name="fk_absence_utilisateur"), nullable=False, index=True)
    jour = db.Column(db.Date, nullable=False)


class Parametre(db.Model):
    """Réglages modifiables par l'administrateur (clé / valeur)."""

    __tablename__ = "parametre"

    cle = db.Column(db.String(64), primary_key=True)
    valeur = db.Column(db.Text, nullable=True)


class JournalAction(db.Model):
    """Traçabilité (TRV-07) : qui a fait quoi, sur quel objet, et quand."""

    __tablename__ = "journal_action"

    id = db.Column(db.Integer, primary_key=True)
    date = db.Column(db.DateTime, nullable=False, default=maintenant, index=True)
    utilisateur_id = db.Column(db.Integer, db.ForeignKey("utilisateur.id"), nullable=True)
    action = db.Column(db.String(40), nullable=False)  # creation, modification, suppression, connexion…
    objet_type = db.Column(db.String(40), nullable=True)
    objet_id = db.Column(db.Integer, nullable=True)
    details = db.Column(db.Text, nullable=True)

    utilisateur = db.relationship("Utilisateur")


def journaliser(action, objet=None, details=None, utilisateur=None):
    """Ajoute une ligne au journal (enregistrée avec le prochain commit)."""
    from flask_login import current_user

    if utilisateur is None and current_user and current_user.is_authenticated:
        utilisateur = current_user
    db.session.add(
        JournalAction(
            utilisateur_id=utilisateur.id if utilisateur else None,
            action=action,
            objet_type=type(objet).__name__ if objet is not None else None,
            objet_id=getattr(objet, "id", None),
            details=details,
        )
    )
