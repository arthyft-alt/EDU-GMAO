"""Module Analyse et indicateurs (ANA-01 à ANA-09).

Formules (choix de Simon) :
- temps d'utilisation H = utilisation hebdomadaire de la machine × nombre de semaines de la période ;
- seuls les bons « Dépannage » sont des pannes ; TR = somme des temps passés (compte-rendu) ;
- MTBF = (H − TR) / nombre de pannes ; MTTR = TR / nombre de pannes ;
- disponibilité = (H − TR) / H = MTBF / (MTBF + MTTR).
Coûts : pièces + main-d'œuvre (temps passé × effectif × taux) + immobilisation (temps passé × taux machine
si la machine était à l'arrêt) ; préventif réalisé par check-list : temps estimé × taux main-d'œuvre.

Calcul automatique : protégé par le mot de passe « indicateurs » (admin dispensé) ; coûts : administrateur seul.
"""
import io
from collections import defaultdict
from datetime import date, datetime, timedelta

from flask import Blueprint, Response, jsonify, request
from flask_login import current_user
from sqlalchemy.orm import contains_eager, joinedload, selectinload

from . import db, tableur
from . import referentiels as ref
from .auth import erreur, role_required, unlock_required
from .calendrier import jours_hors_vacances
from .dates import PARIS, debut_jour_paris
from .reglages import reglage
from .models import (
    Atelier,
    BonIntervention,
    Machine,
    Parametre,
    RealisationPreventive,
    ReleveConditionnel,
    SaisieIndicateurs,
    TachePreventive,
    journaliser,
)

bp = Blueprint("indicateurs", __name__)

EQUIPE = ("admin", "technicien")
PARAMETRES = {"seuil_dispo_vert": 90.0, "seuil_dispo_orange": 75.0, "taux_main_oeuvre": 15.0}


# ---------- Paramètres ----------

def parametre(cle):
    p = db.session.get(Parametre, cle)
    try:
        return float(p.valeur) if p and p.valeur not in (None, "") else PARAMETRES[cle]
    except ValueError:
        return PARAMETRES[cle]


def pastille(disponibilite):
    if disponibilite is None:
        return "neutral"
    if disponibilite >= parametre("seuil_dispo_vert"):
        return "success"
    return "warning" if disponibilite >= parametre("seuil_dispo_orange") else "danger"


@bp.get("/indicateurs/parametres")
@role_required(*EQUIPE)
def lire_parametres():
    return jsonify(parametres={cle: parametre(cle) for cle in PARAMETRES}, periodes=ref.PERIODES_ANALYSE)


@bp.put("/indicateurs/parametres")
@role_required("admin")
def modifier_parametres():
    donnees = request.get_json(silent=True) or {}
    valeurs = {}
    for cle in PARAMETRES:
        if cle in donnees:
            try:
                valeurs[cle] = float(str(donnees[cle]).replace(",", "."))
            except ValueError:
                return erreur("Les seuils et le taux horaire doivent être des nombres.", 400)
    vert = valeurs.get("seuil_dispo_vert", parametre("seuil_dispo_vert"))
    orange = valeurs.get("seuil_dispo_orange", parametre("seuil_dispo_orange"))
    if not 0 <= orange < vert <= 100:
        return erreur("Il faut 0 ≤ seuil orange < seuil vert ≤ 100.", 400)
    if valeurs.get("taux_main_oeuvre", 0) < 0:
        return erreur("Le taux horaire ne peut pas être négatif.", 400)
    for cle, valeur in valeurs.items():
        p = db.session.get(Parametre, cle) or Parametre(cle=cle)
        p.valeur = str(valeur)
        db.session.add(p)
    journaliser("modification", details="Paramètres des indicateurs")
    db.session.commit()
    return jsonify(parametres={cle: parametre(cle) for cle in PARAMETRES})


# ---------- Périodes ----------

def _ajouter_mois(jour, mois):
    total = jour.month - 1 + mois
    return date(jour.year + total // 12, total % 12 + 1, 1)


def bornes(periode, jour):
    """Période contenant le jour : (début inclus, fin exclue)."""
    if periode == "semaine":
        debut = jour - timedelta(days=jour.weekday())
        return debut, debut + timedelta(days=7)
    if periode == "mois":
        debut = jour.replace(day=1)
        return debut, _ajouter_mois(debut, 1)
    if periode == "trimestre":
        debut = date(jour.year, (jour.month - 1) // 3 * 3 + 1, 1)
        return debut, _ajouter_mois(debut, 3)
    if periode == "annee":  # année scolaire : du 1er août au 31 juillet
        debut = date(jour.year if jour >= date(jour.year, 8, 1) else jour.year - 1, 8, 1)
        return debut, date(debut.year + 1, 8, 1)
    raise ValueError("Période inconnue.")


def precedente(periode, debut):
    return bornes(periode, debut - timedelta(days=1))


def _lire_periode():
    periode = request.args.get("periode", "mois")
    if periode not in ref.PERIODES_ANALYSE:
        raise ValueError("Période inconnue.")
    try:
        jour = date.fromisoformat(request.args["debut"]) if request.args.get("debut") else datetime.now(PARIS).date()
    except ValueError:
        raise ValueError("Date invalide.")
    return periode, *bornes(periode, jour)


# ---------- Calculs ----------

def _bons_periode(du, au, machine_ids=None):
    requete = BonIntervention.query.filter(
        BonIntervention.cree_le >= debut_jour_paris(du), BonIntervention.cree_le < debut_jour_paris(au)
    )
    if machine_ids is not None:
        requete = requete.filter(BonIntervention.machine_id.in_(machine_ids))
    # Composants et élément de chaque bon lus en une fois (coûts, Pareto) plutôt que bon par bon
    requete = requete.options(selectinload(BonIntervention.composants), joinedload(BonIntervention.element))
    par_machine = defaultdict(list)
    for b in requete:
        par_machine[b.machine_id].append(b)
    return par_machine


def _arrondi(n, chiffres=1):
    return None if n is None else round(n, chiffres)


def calcul(machines, du, au, avec_couts=False):
    """Indicateurs d'un ensemble de machines (une seule, un atelier ou le parc) sur une période."""
    machine_ids = [m.id for m in machines]
    bons = _bons_periode(du, au, machine_ids)
    # Les semaines de vacances ne comptent pas : les machines ne tournent pas sans élèves
    semaines = jours_hors_vacances(du, au) / 7
    H = TR = arret = 0.0
    n = 0
    sans_utilisation = 0
    for m in machines:
        pannes = [b for b in bons.get(m.id, []) if b.type_travail == "depannage"]
        n += len(pannes)
        TR += sum(b.temps_passe_h or 0 for b in pannes)
        arret += sum(b.duree_arret_h or 0 for b in pannes)
        if m.utilisation_hebdo_h:
            H += m.utilisation_hebdo_h * semaines
        else:
            sans_utilisation += 1
    tbf = max(H - TR, 0) if H else None
    resultat = {
        "heures_utilisation": _arrondi(H) if H else None,
        "nb_pannes": n,
        "temps_reparation_h": _arrondi(TR, 2),
        "temps_arret_h": _arrondi(arret),
        "mtbf_h": _arrondi(tbf / n) if tbf is not None and n else None,
        "mttr_h": _arrondi(TR / n, 2) if n else None,
        "disponibilite": _arrondi(tbf / H * 100) if H else None,
        "machines_sans_utilisation": sans_utilisation,
    }
    resultat["pastille"] = pastille(resultat["disponibilite"])
    if avec_couts:
        resultat["couts"] = couts(machines, du, au, bons)
    return resultat


def couts(machines, du, au, bons=None):
    """Coûts par nature (pièces, main-d'œuvre, immobilisation) et par type (correctif, préventif, autres)."""
    bons = bons if bons is not None else _bons_periode(du, au, [m.id for m in machines])
    taux_mo = parametre("taux_main_oeuvre")
    total = {"pieces": 0.0, "main_oeuvre": 0.0, "immobilisation": 0.0}
    par_type = {"correctif": 0.0, "preventif": 0.0, "autres": 0.0}

    def ajouter(type_travail, pieces=0.0, mo=0.0, immo=0.0):
        total["pieces"] += pieces
        total["main_oeuvre"] += mo
        total["immobilisation"] += immo
        cle = {"depannage": "correctif", "preventif": "preventif"}.get(type_travail, "autres")
        par_type[cle] += pieces + mo + immo

    for m in machines:
        for b in bons.get(m.id, []):
            heures = b.temps_passe_h or 0
            ajouter(
                b.type_travail,
                pieces=b.cout_composants,
                mo=heures * (b.effectif or 1) * taux_mo,
                immo=heures * (m.taux_horaire or 0) if b.machine_arretee else 0,
            )
    # Préventif réalisé par check-list (sans bon) : temps estimé × taux main-d'œuvre
    realisations = (
        RealisationPreventive.query.join(TachePreventive)
        .options(contains_eager(RealisationPreventive.tache))
        .filter(
            TachePreventive.machine_id.in_([m.id for m in machines]),
            RealisationPreventive.echeance >= du,
            RealisationPreventive.echeance < au,
            RealisationPreventive.bon_id.is_(None),
        )
        .all()
    )
    for r in realisations:
        ajouter("preventif", mo=(r.tache.temps_estime_min or 0) / 60 * taux_mo)
    arrondis = {cle: round(v, 2) for cle, v in total.items()}
    return {**arrondis, "total": round(sum(total.values()), 2), "par_type": {k: round(v, 2) for k, v in par_type.items()}}


def _machines(atelier_id=None, machine_id=None):
    requete = Machine.query.filter(Machine.hors_service.is_(False))
    if atelier_id:
        requete = requete.filter(Machine.atelier_id == atelier_id)
    if machine_id:
        requete = Machine.query.filter(Machine.id == machine_id)
    return requete.order_by(Machine.repere).all()


# ---------- Tableau de bord automatique ----------

@bp.get("/indicateurs/auto")
@role_required(*EQUIPE)
@unlock_required("indicateurs")
def tableau_de_bord():
    """Parc, ateliers et (si atelier_id) machines. Les coûts ne sont fournis qu'à l'administrateur."""
    try:
        periode, du, au = _lire_periode()
    except ValueError as e:
        return erreur(str(e), 400)
    # ?couts=0 : l'accueil n'affiche que la disponibilité, inutile de calculer les coûts toutes les 30 s
    admin = current_user.role == "admin" and request.args.get("couts") != "0"
    return jsonify(
        donnees_tableau(periode, du, au, admin, request.args.get("atelier_id", type=int), tendance=request.args.get("couts") != "0")
    )


TENDANCE = ("disponibilite", "mtbf_h", "mttr_h", "nb_pannes", "temps_arret_h")


def donnees_tableau(periode, du, au, avec_couts, atelier_id=None, tendance=True):
    """Parc, ateliers et (si atelier_id) machines sur la période. tendance=True : chaque bloc porte aussi
    « precedent », les mêmes indicateurs sur la période précédente (flèches ↗ ↘ du tableau de bord)."""
    toutes = _machines()
    par_atelier = defaultdict(list)
    for m in toutes:
        par_atelier[m.atelier_id].append(m)
    avant_du, avant_au = precedente(periode, du)

    def bloc(machines):
        d = calcul(machines, du, au, avec_couts)
        if tendance:
            avant = calcul(machines, avant_du, avant_au)
            d["precedent"] = {cle: avant[cle] for cle in TENDANCE}
        return d

    resultat = {
        "periode": {"type": periode, "du": du.isoformat(), "au": (au - timedelta(days=1)).isoformat()},
        "parc": bloc(toutes),
        "ateliers": [
            {"id": a.id, "nom": a.nom, "nb_machines": len(par_atelier[a.id]), **bloc(par_atelier[a.id])}
            for a in Atelier.query.order_by(Atelier.ordre, Atelier.nom)
        ],
    }
    if atelier_id:
        resultat["machines"] = [{"id": m.id, "repere": m.repere, "designation": m.designation, **bloc([m])} for m in par_atelier[atelier_id]]
    return resultat


@bp.get("/indicateurs/machines/<int:machine_id>/evolution")
@role_required(*EQUIPE)
@unlock_required("indicateurs")
def evolution(machine_id):
    """Indicateurs calculés d'une machine sur les 12 dernières périodes (graphiques d'évolution, ANA-03)."""
    machine = db.session.get(Machine, machine_id)
    if not machine:
        return erreur("Machine introuvable.", 404)
    try:
        periode, du, au = _lire_periode()
    except ValueError as e:
        return erreur(str(e), 400)
    points = []
    for _ in range(min(request.args.get("n", 12, type=int), 24)):
        points.append({"debut": du.isoformat(), **calcul([machine], du, au, current_user.role == "admin")})
        du, au = precedente(periode, du)
    return jsonify(points=list(reversed(points)))


# ---------- Pareto (ANA-07) ----------

CRITERES = {
    "arret": "Temps d'arrêt (h)",
    "pannes": "Nombre de pannes",
    "reparation": "Temps de réparation (h)",
    "couts": "Coûts (€)",
}


@bp.get("/indicateurs/pareto")
@role_required(*EQUIPE)
@unlock_required("indicateurs")
def pareto():
    """Classement ABC par machine ou par élément : A jusqu'à 80 % du cumul, B jusqu'à 95 %, C au-delà."""
    critere = request.args.get("critere", "arret")
    groupe = request.args.get("groupe", "machine")
    if critere not in CRITERES or groupe not in ("machine", "element"):
        return erreur("Critère ou regroupement inconnu.", 400)
    if critere == "couts" and current_user.role != "admin":
        return erreur("Le Pareto des coûts est réservé à l'administrateur.", 403)
    try:
        periode, du, au = _lire_periode()
    except ValueError as e:
        return erreur(str(e), 400)
    machines = {m.id: m for m in _machines(atelier_id=request.args.get("atelier_id", type=int))}
    valeurs = defaultdict(float)
    taux_mo = parametre("taux_main_oeuvre")
    for machine_id, bons in _bons_periode(du, au, list(machines)).items():
        m = machines[machine_id]
        for b in bons:
            if critere != "couts" and b.type_travail != "depannage":
                continue
            if groupe == "machine":
                cle = f"{m.repere} — {m.designation}"
            else:
                cle = b.element.nom if b.element else "Élément non renseigné"
            if critere == "arret":
                valeurs[cle] += b.duree_arret_h or 0
            elif critere == "pannes":
                valeurs[cle] += 1
            elif critere == "reparation":
                valeurs[cle] += b.temps_passe_h or 0
            else:
                heures = b.temps_passe_h or 0
                valeurs[cle] += b.cout_composants + heures * (b.effectif or 1) * taux_mo
                valeurs[cle] += heures * (m.taux_horaire or 0) if b.machine_arretee else 0
    lignes = sorted(((cle, v) for cle, v in valeurs.items() if v > 0), key=lambda x: -x[1])
    total = sum(v for _, v in lignes)
    resultat, cumul = [], 0.0
    for cle, v in lignes:
        avant = cumul / total * 100 if total else 0
        cumul += v
        resultat.append(
            {"nom": cle, "valeur": round(v, 2), "pourcentage": round(v / total * 100, 1), "cumul": round(cumul / total * 100, 1),
             "classe": "A" if avant < 80 else "B" if avant < 95 else "C"}
        )
    return jsonify(critere=CRITERES[critere], total=round(total, 2), lignes=resultat,
                   periode={"type": periode, "du": du.isoformat(), "au": (au - timedelta(days=1)).isoformat()})


# ---------- Coûts (calcul automatique : administrateur) ----------

@bp.get("/indicateurs/couts")
@role_required("admin")
def tableau_couts():
    try:
        periode, du, au = _lire_periode()
    except ValueError as e:
        return erreur(str(e), 400)
    toutes = _machines()
    bons = _bons_periode(du, au, [m.id for m in toutes])
    par_atelier = defaultdict(list)
    for m in toutes:
        par_atelier[m.atelier_id].append(m)
    machines = sorted(
        ({"id": m.id, "repere": m.repere, "designation": m.designation, **couts([m], du, au, bons)} for m in toutes),
        key=lambda x: -x["total"],
    )
    # Évolution : mois de l'année scolaire, ou 12 dernières périodes
    evolution = []
    if periode == "annee":
        debut = du
        while debut < au:
            fin = _ajouter_mois(debut, 1)
            evolution.append({"debut": debut.isoformat(), **couts(toutes, debut, fin)})
            debut = fin
    else:
        d, a = du, au
        for _ in range(12):
            evolution.append({"debut": d.isoformat(), **couts(toutes, d, a)})
            d, a = precedente(periode, d)
        evolution.reverse()
    return jsonify(
        periode={"type": periode, "du": du.isoformat(), "au": (au - timedelta(days=1)).isoformat()},
        parc=couts(toutes, du, au, bons),
        ateliers=[{"id": a.id, "nom": a.nom, **couts(par_atelier[a.id], du, au, bons)} for a in Atelier.query.order_by(Atelier.ordre, Atelier.nom)],
        machines=[m for m in machines if m["total"] > 0][:15],
        evolution=evolution,
        taux_main_oeuvre=parametre("taux_main_oeuvre"),
    )


# ---------- Export tableur (ANA-09) ----------

def _decimal(n):
    return "" if n is None else f"{n:.2f}".rstrip("0").rstrip(".").replace(".", ",")


@bp.get("/indicateurs/export.csv")
@role_required(*EQUIPE)
@unlock_required("indicateurs")
def export():
    try:
        periode, du, au = _lire_periode()
    except ValueError as e:
        return erreur(str(e), 400)
    admin = current_user.role == "admin"
    entetes = ["Atelier", "Repère", "Machine", "Heures d'utilisation", "Pannes", "Temps de réparation (h)",
               "Temps d'arrêt (h)", "MTBF (h)", "MTTR (h)", "Disponibilité (%)"]
    if admin:
        entetes += ["Coût pièces", "Coût main-d'œuvre", "Coût immobilisation", "Coût total"]
    sortie = io.StringIO()
    ecrivain = tableur.ecrivain(sortie)
    ecrivain.writerow(entetes)
    for m in _machines(atelier_id=request.args.get("atelier_id", type=int)):
        c = calcul([m], du, au, admin)
        ligne = [m.atelier.nom, m.repere, m.designation, _decimal(c["heures_utilisation"]), c["nb_pannes"],
                 _decimal(c["temps_reparation_h"]), _decimal(c["temps_arret_h"]), _decimal(c["mtbf_h"]),
                 _decimal(c["mttr_h"]), _decimal(c["disponibilite"])]
        if admin:
            ligne += [_decimal(c["couts"][k]) for k in ("pieces", "main_oeuvre", "immobilisation", "total")]
        ecrivain.writerow(ligne)
    return Response(
        "﻿" + sortie.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename=indicateurs-{periode}-{du.isoformat()}.csv"},
    )


# ---------- Saisies des élèves (mode manuel) ----------

CHAMPS_SAISIE = {
    "mtbf_h": ("MTBF", 0, 1_000_000),
    "mttr_h": ("MTTR", 0, 100_000),
    "disponibilite": ("Disponibilité", 0, 100),
    "cout_pieces": ("Coût des pièces", 0, 10_000_000),
    "cout_main_oeuvre": ("Coût de main-d'œuvre", 0, 10_000_000),
    "cout_immobilisation": ("Coût d'immobilisation", 0, 10_000_000),
}


def _filtrer_saisies(requete):
    args = request.args
    if args.get("machine_id", type=int):
        requete = requete.filter(SaisieIndicateurs.machine_id == args.get("machine_id", type=int))
    if args.get("atelier_id", type=int):
        requete = requete.filter(Machine.atelier_id == args.get("atelier_id", type=int))
    return requete


def agreger(saisies, du, au):
    """Regroupe les saisies d'une machine dont la date tombe dans [du, au[ (choix de Simon : une saisie
    hebdomadaire compte aussi dans le mois, le trimestre et l'année).
    Pas de double comptage : les saisies les plus longues passent d'abord, et une saisie qui chevauche
    une saisie déjà retenue est écartée. Coûts : somme ; MTBF, MTTR, disponibilité : moyenne pondérée par la durée."""
    candidates = [(s, *bornes(s.periode, s.debut)) for s in saisies if du <= s.debut < au]
    candidates.sort(key=lambda c: -(c[2] - c[1]).days)
    retenues = []
    for s, debut, fin in candidates:
        if all(fin <= d or debut >= f for _, d, f in retenues):
            retenues.append((s, debut, fin))
    if not retenues:
        return None

    def moyenne(cle):
        valeurs = [(getattr(s, cle), (f - d).days) for s, d, f in retenues if getattr(s, cle) is not None]
        poids = sum(p for _, p in valeurs)
        return round(sum(v * p for v, p in valeurs) / poids, 2) if poids else None

    def somme(cle):
        valeurs = [getattr(s, cle) for s, _, _ in retenues if getattr(s, cle) is not None]
        return round(sum(valeurs), 2) if valeurs else None

    resultat = {
        "mtbf_h": moyenne("mtbf_h"),
        "mttr_h": moyenne("mttr_h"),
        "disponibilite": moyenne("disponibilite"),
        "cout_pieces": somme("cout_pieces"),
        "cout_main_oeuvre": somme("cout_main_oeuvre"),
        "cout_immobilisation": somme("cout_immobilisation"),
        "nb_saisies": len(retenues),
        "saisi_par": sorted({s.saisi_par.nom for s, _, _ in retenues if s.saisi_par}),
    }
    couts = [resultat[c] for c in ("cout_pieces", "cout_main_oeuvre", "cout_immobilisation")]
    resultat["cout_total"] = None if all(c is None for c in couts) else round(sum(c or 0 for c in couts), 2)
    resultat["pastille"] = pastille(resultat["disponibilite"])
    return resultat


@bp.get("/indicateurs/saisies")
@role_required(*EQUIPE)
def liste_saisies():
    """Saisies brutes. Avec une période : toutes celles dont la date tombe dans la période, quel que soit leur type."""
    requete = _filtrer_saisies(SaisieIndicateurs.query.join(Machine))
    if request.args.get("debut"):
        try:
            _, du, au = _lire_periode()
        except ValueError as e:
            return erreur(str(e), 400)
        requete = requete.filter(SaisieIndicateurs.debut >= du, SaisieIndicateurs.debut < au)
    saisies = requete.order_by(SaisieIndicateurs.debut.desc(), Machine.repere).limit(2000).all()
    return jsonify(saisies=[s.to_dict() for s in saisies])


@bp.get("/indicateurs/saisies/agregees")
@role_required(*EQUIPE)
def saisies_agregees():
    """Valeurs des élèves regroupées par machine sur une période (tableaux de bord en mode manuel)."""
    try:
        periode, du, au = _lire_periode()
    except ValueError as e:
        return erreur(str(e), 400)
    requete = _filtrer_saisies(SaisieIndicateurs.query.join(Machine)).filter(
        SaisieIndicateurs.debut >= du, SaisieIndicateurs.debut < au
    )
    par_machine = defaultdict(list)
    for s in requete:
        par_machine[s.machine].append(s)
    machines = []
    for m, liste in sorted(par_machine.items(), key=lambda x: x[0].repere):
        a = agreger(liste, du, au)
        if a:
            machines.append({"machine": {"id": m.id, "repere": m.repere, "designation": m.designation, "atelier_id": m.atelier_id}, **a})
    return jsonify(periode={"type": periode, "du": du.isoformat(), "au": (au - timedelta(days=1)).isoformat()}, machines=machines)


@bp.get("/indicateurs/machines/<int:machine_id>/saisies-evolution")
@role_required(*EQUIPE)
def evolution_saisies(machine_id):
    """Valeurs des élèves d'une machine sur les 12 dernières périodes (courbes de l'onglet Suivi)."""
    if not db.session.get(Machine, machine_id):
        return erreur("Machine introuvable.", 404)
    try:
        periode, du, au = _lire_periode()
    except ValueError as e:
        return erreur(str(e), 400)
    saisies = SaisieIndicateurs.query.filter_by(machine_id=machine_id).all()
    points = []
    for _ in range(min(request.args.get("n", 12, type=int), 24)):
        points.append({"debut": du.isoformat(), **(agreger(saisies, du, au) or {})})
        du, au = precedente(periode, du)
    return jsonify(points=list(reversed(points)))


@bp.put("/indicateurs/saisies")
@role_required(*EQUIPE)
def enregistrer_saisie():
    """Crée ou remplace la saisie d'une machine pour une période."""
    donnees = request.get_json(silent=True) or {}
    try:
        machine = db.session.get(Machine, int(donnees.get("machine_id")))
    except (TypeError, ValueError):
        machine = None
    if not machine:
        return erreur("Choisissez la machine.", 400)
    periode = donnees.get("periode")
    if periode not in ref.PERIODES_ANALYSE:
        return erreur("Choisissez la période.", 400)
    try:
        debut = bornes(periode, date.fromisoformat(str(donnees.get("debut"))))[0]
    except ValueError:
        return erreur("Date de la période invalide.", 400)
    valeurs = {}
    for cle, (libelle, mini, maxi) in CHAMPS_SAISIE.items():
        brut = donnees.get(cle)
        if brut is None or str(brut).strip() == "":
            valeurs[cle] = None
            continue
        try:
            n = float(str(brut).replace(",", ".").strip())
        except ValueError:
            return erreur(f"« {libelle} » doit être un nombre.", 400)
        if not mini <= n <= maxi:
            return erreur(f"« {libelle} » doit être compris entre {mini:g} et {maxi:g}.", 400)
        valeurs[cle] = n
    if all(v is None for v in valeurs.values()):
        return erreur("Saisissez au moins une valeur.", 400)
    saisie = SaisieIndicateurs.query.filter_by(machine_id=machine.id, periode=periode, debut=debut).first()
    if not saisie:
        saisie = SaisieIndicateurs(machine=machine, periode=periode, debut=debut)
        db.session.add(saisie)
    for cle, v in valeurs.items():
        setattr(saisie, cle, v)
    saisie.commentaire = str(donnees.get("commentaire") or "").strip() or None
    saisie.saisi_par_id = current_user.id
    db.session.flush()
    journaliser("saisie_indicateurs", saisie, f"{machine.repere} — {periode} du {debut:%d/%m/%Y}")
    db.session.commit()
    return jsonify(saisie=saisie.to_dict())


@bp.delete("/indicateurs/saisies/<int:saisie_id>")
@role_required(*EQUIPE)
def supprimer_saisie(saisie_id):
    saisie = db.session.get(SaisieIndicateurs, saisie_id)
    if not saisie:
        return erreur("Saisie introuvable.", 404)
    if current_user.role != "admin" and saisie.saisi_par_id != current_user.id:
        return erreur("Seul l'auteur de la saisie (ou un administrateur) peut la supprimer.", 403)
    journaliser("suppression", saisie, saisie.machine.repere)
    db.session.delete(saisie)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Maintenance conditionnelle (ANA-04) ----------

def gravite(type_releve, resultat):
    if type_releve == "thermique":
        return ref.ETATS_THERMIQUES[resultat][1]
    if type_releve == "vibratoire":
        return ref.DEFAUTS_VIBRATOIRES[resultat][1]
    classe = int(resultat)
    return "alerte" if classe >= reglage("huile_alerte") else "surveiller" if classe >= reglage("huile_surveiller") else "ok"


def libelle(type_releve, resultat):
    if type_releve == "thermique":
        return ref.ETATS_THERMIQUES[resultat][0]
    if type_releve == "vibratoire":
        return ref.DEFAUTS_VIBRATOIRES[resultat][0]
    return f"Classe NAS {resultat}"


def releve_dict(r):
    return {
        "id": r.id,
        "machine_id": r.machine_id,
        "date": r.date.isoformat(),
        "type": r.type,
        "resultat": r.resultat,
        "libelle": libelle(r.type, r.resultat),
        "gravite": gravite(r.type, r.resultat),
        "commentaire": r.commentaire,
        "par": r.par.nom if r.par else None,
    }


@bp.get("/conditionnel/referentiels")
@role_required(*EQUIPE)
def referentiels_conditionnel():
    return jsonify(
        thermique={k: v[0] for k, v in ref.ETATS_THERMIQUES.items()},
        vibratoire={k: v[0] for k, v in ref.DEFAUTS_VIBRATOIRES.items()},
        huile={str(c): f"Classe NAS {c}" for c in ref.CLASSES_HUILE},
    )


@bp.get("/machines/<int:machine_id>/releves")
@role_required(*EQUIPE)
def releves_machine(machine_id):
    releves = (
        ReleveConditionnel.query.filter_by(machine_id=machine_id)
        .order_by(ReleveConditionnel.date.desc(), ReleveConditionnel.id.desc())
        .limit(300)
        .all()
    )
    return jsonify(releves=[releve_dict(r) for r in releves])


@bp.post("/machines/<int:machine_id>/releves")
@role_required(*EQUIPE)
def ajouter_releve(machine_id):
    machine = db.session.get(Machine, machine_id)
    if not machine:
        return erreur("Machine introuvable.", 404)
    donnees = request.get_json(silent=True) or {}
    type_releve = donnees.get("type")
    resultat = str(donnees.get("resultat") or "")
    valides = {
        "thermique": ref.ETATS_THERMIQUES,
        "vibratoire": ref.DEFAUTS_VIBRATOIRES,
        "huile": {str(c): None for c in ref.CLASSES_HUILE},
    }
    if type_releve not in valides:
        return erreur("Choisissez le type de relevé.", 400)
    if resultat not in valides[type_releve]:
        return erreur("Choisissez le résultat du relevé.", 400)
    try:
        jour = date.fromisoformat(str(donnees.get("date"))) if donnees.get("date") else datetime.now(PARIS).date()
    except ValueError:
        return erreur("Date invalide.", 400)
    releve = ReleveConditionnel(
        machine=machine, date=jour, type=type_releve, resultat=resultat,
        commentaire=str(donnees.get("commentaire") or "").strip() or None, par_id=current_user.id,
    )
    db.session.add(releve)
    db.session.flush()
    journaliser("creation", releve, f"{machine.repere} — {libelle(type_releve, resultat)}")
    db.session.commit()
    return jsonify(releve=releve_dict(releve)), 201


@bp.delete("/releves/<int:releve_id>")
@role_required(*EQUIPE)
def supprimer_releve(releve_id):
    releve = db.session.get(ReleveConditionnel, releve_id)
    if not releve:
        return erreur("Relevé introuvable.", 404)
    if current_user.role != "admin" and releve.par_id != current_user.id:
        return erreur("Seul l'auteur du relevé (ou un administrateur) peut le supprimer.", 403)
    journaliser("suppression", releve, releve.machine.repere)
    db.session.delete(releve)
    db.session.commit()
    return jsonify(ok=True)


@bp.get("/conditionnel/etat")
@role_required(*EQUIPE)
def etat_conditionnel():
    """Dernier relevé de chaque type, par machine (pour les tableaux de bord)."""
    requete = ReleveConditionnel.query.join(Machine)
    if request.args.get("atelier_id", type=int):
        requete = requete.filter(Machine.atelier_id == request.args.get("atelier_id", type=int))
    derniers = {}
    for r in requete.order_by(ReleveConditionnel.date, ReleveConditionnel.id):
        derniers[(r.machine_id, r.type)] = r
    etat = defaultdict(dict)
    for (machine_id, type_releve), r in derniers.items():
        etat[machine_id][type_releve] = releve_dict(r)
    return jsonify(etat={str(k): v for k, v in etat.items()})
