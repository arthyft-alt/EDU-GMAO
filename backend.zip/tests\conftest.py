import json

import pytest

from app import create_app, db
from app.cli import seed
from app.models import Parametre


@pytest.fixture(autouse=True)
def hachage_rapide(monkeypatch):
    """Hachage des mots de passe allégé pendant les tests (volontairement lent en vrai)."""
    monkeypatch.setattr("app.models.METHODE_HACHAGE", "pbkdf2:sha256:1000")


# Code du jour connu des tests (en vrai, tiré au sort chaque jour)
CODE_DU_JOUR = "1234"


def fixer_code_du_jour(code):
    from app.auth import CLE_CODE_DU_JOUR
    from app.preventif import aujourdhui

    db.session.add(Parametre(cle=CLE_CODE_DU_JOUR, valeur=json.dumps({"jour": aujourdhui().isoformat(), "code": code})))
    db.session.commit()


@pytest.fixture()
def app(tmp_path):
    app = create_app(
        {
            "TESTING": True,
            "SQLALCHEMY_DATABASE_URI": "sqlite:///" + (tmp_path / "test.db").as_posix(),
            "UPLOAD_DIR": tmp_path / "uploads",
            "SAUVEGARDE_DIR": tmp_path / "sauvegardes",
        }
    )
    with app.app_context():
        db.create_all()
        seed(demo=True)
        fixer_code_du_jour(CODE_DU_JOUR)
        yield app
        db.session.remove()


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def connecter(client):
    """connecter("tech") ouvre une session avec un compte de démo."""

    def _connecter(login):
        reponse = client.post("/api/auth/login", json={"login": login, "password": login})
        assert reponse.status_code == 200, reponse.get_json()
        return client

    return _connecter
