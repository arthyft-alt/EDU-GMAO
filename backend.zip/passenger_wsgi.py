"""Point d'entrée pour l'hébergeur cPanel (Passenger).

Passenger monte l'application sur /api et retire ce préfixe de l'adresse :
on le remet pour garder exactement les mêmes routes qu'en local.
"""
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from app import create_app  # noqa: E402

flask_app = create_app()


def application(environ, start_response):
    environ["PATH_INFO"] = environ.get("SCRIPT_NAME", "") + environ.get("PATH_INFO", "")
    environ["SCRIPT_NAME"] = ""
    return flask_app(environ, start_response)
