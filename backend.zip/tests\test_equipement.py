import io

import pytest

from app import db
from app.models import Atelier, JournalAction, Machine

MDP = {"X-Unlock-Password": "1234"}  # code du jour fixé par conftest


def atelier_id(nom="03. Fonderie"):
    return Atelier.query.filter_by(nom=nom).one().id


def donnees_machine(**autres):
    return {"repere": "fon-01", "designation": "Four de fusion", "atelier_id": atelier_id(), **autres}


@pytest.fixture()
def machine(app):
    m = Machine(repere="MAI-01", designation="Tour conventionnel", atelier_id=atelier_id("01. Maintenance"))
    db.session.add(m)
    db.session.commit()
    return m


# ---------- Création et droits ----------

def test_technicien_cree_une_machine_avec_le_mot_de_passe(client, connecter):
    connecter("tech")
    reponse = client.post("/api/machines", json=donnees_machine(compteur_heures="1 250,5".replace(" ", "")), headers=MDP)
    assert reponse.status_code == 201
    m = reponse.get_json()["machine"]
    assert m["repere"] == "FON-01"  # mis en majuscules
    assert m["atelier"] == "03. Fonderie"
    assert m["compteur_heures"] == 1250.5  # virgule décimale acceptée
    assert JournalAction.query.filter_by(action="creation", objet_type="Machine").count() == 1


def test_technicien_sans_mot_de_passe_refuse(client, connecter):
    connecter("tech")
    reponse = client.post("/api/machines", json=donnees_machine())
    assert reponse.status_code == 403
    assert "Code du jour" in reponse.get_json()["error"]
    assert Machine.query.count() == 0


def test_mot_de_passe_demande_a_chaque_action(client, connecter, machine):
    connecter("tech")
    assert client.put(f"/api/machines/{machine.id}", json=donnees_machine(repere="MAI-01"), headers=MDP).status_code == 200
    assert client.put(f"/api/machines/{machine.id}", json=donnees_machine(repere="MAI-01")).status_code == 403


def test_admin_dispense_de_mot_de_passe(client, connecter):
    connecter("admin")
    assert client.post("/api/machines", json=donnees_machine()).status_code == 201


def test_operateur_ne_peut_pas_creer_meme_avec_le_mot_de_passe(client, connecter):
    connecter("operateur")
    assert client.post("/api/machines", json=donnees_machine(), headers=MDP).status_code == 403


def test_operateur_peut_consulter_une_fiche(client, connecter, machine):
    connecter("operateur")
    reponse = client.get(f"/api/machines/{machine.id}")
    assert reponse.status_code == 200
    assert reponse.get_json()["machine"]["designation"] == "Tour conventionnel"


# ---------- Validation ----------

@pytest.mark.parametrize(
    "champs,message",
    [
        ({"repere": ""}, "Repère"),
        ({"designation": "  "}, "Désignation"),
        ({"atelier_id": 9999}, "atelier"),
        ({"atelier_id": "abc"}, "atelier"),
        ({"annee_mise_en_service": "1850"}, "Année"),
        ({"annee_mise_en_service": "2020,5"}, "entier"),
        ({"utilisation_hebdo_h": "200"}, "semaine"),
        ({"compteur_heures": "beaucoup"}, "nombre"),
        ({"repere": "X" * 21}, "20 caractères"),
    ],
)
def test_erreurs_de_saisie(client, connecter, champs, message):
    connecter("admin")
    reponse = client.post("/api/machines", json=donnees_machine(**champs))
    assert reponse.status_code == 400
    assert message in reponse.get_json()["error"]
    assert Machine.query.count() == 0


def test_repere_unique_insensible_a_la_casse(client, connecter, machine):
    connecter("admin")
    reponse = client.post("/api/machines", json=donnees_machine(repere="mai-01"))
    assert reponse.status_code == 400
    assert "déjà utilisé" in reponse.get_json()["error"]


def test_champs_facultatifs_vides(client, connecter):
    connecter("admin")
    m = client.post("/api/machines", json=donnees_machine(marque="", numero_serie=None, annee_mise_en_service="")).get_json()["machine"]
    assert m["marque"] is None and m["numero_serie"] is None and m["annee_mise_en_service"] is None


# ---------- Liste, recherche, hors service ----------

def test_liste_recherche_et_filtre(client, connecter, machine):
    connecter("admin")
    client.post("/api/machines", json=donnees_machine(marque="Nabertherm"))
    assert len(client.get("/api/machines").get_json()["machines"]) == 2
    assert [m["repere"] for m in client.get("/api/machines?q=naber").get_json()["machines"]] == ["FON-01"]
    assert [m["repere"] for m in client.get(f"/api/machines?atelier_id={machine.atelier_id}").get_json()["machines"]] == ["MAI-01"]


def test_hors_service_retire_des_listes(client, connecter, machine):
    connecter("tech")
    assert client.post(f"/api/machines/{machine.id}/hors-service", json={"hors_service": True}, headers=MDP).status_code == 200
    assert client.get("/api/machines").get_json()["machines"] == []
    assert len(client.get("/api/machines?hors_service=1").get_json()["machines"]) == 1
    arbo = {a["nom"]: a["nb_machines"] for a in client.get("/api/arborescence").get_json()["ateliers"]}
    assert arbo["01. Maintenance"] == 0
    client.post(f"/api/machines/{machine.id}/hors-service", json={"hors_service": False}, headers=MDP)
    assert len(client.get("/api/machines").get_json()["machines"]) == 1


def test_suppression(client, connecter, machine):
    connecter("tech")
    assert client.delete(f"/api/machines/{machine.id}").status_code == 403
    assert client.delete(f"/api/machines/{machine.id}", headers=MDP).status_code == 200
    assert Machine.query.count() == 0
    assert client.get(f"/api/machines/{machine.id}").status_code == 404


def test_suppression_refusee_si_historique(client, connecter, machine, monkeypatch):
    monkeypatch.setattr("app.equipement.machine_a_un_historique", lambda m: True)
    connecter("admin")
    reponse = client.delete(f"/api/machines/{machine.id}")
    assert reponse.status_code == 409
    assert "hors service" in reponse.get_json()["error"]


# ---------- Photo ----------

def test_photo(client, connecter, machine, app):
    connecter("tech")
    image = (io.BytesIO(b"\xff\xd8\xff fausse image jpeg"), "photo.jpg", "image/jpeg")
    assert client.post(f"/api/machines/{machine.id}/photo", data={"photo": image}, content_type="multipart/form-data").status_code == 403
    image = (io.BytesIO(b"\xff\xd8\xff fausse image jpeg"), "photo.jpg", "image/jpeg")
    reponse = client.post(f"/api/machines/{machine.id}/photo", data={"photo": image}, content_type="multipart/form-data", headers=MDP)
    assert reponse.status_code == 200
    assert reponse.get_json()["machine"]["photo"] is True
    assert client.get(f"/api/machines/{machine.id}/photo").data.startswith(b"\xff\xd8\xff")
    fichier = app.config["UPLOAD_DIR"] / "machines" / db.session.get(Machine, machine.id).photo
    assert fichier.exists()
    assert client.delete(f"/api/machines/{machine.id}/photo", headers=MDP).status_code == 200
    assert not fichier.exists()


def test_photo_format_refuse(client, connecter, machine):
    connecter("admin")
    fichier = (io.BytesIO(b"%PDF"), "notice.pdf", "application/pdf")
    reponse = client.post(f"/api/machines/{machine.id}/photo", data={"photo": fichier}, content_type="multipart/form-data")
    assert reponse.status_code == 400


# ---------- Administration : ateliers, éléments, code du jour ----------

def test_ateliers_reserves_a_l_admin(client, connecter):
    connecter("tech")
    assert client.post("/api/admin/ateliers", json={"nom": "09. Soudure"}).status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    reponse = client.post("/api/admin/ateliers", json={"nom": "09. Soudure"})
    assert reponse.status_code == 201
    assert reponse.get_json()["ordre"] == 9
    assert client.post("/api/admin/ateliers", json={"nom": "09. soudure"}).status_code == 409
    nouvel_id = reponse.get_json()["id"]
    assert client.put(f"/api/admin/ateliers/{nouvel_id}", json={"nom": "09. Soudage"}).get_json()["nom"] == "09. Soudage"
    assert client.delete(f"/api/admin/ateliers/{nouvel_id}").status_code == 200


def test_atelier_avec_machines_non_supprimable(client, connecter, machine):
    connecter("admin")
    reponse = client.delete(f"/api/admin/ateliers/{machine.atelier_id}")
    assert reponse.status_code == 409
    assert "1 machine" in reponse.get_json()["error"]


def test_elements_admin(client, connecter):
    connecter("admin")
    reponse = client.post("/api/admin/elements", json={"nom": "26 Protéger"})
    assert reponse.status_code == 201
    assert client.post("/api/admin/elements", json={"nom": ""}).status_code == 400


def test_code_du_jour_lisible_et_renouvelable_par_l_admin(client, connecter, machine):
    connecter("tech")
    assert client.get("/api/admin/code-du-jour").status_code == 403
    assert client.post("/api/admin/code-du-jour/renouveler").status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    assert client.get("/api/admin/code-du-jour").get_json()["code"] == "1234"
    nouveau = client.post("/api/admin/code-du-jour/renouveler").get_json()["code"]
    assert len(nouveau) == 4 and nouveau.isdigit() and nouveau != "1234"
    assert client.get("/api/admin/code-du-jour").get_json()["code"] == nouveau
    client.post("/api/auth/logout")
    connecter("tech")
    assert client.delete(f"/api/machines/{machine.id}", headers=MDP).status_code == 403  # l'ancien code ne marche plus
    assert client.delete(f"/api/machines/{machine.id}", headers={"X-Unlock-Password": nouveau}).status_code == 200


def test_nouveau_code_chaque_jour(app, monkeypatch):
    from datetime import date

    from app.auth import code_du_jour

    assert code_du_jour() == "1234"
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: date(2099, 1, 2))
    lendemain = code_du_jour()
    assert lendemain != "1234" and len(lendemain) == 4 and code_du_jour() == lendemain  # stable dans la journée
