"""Module Maintenance corrective : bons d'intervention, répartition, compte-rendu, historique (COR-01 à COR-08)."""
import io
from datetime import date, timedelta

from flask import Blueprint, Response, jsonify, request
from flask_login import current_user, login_required
from sqlalchemy import or_
from sqlalchemy.orm import joinedload, selectinload

from . import db, tableur
from . import referentiels as ref
from .auth import erreur, role_required
from .dates import debut_jour_paris, fin_jour_paris, format_paris, lire_iso
from .models import BonComposant, BonIntervention, Machine, Parametre, Piece, Utilisateur, journaliser, maintenant
from . import stock
from .reglages import types_travaux

bp = Blueprint("interventions", __name__)

EQUIPE = ("admin", "technicien")
ORDRE_URGENCE = {"critique": 0, "normale": 1, "faible": 2}


class Invalide(Exception):
    pass


def _equipe():
    return current_user.role in EQUIPE


def _bon_ou_404(bon_id):
    # Tout utilisateur connecté peut consulter un bon ; seuls admin et techniciens le modifient
    bon = db.session.get(BonIntervention, bon_id)
    if not bon:
        return None, erreur("Bon d'intervention introuvable.", 404)
    return bon, None


def _nouveau_numero():
    annee = maintenant().year
    prefixe = f"BI-{annee}-"
    dernier = (
        BonIntervention.query.filter(BonIntervention.numero.like(f"{prefixe}%"))
        .order_by(BonIntervention.numero.desc())
        .first()
    )
    suivant = int(dernier.numero.rsplit("-", 1)[1]) + 1 if dernier else 1
    return f"{prefixe}{suivant:04d}"


def _choix(valeur, liste, libelle):
    if valeur not in liste:
        raise Invalide(f"Choisissez {libelle}.")
    return valeur


def _texte(donnees, cle, libelle, obligatoire=False, longueur=5000):
    valeur = (str(donnees.get(cle) or "")).strip()
    if obligatoire and not valeur:
        raise Invalide(f"Le champ « {libelle} » est obligatoire.")
    if len(valeur) > longueur:
        raise Invalide(f"Le champ « {libelle} » ne doit pas dépasser {longueur} caractères.")
    return valeur or None


def _nombre(donnees, cle, libelle, mini, maxi, entier=False):
    valeur = donnees.get(cle)
    if valeur is None or str(valeur).strip() == "":
        return None
    try:
        nombre = float(str(valeur).replace(",", ".").strip())
    except ValueError:
        raise Invalide(f"« {libelle} » doit être un nombre.")
    if entier and not nombre.is_integer():
        raise Invalide(f"« {libelle} » doit être un nombre entier.")
    if not mini <= nombre <= maxi:
        raise Invalide(f"« {libelle} » doit être compris entre {mini} et {maxi}.")
    return int(nombre) if entier else nombre


def _composants(lignes):
    """Liste des composants utilisés envoyée par l'écran -> objets BonComposant."""
    if not isinstance(lignes, list):
        raise Invalide("Liste des composants invalide.")
    resultat = []
    for numero, ligne in enumerate(lignes, start=1):
        if not isinstance(ligne, dict):
            raise Invalide("Liste des composants invalide.")
        quantite = _nombre(ligne, "quantite", f"Quantité du composant n° {numero}", 0.01, 100000)
        prix = _nombre(ligne, "prix_unitaire", f"Prix du composant n° {numero}", 0, 1000000)
        piece = None
        if ligne.get("piece_id") not in (None, ""):
            # Pièce du magasin : désignation et référence reprises de la fiche, prix par défaut aussi
            try:
                piece = db.session.get(Piece, int(ligne["piece_id"]))
            except (TypeError, ValueError):
                piece = None
            if not piece:
                raise Invalide(f"Composant n° {numero} : pièce introuvable dans le magasin.")
            designation, reference = piece.designation, piece.reference
            if prix is None:
                prix = piece.prix_unitaire
        else:
            designation = (str(ligne.get("designation") or "")).strip()
            reference = (str(ligne.get("reference") or "")).strip()[:80] or None
            if not designation:
                raise Invalide(f"Composant n° {numero} : indiquez sa désignation.")
        resultat.append(
            BonComposant(
                piece_id=piece.id if piece else None,
                designation=designation[:160],
                reference=reference,
                quantite=quantite if quantite is not None else 1,
                prix_unitaire=prix,
            )
        )
    return resultat


def _filtrer(requete):
    """Filtres communs à la liste et à l'export."""
    args = request.args
    statut = args.get("statut")
    if statut == "ouverts":
        requete = requete.filter(BonIntervention.statut != "termine")
    elif statut:
        requete = requete.filter(BonIntervention.statut.in_(statut.split(",")))
    if args.get("machine_id", type=int):
        requete = requete.filter(BonIntervention.machine_id == args.get("machine_id", type=int))
    if args.get("type"):
        requete = requete.filter(BonIntervention.type_travail == args["type"])
    technicien = args.get("technicien_id")
    if technicien == "aucun":
        requete = requete.filter(~BonIntervention.techniciens.any())
    elif technicien and technicien.isdigit():
        requete = requete.filter(BonIntervention.techniciens.any(Utilisateur.id == int(technicien)))
    try:
        if args.get("du"):
            requete = requete.filter(BonIntervention.cree_le >= debut_jour_paris(date.fromisoformat(args["du"])))
        if args.get("au"):
            requete = requete.filter(BonIntervention.cree_le < fin_jour_paris(date.fromisoformat(args["au"])))
    except ValueError:
        raise Invalide("Date de filtre invalide.")
    recherche = (args.get("q") or "").strip()
    if recherche:
        motif = f"%{recherche}%"
        requete = requete.join(Machine).filter(
            or_(
                BonIntervention.numero.ilike(motif),
                BonIntervention.description.ilike(motif),
                BonIntervention.demandeur.ilike(motif),
                Machine.repere.ilike(motif),
                Machine.designation.ilike(motif),
            )
        )
    return requete


# ---------- Consultation ----------

@bp.get("/bons")
@login_required
def liste_bons():
    requete = BonIntervention.query
    # ?mes=1 : bons créés depuis le compte connecté (« Mes demandes » de l'opérateur)
    if request.args.get("mes") == "1":
        requete = requete.filter(BonIntervention.cree_par_id == current_user.id)
    try:
        requete = _filtrer(requete)
    except Invalide as e:
        return erreur(str(e), 400)
    bons = avec_details(requete).order_by(BonIntervention.cree_le.desc()).limit(1000).all()
    return jsonify(bons=[b.to_dict() for b in bons])


def avec_details(requete):
    """Tout ce qu'affiche un bon, chargé en quelques requêtes au lieu de plusieurs par bon."""
    return requete.options(
        joinedload(BonIntervention.machine).joinedload(Machine.atelier),
        joinedload(BonIntervention.cree_par),
        joinedload(BonIntervention.element),
        selectinload(BonIntervention.techniciens),
        selectinload(BonIntervention.composants),
    )


@bp.get("/bons/<int:bon_id>")
@login_required
def detail_bon(bon_id):
    bon, err = _bon_ou_404(bon_id)
    if err:
        return err
    return jsonify(bon=bon.to_dict())


@bp.get("/techniciens")
@role_required(*EQUIPE)
def techniciens():
    """Techniciens actifs (une case chacun dans la répartition), avec leur nombre de bons ouverts."""
    liste = Utilisateur.query.filter_by(role="technicien", actif=True).order_by(Utilisateur.nom).all()
    return jsonify(
        techniciens=[
            {
                "id": t.id,
                "nom": t.nom,
                "bons_ouverts": BonIntervention.query.filter(
                    BonIntervention.statut != "termine", BonIntervention.techniciens.any(Utilisateur.id == t.id)
                ).count(),
            }
            for t in liste
        ]
    )


@bp.get("/machines/<int:machine_id>/suivi")
@role_required(*EQUIPE)
def suivi_machine(machine_id):
    """Chiffres de l'onglet « Suivi » de la fiche machine disponibles à ce stade."""
    if not db.session.get(Machine, machine_id):
        return erreur("Machine introuvable.", 404)
    bons = BonIntervention.query.filter_by(machine_id=machine_id)
    il_y_a_un_an = maintenant() - timedelta(days=365)
    return jsonify(
        bons_ouverts=bons.filter(BonIntervention.statut != "termine").count(),
        pannes_12_mois=bons.filter(
            BonIntervention.type_travail == "depannage", BonIntervention.cree_le >= il_y_a_un_an
        ).count(),
    )


# ---------- Création ----------

@bp.post("/bons")
@login_required
def creer_bon():
    donnees = request.get_json(silent=True) or {}
    try:
        try:
            machine = db.session.get(Machine, int(donnees.get("machine_id")))
        except (TypeError, ValueError):
            machine = None
        if not machine or machine.hors_service:
            raise Invalide("Choisissez la machine concernée.")
        demandeur = _texte(donnees, "demandeur", "Votre nom", obligatoire=not _equipe(), longueur=120)
        bon = BonIntervention(
            numero=_nouveau_numero(),
            machine=machine,
            type_travail=_choix(donnees.get("type_travail"), ref.TYPES_TRAVAUX, "le type de travail"),
            urgence=_choix(donnees.get("urgence") or "normale", ref.URGENCES, "le niveau d'urgence"),
            demandeur=demandeur or current_user.nom,
            description=_texte(donnees, "description", "Ce que vous avez constaté", obligatoire=True),
            machine_arretee=bool(donnees.get("machine_arretee")),
            cree_par_id=current_user.id,
        )
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    bon.statut = "demande"
    db.session.add(bon)
    db.session.flush()
    journaliser("creation", bon, f"{bon.numero} — {machine.repere}")
    db.session.commit()
    return jsonify(bon=bon.to_dict()), 201


# ---------- Modification, compte-rendu, clôture ----------

@bp.put("/bons/<int:bon_id>")
@role_required(*EQUIPE)
def modifier_bon(bon_id):
    bon, err = _bon_ou_404(bon_id)
    if err:
        return err
    if bon.statut == "termine" and current_user.role != "admin":
        return erreur("Ce bon est terminé : seul un administrateur peut le rouvrir.", 403)
    donnees = request.get_json(silent=True) or {}
    ancien_statut = bon.statut
    try:
        if "type_travail" in donnees:
            bon.type_travail = _choix(donnees["type_travail"], ref.TYPES_TRAVAUX, "le type de travail")
        if "urgence" in donnees:
            bon.urgence = _choix(donnees["urgence"], ref.URGENCES, "le niveau d'urgence")
        if "description" in donnees:
            bon.description = _texte(donnees, "description", "Description", obligatoire=True)
        if "demandeur" in donnees:
            bon.demandeur = _texte(donnees, "demandeur", "Demandeur", obligatoire=True, longueur=120)
        if "machine_arretee" in donnees:
            bon.machine_arretee = bool(donnees["machine_arretee"])
        if "travaux" in donnees:
            bon.travaux = _texte(donnees, "travaux", "Travaux réalisés")
        if "cause" in donnees:
            bon.cause = _texte(donnees, "cause", "Cause")
        if "temps_passe_h" in donnees:
            bon.temps_passe_h = _nombre(donnees, "temps_passe_h", "Temps passé", 0, 1000)
        if "effectif" in donnees:
            bon.effectif = _nombre(donnees, "effectif", "Effectif", 1, 50, entier=True)
        if "remise_en_service" in donnees:
            valeur = donnees["remise_en_service"]
            try:
                bon.remise_en_service = lire_iso(valeur) if valeur else None
            except ValueError:
                raise Invalide("Date de remise en service invalide.")
            if bon.remise_en_service and bon.remise_en_service < bon.cree_le:
                raise Invalide("La remise en service ne peut pas être antérieure à la création du bon.")
        if "element_id" in donnees:
            # Élément en cause (facultatif) : sert aux analyses de Pareto par élément
            valeur = donnees["element_id"]
            if valeur in (None, ""):
                bon.element_id = None
            else:
                from .models import Element

                try:
                    element = db.session.get(Element, int(valeur))
                except (TypeError, ValueError):
                    element = None
                if not element:
                    raise Invalide("Élément introuvable.")
                bon.element_id = element.id
        if "composants" in donnees:
            # Les pièces du magasin sortent du stock dès l'enregistrement (et y reviennent si on les retire)
            anciennes = stock.quantites_par_piece(bon.composants)
            bon.composants = _composants(donnees["composants"])
            db.session.flush()
            stock.synchroniser_composants_bon(bon, anciennes)
        if "statut" in donnees:
            bon.statut = _choix(donnees["statut"], ref.STATUTS_BI, "un statut")

        if bon.statut == "termine":
            # Compte-rendu minimal exigé pour terminer un bon
            if not bon.travaux:
                raise Invalide("Pour terminer le bon, décrivez les travaux réalisés.")
            if bon.temps_passe_h is None:
                raise Invalide("Pour terminer le bon, indiquez le temps passé.")
            if bon.machine_arretee and not bon.remise_en_service:
                raise Invalide("La machine était à l'arrêt : indiquez la date et l'heure de remise en service.")
    except (Invalide, stock.Invalide) as e:
        db.session.rollback()
        return erreur(str(e), 400)

    if bon.statut == "termine" and ancien_statut != "termine":
        bon.termine_le = maintenant()
        journaliser("cloture", bon, bon.numero)
        from .preventif import valider_par_bon

        valider_par_bon(bon)
    elif ancien_statut == "termine" and bon.statut != "termine":
        bon.termine_le = None
        journaliser("reouverture", bon, bon.numero)
    else:
        journaliser("modification", bon, bon.numero)
    db.session.commit()
    return jsonify(bon=bon.to_dict())


# ---------- Répartition ----------

@bp.put("/bons/<int:bon_id>/techniciens")
@role_required(*EQUIPE)
def affecter(bon_id):
    """Remplace la liste des techniciens du bon (glisser-déposer ou cases à cocher)."""
    bon, err = _bon_ou_404(bon_id)
    if err:
        return err
    if bon.statut == "termine" and current_user.role != "admin":
        return erreur("Ce bon est terminé : seul un administrateur peut le modifier.", 403)
    ids = (request.get_json(silent=True) or {}).get("ids")
    if not isinstance(ids, list) or not all(isinstance(i, int) for i in ids):
        return erreur("Liste de techniciens invalide.", 400)
    techniciens = Utilisateur.query.filter(
        Utilisateur.id.in_(ids), Utilisateur.role == "technicien", Utilisateur.actif.is_(True)
    ).all()
    if len(techniciens) != len(set(ids)):
        return erreur("Un des techniciens choisis n'existe pas ou n'est plus actif.", 400)
    bon.techniciens = techniciens
    journaliser("affectation", bon, ", ".join(t.nom for t in techniciens) or "aucun technicien")
    db.session.commit()
    return jsonify(bon=bon.to_dict())


@bp.post("/bons/repartition-auto")
@role_required("admin")
def repartition_auto():
    """Distribue les bons ouverts non attribués à tour de rôle, les plus urgents d'abord (annexe E, point 7)."""
    techniciens = Utilisateur.query.filter_by(role="technicien", actif=True).order_by(Utilisateur.nom).all()
    if not techniciens:
        return erreur("Aucun technicien actif.", 409)
    bons = (
        BonIntervention.query.filter(BonIntervention.statut != "termine", ~BonIntervention.techniciens.any())
        .order_by(BonIntervention.cree_le)
        .all()
    )
    bons.sort(key=lambda b: ORDRE_URGENCE.get(b.urgence, 9))

    # On reprend après le dernier technicien servi lors de la répartition précédente
    pointeur = db.session.get(Parametre, "repartition_dernier_technicien") or Parametre(cle="repartition_dernier_technicien")
    ids = [t.id for t in techniciens]
    depart = ids.index(int(pointeur.valeur)) + 1 if pointeur.valeur and int(pointeur.valeur) in ids else 0
    for i, bon in enumerate(bons):
        technicien = techniciens[(depart + i) % len(techniciens)]
        bon.techniciens = [technicien]
        journaliser("affectation", bon, f"{technicien.nom} (répartition automatique)")
        pointeur.valeur = str(technicien.id)
    db.session.add(pointeur)
    db.session.commit()
    return jsonify(nb_bons=len(bons))


# ---------- Export ----------

def _decimal(nombre):
    """Nombre pour Excel : virgule décimale, sans zéros inutiles (2 ; 1,5 ; 0,75)."""
    if nombre is None:
        return ""
    return f"{nombre:.2f}".rstrip("0").rstrip(".").replace(".", ",")


@bp.get("/bons/export.csv")
@role_required(*EQUIPE)
def export_csv():
    try:
        bons = avec_details(_filtrer(BonIntervention.query)).order_by(BonIntervention.cree_le.desc()).all()
    except Invalide as e:
        return erreur(str(e), 400)
    sortie = io.StringIO()
    ecrivain = tableur.ecrivain(sortie)
    ecrivain.writerow(
        [
            "Numéro", "Date", "Atelier", "Repère", "Machine", "Type", "Urgence", "Statut", "Demandeur",
            "Description", "Techniciens", "Travaux réalisés", "Cause", "Temps passé (h)", "Effectif",
            "Machine à l'arrêt", "Remise en service", "Durée d'arrêt (h)", "Terminé le",
            "Composants utilisés", "Coût composants (€ HT)",
        ]
    )
    libelles_types = types_travaux()
    for b in bons:
        ecrivain.writerow(
            [
                b.numero, format_paris(b.cree_le), b.machine.atelier.nom, b.machine.repere, b.machine.designation,
                libelles_types.get(b.type_travail, b.type_travail), ref.URGENCES.get(b.urgence, b.urgence),
                ref.STATUTS_BI.get(b.statut, b.statut), b.demandeur, b.description,
                ", ".join(t.nom for t in b.techniciens), b.travaux or "", b.cause or "",
                _decimal(b.temps_passe_h), b.effectif or "", "Oui" if b.machine_arretee else "Non",
                format_paris(b.remise_en_service), _decimal(b.duree_arret_h), format_paris(b.termine_le),
                ", ".join(f"{_decimal(c.quantite)} × {c.designation}" for c in b.composants),
                _decimal(b.cout_composants) if b.composants else "",
            ]
        )
    # BOM UTF-8 : Excel affiche alors correctement les accents
    return Response(
        "﻿" + sortie.getvalue(),
        mimetype="text/csv; charset=utf-8",
        headers={"Content-Disposition": f"attachment; filename=historique-interventions-{date.today():%Y-%m-%d}.csv"},
    )
