from datetime import date

import pytest
from flask import jsonify

from app import db
from app.auth import role_required, unlock_required
from app.cli import reset_annuel, seed
from app.models import Atelier, Element, JournalAction, Utilisateur


def test_health(client):
    reponse = client.get("/api/health")
    assert reponse.status_code == 200
    assert reponse.get_json() == {"status": "ok", "database": "sqlite", "version": "1.0"}


# ---------- Connexion ----------

@pytest.mark.parametrize("login,role", [("admin", "admin"), ("tech", "technicien"), ("tech2", "technicien"), ("operateur", "operateur")])
def test_connexion_comptes_demo(client, login, role):
    reponse = client.post("/api/auth/login", json={"login": login, "password": login})
    assert reponse.status_code == 200
    assert reponse.get_json()["utilisateur"]["role"] == role


def test_connexion_insensible_a_la_casse_de_l_identifiant(client):
    assert client.post("/api/auth/login", json={"login": " Admin ", "password": "admin"}).status_code == 200


def test_connexion_mauvais_mot_de_passe(client):
    reponse = client.post("/api/auth/login", json={"login": "admin", "password": "faux"})
    assert reponse.status_code == 401
    assert reponse.get_json()["error"] == "Identifiant ou mot de passe incorrect."


def test_connexion_champs_vides(client):
    assert client.post("/api/auth/login", json={}).status_code == 400


def test_connexion_compte_desactive(client):
    Utilisateur.query.filter_by(login="tech").first().actif = False
    db.session.commit()
    assert client.post("/api/auth/login", json={"login": "tech", "password": "tech"}).status_code == 403


def test_me_et_deconnexion(client, connecter):
    assert client.get("/api/auth/me").get_json() == {"utilisateur": None}
    connecter("tech")
    assert client.get("/api/auth/me").get_json()["utilisateur"]["login"] == "tech"
    client.post("/api/auth/logout")
    assert client.get("/api/auth/me").get_json() == {"utilisateur": None}


def test_connexion_journalisee(client, connecter):
    connecter("operateur")
    ligne = JournalAction.query.filter_by(action="connexion").one()
    assert ligne.utilisateur.login == "operateur"


def test_mots_de_passe_haches_en_pbkdf2(app):
    assert Utilisateur.query.filter_by(login="admin").first().mot_de_passe_hash.startswith("pbkdf2:sha256")


# ---------- Droits ----------

@pytest.fixture()
def routes_test(app):
    @app.get("/api/test/admin")
    @role_required("admin")
    def reservee_admin():
        return jsonify(ok=True)

    @app.get("/api/test/machines")
    @role_required("admin", "technicien")
    @unlock_required("machines")
    def verrouillee():
        return jsonify(ok=True)


def test_route_protegee_sans_connexion(client):
    reponse = client.get("/api/referentiels")
    assert reponse.status_code == 401
    assert reponse.get_json()["error"] == "Vous devez vous connecter."


@pytest.mark.parametrize("login,attendu", [("admin", 200), ("tech", 403), ("operateur", 403)])
def test_role_required(routes_test, client, connecter, login, attendu):
    connecter(login)
    assert client.get("/api/test/admin").status_code == attendu


def test_unlock_required_technicien(routes_test, client, connecter):
    connecter("tech")
    assert client.get("/api/test/machines").status_code == 403
    reponse = client.get("/api/test/machines", headers={"X-Unlock-Password": "0000"})
    assert reponse.status_code == 403 and "Code du jour" in reponse.get_json()["error"]
    assert client.get("/api/test/machines", headers={"X-Unlock-Password": "machines"}).status_code == 403  # ancien mot de passe
    assert client.get("/api/test/machines", headers={"X-Unlock-Password": " 1234 "}).status_code == 200


def test_unlock_required_admin_dispense(routes_test, client, connecter):
    connecter("admin")
    assert client.get("/api/test/machines").status_code == 200


def test_unlock_required_operateur_refuse_meme_avec_mot_de_passe(routes_test, client, connecter):
    connecter("operateur")
    assert client.get("/api/test/machines", headers={"X-Unlock-Password": "1234"}).status_code == 403


def test_verifier_verrou(client, connecter):
    connecter("tech")
    assert client.post("/api/auth/verifier-verrou/indicateurs", json={"password": "1234"}).status_code == 200
    assert client.post("/api/auth/verifier-verrou/indicateurs", json={"password": "x"}).status_code == 403
    assert client.post("/api/auth/verifier-verrou/inconnu", json={"password": "x"}).status_code == 404


def test_erreur_404_en_francais(client):
    assert client.get("/api/nexiste-pas").get_json() == {"error": "Élément introuvable."}


# ---------- Données de départ ----------

def test_referentiels(client, connecter):
    connecter("operateur")
    donnees = client.get("/api/referentiels").get_json()
    assert [a["nom"] for a in donnees["ateliers"]][0] == "01. Maintenance"
    assert len(donnees["ateliers"]) == 8
    assert len(donnees["elements"]) == 10
    assert len(donnees["statuts_bi"]) == 6  # « Urgent » retiré à la demande de Simon


def test_seed_sans_doublons(app):
    seed(demo=True)
    seed(demo=True)
    assert Atelier.query.count() == 8
    assert Element.query.count() == 10
    assert Utilisateur.query.count() == 4


def test_seed_sans_demo(tmp_path):
    from app import create_app

    app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///" + (tmp_path / "vide.db").as_posix()})
    with app.app_context():
        db.create_all()
        seed(demo=False)
        assert Utilisateur.query.count() == 0
        assert Atelier.query.count() == 8


# ---------- 1er août ----------

def test_reset_annuel_hors_1er_aout(app):
    assert "rien à faire" in reset_annuel(date(2027, 3, 15))
    assert Utilisateur.query.filter_by(login="tech").first().nom == "Technicien 1 (démo)"


def test_reset_annuel_anonymise_les_eleves_une_seule_fois(app):
    assert "2 élève(s)" in reset_annuel(date(2027, 8, 1))
    eleves = Utilisateur.query.filter_by(role="technicien").all()
    assert all(u.nom.startswith("Élève anonyme") and u.login.startswith("anonyme-") and not u.actif for u in eleves)
    noms = {u.login: u.nom for u in Utilisateur.query}
    assert noms["admin"] == "Administrateur (démo)"
    assert noms["operateur"] == "Opérateur (démo)"
    assert "déjà été faite" in reset_annuel(date(2027, 8, 1))


# ---------- Hébergeur ----------

def test_passenger_remet_le_prefixe_api():
    import passenger_wsgi

    capture = {}

    def start_response(status, headers):
        capture["status"] = status

    environ = {
        "REQUEST_METHOD": "GET",
        "SCRIPT_NAME": "/api",
        "PATH_INFO": "/health",
        "SERVER_NAME": "test",
        "SERVER_PORT": "80",
        "wsgi.url_scheme": "http",
        "wsgi.input": None,
    }
    corps = b"".join(passenger_wsgi.application(environ, start_response))
    assert capture["status"].startswith("200")
    assert b'"status":"ok"' in corps.replace(b" ", b"")
