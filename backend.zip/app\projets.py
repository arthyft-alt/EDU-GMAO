"""Projets et diagramme de Gantt (CHA-03 à CHA-06).

Planification automatique : une tâche commence au plus tôt à la date de début du projet, à sa date « au plus tôt »
et après la fin de tous ses prédécesseurs ; sa durée se compte en semaines de cours (les semaines de vacances et
d'apprentissage sont sautées). Un jalon a une durée nulle.
"""
from datetime import date, datetime, timedelta

from flask import Blueprint, jsonify, request
from flask_login import current_user

from . import db
from .auth import erreur, role_required
from .calendrier import lundi, semaines_non_travaillees
from .dates import PARIS
from .models import EvenementCalendrier, Projet, TacheProjet, Utilisateur, journaliser, maintenant

bp = Blueprint("projets", __name__)

EQUIPE = ("admin", "technicien")
STATUTS = {"a_faire": "À faire", "en_cours": "En cours", "termine": "Terminé"}
LIMITE_SEMAINES = 520  # garde-fou : 10 ans


class Invalide(Exception):
    pass


# ---------- Planification ----------

def _ordre_topologique(taches):
    """Tâches triées pour que chaque prédécesseur passe avant ; erreur si la chaîne boucle."""
    etat, resultat = {}, []

    def visiter(t, chemin):
        if etat.get(t.id) == "fini":
            return
        if etat.get(t.id) == "en_cours":
            raise Invalide(f"Boucle dans les prédécesseurs : « {t.nom} » dépend d'elle-même ({' → '.join(chemin)}).")
        etat[t.id] = "en_cours"
        for p in t.predecesseurs:
            visiter(p, chemin + [p.nom])
        etat[t.id] = "fini"
        resultat.append(t)

    for t in sorted(taches, key=lambda x: x.ordre):
        visiter(t, [t.nom])
    return resultat


def planifier(projet, non_travail=None):
    """Dates de début et de fin (lundis) de chaque tâche : {id: (debut, fin)}."""
    non_travail = semaines_non_travaillees() if non_travail is None else non_travail

    def prochaine_semaine_de_cours(jour):
        for _ in range(LIMITE_SEMAINES):
            if jour not in non_travail:
                return jour
            jour += timedelta(days=7)
        raise Invalide("Aucune semaine de cours trouvée : vérifiez le calendrier scolaire.")

    plan = {}
    for t in _ordre_topologique(projet.taches):
        debut = lundi(projet.date_debut)
        if t.debut_au_plus_tot:
            debut = max(debut, lundi(t.debut_au_plus_tot))
        for p in t.predecesseurs:
            debut = max(debut, plan[p.id][2])
        debut = prochaine_semaine_de_cours(debut)
        if t.jalon:
            plan[t.id] = (debut, debut, debut)
            continue
        fin, restant, jour = debut, t.duree_semaines, debut
        for _ in range(LIMITE_SEMAINES):
            if jour not in non_travail:
                restant -= 1
                fin = jour
                if restant == 0:
                    break
            jour += timedelta(days=7)
        plan[t.id] = (debut, fin, fin + timedelta(days=7))  # (début, dernière semaine, semaine suivante)
    return plan


def pert(projet):
    """Réseau PERT : dates au plus tôt / au plus tard en semaines de cours (S1 = 1re semaine), marges, chemin critique."""
    ordre = _ordre_topologique(projet.taches)
    duree = {t.id: 0 if t.jalon else t.duree_semaines for t in ordre}
    successeurs = {t.id: [] for t in ordre}
    for t in ordre:
        for p in t.predecesseurs:
            successeurs[p.id].append(t.id)
    tot, fin_tot, niveau = {}, {}, {}
    for t in ordre:
        tot[t.id] = max((fin_tot[p.id] for p in t.predecesseurs), default=0)
        fin_tot[t.id] = tot[t.id] + duree[t.id]
        niveau[t.id] = max((niveau[p.id] + 1 for p in t.predecesseurs), default=0)
    total = max(fin_tot.values(), default=0)
    tard, fin_tard = {}, {}
    for t in reversed(ordre):
        fin_tard[t.id] = min((tard[s] for s in successeurs[t.id]), default=total)
        tard[t.id] = fin_tard[t.id] - duree[t.id]
    return {
        "duree_totale": total,
        "noeuds": {
            t.id: {
                "debut_tot": tot[t.id], "fin_tot": fin_tot[t.id], "debut_tard": tard[t.id], "fin_tard": fin_tard[t.id],
                "marge": tard[t.id] - tot[t.id], "critique": tard[t.id] == tot[t.id], "niveau": niveau[t.id],
            }
            for t in ordre
        },
    }


def tache_dict(t, plan=None):
    aujourdhui = datetime.now(PARIS).date()
    d = {
        "id": t.id,
        "projet_id": t.projet_id,
        "projet": t.projet.nom,
        "nom": t.nom,
        "description": t.description,
        "ordre": t.ordre,
        "duree_semaines": t.duree_semaines,
        "debut_au_plus_tot": t.debut_au_plus_tot.isoformat() if t.debut_au_plus_tot else None,
        "avancement": t.avancement,
        "statut": t.statut,
        "jalon": t.jalon,
        "predecesseurs": [p.id for p in t.predecesseurs],
        "techniciens": [{"id": u.id, "nom": u.nom} for u in t.techniciens],
    }
    if plan and t.id in plan:
        debut, fin, _ = plan[t.id]
        d.update(debut=debut.isoformat(), fin=fin.isoformat(), en_retard=t.statut != "termine" and fin + timedelta(days=6) < aujourdhui)
    return d


def _membres_du_projet(projet):
    """Le projet principal concerne toute la classe : tous les élèves actifs en sont membres."""
    if projet.principal:
        return Utilisateur.query.filter_by(role="technicien", actif=True).order_by(Utilisateur.nom).all()
    return projet.membres


def projet_dict(projet, details=False):
    taches = projet.taches
    duree = sum(t.duree_semaines for t in taches if not t.jalon)
    avancement = round(sum(t.avancement * t.duree_semaines for t in taches if not t.jalon) / duree) if duree else 0
    d = {
        "id": projet.id,
        "nom": projet.nom,
        "description": projet.description,
        "date_debut": projet.date_debut.isoformat(),
        "actif": projet.actif,
        "principal": projet.principal,
        "membres": [{"id": u.id, "nom": u.nom} for u in _membres_du_projet(projet)],
        "nb_taches": len(taches),
        "avancement": avancement,
    }
    if details:
        non_travail = semaines_non_travaillees()
        try:
            plan = planifier(projet, non_travail)
            d["erreur_planning"] = None
        except Invalide as e:
            plan, d["erreur_planning"] = {}, str(e)
        d["taches"] = [tache_dict(t, plan) for t in taches]
        fins = [v[1] for v in plan.values()]
        debut = lundi(projet.date_debut)
        fin = max(fins + [debut]) + timedelta(days=14)
        d["semaines"] = []
        jour = debut
        while jour <= fin:
            d["semaines"].append({"lundi": jour.isoformat(), "numero": jour.isocalendar()[1], "non_travaillee": jour in non_travail})
            jour += timedelta(days=7)
        d["evenements"] = [
            e.to_dict() for e in EvenementCalendrier.query.filter(EvenementCalendrier.date.between(debut, fin + timedelta(days=6))).order_by(EvenementCalendrier.date)
        ]
        d["retards"] = sum(1 for t in d["taches"] if t.get("en_retard"))
        d["pert"] = pert(projet) if not d["erreur_planning"] else None
    return d


# ---------- Projets ----------

def _membres(ids):
    if not isinstance(ids, list) or not all(isinstance(i, int) for i in ids):
        raise Invalide("Liste d'élèves invalide.")
    membres = Utilisateur.query.filter(Utilisateur.id.in_(ids), Utilisateur.role == "technicien").all()
    if len(membres) != len(set(ids)):
        raise Invalide("Un des élèves choisis n'existe pas.")
    return membres


def _appliquer_projet(projet, donnees):
    nom = str(donnees.get("nom") or "").strip()
    if not nom:
        raise Invalide("Le nom du projet est obligatoire.")
    try:
        debut = date.fromisoformat(str(donnees.get("date_debut")))
    except ValueError:
        raise Invalide("Indiquez la date de début du projet.")
    projet.nom = nom[:160]
    projet.description = str(donnees.get("description") or "").strip() or None
    projet.date_debut = debut
    projet.membres = [] if projet.principal else _membres(donnees.get("membres") or [])


def _projet_ou_404(projet_id):
    projet = db.session.get(Projet, projet_id)
    if not projet:
        return None, erreur("Projet introuvable.", 404)
    return projet, None


@bp.get("/projets/principal")
@role_required(*EQUIPE)
def projet_principal():
    """Projet de l'année pour toute la classe (onglet « Déploiement de la GMAO »)."""
    projet = Projet.query.filter_by(principal=True, actif=True).first()
    return jsonify(projet=projet_dict(projet, details=True) if projet else None)


@bp.get("/projets")
@role_required(*EQUIPE)
def liste_projets():
    requete = Projet.query.filter(Projet.principal.is_(False))
    if request.args.get("archives") != "1":
        requete = requete.filter(Projet.actif.is_(True))
    return jsonify(projets=[projet_dict(p) for p in requete.order_by(Projet.actif.desc(), Projet.nom)])


@bp.get("/projets/<int:projet_id>")
@role_required(*EQUIPE)
def detail_projet(projet_id):
    projet, err = _projet_ou_404(projet_id)
    if err:
        return err
    return jsonify(projet=projet_dict(projet, details=True))


@bp.post("/projets")
@role_required("admin")
def creer_projet():
    donnees = request.get_json(silent=True) or {}
    projet = Projet(principal=bool(donnees.get("principal")))
    if projet.principal and Projet.query.filter_by(principal=True, actif=True).first():
        return erreur("Le projet « Déploiement de la GMAO » de l'année existe déjà.", 409)
    try:
        _appliquer_projet(projet, donnees)
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    db.session.add(projet)
    db.session.flush()
    journaliser("creation", projet, projet.nom)
    db.session.commit()
    return jsonify(projet=projet_dict(projet)), 201


@bp.put("/projets/<int:projet_id>")
@role_required("admin")
def modifier_projet(projet_id):
    projet, err = _projet_ou_404(projet_id)
    if err:
        return err
    donnees = request.get_json(silent=True) or {}
    try:
        _appliquer_projet(projet, donnees)
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    if "actif" in donnees:
        projet.actif = bool(donnees["actif"])
    journaliser("modification", projet, projet.nom)
    db.session.commit()
    return jsonify(projet=projet_dict(projet))


@bp.delete("/projets/<int:projet_id>")
@role_required("admin")
def supprimer_projet(projet_id):
    projet, err = _projet_ou_404(projet_id)
    if err:
        return err
    journaliser("suppression", projet, projet.nom)
    db.session.delete(projet)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Tâches du projet ----------

def _tache_ou_404(tache_id):
    tache = db.session.get(TacheProjet, tache_id)
    if not tache:
        return None, erreur("Tâche introuvable.", 404)
    return tache, None


def _appliquer_tache(tache, projet, donnees):
    nom = str(donnees.get("nom") or "").strip()
    if not nom:
        raise Invalide("Le nom de la tâche est obligatoire.")
    jalon = bool(donnees.get("jalon"))
    try:
        duree = 0 if jalon else int(donnees.get("duree_semaines") or 1)
    except (TypeError, ValueError):
        raise Invalide("La durée est un nombre entier de semaines.")
    if not jalon and not 1 <= duree <= 52:
        raise Invalide("La durée doit être comprise entre 1 et 52 semaines.")
    try:
        au_plus_tot = date.fromisoformat(str(donnees["debut_au_plus_tot"])) if donnees.get("debut_au_plus_tot") else None
    except ValueError:
        raise Invalide("Date « au plus tôt » invalide.")
    try:
        avancement = int(donnees.get("avancement") or 0)
    except (TypeError, ValueError):
        raise Invalide("L'avancement est un pourcentage.")
    if not 0 <= avancement <= 100:
        raise Invalide("L'avancement doit être compris entre 0 et 100 %.")
    statut = donnees.get("statut") or ("termine" if avancement == 100 else "en_cours" if avancement else "a_faire")
    if statut not in STATUTS:
        raise Invalide("Statut inconnu.")
    ids = donnees.get("predecesseurs") or []
    predecesseurs = TacheProjet.query.filter(TacheProjet.id.in_(ids), TacheProjet.projet_id == projet.id).all() if ids else []
    if len(predecesseurs) != len(set(ids)):
        raise Invalide("Les prédécesseurs doivent appartenir au même projet.")
    if tache.id and tache.id in ids:
        raise Invalide("Une tâche ne peut pas être son propre prédécesseur.")
    tache.nom = nom[:160]
    tache.description = str(donnees.get("description") or "").strip() or None
    tache.jalon = jalon
    tache.duree_semaines = duree
    tache.debut_au_plus_tot = au_plus_tot
    tache.avancement = 100 if statut == "termine" else avancement
    if statut == "termine" and tache.statut != "termine":
        tache.termine_le = maintenant()
    elif statut != "termine":
        tache.termine_le = None
    tache.statut = statut
    tache.predecesseurs = predecesseurs


@bp.post("/projets/<int:projet_id>/taches")
@role_required(*EQUIPE)
def creer_tache(projet_id):
    projet, err = _projet_ou_404(projet_id)
    if err:
        return err
    # Rattachée par son identifiant : la tâche n'entre dans la session qu'une fois complète
    tache = TacheProjet(projet_id=projet.id, ordre=(max((t.ordre for t in projet.taches), default=0) + 1))
    try:
        _appliquer_tache(tache, projet, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    db.session.add(tache)
    db.session.flush()
    db.session.expire(projet, ["taches"])
    journaliser("creation", tache, f"{projet.nom} — {tache.nom}")
    db.session.commit()
    return jsonify(tache=tache_dict(tache)), 201


@bp.put("/projets/taches/<int:tache_id>")
@role_required(*EQUIPE)
def modifier_tache(tache_id):
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    donnees = request.get_json(silent=True) or {}
    try:
        _appliquer_tache(tache, tache.projet, donnees)
        if "ordre" in donnees:
            tache.ordre = int(donnees["ordre"])
        planifier(tache.projet)
    except (Invalide, TypeError, ValueError) as e:
        db.session.rollback()
        return erreur(str(e) if isinstance(e, Invalide) else "Ordre invalide.", 400)
    journaliser("modification", tache, f"{tache.projet.nom} — {tache.nom}")
    db.session.commit()
    return jsonify(tache=tache_dict(tache))


@bp.delete("/projets/taches/<int:tache_id>")
@role_required(*EQUIPE)
def supprimer_tache(tache_id):
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    for autre in tache.projet.taches:  # les tâches qui en dépendaient perdent ce prédécesseur
        if tache in autre.predecesseurs:
            autre.predecesseurs.remove(tache)
    journaliser("suppression", tache, f"{tache.projet.nom} — {tache.nom}")
    db.session.delete(tache)
    db.session.commit()
    return jsonify(ok=True)


@bp.put("/projets/taches/<int:tache_id>/techniciens")
@role_required(*EQUIPE)
def affecter_tache(tache_id):
    """Élèves de la tâche (bon de travail répartissable, CHA-05)."""
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    ids = (request.get_json(silent=True) or {}).get("ids")
    if not isinstance(ids, list) or not all(isinstance(i, int) for i in ids):
        return erreur("Liste d'élèves invalide.", 400)
    techniciens = Utilisateur.query.filter(Utilisateur.id.in_(ids), Utilisateur.role == "technicien", Utilisateur.actif.is_(True)).all()
    if len(techniciens) != len(set(ids)):
        return erreur("Un des élèves choisis n'existe pas ou n'est plus actif.", 400)
    tache.techniciens = techniciens
    journaliser("affectation", tache, ", ".join(t.nom for t in techniciens) or "aucun élève")
    db.session.commit()
    return jsonify(tache=tache_dict(tache))


@bp.get("/projets/taches")
@role_required(*EQUIPE)
def taches_ouvertes():
    """Tâches non terminées des projets actifs. ?semaine=1 : seulement celles de la semaine en cours ou en retard
    (tableau de répartition)."""
    requete = TacheProjet.query.join(Projet).filter(Projet.actif.is_(True), TacheProjet.statut != "termine", TacheProjet.jalon.is_(False))
    technicien = request.args.get("technicien_id", type=int)
    if technicien:
        requete = requete.filter(TacheProjet.techniciens.any(Utilisateur.id == technicien))
    resultat = []
    plans = {}
    for t in requete.order_by(Projet.nom, TacheProjet.ordre):
        if t.projet_id not in plans:
            try:
                plans[t.projet_id] = planifier(t.projet)
            except Invalide:
                plans[t.projet_id] = {}
        d = tache_dict(t, plans[t.projet_id])
        if request.args.get("semaine") == "1":
            lundi_courant = lundi(datetime.now(PARIS).date())
            if not d.get("en_retard") and not (d.get("debut") and d["debut"] <= lundi_courant.isoformat() <= d["fin"]):
                continue
        resultat.append(d)
    return jsonify(taches=resultat)


def archiver_projets():
    """Réinitialisation du 1er août (CHA-06) : les projets en cours sont archivés."""
    return Projet.query.filter(Projet.actif.is_(True)).update({"actif": False}, synchronize_session=False)
