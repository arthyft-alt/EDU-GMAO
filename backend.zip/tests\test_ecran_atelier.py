from datetime import date, datetime

import pytest

from app import db
from app.models import (
    AbsenceEleve,
    Atelier,
    BonIntervention,
    BonPreventif,
    Chantier,
    ChantierAffectation,
    Machine,
    SemaineSecurite,
    TachePreventive,
    Utilisateur,
)

AUJOURDHUI = date(2026, 11, 18)  # un mercredi


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: AUJOURDHUI)


@pytest.fixture()
def atelier_en_activite(app):
    tech, tech2 = (Utilisateur.query.filter_by(login=l).one() for l in ("tech", "tech2"))
    tour = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.filter_by(nom="01. Maintenance").one())
    bon = dict(machine=tour, demandeur="x", description="x", type_travail="depannage")
    retard = TachePreventive(machine=tour, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite="mois", date_debut=date(2026, 11, 2))
    semaine = TachePreventive(machine=tour, nom="Contrôle", niveau=3, type_preventif="Inspection", periodicite="mois", date_debut=date(2026, 11, 16))
    plus_tard = TachePreventive(machine=tour, nom="Vidange", niveau=2, type_preventif="Lubrification", periodicite="an", date_debut=date(2027, 3, 1))
    chantier = Chantier(titre="Rangement de l'armoire", statut="en_cours")
    db.session.add_all(
        [
            tour,
            BonIntervention(numero="BI-1", statut="demande", urgence="normale", cree_le=datetime(2026, 11, 10, 8), **bon),
            BonIntervention(numero="BI-2", statut="en_cours", urgence="normale", cree_le=datetime(2026, 11, 12, 8), techniciens=[tech], **bon),
            BonIntervention(numero="BI-3", statut="demande", urgence="critique", cree_le=datetime(2026, 11, 17, 8), **bon),
            BonIntervention(numero="BI-4", statut="termine", urgence="critique", cree_le=datetime(2026, 11, 9, 8), **bon),
            retard,
            semaine,
            plus_tard,
            chantier,
            ChantierAffectation(chantier=chantier, utilisateur=tech2),
            AbsenceEleve(utilisateur_id=tech2.id, jour=AUJOURDHUI),
            SemaineSecurite(lundi=date(2026, 11, 9), couleur="vert"),
            SemaineSecurite(lundi=date(2026, 11, 16), couleur="vert"),
        ]
    )
    db.session.flush()
    db.session.add(BonPreventif(tache=semaine, echeance=date(2026, 11, 16), techniciens=[tech2]))
    db.session.commit()


def test_ecran_atelier(client, connecter, atelier_en_activite):
    connecter("operateur")  # le compte de la télévision
    d = client.get("/api/ecran-atelier").get_json()
    assert [b["numero"] for b in d["bons"]] == ["BI-3", "BI-2", "BI-1"]  # critique, puis en cours, puis le plus ancien
    assert d["bons"][1]["eleves"] == ["Technicien 1 (démo)"] and d["bons"][1]["statut_libelle"] == "En cours"
    assert [p["nom"] for p in d["preventif"]] == ["Graissage", "Contrôle"]  # en retard d'abord ; la vidange n'est pas pour cette semaine
    assert d["preventif"][0]["statut"] == "en_retard" and d["preventif"][1]["eleves"] == ["Technicien 2 (démo)"]
    equipe = {e["nom"]: e for e in d["equipe"]}
    assert [t["texte"] for t in equipe["Technicien 1 (démo)"]["travail"]] == ["BI-2 · MAI-01"]
    assert equipe["Technicien 2 (démo)"]["absent"] is True
    assert {t["genre"] for t in equipe["Technicien 2 (démo)"]["travail"]} == {"preventif", "chantier"}
    assert d["securite"] == {"couleur": "vert", "serie": 2, "record": 2} and d["semaine"]["numero"] == 47


def test_ecran_atelier_demande_une_connexion(client):
    assert client.get("/api/ecran-atelier").status_code == 401
