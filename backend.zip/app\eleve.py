"""Espace élève (ELV-01 à ELV-03) : la semaine d'un élève (tout ce qui lui est confié) et son bilan d'activité.
Un élève ne voit que sa propre semaine ; l'enseignant choisit l'élève."""
from datetime import date, datetime, timedelta

from flask import Blueprint, jsonify, request
from flask_login import current_user

from . import db
from .auth import erreur, role_required
from .calendrier import annee_scolaire, lundi
from .dates import PARIS, debut_jour_paris
from .models import (
    Atelier,
    BonIntervention,
    BonPreventif,
    Chantier,
    ChantierAffectation,
    EvenementCalendrier,
    Projet,
    RealisationPreventive,
    SemaineCalendrier,
    TacheProjet,
    TachePreventive,
    Utilisateur,
    iso,
    maintenant,
)
from .preventif import taches_a_prendre
from .reglages import atelier_position_defaut
from .projets import Invalide, planifier, tache_dict as tache_projet_dict

bp = Blueprint("eleve", __name__)


def _eleve():
    """L'élève concerné : soi-même pour un technicien ; au choix (?technicien_id=) pour l'enseignant."""
    if current_user.role == "technicien":
        return current_user, None
    eleve = db.session.get(Utilisateur, request.args.get("technicien_id", type=int) or 0)
    if not eleve or eleve.role != "technicien":
        return None, erreur("Choisissez un élève.", 400)
    return eleve, None


def _semaine():
    try:
        jour = date.fromisoformat(request.args["debut"]) if request.args.get("debut") else datetime.now(PARIS).date()
    except ValueError:
        raise ValueError("Date invalide.")
    debut = lundi(jour)
    return debut, debut + timedelta(days=6)


def _bilan(eleve, du, au):
    """Ce que l'élève a fait entre du et au (inclus)."""
    debut, fin = debut_jour_paris(du), debut_jour_paris(au + timedelta(days=1))
    bons = BonIntervention.query.filter(
        BonIntervention.techniciens.any(Utilisateur.id == eleve.id),
        BonIntervention.statut == "termine",
        BonIntervention.termine_le >= debut,
        BonIntervention.termine_le < fin,
    ).all()
    chantiers = ChantierAffectation.query.filter(
        ChantierAffectation.utilisateur_id == eleve.id, ChantierAffectation.termine_le >= debut, ChantierAffectation.termine_le < fin
    ).count()
    # Préventif : échéances qu'il a cochées, et bons de préventif faits par son groupe (comptés une fois)
    preventif = {
        (r.tache_id, r.echeance)
        for r in RealisationPreventive.query.filter(
            RealisationPreventive.par_id == eleve.id, RealisationPreventive.realise_le >= debut, RealisationPreventive.realise_le < fin
        )
    } | {
        (b.tache_id, b.echeance)
        for b in BonPreventif.query.filter(
            BonPreventif.techniciens.any(Utilisateur.id == eleve.id), BonPreventif.termine_le >= debut, BonPreventif.termine_le < fin
        )
    }
    return {
        "bons_termines": len(bons),
        "temps_passe_h": round(sum(b.temps_passe_h or 0 for b in bons), 2),
        "chantiers_termines": chantiers,
        "preventif_realise": len(preventif),
    }


@bp.get("/eleve/semaine")
@role_required("admin", "technicien")
def semaine():
    eleve, err = _eleve()
    if err:
        return err
    try:
        du, au = _semaine()
    except ValueError as e:
        return erreur(str(e), 400)

    # Correctif, amélioration… : bons d'intervention ouverts confiés à l'élève
    bons = (
        BonIntervention.query.filter(BonIntervention.techniciens.any(Utilisateur.id == eleve.id), BonIntervention.statut != "termine")
        .order_by(BonIntervention.cree_le)
        .all()
    )

    # Bons de préventif ouverts confiés à l'élève (mode opératoire + « Fait »)
    bons_preventifs = (
        BonPreventif.query.filter(BonPreventif.techniciens.any(Utilisateur.id == eleve.id), BonPreventif.termine_le.is_(None))
        .order_by(BonPreventif.echeance)
        .all()
    )

    # Chantiers ouverts (en mode individuel : tant que sa propre part n'est pas terminée)
    chantiers = [
        c
        for c in Chantier.query.filter(Chantier.statut != "termine", Chantier.affectations.any(ChantierAffectation.utilisateur_id == eleve.id))
        if not any(a.utilisateur_id == eleve.id and a.termine_le for a in c.affectations)
    ]

    # Tâches de projet confiées dont la barre du Gantt touche la semaine (ou en retard)
    taches_projet, plans = [], {}
    for t in TacheProjet.query.join(Projet).filter(
        Projet.actif.is_(True), TacheProjet.statut != "termine", TacheProjet.techniciens.any(Utilisateur.id == eleve.id)
    ):
        if t.projet_id not in plans:
            try:
                plans[t.projet_id] = planifier(t.projet)
            except Invalide:
                plans[t.projet_id] = {}
        d = tache_projet_dict(t, plans[t.projet_id])
        if d.get("debut") and (d["debut"] <= au.isoformat() and d["fin"] >= du.isoformat() or d.get("en_retard")):
            taches_projet.append(d)

    # Préventif de niveau 3-4 à prendre : échéance dans la semaine (ou en retard), confié à personne
    a_prendre = taches_a_prendre(du, au)

    type_semaine = db.session.query(SemaineCalendrier.type).filter_by(lundi=du).scalar() or "cours"
    evenements = EvenementCalendrier.query.filter(EvenementCalendrier.date.between(du, au)).order_by(EvenementCalendrier.date).all()
    debut_annee = date(annee_scolaire(du), 8, 1)
    return jsonify(
        eleve={"id": eleve.id, "nom": eleve.nom},
        semaine={"lundi": du.isoformat(), "dimanche": au.isoformat(), "numero": du.isocalendar()[1], "type": type_semaine},
        evenements=[e.to_dict() for e in evenements],
        bons=[b.to_dict() for b in bons],
        bons_preventifs=[b.to_dict() for b in bons_preventifs],
        chantiers=[c.to_dict() for c in chantiers],
        taches_projet=taches_projet,
        preventif_a_prendre=a_prendre,
        bilan={"semaine": _bilan(eleve, du, au), "annee": _bilan(eleve, debut_annee, au)},
    )


# ---------- Position des élèves (ADM-05) ----------

def _atelier_par_defaut():
    return atelier_position_defaut()


def position_dict(eleve, defaut=None):
    atelier = eleve.position_atelier or defaut
    return {
        "eleve": {"id": eleve.id, "nom": eleve.nom},
        "atelier": {"id": atelier.id, "nom": atelier.nom} if atelier else None,
        "par_defaut": eleve.position_atelier_id is None,
        "mise_a_jour": iso(eleve.position_le),
    }


@bp.get("/eleve/position")
@role_required("technicien")
def ma_position():
    return jsonify(position=position_dict(current_user, _atelier_par_defaut()))


@bp.put("/eleve/position")
@role_required("admin", "technicien")
def changer_position():
    """L'élève indique l'atelier où il se trouve ; l'enseignant peut corriger celle d'un élève (technicien_id)."""
    donnees = request.get_json(silent=True) or {}
    if current_user.role == "technicien":
        eleve = current_user
    else:
        eleve = db.session.get(Utilisateur, donnees.get("technicien_id") or 0)
        if not eleve or eleve.role != "technicien":
            return erreur("Choisissez un élève.", 400)
    try:
        atelier = db.session.get(Atelier, int(donnees.get("atelier_id")))
    except (TypeError, ValueError):
        atelier = None
    if not atelier:
        return erreur("Choisissez l'atelier.", 400)
    eleve.position_atelier = atelier
    eleve.position_le = maintenant()
    db.session.commit()
    return jsonify(position=position_dict(eleve))


@bp.get("/eleve/positions")
@role_required("admin")
def positions():
    """Tableau récapitulatif de l'enseignant : où se trouve chaque élève actif."""
    defaut = _atelier_par_defaut()
    eleves = Utilisateur.query.filter_by(role="technicien", actif=True).order_by(Utilisateur.nom).all()
    ateliers = Atelier.query.order_by(Atelier.ordre, Atelier.nom).all()
    return jsonify(positions=[position_dict(e, defaut) for e in eleves], ateliers=[a.to_dict() for a in ateliers])
