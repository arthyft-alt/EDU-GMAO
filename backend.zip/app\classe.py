"""Classe et promotion (demande de Simon du 29/10/2026, choix 1A, 2A) : une seule promotion à la fois.

- Créer toute la classe d'un coup à partir d'une liste de noms (copiée d'Excel ou de Pronote) : comptes créés,
  identifiants et mots de passe simples à imprimer.
- « Clôturer l'année » quand l'enseignant le décide : copie de sécurité, puis le même changement d'année que le
  1er août (élèves anonymisés, travail en cours remis « à attribuer », groupes vidés…). L'historique reste entier.
"""
import re
import unicodedata

from flask import Blueprint, jsonify, request

from . import db, preventif
from .admin import mot_de_passe_simple
from .auth import erreur, role_required
from .models import GroupeEleves, Parametre, Utilisateur, journaliser

bp = Blueprint("classe", __name__)

CONFIRMATION = "CLOTURER"
ELEVES_MAX = 60


def _anciens():
    return (Utilisateur.login.like("anonyme-%")) | (Utilisateur.login.like("supprime-%"))


def identifiant(nom, pris):
    """« DUPONT Jean-Marc » → « dupont.jean-marc » ; « dupont.jean-marc2 » s'il est déjà pris."""
    sans_accents = unicodedata.normalize("NFKD", nom).encode("ascii", "ignore").decode().lower()
    mots = [re.sub(r"[^a-z0-9-]", "", m).strip("-") for m in sans_accents.split()]
    base = ".".join(m for m in mots if m)[:50] or "eleve"
    login, n = base, 2
    while login in pris:
        login, n = f"{base}{n}", n + 1
    pris.add(login)
    return login


@bp.get("/admin/promotion")
@role_required("admin")
def promotion():
    eleves = Utilisateur.query.filter(Utilisateur.role == "technicien", ~_anciens()).order_by(Utilisateur.nom).all()
    return jsonify(
        eleves=[{"id": e.id, "nom": e.nom, "login": e.login, "actif": e.actif} for e in eleves],
        anciens=Utilisateur.query.filter(Utilisateur.role == "technicien", _anciens()).count(),
        groupes=[{"id": g.id, "nom": g.nom, "membres": len(g.membres)} for g in GroupeEleves.query.order_by(GroupeEleves.nom)],
    )


@bp.post("/admin/promotion/eleves")
@role_required("admin")
def creer_classe():
    """{texte} : un élève par ligne (« Nom Prénom »). Renvoie les fiches d'identifiants à imprimer."""
    lignes = str((request.get_json(silent=True) or {}).get("texte") or "").splitlines()
    noms = []
    for ligne in lignes:
        # Une liste copiée d'un tableur peut avoir des colonnes séparées par des tabulations ou des « ; »
        nom = " ".join(re.split(r"[\t;]+", ligne)).strip()
        nom = " ".join(nom.split())
        if nom and nom.lower() not in {n.lower() for n in noms}:
            noms.append(nom)
    if not noms:
        return erreur("Collez au moins un nom d'élève (un par ligne).", 400)
    if len(noms) > ELEVES_MAX:
        return erreur(f"{ELEVES_MAX} élèves au maximum à la fois.", 400)
    trop_longs = [n for n in noms if len(n) > 120]
    if trop_longs:
        return erreur(f"Nom trop long : « {trop_longs[0][:40]}… ».", 400)
    pris = {login for (login,) in db.session.query(Utilisateur.login)}
    fiches = []
    for nom in noms:
        mot_de_passe = mot_de_passe_simple("technicien")
        eleve = Utilisateur(nom=nom, login=identifiant(nom, pris), role="technicien", actif=True)
        eleve.definir_mot_de_passe(mot_de_passe)
        db.session.add(eleve)
        db.session.flush()
        fiches.append({"id": eleve.id, "nom": eleve.nom, "login": eleve.login, "password": mot_de_passe})
    journaliser("creation", details=f"Classe créée : {len(fiches)} compte(s) élève")
    db.session.commit()
    return jsonify(fiches=fiches), 201


@bp.post("/admin/promotion/cloturer")
@role_required("admin")
def cloturer():
    """Fin d'année décidée par l'enseignant : tous les élèves actuels sont anonymisés (comme le 1er août)."""
    from .cli import changement_annee
    from .donnees import copie_de_securite

    if str((request.get_json(silent=True) or {}).get("confirmation", "")).strip().upper() != CONFIRMATION:
        return erreur(f"Tapez {CONFIRMATION} pour confirmer.", 400)
    eleves = Utilisateur.query.filter(Utilisateur.role == "technicien", ~_anciens()).all()
    if not eleves:
        return erreur("Aucun élève à anonymiser : l'année est déjà clôturée.", 409)
    sauvegarde = copie_de_securite("cloture-annee")
    jour = preventif.aujourdhui()
    bilan = changement_annee(jour, eleves)
    # Clôture faite en fin d'année scolaire (mai à août) : le passage automatique du 1er août qui suit est inutile
    # (sinon il anonymiserait les comptes de la nouvelle classe créés en juillet)
    if jour.month in (5, 6, 7, 8):
        param = db.session.get(Parametre, "dernier_reset_annuel") or Parametre(cle="dernier_reset_annuel")
        param.valeur = str(jour.year)
        db.session.add(param)
    db.session.commit()
    return jsonify(bilan=bilan, sauvegarde=sauvegarde)
