"""Listes de référence utilisées par les écrans (ateliers, éléments, types, statuts…)."""
from flask import Blueprint, jsonify
from flask_login import login_required

from . import referentiels as ref
from .models import Atelier, Element
from .reglages import liste, types_travaux

bp = Blueprint("parametres", __name__)


@bp.get("/referentiels")
@login_required
def referentiels():
    return jsonify(
        ateliers=[a.to_dict() for a in Atelier.query.order_by(Atelier.ordre, Atelier.nom)],
        elements=[e.to_dict() for e in Element.query.order_by(Element.ordre, Element.nom)],
        roles=ref.ROLES,
        types_travaux=types_travaux(),
        periodicites=ref.PERIODICITES,
        statuts_bi=ref.STATUTS_BI,
        urgences=ref.URGENCES,
        types_preventif=liste("types_preventif"),
        categories_pieces=liste("categories_pieces"),
        categories_documents=liste("categories_documents"),
        niveaux_maintenance=ref.NIVEAUX_MAINTENANCE,
    )
