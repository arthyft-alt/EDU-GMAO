"""Création de l'application Flask."""
from flask import Blueprint, Flask, jsonify
from flask_login import LoginManager
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy import event
from werkzeug.exceptions import HTTPException

from .config import CLE_PAR_DEFAUT, VERSION, Config, INSTANCE_DIR

db = SQLAlchemy()
migrate = Migrate()
login_manager = LoginManager()

MESSAGES_ERREUR = {
    400: "Requête invalide.",
    401: "Vous devez vous connecter.",
    403: "Vous n'avez pas les droits pour cette action.",
    404: "Élément introuvable.",
    405: "Action non autorisée sur cette adresse.",
    409: "Action impossible : conflit avec des données existantes.",
    413: "Fichier trop volumineux.",
    500: "Erreur interne du serveur.",
}


def _reglages_sqlite(connexion, _enregistrement):
    """SQLite local : journal WAL (lectures pendant les écritures, écritures bien plus rapides)."""
    curseur = connexion.cursor()
    curseur.execute("PRAGMA journal_mode=WAL")
    curseur.execute("PRAGMA synchronous=NORMAL")
    curseur.execute("PRAGMA busy_timeout=5000")
    curseur.close()


def create_app(config=None):
    INSTANCE_DIR.mkdir(parents=True, exist_ok=True)
    app = Flask(__name__, instance_path=str(INSTANCE_DIR))
    app.config.from_object(Config)
    if config:
        app.config.update(config)

    # En ligne (MySQL), la clé secrète par défaut permettrait de fabriquer de faux cookies de connexion
    if app.config["SECRET_KEY"] == CLE_PAR_DEFAUT and not app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite"):
        raise RuntimeError(
            "SECRET_KEY n'est pas définie dans le fichier .env du serveur : "
            "générez-en une (guide 05, étape 7) avant de mettre la GMAO en ligne."
        )

    db.init_app(app)
    if app.config["SQLALCHEMY_DATABASE_URI"].startswith("sqlite"):
        with app.app_context():
            event.listen(db.engine, "connect", _reglages_sqlite)
    # render_as_batch : nécessaire pour modifier des tables existantes sous SQLite
    migrate.init_app(app, db, render_as_batch=True)
    login_manager.init_app(app)

    from . import models  # noqa: F401  (enregistre les tables)

    @login_manager.user_loader
    def charger_utilisateur(identifiant):
        # Compte désactivé, mot de passe ou QR code changé depuis la connexion : la session n'est plus valable
        try:
            utilisateur = db.session.get(models.Utilisateur, int(str(identifiant).split(":", 1)[0]))
        except ValueError:
            return None
        if not utilisateur or not utilisateur.actif or utilisateur.get_id() != identifiant:
            return None
        return utilisateur

    @login_manager.unauthorized_handler
    def non_connecte():
        return jsonify(error=MESSAGES_ERREUR[401]), 401

    @app.after_request
    def entetes_de_securite(reponse):
        # Le navigateur ne doit jamais « deviner » le type d'un fichier déposé (photo qui serait en fait une page)
        reponse.headers.setdefault("X-Content-Type-Options", "nosniff")
        reponse.headers.setdefault("Referrer-Policy", "same-origin")
        # Les réponses de l'API ne sont pas gardées en cache (données qui changent sans cesse)
        if reponse.mimetype == "application/json":
            reponse.headers.setdefault("Cache-Control", "no-store")
        return reponse

    @app.errorhandler(HTTPException)
    def erreur_http(e):
        return jsonify(error=MESSAGES_ERREUR.get(e.code, e.description)), e.code

    @app.errorhandler(Exception)
    def erreur_interne(e):
        app.logger.exception(e)
        db.session.rollback()
        return jsonify(error=MESSAGES_ERREUR[500]), 500

    # Toutes les routes de l'API sont sous /api
    api = Blueprint("api", __name__, url_prefix="/api")

    @api.get("/health")
    def health():
        moteur = db.engine.dialect.name
        return jsonify(status="ok", database="mysql" if moteur in ("mysql", "mariadb") else moteur, version=VERSION)

    from . import admin, aic, analyses, auth, classe, bilan_semaine, calendrier, chantiers, documentation, donnees, ecran_atelier, eleve, export_machine, import_excel, roles, suppression, equipement, indicateurs, interventions, parametres, messagerie, preventif, projets, reglages, securite, stock, tableau_de_bord

    api.register_blueprint(auth.bp)
    api.register_blueprint(parametres.bp)
    api.register_blueprint(equipement.bp)
    api.register_blueprint(interventions.bp)
    api.register_blueprint(stock.bp)
    api.register_blueprint(preventif.bp)
    api.register_blueprint(documentation.bp)
    api.register_blueprint(indicateurs.bp)
    api.register_blueprint(analyses.bp)
    api.register_blueprint(ecran_atelier.bp)
    api.register_blueprint(import_excel.bp)
    api.register_blueprint(export_machine.bp)
    api.register_blueprint(suppression.bp)
    api.register_blueprint(classe.bp)
    api.register_blueprint(roles.bp)
    api.register_blueprint(calendrier.bp)
    api.register_blueprint(chantiers.bp)
    api.register_blueprint(projets.bp)
    api.register_blueprint(eleve.bp)
    api.register_blueprint(aic.bp)
    api.register_blueprint(donnees.bp)
    api.register_blueprint(admin.bp)
    api.register_blueprint(reglages.bp)
    api.register_blueprint(tableau_de_bord.bp)
    api.register_blueprint(messagerie.bp)
    api.register_blueprint(bilan_semaine.bp)
    api.register_blueprint(securite.bp)
    app.register_blueprint(api)

    from . import cli

    cli.enregistrer(app)

    return app
