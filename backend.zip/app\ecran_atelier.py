"""Écran d'atelier (fonction n° 24 retenue par Simon le 29/10/2026) : une page pour une télévision de l'atelier.

Choix de Simon : les bons en cours et en attente, le préventif de la semaine et en retard, qui fait quoi,
le bandeau sécurité et l'heure ; accès avec un compte (le compte opérateur convient), tous les ateliers.
L'écran relit ces données toutes les 30 s (pas de temps réel sur cPanel).
"""
from flask import Blueprint, jsonify

from . import preventif
from . import referentiels as ref
from .aic import compteurs
from .auth import role_required
from .calendrier import lundi, semaines_de_vacances
from .models import (
    AbsenceEleve,
    BonIntervention,
    BonPreventif,
    Chantier,
    ChantierAffectation,
    Machine,
    SemaineSecurite,
    TachePreventive,
    Utilisateur,
)

bp = Blueprint("ecran_atelier", __name__)

ORDRE_URGENCE = {"critique": 0, "normale": 1, "faible": 2}
ORDRE_STATUT = {"en_cours": 0, "a_cloturer": 1, "preparation": 2, "demande": 3, "autre": 4}


def _machine(m):
    return {"repere": m.repere, "designation": m.designation, "atelier": m.atelier.nom}


@bp.get("/ecran-atelier")
@role_required("admin", "technicien", "operateur")
def ecran():
    jour = preventif.aujourdhui()
    vacances = semaines_de_vacances()

    # Bons en cours et en attente : les urgences critiques en tête, puis ce qui avance, puis le plus ancien
    bons = BonIntervention.query.filter(BonIntervention.statut != "termine").all()
    bons.sort(key=lambda b: (ORDRE_URGENCE.get(b.urgence, 1), ORDRE_STATUT.get(b.statut, 5), b.cree_le))

    # Préventif de la semaine et en retard (tous niveaux), avec les élèves de son bon de préventif
    requete = TachePreventive.query.join(Machine).filter(TachePreventive.actif.is_(True), Machine.hors_service.is_(False))
    taches = preventif.avec_machine(requete).all()
    faites = preventif.realisations_par_tache(taches, jour)
    ouverts = preventif.bons_preventifs_ouverts([t.id for t in taches])
    a_faire = []
    for t in taches:
        d = preventif.tache_dict(t, jour=jour, vacances=vacances, realisations=faites[t.id], bons=ouverts)
        if d["statut"] in ("a_faire", "en_retard"):
            a_faire.append(
                {
                    "id": t.id,
                    "nom": t.nom,
                    "niveau": t.niveau,
                    "machine": _machine(t.machine),
                    "statut": d["statut"],
                    "echeance": d["echeance"],
                    "eleves": [e["nom"] for e in d["bon_preventif"]["techniciens"]] if d["bon_preventif"] else [],
                }
            )
    a_faire.sort(key=lambda p: (p["statut"] != "en_retard", p["echeance"], p["machine"]["repere"]))

    # Qui fait quoi : chaque élève actif, son travail ouvert, sa position et son absence du jour
    absents = {a.utilisateur_id for a in AbsenceEleve.query.filter_by(jour=jour)}
    travail = {}

    def ajouter(eleve_id, genre, texte):
        travail.setdefault(eleve_id, []).append({"genre": genre, "texte": texte})

    for b in bons:
        for t in b.techniciens:
            ajouter(t.id, "bon", f"{b.numero} · {b.machine.repere}")
    for bp_ in BonPreventif.query.filter(BonPreventif.termine_le.is_(None)):
        for t in bp_.techniciens:
            ajouter(t.id, "preventif", f"{bp_.tache.machine.repere} · {bp_.tache.nom}")
    for a in ChantierAffectation.query.join(Chantier).filter(Chantier.statut != "termine", ChantierAffectation.termine_le.is_(None)):
        ajouter(a.utilisateur_id, "chantier", a.chantier.titre)
    eleves = Utilisateur.query.filter_by(role="technicien", actif=True).order_by(Utilisateur.nom).all()
    from .roles import roles_de_la_semaine

    roles = roles_de_la_semaine()  # vide si l'option « rôles » est désactivée

    cette_semaine = lundi(jour)
    semaine = SemaineSecurite.query.filter(SemaineSecurite.lundi <= cette_semaine).order_by(SemaineSecurite.lundi.desc()).first()
    serie, record = compteurs(cette_semaine)
    return jsonify(
        bons=[
            {
                "id": b.id,
                "numero": b.numero,
                "machine": _machine(b.machine),
                "description": b.description,
                "statut": b.statut,
                "statut_libelle": ref.STATUTS_BI.get(b.statut, b.statut),
                "urgence": b.urgence,
                "eleves": [t.nom for t in b.techniciens],
            }
            for b in bons
        ],
        preventif=a_faire,
        equipe=[
            {
                "id": e.id,
                "nom": e.nom,
                "absent": e.id in absents,
                "position": e.position_atelier.nom if e.position_atelier else None,
                "travail": travail.get(e.id, []),
                "roles": [r["role"] for r in roles.get(e.id, [])],
            }
            for e in eleves
        ],
        securite={"couleur": semaine.couleur if semaine else None, "serie": serie, "record": record},
        semaine={"numero": cette_semaine.isocalendar()[1], "vacances": cette_semaine in vacances},
    )
