"""Administration des données : sauvegarde / chargement (ADM-02), bilan des élèves (ADM-01), journal (TRV-07).
Réservé à l'administrateur."""
import io
import json
import shutil
import tempfile
import zipfile
from datetime import date, datetime, timedelta
from pathlib import Path

from alembic.migration import MigrationContext
from flask import Blueprint, Response, current_app, jsonify, request, send_file
from sqlalchemy import Boolean, Date, DateTime, Float, Integer

from . import db, tableur
from .auth import erreur, role_required
from .calendrier import annee_scolaire
from .config import INSTANCE_DIR
from .dates import PARIS, debut_jour_paris, format_paris
from .models import (
    BonIntervention,
    ChantierAffectation,
    JournalAction,
    RealisationPreventive,
    ReleveConditionnel,
    SaisieIndicateurs,
    TacheProjet,
    Utilisateur,
    journaliser,
)

bp = Blueprint("donnees", __name__, url_prefix="/admin")

FORMAT = "gmao-brisson-sauvegarde"
TAILLE_MAX_SAUVEGARDE = 1024 * 1024 * 1024  # 1 Go


# ---------- Sauvegarde ----------

def _revision():
    with db.engine.connect() as connexion:
        return MigrationContext.configure(connexion).get_current_revision()


def _valeur_json(valeur):
    if isinstance(valeur, (datetime, date)):
        return valeur.isoformat()
    return valeur


def _valeur_base(colonne, valeur):
    """Valeur lue dans la sauvegarde -> type de la colonne."""
    if valeur is None:
        return None
    if isinstance(colonne.type, DateTime):
        return datetime.fromisoformat(valeur)
    if isinstance(colonne.type, Date):
        return date.fromisoformat(valeur)
    if isinstance(colonne.type, Boolean):
        return bool(valeur)
    if isinstance(colonne.type, Integer):
        return int(valeur)
    if isinstance(colonne.type, Float):
        return float(valeur)
    return valeur


def creer_sauvegarde(destination):
    """Écrit la sauvegarde complète (données + fichiers déposés) dans le fichier zip `destination`."""
    tables = {}
    with db.engine.connect() as connexion:
        for table in db.metadata.sorted_tables:
            lignes = connexion.execute(table.select()).mappings().all()
            tables[table.name] = [{k: _valeur_json(v) for k, v in ligne.items()} for ligne in lignes]
    manifeste = {
        "format": FORMAT,
        "revision": _revision(),
        "cree_le": datetime.now(PARIS).isoformat(timespec="seconds"),
        "lignes": {nom: len(l) for nom, l in tables.items()},
    }
    dossier = Path(current_app.config["UPLOAD_DIR"])
    with zipfile.ZipFile(destination, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("manifeste.json", json.dumps(manifeste, ensure_ascii=False, indent=2))
        z.writestr("donnees.json", json.dumps(tables, ensure_ascii=False))
        if dossier.exists():
            for fichier in dossier.rglob("*"):
                if fichier.is_file():
                    z.write(fichier, f"fichiers/{fichier.relative_to(dossier).as_posix()}")
    return manifeste


COPIES_GARDEES = 10


def dossier_sauvegardes():
    """Copies de sécurité écrites sur le serveur (réglable : les tests utilisent un dossier temporaire)."""
    dossier = Path(current_app.config.get("SAUVEGARDE_DIR") or INSTANCE_DIR / "sauvegardes")
    dossier.mkdir(parents=True, exist_ok=True)
    return dossier


def copie_de_securite(motif):
    """Sauvegarde complète écrite sur le serveur avant une opération qui efface des données (suppression,
    clôture de l'année) : instance/sauvegardes/avant-<motif>-<date>.zip. Seules les 10 plus récentes sont gardées."""
    dossier = dossier_sauvegardes()
    chemin = dossier / f"avant-{motif}-{datetime.now(PARIS):%Y-%m-%d-%Hh%M%S}.zip"
    creer_sauvegarde(chemin)
    automatiques = sorted(
        (f for f in dossier.glob("avant-*.zip") if not f.name.startswith("avant-chargement")), key=lambda f: f.stat().st_mtime, reverse=True
    )
    for ancienne in automatiques[COPIES_GARDEES:]:
        ancienne.unlink(missing_ok=True)
    return chemin.name


@bp.get("/sauvegarde")
@role_required("admin")
def telecharger_sauvegarde():
    # Fichier temporaire sur disque (effacé après l'envoi) : les PDF et photos peuvent peser lourd
    tampon = tempfile.TemporaryFile()
    creer_sauvegarde(tampon)
    tampon.seek(0)
    journaliser("sauvegarde", details="Téléchargement d'une sauvegarde complète")
    db.session.commit()
    nom = f"sauvegarde-gmao-{datetime.now(PARIS):%Y-%m-%d-%Hh%M}.zip"
    return send_file(tampon, mimetype="application/zip", as_attachment=True, download_name=nom)


@bp.post("/sauvegarde")
@role_required("admin")
def charger_sauvegarde():
    """Remplace toutes les données et tous les fichiers par ceux de la sauvegarde.
    Une copie de sécurité de l'état actuel est d'abord écrite dans instance/sauvegardes/."""
    # Une sauvegarde contient tous les PDF et photos : elle dépasse vite la limite de 20 Mo des autres envois
    request.max_content_length = TAILLE_MAX_SAUVEGARDE
    fichier = request.files.get("fichier")
    if not fichier:
        return erreur("Choisissez le fichier de sauvegarde (.zip).", 400)
    try:
        # Recopiée sur disque plutôt qu'en mémoire (serveur mutualisé)
        recu = tempfile.TemporaryFile()
        shutil.copyfileobj(fichier.stream, recu)
        recu.seek(0)
        archive = zipfile.ZipFile(recu)
        manifeste = json.loads(archive.read("manifeste.json"))
        tables = json.loads(archive.read("donnees.json"))
    except (zipfile.BadZipFile, KeyError, ValueError):
        return erreur("Ce fichier n'est pas une sauvegarde de la GMAO.", 400)
    if manifeste.get("format") != FORMAT:
        return erreur("Ce fichier n'est pas une sauvegarde de la GMAO.", 400)
    if manifeste.get("revision") != _revision():
        return erreur(
            "Cette sauvegarde vient d'une autre version de la GMAO : mettez les deux installations à la même version avant de la charger.",
            409,
        )

    # Copie de sécurité de l'état actuel
    dossier_copies = dossier_sauvegardes()
    copie = dossier_copies / f"avant-chargement-{datetime.now(PARIS):%Y-%m-%d-%Hh%M%S}.zip"
    creer_sauvegarde(copie)

    # Remplacement des données (ordre des dépendances : on vide à l'envers, on remplit à l'endroit)
    db.session.remove()
    try:
        with db.engine.begin() as connexion:
            for table in reversed(db.metadata.sorted_tables):
                connexion.execute(table.delete())
            for table in db.metadata.sorted_tables:
                lignes = tables.get(table.name) or []
                if lignes:
                    colonnes = {c.name: c for c in table.columns}
                    connexion.execute(
                        table.insert(),
                        [{k: _valeur_base(colonnes[k], v) for k, v in ligne.items() if k in colonnes} for ligne in lignes],
                    )
    except Exception as e:  # la transaction est annulée : la base reste dans son état d'avant
        current_app.logger.exception(e)
        return erreur("Le chargement a échoué ; rien n'a été modifié. Copie de sécurité : " + copie.name, 500)

    # Remplacement des fichiers déposés
    dossier = Path(current_app.config["UPLOAD_DIR"])
    with tempfile.TemporaryDirectory() as temporaire:
        nouveau = Path(temporaire) / "fichiers"
        nouveau.mkdir()
        for nom in archive.namelist():
            if nom.startswith("fichiers/") and not nom.endswith("/"):
                cible = (nouveau / nom[len("fichiers/"):]).resolve()
                if nouveau.resolve() not in cible.parents:
                    continue  # chemin suspect : ignoré
                cible.parent.mkdir(parents=True, exist_ok=True)
                cible.write_bytes(archive.read(nom))
        if dossier.exists():
            shutil.rmtree(dossier)
        shutil.copytree(nouveau, dossier)

    journaliser("chargement_sauvegarde", details=f"Sauvegarde du {manifeste['cree_le']} chargée (copie de sécurité : {copie.name})")
    db.session.commit()
    return jsonify(ok=True, sauvegarde_du=manifeste["cree_le"], copie_de_securite=copie.name, lignes=manifeste["lignes"])


# ---------- Bilan d'un élève (ADM-01) ----------

def _periode():
    aujourdhui = datetime.now(PARIS).date()
    try:
        du = date.fromisoformat(request.args["du"]) if request.args.get("du") else date(annee_scolaire(aujourdhui), 8, 1)
        au = date.fromisoformat(request.args["au"]) if request.args.get("au") else aujourdhui
    except ValueError:
        raise ValueError("Date invalide.")
    return du, au


def bilan(eleve, du, au):
    debut, fin = debut_jour_paris(du), debut_jour_paris(au + timedelta(days=1))
    bons = (
        BonIntervention.query.filter(BonIntervention.techniciens.any(Utilisateur.id == eleve.id), BonIntervention.cree_le >= debut, BonIntervention.cree_le < fin)
        .order_by(BonIntervention.cree_le)
        .all()
    )
    chantiers = ChantierAffectation.query.filter_by(utilisateur_id=eleve.id).all()
    chantiers = [a for a in chantiers if debut <= a.chantier.cree_le < fin or (a.termine_le and debut <= a.termine_le < fin)]
    preventif = (
        RealisationPreventive.query.filter(RealisationPreventive.par_id == eleve.id, RealisationPreventive.realise_le >= debut, RealisationPreventive.realise_le < fin)
        .order_by(RealisationPreventive.realise_le)
        .all()
    )
    taches = TacheProjet.query.filter(TacheProjet.techniciens.any(Utilisateur.id == eleve.id)).all()
    saisies = SaisieIndicateurs.query.filter(SaisieIndicateurs.saisi_par_id == eleve.id, SaisieIndicateurs.debut >= du, SaisieIndicateurs.debut <= au).all()
    releves = ReleveConditionnel.query.filter(ReleveConditionnel.par_id == eleve.id, ReleveConditionnel.date >= du, ReleveConditionnel.date <= au).all()
    termines = [b for b in bons if b.statut == "termine"]
    return {
        "eleve": {"id": eleve.id, "nom": eleve.nom, "login": eleve.login},
        "periode": {"du": du.isoformat(), "au": au.isoformat()},
        "totaux": {
            "bons": len(bons),
            "bons_termines": len(termines),
            "temps_intervention_h": round(sum(b.temps_passe_h or 0 for b in termines), 2),
            "chantiers": len(chantiers),
            "chantiers_termines": sum(1 for a in chantiers if a.termine_le or a.chantier.statut == "termine"),
            "preventif": len(preventif),
            "taches_projet": len(taches),
            "saisies_indicateurs": len(saisies),
            "releves": len(releves),
        },
        "bons": [
            {"numero": b.numero, "date": b.cree_le.isoformat(), "machine": f"{b.machine.repere} — {b.machine.designation}", "type": b.type_travail,
             "statut": b.statut, "description": b.description, "travaux": b.travaux, "temps_passe_h": b.temps_passe_h}
            for b in bons
        ],
        "chantiers": [
            {"titre": a.chantier.titre, "type": a.chantier.type, "statut": "termine" if a.termine_le or a.chantier.statut == "termine" else a.chantier.statut,
             "termine_le": (a.termine_le or a.chantier.termine_le).isoformat() if (a.termine_le or a.chantier.termine_le) else None}
            for a in chantiers
        ],
        "preventif": [
            {"tache": r.tache.nom, "machine": r.tache.machine.repere, "niveau": r.tache.niveau, "echeance": r.echeance.isoformat(), "realise_le": r.realise_le.isoformat()}
            for r in preventif
        ],
        "taches_projet": [{"projet": t.projet.nom, "tache": t.nom, "avancement": t.avancement, "statut": t.statut} for t in taches],
        "saisies_indicateurs": [{"machine": s.machine.repere, "periode": s.periode, "debut": s.debut.isoformat()} for s in saisies],
        "releves": [{"machine": r.machine.repere, "date": r.date.isoformat(), "type": r.type, "resultat": r.resultat} for r in releves],
    }


def _eleve(eleve_id):
    eleve = db.session.get(Utilisateur, eleve_id)
    if not eleve or eleve.role != "technicien":
        return None, erreur("Élève introuvable.", 404)
    return eleve, None


@bp.get("/bilan/<int:eleve_id>")
@role_required("admin")
def bilan_eleve(eleve_id):
    eleve, err = _eleve(eleve_id)
    if err:
        return err
    try:
        du, au = _periode()
    except ValueError as e:
        return erreur(str(e), 400)
    return jsonify(bilan=bilan(eleve, du, au))


def _decimal(n):
    return "" if n is None else f"{n:.2f}".rstrip("0").rstrip(".").replace(".", ",")


@bp.get("/bilan/<int:eleve_id>/export.csv")
@role_required("admin")
def bilan_csv(eleve_id):
    eleve, err = _eleve(eleve_id)
    if err:
        return err
    try:
        du, au = _periode()
    except ValueError as e:
        return erreur(str(e), 400)
    b = bilan(eleve, du, au)
    sortie = io.StringIO()
    e = tableur.ecrivain(sortie)
    e.writerow(["Rubrique", "Date", "Référence", "Machine / projet", "Détail", "Statut", "Temps (h)"])
    for x in b["bons"]:
        e.writerow(["Intervention", format_paris(datetime.fromisoformat(x["date"])), x["numero"], x["machine"], x["travaux"] or x["description"], x["statut"], _decimal(x["temps_passe_h"])])
    for x in b["chantiers"]:
        e.writerow(["Chantier", format_paris(datetime.fromisoformat(x["termine_le"])) if x["termine_le"] else "", "", "", x["titre"], x["statut"], ""])
    for x in b["preventif"]:
        e.writerow(["Préventif", format_paris(datetime.fromisoformat(x["realise_le"])), f"Niveau {x['niveau']}", x["machine"], x["tache"], "réalisé", ""])
    for x in b["taches_projet"]:
        e.writerow(["Projet", "", "", x["projet"], x["tache"], f"{x['avancement']} %", ""])
    for x in b["saisies_indicateurs"]:
        e.writerow(["Indicateurs", x["debut"], x["periode"], x["machine"], "Calcul MTBF / MTTR / coûts", "saisi", ""])
    for x in b["releves"]:
        e.writerow(["Conditionnel", x["date"], x["type"], x["machine"], x["resultat"], "", ""])
    nom = f"bilan-{eleve.login}-{du.isoformat()}.csv"
    return Response("﻿" + sortie.getvalue(), mimetype="text/csv; charset=utf-8", headers={"Content-Disposition": f"attachment; filename={nom}"})


# ---------- Journal des actions (TRV-07) ----------

def _filtrer_journal(requete):
    args = request.args
    if args.get("utilisateur_id", type=int):
        requete = requete.filter(JournalAction.utilisateur_id == args.get("utilisateur_id", type=int))
    if args.get("action"):
        requete = requete.filter(JournalAction.action == args["action"])
    if args.get("objet"):
        requete = requete.filter(JournalAction.objet_type == args["objet"])
    try:
        if args.get("du"):
            requete = requete.filter(JournalAction.date >= debut_jour_paris(date.fromisoformat(args["du"])))
        if args.get("au"):
            requete = requete.filter(JournalAction.date < debut_jour_paris(date.fromisoformat(args["au"]) + timedelta(days=1)))
    except ValueError:
        raise ValueError("Date invalide.")
    return requete


def _ligne_journal(j):
    return {
        "id": j.id,
        "date": j.date.isoformat() + "+00:00",
        "utilisateur": j.utilisateur.nom if j.utilisateur else None,
        "action": j.action,
        "objet": j.objet_type,
        "objet_id": j.objet_id,
        "details": j.details,
    }


@bp.get("/journal")
@role_required("admin")
def journal():
    try:
        requete = _filtrer_journal(JournalAction.query)
    except ValueError as e:
        return erreur(str(e), 400)
    page = max(request.args.get("page", 1, type=int), 1)
    total = requete.count()
    lignes = requete.order_by(JournalAction.date.desc(), JournalAction.id.desc()).offset((page - 1) * 100).limit(100).all()
    actions = [a for (a,) in db.session.query(JournalAction.action).distinct().order_by(JournalAction.action)]
    objets = [o for (o,) in db.session.query(JournalAction.objet_type).distinct().order_by(JournalAction.objet_type) if o]
    return jsonify(lignes=[_ligne_journal(j) for j in lignes], total=total, page=page, actions=actions, objets=objets)


@bp.get("/journal/export.csv")
@role_required("admin")
def journal_csv():
    try:
        lignes = _filtrer_journal(JournalAction.query).order_by(JournalAction.date.desc()).limit(50000).all()
    except ValueError as e:
        return erreur(str(e), 400)
    sortie = io.StringIO()
    e = tableur.ecrivain(sortie)
    e.writerow(["Date", "Qui", "Action", "Objet", "N°", "Détails"])
    for j in lignes:
        e.writerow([format_paris(j.date), j.utilisateur.nom if j.utilisateur else "", j.action, j.objet_type or "", j.objet_id or "", j.details or ""])
    return Response("﻿" + sortie.getvalue(), mimetype="text/csv; charset=utf-8",
                    headers={"Content-Disposition": f"attachment; filename=journal-{date.today():%Y-%m-%d}.csv"})


@bp.get("/rappel-1er-aout")
@role_required("admin")
def rappel_premier_aout():
    """En juillet : rappeler d'exporter les bilans avant l'anonymisation du 1er août."""
    jour = datetime.now(PARIS).date()
    return jsonify(afficher=jour.month == 7, date=date(jour.year, 8, 1).isoformat())
