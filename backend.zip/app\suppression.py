"""Suppression par l'enseignant (demande de Simon du 29/10/2026, choix 3A, 4A, 5A).

Tout objet métier peut être supprimé par l'administrateur, après un aperçu qui liste tout ce qui sera effacé avec
lui, la saisie du mot SUPPRIMER, et une copie de sécurité automatique. Le moteur suit les liens de la base :
- un lien obligatoire (ex. le bon d'une machine) : l'objet lié est supprimé lui aussi, et ainsi de suite ;
- un lien facultatif (ex. le mouvement de stock d'un bon) : l'objet lié est gardé, seul le lien est retiré.
Un compte n'est jamais effacé de la base : il devient « Élève supprimé » (son travail reste dans l'historique).
"""
import secrets
from collections import defaultdict

from flask import Blueprint, current_app, jsonify, request
from flask_login import current_user
from sqlalchemy import delete, select, update

from . import db
from .auth import erreur, role_required
from .models import (
    AbsenceEleve,
    BonComposant,
    BonIntervention,
    BonPreventif,
    Chantier,
    ChantierAffectation,
    Commande,
    Document,
    Fournisseur,
    GroupeEleves,
    Machine,
    Parametre,
    Piece,
    Projet,
    RoleAttribution,
    RoueEchange,
    TachePreventive,
    TacheProjet,
    Utilisateur,
    journaliser,
)

bp = Blueprint("suppression", __name__)

CONFIRMATION = "SUPPRIMER"

# Objets que l'enseignant peut supprimer : type → (modèle, libellé de l'objet)
OBJETS = {
    "machine": (Machine, lambda o: f"la machine {o.repere} — {o.designation}"),
    "bon": (BonIntervention, lambda o: f"le bon {o.numero}"),
    "composant": (BonComposant, lambda o: f"le composant « {o.designation} » du bon {o.bon.numero}"),
    "piece": (Piece, lambda o: f"la pièce {o.reference} — {o.designation}"),
    "tache": (TachePreventive, lambda o: f"la tâche préventive « {o.nom} » ({o.machine.repere})"),
    "document": (Document, lambda o: f"le document « {o.titre} »"),
    "chantier": (Chantier, lambda o: f"le chantier « {o.titre} »"),
    "projet": (Projet, lambda o: f"le projet « {o.nom} »"),
    "fournisseur": (Fournisseur, lambda o: f"le fournisseur {o.nom}"),
    "commande": (Commande, lambda o: f"le bon de commande {o.numero}"),
}

# Libellés des tables pour l'aperçu (les tables de liaison n'y figurent pas)
LIBELLES = {
    "machine": ("machine", "machines"),
    "bon_intervention": ("bon d'intervention", "bons d'intervention"),
    "bon_composant": ("composant de bon", "composants de bons"),
    "piece": ("pièce du magasin", "pièces du magasin"),
    "tache_preventive": ("tâche préventive", "tâches préventives"),
    "realisation_preventive": ("échéance préventive cochée", "échéances préventives cochées"),
    "bon_preventif": ("bon de préventif", "bons de préventif"),
    "tache_photo": ("photo de mode opératoire", "photos de mode opératoire"),
    "tache_piece": ("pièce prévue sur le préventif", "pièces prévues sur le préventif"),
    "document": ("document", "documents"),
    "document_machine": ("lien document-machine", "liens document-machine"),
    "piece_machine": ("lien pièce-machine", "liens pièce-machine"),
    "ips_machine": ("IPS (consignes de sécurité)", "IPS (consignes de sécurité)"),
    "releve_conditionnel": ("relevé conditionnel", "relevés conditionnels"),
    "saisie_indicateurs": ("saisie d'indicateurs des élèves", "saisies d'indicateurs des élèves"),
    "chantier": ("chantier", "chantiers"),
    "projet": ("projet", "projets"),
    "tache_projet": ("tâche de projet", "tâches de projet"),
    "commande": ("bon de commande", "bons de commande"),
    "commande_ligne": ("ligne de bon de commande", "lignes de bons de commande"),
    "mouvement": ("mouvement de stock", "mouvements de stock"),
    "panier_ligne": ("ligne du panier", "lignes du panier"),
    "fournisseur": ("fournisseur", "fournisseurs"),
}
# Liens facultatifs à supprimer quand même (sinon l'objet gardé n'aurait plus de sens)
SUPPRIMER_AUSSI = {("panier_ligne", "piece_id")}
# Fichiers rangés sur le disque : table → (colonne, sous-dossier de UPLOAD_DIR)
FICHIERS = {"machine": ("photo", "machines"), "tache_photo": ("fichier", "preventif"), "document": ("fichier", "documents")}


def _texte(table, nombre):
    singulier, pluriel = LIBELLES.get(table, (table, table))
    return f"{nombre} {singulier if nombre == 1 else pluriel}"


def _liens():
    """table → [(table qui y fait référence, colonne)] : la carte des liens de la base."""
    liens = defaultdict(list)
    for table in db.metadata.sorted_tables:
        for colonne in table.columns:
            for cle in colonne.foreign_keys:
                liens[cle.column.table.name].append((table, colonne))
    return liens


class Plan:
    """Ce qu'une suppression efface (par table) et les liens qu'elle retire (objets gardés)."""

    def __init__(self):
        self.supprimes = defaultdict(set)  # table → ids
        self.liaisons = []  # (table de liaison, colonne, ids) : lignes effacées sans identifiant propre
        self.detaches = defaultdict(set)  # (table, colonne) → ids des lignes gardées dont on retire le lien

    def parcourir(self, table, ids, liens):
        nouveaux = set(ids) - self.supprimes[table.name]
        if not nouveaux:
            return
        self.supprimes[table.name] |= nouveaux
        for enfant, colonne in liens[table.name]:
            cle_primaire = [c.name for c in enfant.primary_key.columns]
            if cle_primaire != ["id"]:
                self.liaisons.append((enfant, colonne, nouveaux))
                continue
            lignes = {i for (i,) in db.session.execute(select(enfant.c.id).where(colonne.in_(nouveaux)))}
            if not lignes:
                continue
            if colonne.nullable and (enfant.name, colonne.name) not in SUPPRIMER_AUSSI:
                self.detaches[(enfant, colonne)] |= lignes
            else:
                self.parcourir(enfant, lignes, liens)

    def apercu(self, racine):
        # Dans l'ordre de LIBELLES (bons, préventif, documents…), plus lisible que l'ordre de parcours
        effaces = [_texte(t, len(self.supprimes[t])) for t in LIBELLES if self.supprimes.get(t) and t != racine]
        gardes = defaultdict(int)
        for (table, _), ids in self.detaches.items():
            restants = ids - self.supprimes[table.name]
            if restants and table.name in LIBELLES:
                gardes[table.name] += len(restants)
        return effaces, [_texte(t, n) for t, n in gardes.items()]

    def executer(self):
        fichiers = []
        for table_nom, (colonne, dossier) in FICHIERS.items():
            ids = self.supprimes.get(table_nom)
            if ids:
                table = db.metadata.tables[table_nom]
                fichiers += [(dossier, f) for (f,) in db.session.execute(select(table.c[colonne]).where(table.c.id.in_(ids))) if f]
        for (table, colonne), ids in self.detaches.items():
            restants = ids - self.supprimes[table.name]
            if restants:
                db.session.execute(update(table).where(table.c.id.in_(restants)).values({colonne.name: None}))
        for table, colonne, ids in self.liaisons:
            db.session.execute(delete(table).where(colonne.in_(ids)))
        # Des feuilles vers la racine : une ligne n'est effacée qu'après tout ce qui pointe vers elle
        for table in reversed(db.metadata.sorted_tables):
            ids = self.supprimes.get(table.name)
            if ids:
                db.session.execute(delete(table).where(table.c.id.in_(ids)))
        return fichiers


def _objet(type_objet, objet_id):
    if type_objet not in OBJETS:
        return None, None, erreur("Ce type d'objet ne peut pas être supprimé.", 400)
    modele, libelle = OBJETS[type_objet]
    objet = db.session.get(modele, objet_id)
    if not objet:
        return None, None, erreur("Objet introuvable (déjà supprimé ?).", 404)
    return objet, libelle(objet), None


def _plan(objet):
    plan = Plan()
    plan.parcourir(objet.__table__, {objet.id}, _liens())
    return plan


# ---------- Comptes : « Élève supprimé », le travail reste dans l'historique ----------

def liberer_travail(utilisateurs):
    """Retire des comptes du travail encore ouvert, qui revient « à attribuer » (bons, préventif confié,
    chantiers, tâches de projet), et des groupes. Utilisé à la suppression, à la désactivation et au changement d'année."""
    ids = {u.id for u in utilisateurs}
    if not ids:
        return 0
    libere = 0
    for bon in BonIntervention.query.filter(BonIntervention.statut != "termine", BonIntervention.techniciens.any(Utilisateur.id.in_(ids))):
        bon.techniciens = [t for t in bon.techniciens if t.id not in ids]
        libere += 1
    for bon in BonPreventif.query.filter(BonPreventif.termine_le.is_(None), BonPreventif.techniciens.any(Utilisateur.id.in_(ids))):
        bon.techniciens = [t for t in bon.techniciens if t.id not in ids]
        libere += 1
    for tache in TacheProjet.query.filter(TacheProjet.statut != "termine", TacheProjet.techniciens.any(Utilisateur.id.in_(ids))):
        tache.techniciens = [t for t in tache.techniciens if t.id not in ids]
        libere += 1
    libere += ChantierAffectation.query.filter(ChantierAffectation.utilisateur_id.in_(ids), ChantierAffectation.termine_le.is_(None)).delete(
        synchronize_session=False
    )
    for groupe in GroupeEleves.query.filter(GroupeEleves.membres.any(Utilisateur.id.in_(ids))):
        groupe.membres = [m for m in groupe.membres if m.id not in ids]
    # Rôles (option) : rôles fixes et échanges de roue de ces élèves
    RoleAttribution.query.filter(RoleAttribution.utilisateur_id.in_(ids)).delete(synchronize_session=False)
    RoueEchange.query.filter(RoueEchange.eleve_a_id.in_(ids) | RoueEchange.eleve_b_id.in_(ids)).delete(synchronize_session=False)
    return libere


NOMS_SUPPRIMES = {"technicien": "Élève supprimé", "operateur": "Opérateur supprimé", "admin": "Enseignant supprimé"}


def _refus_compte(u):
    if u.id == current_user.id:
        return "Vous ne pouvez pas supprimer votre propre compte."
    if u.role == "admin" and Utilisateur.query.filter(Utilisateur.role == "admin", Utilisateur.actif.is_(True), Utilisateur.id != u.id).count() == 0:
        return "C'est le dernier enseignant actif : créez-en un autre avant de supprimer celui-ci."
    if u.login.startswith(("supprime-", "anonyme-")):
        return "Ce compte est déjà supprimé ou anonymisé."
    return None


def supprimer_compte(u):
    liberer_travail([u])
    AbsenceEleve.query.filter_by(utilisateur_id=u.id).delete()
    Parametre.query.filter_by(cle=f"qr_operateur_{u.id}").delete()  # QR code de connexion d'un opérateur
    for projet in Projet.query.filter(Projet.membres.any(Utilisateur.id == u.id)):
        projet.membres = [m for m in projet.membres if m.id != u.id]
    ancien = u.login
    u.nom = NOMS_SUPPRIMES.get(u.role, "Compte supprimé")
    u.login = f"supprime-{u.id}"
    u.email = None
    u.actif = False
    u.atelier_id = u.position_atelier_id = u.position_le = None
    u.definir_mot_de_passe(secrets.token_urlsafe(24))
    return ancien


# ---------- Routes ----------

@bp.get("/admin/suppression/<type_objet>/<int:objet_id>")
@role_required("admin")
def apercu(type_objet, objet_id):
    """Ce que la suppression effacerait, avant de confirmer."""
    if type_objet == "utilisateur":
        u = db.session.get(Utilisateur, objet_id)
        if not u:
            return erreur("Compte introuvable.", 404)
        refus = _refus_compte(u)
        ouverts = (
            BonIntervention.query.filter(BonIntervention.statut != "termine", BonIntervention.techniciens.any(Utilisateur.id == u.id)).count()
            + BonPreventif.query.filter(BonPreventif.termine_le.is_(None), BonPreventif.techniciens.any(Utilisateur.id == u.id)).count()
            + ChantierAffectation.query.filter_by(utilisateur_id=u.id, termine_le=None).count()
        )
        return jsonify(
            titre=f"le compte de {u.nom} ({u.login})",
            refus=refus,
            effaces=["le compte et son mot de passe : il ne pourra plus se connecter"],
            gardes=[f"tout son travail passé, affiché sous le nom « {NOMS_SUPPRIMES.get(u.role, 'Compte supprimé')} »"]
            + ([f"{ouverts} travail(aux) en cours, qui repasse(nt) « à attribuer »"] if ouverts else []),
        )
    objet, titre, err = _objet(type_objet, objet_id)
    if err:
        return err
    effaces, gardes = _plan(objet).apercu(objet.__tablename__)
    if type_objet == "composant" and objet.piece_id:
        gardes.append(f"{objet.quantite:g} pièce(s) remise(s) en stock")
    if type_objet in ("bon", "machine"):
        gardes.append("les sorties de stock déjà faites (les pièces ont été utilisées)")
    return jsonify(titre=titre, refus=None, effaces=effaces, gardes=gardes)


@bp.delete("/admin/suppression/<type_objet>/<int:objet_id>")
@role_required("admin")
def supprimer(type_objet, objet_id):
    """Supprime après la saisie de SUPPRIMER et une copie de sécurité automatique."""
    from .donnees import copie_de_securite
    from .stock import mouvementer

    if str((request.get_json(silent=True) or {}).get("confirmation", "")).strip().upper() != CONFIRMATION:
        return erreur(f"Tapez {CONFIRMATION} pour confirmer.", 400)
    if type_objet == "utilisateur":
        u = db.session.get(Utilisateur, objet_id)
        if not u:
            return erreur("Compte introuvable.", 404)
        refus = _refus_compte(u)
        if refus:
            return erreur(refus, 409)
        sauvegarde = copie_de_securite("suppression-compte")
        ancien = supprimer_compte(u)
        journaliser("suppression", u, f"Compte {ancien} supprimé (historique gardé sous « {u.nom} »)")
        db.session.commit()
        return jsonify(ok=True, sauvegarde=sauvegarde)

    objet, titre, err = _objet(type_objet, objet_id)
    if err:
        return err
    sauvegarde = copie_de_securite(f"suppression-{type_objet}")
    if type_objet == "composant" and objet.piece_id:
        # Un composant retiré d'un bon : la pièce n'a pas été utilisée, elle revient en stock
        mouvementer(db.session.get(Piece, objet.piece_id), "entree", objet.quantite, f"Composant retiré du bon {objet.bon.numero}")
    plan = _plan(objet)
    effaces, _ = plan.apercu(objet.__tablename__)
    journaliser("suppression", objet, f"Suppression de {titre}" + (f" (avec {', '.join(effaces)})" if effaces else ""))
    db.session.flush()
    fichiers = plan.executer()
    db.session.commit()
    dossier = current_app.config["UPLOAD_DIR"]
    for sous_dossier, nom in fichiers:
        (dossier / sous_dossier / nom).unlink(missing_ok=True)
    return jsonify(ok=True, sauvegarde=sauvegarde)
