"""Instruction Permanente de Sécurité (IPS) de chaque machine (circulaire 96-294, BOEN n° 47 du 26/12/96).

Rédaction : techniciens (mot de passe « machines ») et enseignants. Visa : enseignant seulement ; toute
modification le retire (« à revalider »). Une IPS validée est lisible sans connexion à une adresse secrète
propre à la machine (QR code affiché sur le poste) ; l'enseignant peut renouveler cette adresse.
"""
import secrets

from flask import Blueprint, current_app, jsonify, request, send_from_directory
from flask_login import current_user

from . import db
from .auth import erreur, role_required, unlock_required
from .models import IpsMachine, Machine, Pictogramme, iso, journaliser, maintenant

bp = Blueprint("securite", __name__)

EQUIPE = ("admin", "technicien")

CONFORMITES = {"oui": "Oui", "non": "Non", "en_cours": "En cours de mise en conformité"}
ACCESSIBILITES = {
    "eleves": "Accessible aux élèves",
    "conditions": "Accessible aux élèves sous conditions",
    "surveillance": "Accessible aux élèves sous la surveillance d'un enseignant",
    "interdite": "Interdite aux élèves",
}


def _lignes(texte):
    return [l.strip() for l in (texte or "").split("\n") if l.strip()]


def ips_dict(machine, ips, public=False):
    """La fiche complète. public=True : adresses des images de pictogrammes accessibles sans connexion."""
    def picto(p):
        d = p.to_dict()
        if public and p.image:
            d["image_url"] = f"/api/public/ips/{ips.jeton}/pictogrammes/{p.id}"
        return d

    d = {
        "machine": {
            "id": machine.id,
            "repere": machine.repere,
            "designation": machine.designation,
            "atelier": machine.atelier.nom,
            "marque": machine.marque,
            "type": machine.modele,
            "annee": machine.annee_mise_en_service,
            "numero_serie": machine.numero_serie,
        },
        "existe": ips is not None,
        "conformite": ips.conformite if ips else None,
        "accessibilite": ips.accessibilite if ips else None,
        "risques": _lignes(ips.risques) if ips else [],
        "consignes": _lignes(ips.consignes) if ips else [],
        "pictogrammes": [picto(p) for p in ips.pictogrammes] if ips else [],
        "modifie_le": iso(ips.modifie_le) if ips else None,
        "modifie_par": ips.modifie_par.nom if ips and ips.modifie_par else None,
        "valide_le": iso(ips.valide_le) if ips else None,
        "valide_par": ips.valide_par.nom if ips and ips.valide_par else None,
        "libelles": {"conformites": CONFORMITES, "accessibilites": ACCESSIBILITES},
    }
    if not public and ips:
        d["jeton"] = ips.jeton
    return d


def _machine_ou_404(machine_id):
    machine = db.session.get(Machine, machine_id)
    if not machine:
        return None, erreur("Machine introuvable.", 404)
    return machine, None


@bp.get("/machines/<int:machine_id>/ips")
@role_required(*EQUIPE)
def lire(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    return jsonify(ips=ips_dict(machine, machine.ips))


@bp.put("/machines/<int:machine_id>/ips")
@role_required(*EQUIPE)
@unlock_required("machines")
def modifier(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    donnees = request.get_json(silent=True) or {}
    conformite = donnees.get("conformite") or None
    accessibilite = donnees.get("accessibilite") or None
    if conformite is not None and conformite not in CONFORMITES:
        return erreur("Conformité au décret 93-40 : choisissez Oui, Non ou En cours.", 400)
    if accessibilite is not None and accessibilite not in ACCESSIBILITES:
        return erreur("Choisissez le type d'accessibilité.", 400)
    risques, consignes = donnees.get("risques") or [], donnees.get("consignes") or []
    if not all(isinstance(l, str) for l in [*risques, *consignes]):
        return erreur("Risques et consignes : une ligne de texte par élément.", 400)
    ids = donnees.get("pictogrammes") or []
    pictos = Pictogramme.query.filter(Pictogramme.id.in_(ids)).all() if ids else []
    if len(pictos) != len(set(ids)):
        return erreur("Pictogramme introuvable.", 400)

    ips = machine.ips or IpsMachine(machine=machine, jeton=secrets.token_urlsafe(24))
    ips.conformite = conformite
    ips.accessibilite = accessibilite
    ips.risques = "\n".join(l.strip()[:300] for l in risques if l.strip())
    ips.consignes = "\n".join(l.strip()[:300] for l in consignes if l.strip())
    ips.pictogrammes = pictos
    ips.modifie_le = maintenant()
    ips.modifie_par_id = current_user.id
    # Toute modification retire le visa : l'IPS doit être revalidée par un enseignant
    ips.valide_le = None
    ips.valide_par_id = None
    db.session.add(ips)
    db.session.flush()
    journaliser("modification", ips, f"IPS de {machine.repere} (visa retiré)")
    db.session.commit()
    return jsonify(ips=ips_dict(machine, ips))


@bp.post("/machines/<int:machine_id>/ips/valider")
@role_required("admin")
def valider(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    if not machine.ips:
        return erreur("Rédigez d'abord l'IPS de cette machine.", 409)
    if not machine.ips.accessibilite or not machine.ips.conformite:
        return erreur("Renseignez la conformité et l'accessibilité avant de valider.", 409)
    machine.ips.valide_le = maintenant()
    machine.ips.valide_par_id = current_user.id
    journaliser("validation", machine.ips, f"IPS de {machine.repere} validée")
    db.session.commit()
    return jsonify(ips=ips_dict(machine, machine.ips))


@bp.post("/machines/<int:machine_id>/ips/renouveler-qr")
@role_required("admin")
def renouveler_qr(machine_id):
    """Nouvelle adresse publique : l'ancien QR code ne fonctionne plus (à réimprimer)."""
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    if not machine.ips:
        return erreur("Rédigez d'abord l'IPS de cette machine.", 409)
    machine.ips.jeton = secrets.token_urlsafe(24)
    journaliser("modification", machine.ips, f"QR code de l'IPS de {machine.repere} renouvelé")
    db.session.commit()
    return jsonify(ips=ips_dict(machine, machine.ips))


# ---------- Accès public (QR code affiché sur la machine), sans connexion ----------

def _ips_publique(jeton):
    ips = IpsMachine.query.filter_by(jeton=jeton).first() if jeton else None
    if not ips:
        return None, erreur("Cette fiche de sécurité n'existe plus : le QR code a peut-être été renouvelé.", 404)
    if not ips.valide_le:
        return None, erreur("Cette fiche de sécurité est en cours de révision. Demandez-la à un enseignant.", 404)
    return ips, None


@bp.get("/public/ips/<jeton>")
def publique(jeton):
    ips, err = _ips_publique(jeton)
    if err:
        return err
    return jsonify(ips=ips_dict(ips.machine, ips, public=True))


@bp.get("/public/ips/<jeton>/pictogrammes/<int:picto_id>")
def picto_public(jeton, picto_id):
    """Image d'un pictogramme ajouté par l'admin, seulement s'il figure sur cette IPS."""
    ips, err = _ips_publique(jeton)
    if err:
        return err
    picto = next((p for p in ips.pictogrammes if p.id == picto_id and p.image), None)
    if not picto:
        return erreur("Image introuvable.", 404)
    return send_from_directory(current_app.config["UPLOAD_DIR"] / "pictogrammes", picto.image, max_age=86400)
