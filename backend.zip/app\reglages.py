"""Paramètres généraux modifiables par l'administrateur (données fondatrices, FND-01 à FND-07) :
établissement, longueur des mots de passe, listes de choix, réglages de fonctionnement."""
import json
import uuid

from flask import Blueprint, current_app, has_request_context, jsonify, request, send_from_directory

from . import db
from . import referentiels as ref
from .auth import erreur, role_required
from .models import Atelier, Document, Parametre, Piece, TachePreventive, journaliser

bp = Blueprint("reglages", __name__)

# Valeurs par défaut, utilisées tant que l'administrateur n'a rien changé
DEFAUTS = {
    "nom_application": "GMAO Brisson",
    "etablissement_nom": "Lycée polyvalent Henri Brisson",
    "etablissement_section": "Section BTS Maintenance des Systèmes",
    "etablissement_adresse": "25 avenue Henri Brisson, 18100 Vierzon",
    "etablissement_logo": "",
    "connexion_fond": "",
    "message_bienvenue": "Bienvenue sur la GMAO des ateliers. Connectez-vous avec l'identifiant donné par votre enseignant.",
    "mdp_min_admin": "8",
    "mdp_min_autres": "4",
    "taux_horaire_defaut": "",
    "anticipation_preventif_jours": "7",
    "huile_surveiller": str(ref.HUILE_SURVEILLER),
    "huile_alerte": str(ref.HUILE_ALERTE),
    "atelier_position_defaut": "",
    "duree_aic_minutes": "10",
    "option_roles": "0",  # rôles des élèves et roue hebdomadaire (option facultative, choix de Simon du 29/10/2026)
}

TEXTES = {
    "nom_application": ("Le nom de l'application", 60, True),
    "etablissement_nom": ("Le nom de l'établissement", 160, True),
    "etablissement_section": ("La section", 160, False),
    "etablissement_adresse": ("L'adresse", 300, False),
    "message_bienvenue": ("Le message de bienvenue", 500, False),
}

# Entiers : clé -> (libellé, minimum, maximum)
ENTIERS = {
    "mdp_min_admin": ("La longueur minimale des mots de passe administrateur", 4, 64),
    "mdp_min_autres": ("La longueur minimale des mots de passe élèves et opérateurs", 4, 64),
    "anticipation_preventif_jours": ("L'anticipation du préventif", 0, 60),
    "huile_surveiller": ("La classe NAS « à surveiller »", 0, 12),
    "huile_alerte": ("La classe NAS « polluée »", 0, 12),
    "duree_aic_minutes": ("La durée de la réunion AIC", 1, 60),
}

# Listes de choix modifiables : clé -> (libellé, valeurs de départ, colonnes qui utilisent la valeur)
LISTES = {
    "types_preventif": ("Types de préventif", ref.TYPES_PREVENTIF, [(TachePreventive, "type_preventif")]),
    "categories_pieces": ("Catégories de pièces", ref.CATEGORIES_PIECES, [(Piece, "categorie")]),
    "categories_documents": ("Catégories de documents", ref.CATEGORIES_DOCUMENTS, [(Document, "categorie")]),
}

TYPES_IMAGE = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}

# Images de l'établissement : nom dans l'adresse -> (réglage, libellé pour le journal)
IMAGES = {
    "logo": ("etablissement_logo", "Logo de l'établissement"),
    "fond": ("connexion_fond", "Photo de fond de la page de connexion"),
}


def _cache():
    """Réglages déjà lus pendant la requête en cours : un calcul sur 600 tâches préventives
    ne relit pas 600 fois la même valeur en base. Hors requête (commandes, tests) : pas de cache."""
    if not has_request_context():
        return None
    cache = getattr(request, "_cache_reglages", None)
    if cache is None:
        cache = request._cache_reglages = {}
    return cache


def _brut(cle):
    cache = _cache()
    if cache is not None and cle in cache:
        return cache[cle]
    p = db.session.get(Parametre, cle)
    valeur = p.valeur if p and p.valeur is not None else None
    if cache is not None:
        cache[cle] = valeur
    return valeur


def _definir(cle, valeur):
    p = db.session.get(Parametre, cle) or Parametre(cle=cle)
    p.valeur = valeur
    db.session.add(p)
    cache = _cache()
    if cache is not None:
        cache[cle] = valeur


def reglage(cle):
    """Valeur d'un réglage : texte, entier, nombre ou None (taux horaire non renseigné)."""
    valeur = _brut(cle)
    if valeur is None or (valeur == "" and cle in ENTIERS):
        valeur = DEFAUTS[cle]
    if cle in ENTIERS:
        try:
            return int(valeur)
        except ValueError:
            return int(DEFAUTS[cle])
    if cle == "taux_horaire_defaut":
        try:
            return float(valeur) if valeur != "" else None
        except ValueError:
            return None
    return valeur


def liste(cle):
    valeur = _brut(f"liste_{cle}")
    if valeur:
        try:
            return json.loads(valeur)
        except ValueError:
            pass
    return list(LISTES[cle][1])


def types_travaux():
    """Libellés des types de travaux : les codes ne changent jamais (« depannage » reste la panne)."""
    libelles = dict(ref.TYPES_TRAVAUX)
    try:
        libelles.update({k: v for k, v in json.loads(_brut("libelles_types_travaux") or "{}").items() if k in libelles})
    except ValueError:
        pass
    return libelles


def longueur_min_mot_de_passe(role):
    return reglage("mdp_min_admin" if role == "admin" else "mdp_min_autres")


def controler_mot_de_passe(mot_de_passe, role):
    """Message d'erreur si le mot de passe est trop court pour ce profil, sinon None."""
    minimum = longueur_min_mot_de_passe(role)
    if len(mot_de_passe or "") < minimum:
        return f"Le mot de passe doit contenir au moins {minimum} caractères."
    return None


def atelier_position_defaut():
    """Atelier affiché pour un élève qui n'a pas indiqué sa position (ADM-05)."""
    try:
        atelier = db.session.get(Atelier, int(reglage("atelier_position_defaut")))
    except (TypeError, ValueError):
        atelier = None
    return (
        atelier
        or Atelier.query.filter_by(nom="02. ATN Maintenance").first()
        or Atelier.query.order_by(Atelier.ordre).first()
    )


def _dossier_logo():
    dossier = current_app.config["UPLOAD_DIR"] / "etablissement"
    dossier.mkdir(parents=True, exist_ok=True)
    return dossier


def _url_image(nom):
    fichier = reglage(IMAGES[nom][0])
    return f"/api/etablissement/{nom}?v={fichier}" if fichier else None


def _public():
    return {
        "nom_application": reglage("nom_application"),
        "etablissement_nom": reglage("etablissement_nom"),
        "etablissement_section": reglage("etablissement_section"),
        "etablissement_adresse": reglage("etablissement_adresse"),
        "logo": _url_image("logo"),
        "fond": _url_image("fond"),
        "message_bienvenue": reglage("message_bienvenue"),
        "types_travaux": types_travaux(),
        "taux_horaire_defaut": reglage("taux_horaire_defaut"),
        "option_roles": reglage("option_roles") == "1",
    }


# ---------- Lecture (sans connexion : la page de connexion affiche le nom, le logo, la photo et le message) ----------

@bp.get("/etablissement")
def etablissement():
    return jsonify(_public())


@bp.get("/etablissement/<nom>")
def image(nom):
    fichier = reglage(IMAGES[nom][0]) if nom in IMAGES else None
    if not fichier:
        return erreur("Aucune image.", 404)
    return send_from_directory(_dossier_logo(), fichier, max_age=86400)


# ---------- Modification par l'administrateur ----------

@bp.get("/admin/reglages")
@role_required("admin")
def lire_reglages():
    ateliers = Atelier.query.order_by(Atelier.ordre, Atelier.nom).all()
    defaut = atelier_position_defaut()
    return jsonify(
        reglages={
            **{cle: reglage(cle) for cle in DEFAUTS if cle not in ("etablissement_logo", "connexion_fond")},
            "atelier_position_defaut": defaut.id if defaut else None,
        },
        etablissement=_public(),
        listes={cle: {"libelle": libelle, "valeurs": liste(cle)} for cle, (libelle, _, _) in LISTES.items()},
        ateliers=[a.to_dict() for a in ateliers],
    )


@bp.put("/admin/reglages")
@role_required("admin")
def modifier_reglages():
    donnees = request.get_json(silent=True) or {}
    valeurs = {}
    for cle, (libelle, longueur, obligatoire) in TEXTES.items():
        if cle in donnees:
            texte = str(donnees[cle] or "").strip()
            if obligatoire and not texte:
                return erreur(f"{libelle} est obligatoire.", 400)
            if len(texte) > longueur:
                return erreur(f"{libelle} ne doit pas dépasser {longueur} caractères.", 400)
            valeurs[cle] = texte
    for cle, (libelle, mini, maxi) in ENTIERS.items():
        if cle in donnees:
            try:
                nombre = int(str(donnees[cle]).strip())
            except ValueError:
                return erreur(f"{libelle} doit être un nombre entier.", 400)
            if not mini <= nombre <= maxi:
                return erreur(f"{libelle} doit être comprise entre {mini} et {maxi}.", 400)
            valeurs[cle] = str(nombre)
    if "taux_horaire_defaut" in donnees:
        texte = str(donnees["taux_horaire_defaut"] or "").strip().replace(",", ".")
        if texte:
            try:
                taux = float(texte)
            except ValueError:
                return erreur("Le taux horaire par défaut doit être un nombre.", 400)
            if not 0 <= taux <= 100_000:
                return erreur("Le taux horaire par défaut doit être compris entre 0 et 100 000 €.", 400)
            texte = str(taux)
        valeurs["taux_horaire_defaut"] = texte
    if "atelier_position_defaut" in donnees:
        try:
            atelier = db.session.get(Atelier, int(donnees["atelier_position_defaut"]))
        except (TypeError, ValueError):
            atelier = None
        if not atelier:
            return erreur("Choisissez l'atelier par défaut.", 400)
        valeurs["atelier_position_defaut"] = str(atelier.id)

    if "option_roles" in donnees:
        valeurs["option_roles"] = "1" if donnees["option_roles"] in (True, "1", 1, "true") else "0"

    surveiller = int(valeurs.get("huile_surveiller", reglage("huile_surveiller")))
    alerte = int(valeurs.get("huile_alerte", reglage("huile_alerte")))
    if surveiller >= alerte:
        return erreur("La classe « à surveiller » doit être inférieure à la classe « polluée ».", 400)

    for cle, valeur in valeurs.items():
        _definir(cle, valeur)
    if valeurs:
        journaliser("modification", details="Paramètres : " + ", ".join(sorted(valeurs)))
    db.session.commit()
    return lire_reglages()


@bp.post("/admin/reglages/<nom>")
@role_required("admin")
def changer_image(nom):
    """Remplace le logo ou la photo de fond de la page de connexion (champ de formulaire « logo » ou « fond »)."""
    if nom not in IMAGES:
        return erreur("Image inconnue.", 404)
    cle, libelle = IMAGES[nom]
    fichier = request.files.get(nom)
    if not fichier or fichier.mimetype not in TYPES_IMAGE:
        return erreur("Choisissez une image JPEG, PNG ou WebP.", 400)
    ancien = reglage(cle)
    nouveau = f"{nom}_{uuid.uuid4().hex[:12]}{TYPES_IMAGE[fichier.mimetype]}"
    fichier.save(_dossier_logo() / nouveau)
    _definir(cle, nouveau)
    journaliser("modification", details=libelle)
    db.session.commit()
    if ancien:
        (_dossier_logo() / ancien).unlink(missing_ok=True)
    return jsonify(_public())


@bp.delete("/admin/reglages/<nom>")
@role_required("admin")
def retirer_image(nom):
    """Revient à l'image d'origine (logo du lycée, fond par défaut)."""
    if nom not in IMAGES:
        return erreur("Image inconnue.", 404)
    cle, libelle = IMAGES[nom]
    ancien = reglage(cle)
    _definir(cle, "")
    journaliser("modification", details=f"{libelle} : retour à l'image d'origine")
    db.session.commit()
    if ancien:
        (_dossier_logo() / ancien).unlink(missing_ok=True)
    return jsonify(_public())


@bp.put("/admin/types-travaux")
@role_required("admin")
def modifier_types_travaux():
    donnees = request.get_json(silent=True) or {}
    libelles = types_travaux()
    for code in libelles:
        if code in donnees:
            texte = str(donnees[code] or "").strip()
            if not texte or len(texte) > 40:
                return erreur("Chaque type de travail doit avoir un nom (40 caractères au maximum).", 400)
            libelles[code] = texte
    if len({v.lower() for v in libelles.values()}) != len(libelles):
        return erreur("Deux types de travaux ne peuvent pas porter le même nom.", 400)
    _definir("libelles_types_travaux", json.dumps(libelles, ensure_ascii=False))
    journaliser("modification", details="Libellés des types de travaux")
    db.session.commit()
    return jsonify(types_travaux=libelles)


# ---------- Listes de choix (types de préventif, catégories de pièces et de documents) ----------

def _liste_ou_404(cle):
    if cle not in LISTES:
        return None, erreur("Liste inconnue.", 404)
    return liste(cle), None


def _nom_liste(donnees, valeurs, ignorer=None):
    nom = str(donnees.get("nom") or "").strip()
    if not nom:
        return None, "Le nom est obligatoire."
    if len(nom) > 80:
        return None, "Le nom ne doit pas dépasser 80 caractères."
    if any(v.lower() == nom.lower() for i, v in enumerate(valeurs) if i != ignorer):
        return None, f"« {nom} » existe déjà."
    return nom, None


def _utilisations(cle, valeur):
    return sum(modele.query.filter(getattr(modele, colonne) == valeur).count() for modele, colonne in LISTES[cle][2])


def _enregistrer_liste(cle, valeurs, details):
    _definir(f"liste_{cle}", json.dumps(valeurs, ensure_ascii=False))
    journaliser("modification", details=f"{LISTES[cle][0]} : {details}")
    db.session.commit()
    return jsonify(valeurs=valeurs)


@bp.post("/admin/listes/<cle>")
@role_required("admin")
def ajouter_a_la_liste(cle):
    valeurs, err = _liste_ou_404(cle)
    if err:
        return err
    nom, probleme = _nom_liste(request.get_json(silent=True) or {}, valeurs)
    if probleme:
        return erreur(probleme, 400 if "existe" not in probleme else 409)
    return _enregistrer_liste(cle, [*valeurs, nom], f"ajout de « {nom} »")


@bp.put("/admin/listes/<cle>/<int:indice>")
@role_required("admin")
def renommer_dans_la_liste(cle, indice):
    """Renommer met aussi à jour les pièces, documents ou tâches qui utilisaient l'ancien nom."""
    valeurs, err = _liste_ou_404(cle)
    if err:
        return err
    if not 0 <= indice < len(valeurs):
        return erreur("Élément introuvable.", 404)
    nom, probleme = _nom_liste(request.get_json(silent=True) or {}, valeurs, ignorer=indice)
    if probleme:
        return erreur(probleme, 400 if "existe" not in probleme else 409)
    ancien = valeurs[indice]
    for modele, colonne in LISTES[cle][2]:
        modele.query.filter(getattr(modele, colonne) == ancien).update({colonne: nom}, synchronize_session=False)
    valeurs[indice] = nom
    return _enregistrer_liste(cle, valeurs, f"« {ancien} » → « {nom} »")


@bp.delete("/admin/listes/<cle>/<int:indice>")
@role_required("admin")
def retirer_de_la_liste(cle, indice):
    valeurs, err = _liste_ou_404(cle)
    if err:
        return err
    if not 0 <= indice < len(valeurs):
        return erreur("Élément introuvable.", 404)
    if len(valeurs) == 1:
        return erreur("La liste doit garder au moins un choix.", 409)
    nom = valeurs[indice]
    nb = _utilisations(cle, nom)
    if nb:
        return erreur(f"Impossible de retirer « {nom} » : {nb} fiche(s) l'utilisent. Renommez-le plutôt.", 409)
    return _enregistrer_liste(cle, [v for i, v in enumerate(valeurs) if i != indice], f"retrait de « {nom} »")
