"""Dates : stockées en UTC sans fuseau, saisies et affichées à l'heure de Paris."""
from datetime import datetime, time, timedelta, timezone
from zoneinfo import ZoneInfo

PARIS = ZoneInfo("Europe/Paris")


def lire_iso(texte):
    """Date ISO envoyée par l'écran (ex. 2026-10-27T14:30:00.000Z) -> UTC sans fuseau.
    Une date sans fuseau est comprise comme une heure de Paris. Lève ValueError si illisible."""
    texte = texte.strip().replace("Z", "+00:00")
    date = datetime.fromisoformat(texte)
    if date.tzinfo is None:
        date = date.replace(tzinfo=PARIS)
    return date.astimezone(timezone.utc).replace(tzinfo=None)


def debut_jour_paris(jour):
    """Minuit (heure de Paris) du jour donné, en UTC sans fuseau."""
    return datetime.combine(jour, time.min, tzinfo=PARIS).astimezone(timezone.utc).replace(tzinfo=None)


def fin_jour_paris(jour):
    return debut_jour_paris(jour + timedelta(days=1))


def format_paris(date):
    """UTC sans fuseau -> « 27/10/2026 14:30 » à l'heure de Paris (exports)."""
    if not date:
        return ""
    return date.replace(tzinfo=timezone.utc).astimezone(PARIS).strftime("%d/%m/%Y %H:%M")
