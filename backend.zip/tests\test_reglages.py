import io
import re

import pytest

from app import db
from app.indicateurs import gravite
from app.models import Atelier, Piece, Utilisateur


# ---------- Établissement (lecture publique, modification par l'administrateur) ----------

def test_etablissement_lisible_sans_connexion(client):
    d = client.get("/api/etablissement").get_json()
    assert d["nom_application"] == "GMAO Brisson" and d["logo"] is None
    assert d["types_travaux"]["depannage"].startswith("Dépannage")


@pytest.mark.parametrize("login", ["tech", "operateur"])
def test_reglages_reserves_a_l_administrateur(client, connecter, login):
    connecter(login)
    assert client.get("/api/admin/reglages").status_code == 403
    assert client.put("/api/admin/reglages", json={"nom_application": "X"}).status_code == 403
    assert client.post("/api/admin/listes/categories_pieces", json={"nom": "X"}).status_code == 403
    assert client.put("/api/admin/types-travaux", json={"autre": "X"}).status_code == 403


def test_modifier_les_reglages(client, connecter):
    connecter("admin")
    reponse = client.put(
        "/api/admin/reglages",
        json={"nom_application": "GMAO Lycée", "etablissement_adresse": "1 rue A, 18000 Bourges", "taux_horaire_defaut": "45,5",
              "anticipation_preventif_jours": "3", "duree_aic_minutes": "12"},
    )
    assert reponse.status_code == 200, reponse.get_json()
    r = reponse.get_json()["reglages"]
    assert r["taux_horaire_defaut"] == 45.5 and r["anticipation_preventif_jours"] == 3
    public = client.get("/api/etablissement").get_json()
    assert public["nom_application"] == "GMAO Lycée" and public["etablissement_adresse"] == "1 rue A, 18000 Bourges"
    assert client.get("/api/aic/parametres").get_json()["duree_minutes"] == 12


@pytest.mark.parametrize(
    "donnees",
    [
        {"nom_application": ""},
        {"duree_aic_minutes": "0"},
        {"mdp_min_admin": "2"},
        {"anticipation_preventif_jours": "deux"},
        {"huile_surveiller": "10", "huile_alerte": "9"},
        {"taux_horaire_defaut": "-3"},
        {"atelier_position_defaut": 999},
    ],
)
def test_reglages_invalides(client, connecter, donnees):
    connecter("admin")
    assert client.put("/api/admin/reglages", json=donnees).status_code == 400


def test_seuils_huile_reglables(client, connecter):
    assert gravite("huile", "8") == "surveiller"
    connecter("admin")
    client.put("/api/admin/reglages", json={"huile_surveiller": "9", "huile_alerte": "11"})
    assert gravite("huile", "8") == "ok" and gravite("huile", "11") == "alerte"


def test_atelier_par_defaut_des_eleves(client, connecter):
    fonderie = Atelier.query.filter_by(nom="03. Fonderie").one()
    connecter("admin")
    assert client.put("/api/admin/reglages", json={"atelier_position_defaut": fonderie.id}).status_code == 200
    connecter("tech")
    position = client.get("/api/eleve/position").get_json()["position"]
    assert position["atelier"]["nom"] == "03. Fonderie" and position["par_defaut"] is True


def test_logo(client, connecter):
    connecter("admin")
    assert client.post("/api/admin/reglages/logo", data={"logo": (io.BytesIO(b"<svg/>"), "x.svg", "image/svg+xml")}).status_code == 400
    d = client.post("/api/admin/reglages/logo", data={"logo": (io.BytesIO(b"\x89PNG fichier"), "logo.png", "image/png")}).get_json()
    assert d["logo"].startswith("/api/etablissement/logo")
    client.post("/api/auth/logout")
    assert client.get("/api/etablissement/logo").data == b"\x89PNG fichier"
    connecter("admin")
    assert client.delete("/api/admin/reglages/logo").get_json()["logo"] is None
    assert client.get("/api/etablissement/logo").status_code == 404


# ---------- Listes de choix ----------

def test_types_de_travaux_renommables(client, connecter):
    connecter("admin")
    assert client.put("/api/admin/types-travaux", json={"autre": ""}).status_code == 400
    assert client.put("/api/admin/types-travaux", json={"autre": "Préventif"}).status_code == 400  # doublon
    assert client.put("/api/admin/types-travaux", json={"autre": "Divers"}).status_code == 200
    assert client.get("/api/referentiels").get_json()["types_travaux"]["autre"] == "Divers"


def test_liste_ajout_renommage_retrait(client, connecter):
    connecter("admin")
    url = "/api/admin/listes/categories_pieces"
    assert client.post(url, json={"nom": "mécanique"}).status_code == 409
    assert client.post(url, json={"nom": "Outillage"}).status_code == 200
    assert "Outillage" in client.get("/api/referentiels").get_json()["categories_pieces"]

    # Une pièce peut utiliser la nouvelle catégorie ; la renommer met la pièce à jour
    reponse = client.post("/api/pieces", json={"designation": "Clé", "categorie": "Outillage"})
    assert reponse.status_code == 201, reponse.get_json()
    valeurs = client.get("/api/admin/reglages").get_json()["listes"]["categories_pieces"]["valeurs"]
    indice = valeurs.index("Outillage")
    assert client.put(f"{url}/{indice}", json={"nom": "Outils"}).status_code == 200
    assert Piece.query.filter_by(designation="Clé").one().categorie == "Outils"

    # Retrait refusé tant qu'une pièce l'utilise, accepté pour une valeur libre
    assert client.delete(f"{url}/{indice}").status_code == 409
    indice_autre = valeurs.index("Autre")
    assert client.delete(f"{url}/{indice_autre}").status_code == 200
    assert "Autre" not in client.get("/api/referentiels").get_json()["categories_pieces"]
    assert client.post("/api/pieces", json={"designation": "X", "categorie": "Autre"}).status_code == 400


def test_liste_inconnue(client, connecter):
    connecter("admin")
    assert client.post("/api/admin/listes/n_importe_quoi", json={"nom": "X"}).status_code == 404


# ---------- Comptes : e-mail des administrateurs et longueur des mots de passe ----------

def test_administrateur_avec_email_obligatoire(client, connecter):
    connecter("admin")
    base = {"login": "prof", "nom": "Prof", "role": "admin", "password": "motdepasse"}
    assert "e-mail" in client.post("/api/admin/utilisateurs", json=base).get_json()["error"]
    assert client.post("/api/admin/utilisateurs", json={**base, "email": "pas-une-adresse"}).status_code == 400
    reponse = client.post("/api/admin/utilisateurs", json={**base, "email": "Prof@Lycee.fr"})
    assert reponse.status_code == 201 and reponse.get_json()["utilisateur"]["email"] == "prof@lycee.fr"
    doublon = client.post("/api/admin/utilisateurs", json={**base, "login": "prof2", "email": "prof@lycee.fr"})
    assert doublon.status_code == 400 and "déjà utilisée" in doublon.get_json()["error"]


def test_longueur_des_mots_de_passe_selon_le_profil(client, connecter):
    connecter("admin")
    court = client.post("/api/admin/utilisateurs", json={"login": "p", "nom": "P", "role": "admin", "email": "p@l.fr", "password": "abcd"})
    assert court.status_code == 400 and "8 caractères" in court.get_json()["error"]
    eleve = client.post("/api/admin/utilisateurs", json={"login": "e", "nom": "E", "role": "technicien", "password": "abcd"})
    assert eleve.status_code == 201
    client.put("/api/admin/reglages", json={"mdp_min_autres": "6"})
    uid = eleve.get_json()["utilisateur"]["id"]
    assert client.put(f"/api/admin/utilisateurs/{uid}/mot-de-passe", json={"password": "abcde"}).status_code == 400
    assert client.put(f"/api/admin/utilisateurs/{uid}/mot-de-passe", json={"password": "abcdef"}).status_code == 200


# ---------- Mon compte ----------

def test_eleve_change_son_mot_de_passe(client, connecter):
    connecter("tech")
    assert client.put("/api/auth/mot-de-passe", json={"ancien": "faux", "nouveau": "nouveau1"}).status_code == 400
    assert client.put("/api/auth/mot-de-passe", json={"ancien": "tech", "nouveau": "abc"}).status_code == 400
    assert client.put("/api/auth/mot-de-passe", json={"ancien": "tech", "nouveau": "nouveau1"}).status_code == 200
    client.post("/api/auth/logout")
    assert client.post("/api/auth/login", json={"login": "tech", "password": "tech"}).status_code == 401
    assert client.post("/api/auth/login", json={"login": "tech", "password": "nouveau1"}).status_code == 200


def test_compte_operateur_partage_non_modifiable(client, connecter):
    connecter("operateur")
    assert client.put("/api/auth/mot-de-passe", json={"ancien": "operateur", "nouveau": "nouveau1"}).status_code == 403


def test_administrateur_change_son_email(client, connecter):
    connecter("tech")
    assert client.put("/api/auth/email", json={"email": "a@b.fr"}).status_code == 403
    connecter("admin")
    reponse = client.put("/api/auth/email", json={"email": "simon@lycee.fr"})
    assert reponse.status_code == 200 and client.get("/api/auth/me").get_json()["utilisateur"]["email"] == "simon@lycee.fr"


# ---------- Mot de passe oublié ----------

def test_mot_de_passe_oublie_sans_messagerie(client):
    reponse = client.post("/api/auth/mot-de-passe-oublie", json={"email": "x@y.fr"})
    assert reponse.status_code == 503 and "pas encore configuré" in reponse.get_json()["error"]


def test_mot_de_passe_oublie_par_email(app, client, monkeypatch):
    app.config.update(MAIL_SERVER="smtp.exemple.fr", MAIL_FROM="gmao@exemple.fr", PUBLIC_URL="https://gmao.exemple.fr")
    envoyes = []
    monkeypatch.setattr("app.courriel.envoyer", lambda dest, sujet, texte: envoyes.append((dest, texte)))
    admin = Utilisateur.query.filter_by(login="admin").one()
    admin.email = "simon@lycee.fr"
    db.session.commit()

    # Adresse inconnue : même réponse, aucun envoi (on ne dévoile pas quelles adresses existent)
    inconnue = client.post("/api/auth/mot-de-passe-oublie", json={"email": "inconnu@lycee.fr"})
    assert inconnue.status_code == 200 and envoyes == []

    assert client.post("/api/auth/mot-de-passe-oublie", json={"email": "Simon@lycee.fr "}).status_code == 200
    assert len(envoyes) == 1 and envoyes[0][0] == "simon@lycee.fr"
    client.post("/api/auth/mot-de-passe-oublie", json={"email": "simon@lycee.fr"})
    assert len(envoyes) == 1  # pas de deuxième envoi dans les 2 minutes

    jeton = re.search(r"https://gmao\.exemple\.fr/\?reinitialiser=(\S+)", envoyes[0][1]).group(1)
    assert client.post("/api/auth/reinitialiser", json={"jeton": jeton, "password": "court"}).status_code == 400
    assert client.post("/api/auth/reinitialiser", json={"jeton": "faux", "password": "nouveau-mdp"}).status_code == 400
    assert client.post("/api/auth/reinitialiser", json={"jeton": jeton, "password": "nouveau-mdp"}).status_code == 200
    assert client.post("/api/auth/reinitialiser", json={"jeton": jeton, "password": "encore-autre"}).status_code == 400  # usage unique
    assert client.post("/api/auth/login", json={"login": "admin", "password": "nouveau-mdp"}).status_code == 200


def test_eleve_ne_recoit_pas_de_lien(app, client, monkeypatch):
    app.config.update(MAIL_SERVER="smtp.exemple.fr")
    envoyes = []
    monkeypatch.setattr("app.courriel.envoyer", lambda *a: envoyes.append(a))
    tech = Utilisateur.query.filter_by(login="tech").one()
    tech.email = "eleve@lycee.fr"
    db.session.commit()
    assert client.post("/api/auth/mot-de-passe-oublie", json={"email": "eleve@lycee.fr"}).status_code == 200
    assert envoyes == []


def test_photo_de_fond_et_message_de_bienvenue(client, connecter):
    public = client.get("/api/etablissement").get_json()
    assert public["fond"] is None and public["message_bienvenue"].startswith("Bienvenue")

    connecter("tech")
    assert client.post("/api/admin/reglages/fond", data={"fond": (io.BytesIO(b"x"), "f.jpg", "image/jpeg")}).status_code == 403
    connecter("admin")
    assert client.post("/api/admin/reglages/inconnu", data={}).status_code == 404
    d = client.post("/api/admin/reglages/fond", data={"fond": (io.BytesIO(b"\xff\xd8 photo"), "atelier.jpg", "image/jpeg")}).get_json()
    assert d["fond"].startswith("/api/etablissement/fond") and d["logo"] is None
    assert client.put("/api/admin/reglages", json={"message_bienvenue": "Bonne séance à tous !"}).status_code == 200
    assert client.put("/api/admin/reglages", json={"message_bienvenue": "x" * 501}).status_code == 400

    client.post("/api/auth/logout")
    public = client.get("/api/etablissement").get_json()
    assert public["message_bienvenue"] == "Bonne séance à tous !"
    assert client.get("/api/etablissement/fond").data == b"\xff\xd8 photo"
    assert client.get("/api/etablissement/inconnu").status_code == 404

    connecter("admin")
    assert client.delete("/api/admin/reglages/fond").get_json()["fond"] is None
    assert client.get("/api/etablissement/fond").status_code == 404
