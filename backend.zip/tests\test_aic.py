from datetime import date, datetime

import pytest

from app import db
from app.aic import compteurs
from app.cli import reset_annuel
from app.models import SemaineSecurite


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    class Fausse(datetime):
        @classmethod
        def now(cls, tz=None):
            return datetime(2026, 11, 18, 10, tzinfo=tz)

    monkeypatch.setattr("app.aic.datetime", Fausse)


def colorer(client, lundi, couleur):
    return client.put("/api/aic/croix", json={"lundi": lundi, "couleur": couleur})


def test_duree_de_la_reunion(client, connecter):
    connecter("tech")
    assert client.get("/api/aic/parametres").get_json() == {"duree_minutes": 10}
    assert client.put("/api/aic/parametres", json={"duree_minutes": 12}).status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    assert client.put("/api/aic/parametres", json={"duree_minutes": 12}).get_json() == {"duree_minutes": 12}
    assert client.put("/api/aic/parametres", json={"duree_minutes": 0}).status_code == 400


def test_croix_securite_compteurs(client, connecter):
    connecter("tech")
    for lundi, couleur in [("2026-09-07", "vert"), ("2026-09-14", "vert"), ("2026-09-21", "orange"), ("2026-09-28", "rouge"),
                           ("2026-10-05", "vert"), ("2026-10-12", "vert")]:
        assert colorer(client, lundi, couleur).status_code == 200
    reponse = colorer(client, "2026-10-19", "gris").get_json()  # vacances : ne coupe pas la série
    assert (reponse["serie"], reponse["record"]) == (2, 3)
    assert colorer(client, "2026-11-02", "vert").get_json()["serie"] == 3
    # Retour à « sans couleur »
    colorer(client, "2026-11-02", None)
    d = client.get("/api/aic/croix?annee=2026").get_json()
    couleurs = {s["lundi"]: s["couleur"] for s in d["semaines"]}
    assert couleurs["2026-09-28"] == "rouge" and couleurs["2026-11-02"] is None
    assert (d["serie"], d["record"]) == (2, 3)
    assert next(s for s in d["semaines"] if s["en_cours"])["lundi"] == "2026-11-16"


def test_semaines_a_venir_et_vacances(client, connecter):
    connecter("admin")
    client.put("/api/calendrier/semaines", json={"lundis": ["2026-12-21"], "type": "vacances"})
    assert colorer(client, "2026-12-07", "vert").status_code == 400  # pas de « vert » dans le futur
    assert colorer(client, "2026-12-07", "gris").status_code == 200
    d = client.get("/api/aic/croix?annee=2026").get_json()
    assert {s["lundi"]: s["couleur"] for s in d["semaines"]}["2026-12-21"] == "gris"  # vacances grisées d'office
    assert colorer(client, "2026-09-07", "violet").status_code == 400
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get("/api/aic/croix").status_code == 403


def test_1er_aout_efface_les_couleurs_mais_garde_le_record(client, connecter):
    connecter("tech")
    for lundi in ("2026-09-07", "2026-09-14", "2026-09-21"):
        colorer(client, lundi, "vert")
    reset_annuel(date(2027, 8, 1))
    assert SemaineSecurite.query.count() == 0
    assert compteurs(date(2027, 8, 2)) == (0, 3)


# ---------- Retours de Simon du 28/10 ----------

def test_performance_du_mois_sans_code_pendant_l_aic(client, connecter):
    connecter("tech")
    assert client.get("/api/indicateurs/auto?periode=mois").status_code == 403  # ailleurs : code du jour
    d = client.get("/api/aic/performance").get_json()
    assert d["periode"]["type"] == "mois" and "parc" in d and "ateliers" in d
    assert "couts" not in d["parc"] and "precedent" in d["parc"]


def test_bandeau_securite_de_l_accueil(client, connecter):
    from datetime import timedelta

    connecter("admin")
    lundi = date(2026, 11, 16)  # semaine de la date figée par date_fixe (18/11/2026)
    vide = client.get("/api/securite/semaine").get_json()
    assert vide["couleur"] is None
    client.put("/api/aic/croix", json={"lundi": (lundi - timedelta(days=7)).isoformat(), "couleur": "vert"})
    d = client.get("/api/securite/semaine").get_json()
    assert d["couleur"] == "vert" and d["semaine_en_cours"] is False and d["serie"] == 1  # semaine précédente
    client.put("/api/aic/croix", json={"lundi": lundi.isoformat(), "couleur": "orange"})
    connecter("operateur")  # visible par tous les profils
    d = client.get("/api/securite/semaine").get_json()
    assert d["couleur"] == "orange" and d["semaine_en_cours"] is True


def test_post_it_ecrit_par_un_eleve(client, connecter):
    from app.models import Utilisateur

    connecter("tech")
    assert client.post("/api/chantiers", json={"titre": "X"}).status_code == 403  # chantier complet : enseignant
    assert client.post("/api/chantiers/postit", json={"titre": " "}).status_code == 400
    tech2 = Utilisateur.query.filter_by(login="tech2").one().id
    reponse = client.post("/api/chantiers/postit", json={"titre": "Ranger le poste de soudure", "ids": [tech2]})
    assert reponse.status_code == 201
    chantier = reponse.get_json()["chantier"]
    assert chantier["type"] == "autre" and [t["nom"] for t in chantier["techniciens"]] == ["Technicien 2 (démo)"]
    connecter("operateur")
    assert client.post("/api/chantiers/postit", json={"titre": "X"}).status_code == 403


def test_tendance_des_indicateurs(client, connecter):
    connecter("admin")
    d = client.get("/api/indicateurs/auto?periode=mois").get_json()
    assert set(d["parc"]["precedent"]) == {"disponibilite", "mtbf_h", "mttr_h", "nb_pannes", "temps_arret_h"}
    assert all("precedent" in a for a in d["ateliers"])
