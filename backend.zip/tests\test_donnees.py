import io
import json
import zipfile
from datetime import datetime

import pytest

from app import db
from app.models import Atelier, BonIntervention, JournalAction, Machine, Utilisateur


@pytest.fixture()
def donnees(app):
    m = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.filter_by(nom="01. Maintenance").one())
    db.session.add(m)
    db.session.flush()
    b = BonIntervention(numero="BI-1", machine=m, type_travail="depannage", urgence="normale", statut="termine", demandeur="x",
                        description="Bruit", travaux="Graissage", temps_passe_h=1.5, cree_le=datetime(2026, 10, 5, 9), termine_le=datetime(2026, 10, 5, 11))
    db.session.add(b)
    b.techniciens = [Utilisateur.query.filter_by(login="tech").one()]
    db.session.commit()
    dossier = app.config["UPLOAD_DIR"] / "machines"
    dossier.mkdir(parents=True, exist_ok=True)
    (dossier / "photo.jpg").write_bytes(b"\xff\xd8\xff photo")
    return m


def test_sauvegarde_reservee_admin(client, connecter, donnees):
    connecter("tech")
    assert client.get("/api/admin/sauvegarde").status_code == 403
    assert client.post("/api/admin/sauvegarde", data={}, content_type="multipart/form-data").status_code == 403


def test_sauvegarde_puis_chargement_restitue_tout(client, connecter, donnees, app):
    connecter("admin")
    reponse = client.get("/api/admin/sauvegarde")
    assert reponse.status_code == 200 and reponse.mimetype == "application/zip"
    contenu = reponse.data
    archive = zipfile.ZipFile(io.BytesIO(contenu))
    assert {"manifeste.json", "donnees.json", "fichiers/machines/photo.jpg"} <= set(archive.namelist())
    assert json.loads(archive.read("manifeste.json"))["lignes"]["machine"] == 1

    # On modifie tout après la sauvegarde…
    Machine.query.one().designation = "Modifiée"
    db.session.add(Machine(repere="NEW-01", designation="Nouvelle", atelier_id=donnees.atelier_id))
    db.session.commit()
    (app.config["UPLOAD_DIR"] / "machines" / "photo.jpg").unlink()

    # … puis on recharge : tout revient comme avant
    charge = client.post("/api/admin/sauvegarde", data={"fichier": (io.BytesIO(contenu), "sauvegarde.zip")}, content_type="multipart/form-data")
    assert charge.status_code == 200, charge.get_json()
    db.session.remove()
    assert [m.designation for m in Machine.query.all()] == ["Tour"]
    assert BonIntervention.query.one().techniciens[0].login == "tech"
    assert BonIntervention.query.one().cree_le == datetime(2026, 10, 5, 9)
    assert (app.config["UPLOAD_DIR"] / "machines" / "photo.jpg").read_bytes() == b"\xff\xd8\xff photo"
    # Copie de sécurité de l'état d'avant
    assert charge.get_json()["copie_de_securite"].startswith("avant-chargement-")


def test_fichier_invalide_refuse(client, connecter, donnees):
    connecter("admin")
    pas_zip = client.post("/api/admin/sauvegarde", data={"fichier": (io.BytesIO(b"bonjour"), "x.zip")}, content_type="multipart/form-data")
    assert pas_zip.status_code == 400
    tampon = io.BytesIO()
    with zipfile.ZipFile(tampon, "w") as z:
        z.writestr("manifeste.json", json.dumps({"format": "gmao-brisson-sauvegarde", "revision": "autre"}))
        z.writestr("donnees.json", "{}")
    autre = client.post("/api/admin/sauvegarde", data={"fichier": (io.BytesIO(tampon.getvalue()), "x.zip")}, content_type="multipart/form-data")
    assert autre.status_code == 409 and "autre version" in autre.get_json()["error"]
    assert Machine.query.count() == 1  # rien n'a changé


def test_bilan_eleve(client, connecter, donnees):
    connecter("admin")
    tech = Utilisateur.query.filter_by(login="tech").one()
    b = client.get(f"/api/admin/bilan/{tech.id}?du=2026-08-01&au=2026-12-31").get_json()["bilan"]
    assert b["totaux"]["bons_termines"] == 1 and b["totaux"]["temps_intervention_h"] == 1.5
    assert b["bons"][0]["machine"] == "MAI-01 — Tour"
    texte = client.get(f"/api/admin/bilan/{tech.id}/export.csv?du=2026-08-01&au=2026-12-31").data.decode("utf-8")
    assert texte.startswith("﻿") and "Intervention;05/10/2026" in texte and ";1,5" in texte
    assert client.get(f"/api/admin/bilan/{Utilisateur.query.filter_by(login='admin').one().id}").status_code == 404
    client.post("/api/auth/logout")
    connecter("tech")
    assert client.get(f"/api/admin/bilan/{tech.id}").status_code == 403


def test_journal_des_actions(client, connecter, donnees):
    connecter("admin")
    d = client.get("/api/admin/journal").get_json()
    assert d["total"] >= 1 and "connexion" in d["actions"]
    filtre = client.get("/api/admin/journal?action=connexion").get_json()
    assert all(l["action"] == "connexion" for l in filtre["lignes"])
    assert client.get("/api/admin/journal/export.csv").data.decode("utf-8").startswith("﻿Date;Qui")
