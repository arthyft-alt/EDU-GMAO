"""Module Équipement : machines (EQ-01 à EQ-07)."""
import shutil
import uuid
from datetime import date

from flask import Blueprint, current_app, jsonify, request, send_from_directory
from flask_login import login_required
from sqlalchemy import func, or_

from . import db
from .auth import erreur, role_required, unlock_required
from .models import (
    Atelier,
    BonIntervention,
    Document,
    DocumentMachine,
    IpsMachine,
    Machine,
    PieceMachine,
    ReleveConditionnel,
    SaisieIndicateurs,
    TachePhoto,
    TachePreventive,
    journaliser,
)

bp = Blueprint("equipement", __name__)

EQUIPE = ("admin", "technicien")
TYPES_PHOTO = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}


class Invalide(Exception):
    pass


def _texte(donnees, cle, obligatoire=False, longueur=None, libelle=None):
    valeur = donnees.get(cle)
    valeur = str(valeur).strip() if valeur is not None else ""
    if not valeur:
        if obligatoire:
            raise Invalide(f"Le champ « {libelle or cle} » est obligatoire.")
        return None
    if longueur and len(valeur) > longueur:
        raise Invalide(f"Le champ « {libelle or cle} » ne doit pas dépasser {longueur} caractères.")
    return valeur


def _nombre(donnees, cle, libelle, mini=None, maxi=None, entier=False):
    valeur = donnees.get(cle)
    if valeur is None or str(valeur).strip() == "":
        return None
    try:
        # accepte la virgule décimale (1,5)
        nombre = float(str(valeur).replace(",", ".").strip())
    except ValueError:
        raise Invalide(f"« {libelle} » doit être un nombre.")
    if entier:
        if not nombre.is_integer():
            raise Invalide(f"« {libelle} » doit être un nombre entier.")
        nombre = int(nombre)
    if (mini is not None and nombre < mini) or (maxi is not None and nombre > maxi):
        raise Invalide(f"« {libelle} » doit être compris entre {mini} et {maxi}.")
    return nombre


def _appliquer(machine, donnees):
    """Valide les données reçues et les recopie dans la machine."""
    repere = _texte(donnees, "repere", True, 20, "Repère").upper()
    doublon = Machine.query.filter(func.upper(Machine.repere) == repere, Machine.id != machine.id).first()
    if doublon:
        raise Invalide(f"Le repère « {repere} » est déjà utilisé par « {doublon.designation} ».")

    atelier_id = donnees.get("atelier_id")
    try:
        atelier = db.session.get(Atelier, int(atelier_id)) if atelier_id not in (None, "") else None
    except (TypeError, ValueError):
        atelier = None
    if not atelier:
        raise Invalide("Choisissez l'atelier de la machine.")

    machine.repere = repere
    machine.designation = _texte(donnees, "designation", True, 160, "Désignation")
    machine.marque = _texte(donnees, "marque", longueur=80, libelle="Marque")
    machine.modele = _texte(donnees, "modele", longueur=80, libelle="Modèle")
    machine.atelier = atelier
    machine.numero_serie = _texte(donnees, "numero_serie", longueur=80, libelle="Numéro de série")
    machine.annee_mise_en_service = _nombre(
        donnees, "annee_mise_en_service", "Année de mise en service", 1900, date.today().year + 1, entier=True
    )
    machine.compteur_heures = _nombre(donnees, "compteur_heures", "Temps de fonctionnement", 0, 10_000_000)
    machine.utilisation_hebdo_h = _nombre(donnees, "utilisation_hebdo_h", "Utilisation par semaine", 0, 168)
    machine.taux_horaire = _nombre(donnees, "taux_horaire", "Taux horaire de la machine", 0, 100_000)
    machine.remarques = _texte(donnees, "remarques", longueur=5000, libelle="Remarques")


def machine_a_un_historique(machine):
    """Vrai si la machine est référencée ailleurs (bons, préventif, pièces, documents…).
    À compléter avec chaque nouveau module, pour ne jamais effacer un historique."""
    return (
        BonIntervention.query.filter_by(machine_id=machine.id).first() is not None
        or TachePreventive.query.filter_by(machine_id=machine.id).first() is not None
        or ReleveConditionnel.query.filter_by(machine_id=machine.id).first() is not None
        or SaisieIndicateurs.query.filter_by(machine_id=machine.id).first() is not None
    )


def _machine_ou_404(machine_id):
    machine = db.session.get(Machine, machine_id)
    if not machine:
        return None, erreur("Machine introuvable.", 404)
    return machine, None


def _dossier_photos():
    dossier = current_app.config["UPLOAD_DIR"] / "machines"
    dossier.mkdir(parents=True, exist_ok=True)
    return dossier


def _supprimer_photo(machine):
    if machine.photo:
        (_dossier_photos() / machine.photo).unlink(missing_ok=True)
        machine.photo = None


# ---------- Arborescence ----------

@bp.get("/arborescence")
@login_required
def arborescence():
    """Ateliers avec leur nombre de machines en service."""
    comptes = dict(
        db.session.query(Machine.atelier_id, func.count(Machine.id))
        .filter(Machine.hors_service.is_(False))
        .group_by(Machine.atelier_id)
        .all()
    )
    ateliers = Atelier.query.order_by(Atelier.ordre, Atelier.nom).all()
    return jsonify(ateliers=[{**a.to_dict(), "nb_machines": comptes.get(a.id, 0)} for a in ateliers])


# ---------- Machines ----------

@bp.get("/machines")
@login_required
def liste_machines():
    requete = Machine.query.join(Atelier)
    atelier_id = request.args.get("atelier_id", type=int)
    if atelier_id:
        requete = requete.filter(Machine.atelier_id == atelier_id)
    if request.args.get("hors_service") != "1":
        requete = requete.filter(Machine.hors_service.is_(False))
    recherche = (request.args.get("q") or "").strip()
    if recherche:
        motif = f"%{recherche}%"
        requete = requete.filter(
            or_(
                Machine.repere.ilike(motif),
                Machine.designation.ilike(motif),
                Machine.marque.ilike(motif),
                Machine.modele.ilike(motif),
                Machine.numero_serie.ilike(motif),
            )
        )
    machines = requete.order_by(Atelier.ordre, Machine.repere).all()
    return jsonify(machines=[m.to_dict() for m in machines])


@bp.get("/machines/<int:machine_id>")
@login_required
def detail_machine(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    return jsonify(machine=machine.to_dict())


@bp.post("/machines")
@role_required(*EQUIPE)
@unlock_required("machines")
def creer_machine():
    machine = Machine()
    try:
        _appliquer(machine, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    db.session.add(machine)
    db.session.flush()
    journaliser("creation", machine, f"{machine.repere} — {machine.designation}")
    db.session.commit()
    return jsonify(machine=machine.to_dict()), 201


@bp.put("/machines/<int:machine_id>")
@role_required(*EQUIPE)
@unlock_required("machines")
def modifier_machine(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    try:
        _appliquer(machine, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    journaliser("modification", machine, f"{machine.repere} — {machine.designation}")
    db.session.commit()
    return jsonify(machine=machine.to_dict())


def _copier_fichier(dossier_source, nom, dossier_cible, prefixe):
    """Copie d'une photo sous un nouveau nom ; None si le fichier d'origine a disparu."""
    source = dossier_source / nom
    if not source.is_file():
        return None
    nouveau = f"{prefixe}_{uuid.uuid4().hex[:12]}{source.suffix}"
    shutil.copyfile(source, dossier_cible / nouveau)
    return nouveau


@bp.post("/machines/<int:machine_id>/copier")
@role_required("admin")
def copier_machine(machine_id):
    """Machine identique (n° 9, choix de Simon : enseignants seulement) : la fiche, ses pièces détachées,
    son plan de préventif (photos et pictogrammes compris) et ses documents. Jamais l'historique ni l'IPS.
    Le numéro de série et le temps de fonctionnement, propres à chaque machine, restent vides."""
    from . import preventif

    modele, err = _machine_ou_404(machine_id)
    if err:
        return err
    donnees = {**modele.to_dict(), "numero_serie": None, "compteur_heures": None, **(request.get_json(silent=True) or {})}
    copie = Machine()
    try:
        _appliquer(copie, donnees)
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    db.session.add(copie)
    db.session.flush()
    if modele.photo:
        copie.photo = _copier_fichier(_dossier_photos(), modele.photo, _dossier_photos(), copie.id)

    for a in PieceMachine.query.filter_by(machine_id=modele.id):
        db.session.add(PieceMachine(piece_id=a.piece_id, machine=copie, element_id=a.element_id))
    for a in DocumentMachine.query.filter_by(machine_id=modele.id):
        db.session.add(DocumentMachine(document_id=a.document_id, machine_id=copie.id, element_id=a.element_id))

    # Préventif : les tâches démarrent à la prochaine échéance du modèle (pas de retard dès la création)
    photos = preventif._dossier_photos()
    taches = modele.taches_preventives.filter_by(actif=True).all()
    for t in taches:
        prochaine = preventif.etat(t)["prochaine_echeance"]
        nouvelle = TachePreventive(
            machine=copie,
            nom=t.nom,
            niveau=t.niveau,
            type_preventif=t.type_preventif,
            periodicite=t.periodicite,
            date_debut=date.fromisoformat(prochaine) if prochaine else t.date_debut,
            temps_estime_min=t.temps_estime_min,
            consignes=t.consignes,
            operations=t.operations,
            moyens=t.moyens,
            redacteur=t.redacteur,
            date_redaction=t.date_redaction,
            pictogrammes=list(t.pictogrammes),
        )
        db.session.add(nouvelle)
        db.session.flush()
        for ph in t.photos:
            fichier = _copier_fichier(photos, ph.fichier, photos, nouvelle.id)
            if fichier:
                nouvelle.photos.append(TachePhoto(fichier=fichier, legende=ph.legende))

    journaliser("creation", copie, f"{copie.repere} — copie de {modele.repere} ({len(taches)} tâche(s) préventive(s))")
    db.session.commit()
    return jsonify(machine=copie.to_dict()), 201


@bp.get("/etiquettes/machines")
@role_required(*EQUIPE)
def etiquettes_machines():
    """Ce qu'on peut imprimer en étiquette QR pour chaque machine (demande de Simon du 29/10) : la fiche,
    l'IPS (seulement validée : son QR s'ouvre sans connexion), le préventif et la documentation (ou chaque document)."""
    machines = Machine.query.filter(Machine.hors_service.is_(False)).order_by(Machine.repere).all()
    ips = {i.machine_id: i.jeton for i in IpsMachine.query.filter(IpsMachine.valide_le.isnot(None))}
    taches = dict(
        db.session.query(TachePreventive.machine_id, func.count(TachePreventive.id)).filter(TachePreventive.actif.is_(True)).group_by(TachePreventive.machine_id)
    )
    documents = {}
    for lien, doc in db.session.query(DocumentMachine, Document).join(Document, Document.id == DocumentMachine.document_id).order_by(Document.titre):
        documents.setdefault(lien.machine_id, []).append({"id": doc.id, "titre": doc.titre, "categorie": doc.categorie})
    return jsonify(
        machines=[
            {
                "id": m.id,
                "repere": m.repere,
                "designation": m.designation,
                "atelier_id": m.atelier_id,
                "atelier": m.atelier.nom,
                "ips": ips.get(m.id),
                "taches": taches.get(m.id, 0),
                "documents": documents.get(m.id, []),
            }
            for m in machines
        ]
    )


@bp.post("/machines/<int:machine_id>/hors-service")
@role_required(*EQUIPE)
@unlock_required("machines")
def changer_hors_service(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    machine.hors_service = bool((request.get_json(silent=True) or {}).get("hors_service", True))
    journaliser("hors_service" if machine.hors_service else "remise_en_service", machine, machine.repere)
    db.session.commit()
    return jsonify(machine=machine.to_dict())


@bp.delete("/machines/<int:machine_id>")
@role_required(*EQUIPE)
@unlock_required("machines")
def supprimer_machine(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    if machine_a_un_historique(machine):
        return erreur(
            "Cette machine a un historique : elle ne peut pas être supprimée. Mettez-la plutôt hors service.", 409
        )
    _supprimer_photo(machine)
    PieceMachine.query.filter_by(machine_id=machine.id).delete()
    DocumentMachine.query.filter_by(machine_id=machine.id).delete()  # les documents restent, sans cette machine
    journaliser("suppression", machine, f"{machine.repere} — {machine.designation}")
    db.session.delete(machine)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Photo ----------

@bp.get("/machines/<int:machine_id>/photo")
@login_required
def photo_machine(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    if not machine.photo:
        return erreur("Cette machine n'a pas de photo.", 404)
    return send_from_directory(_dossier_photos(), machine.photo, max_age=3600)


@bp.post("/machines/<int:machine_id>/photo")
@role_required(*EQUIPE)
@unlock_required("machines")
def deposer_photo(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    fichier = request.files.get("photo")
    if not fichier or not fichier.filename:
        return erreur("Aucune photo reçue.", 400)
    extension = TYPES_PHOTO.get(fichier.mimetype)
    if not extension:
        return erreur("Format de photo non accepté (JPEG, PNG ou WebP).", 400)
    _supprimer_photo(machine)
    machine.photo = f"{machine.id}_{uuid.uuid4().hex[:12]}{extension}"
    fichier.save(_dossier_photos() / machine.photo)
    journaliser("modification", machine, "Photo ajoutée")
    db.session.commit()
    return jsonify(machine=machine.to_dict())


@bp.delete("/machines/<int:machine_id>/photo")
@role_required(*EQUIPE)
@unlock_required("machines")
def supprimer_photo(machine_id):
    machine, err = _machine_ou_404(machine_id)
    if err:
        return err
    _supprimer_photo(machine)
    journaliser("modification", machine, "Photo supprimée")
    db.session.commit()
    return jsonify(machine=machine.to_dict())
