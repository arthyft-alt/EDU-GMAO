"""Données fondatrices réservées à l'administrateur : ateliers, éléments, mots de passe de déverrouillage."""
import re
import secrets

from flask import Blueprint, jsonify, request
from flask_login import current_user
from sqlalchemy import func

from . import db
from .auth import code_du_jour, erreur, role_required
from .models import Atelier, DocumentMachine, Element, GroupeEleves, Machine, Parametre, PieceMachine, Utilisateur, journaliser
from .referentiels import ROLES
from .reglages import controler_mot_de_passe, longueur_min_mot_de_passe

bp = Blueprint("admin", __name__, url_prefix="/admin")

EMAIL = re.compile(r"[^@\s]+@[^@\s]+\.[^@\s]+")


def _nom(donnees):
    nom = (donnees.get("nom") or "").strip()
    if not nom:
        return None, erreur("Le nom est obligatoire.", 400)
    if len(nom) > 120:
        return None, erreur("Le nom ne doit pas dépasser 120 caractères.", 400)
    return nom, None


def _crud(modele, libelle, est_utilise):
    """Routes de création / renommage / suppression d'une liste simple (ateliers, éléments)."""
    nom_liste = modele.__tablename__ + "s"

    def creer():
        nom, err = _nom(request.get_json(silent=True) or {})
        if err:
            return err
        if modele.query.filter(func.lower(modele.nom) == nom.lower()).first():
            return erreur(f"{libelle} « {nom} » existe déjà.", 409)
        ordre = (db.session.query(func.max(modele.ordre)).scalar() or 0) + 1
        objet = modele(nom=nom, ordre=ordre)
        db.session.add(objet)
        db.session.flush()
        journaliser("creation", objet, nom)
        db.session.commit()
        return jsonify(objet.to_dict()), 201

    def modifier(objet_id):
        objet = db.session.get(modele, objet_id)
        if not objet:
            return erreur(f"{libelle} introuvable.", 404)
        donnees = request.get_json(silent=True) or {}
        nom, err = _nom(donnees)
        if err:
            return err
        doublon = modele.query.filter(func.lower(modele.nom) == nom.lower(), modele.id != objet.id).first()
        if doublon:
            return erreur(f"{libelle} « {nom} » existe déjà.", 409)
        if "ordre" in donnees:
            try:
                objet.ordre = int(donnees["ordre"])
            except (TypeError, ValueError):
                return erreur("L'ordre doit être un nombre entier.", 400)
        journaliser("modification", objet, f"{objet.nom} → {nom}")
        objet.nom = nom
        db.session.commit()
        return jsonify(objet.to_dict())

    def supprimer(objet_id):
        objet = db.session.get(modele, objet_id)
        if not objet:
            return erreur(f"{libelle} introuvable.", 404)
        motif = est_utilise(objet)
        if motif:
            return erreur(motif, 409)
        journaliser("suppression", objet, objet.nom)
        db.session.delete(objet)
        db.session.commit()
        return jsonify(ok=True)

    bp.add_url_rule(f"/{nom_liste}", f"creer_{nom_liste}", role_required("admin")(creer), methods=["POST"])
    bp.add_url_rule(f"/{nom_liste}/<int:objet_id>", f"modifier_{nom_liste}", role_required("admin")(modifier), methods=["PUT"])
    bp.add_url_rule(
        f"/{nom_liste}/<int:objet_id>", f"supprimer_{nom_liste}", role_required("admin")(supprimer), methods=["DELETE"]
    )


def _atelier_utilise(atelier):
    nb = Machine.query.filter_by(atelier_id=atelier.id).count()
    if nb:
        return f"Impossible de supprimer « {atelier.nom} » : {nb} machine(s) y sont rattachée(s), y compris hors service."
    return None


def _element_utilise(element):
    nb = PieceMachine.query.filter_by(element_id=element.id).count()
    if nb:
        return f"Impossible de supprimer « {element.nom} » : {nb} pièce(s) y sont rangées."
    nb = DocumentMachine.query.filter_by(element_id=element.id).count()
    if nb:
        return f"Impossible de supprimer « {element.nom} » : {nb} document(s) y sont classés."
    return None


_crud(Atelier, "L'atelier", _atelier_utilise)
_crud(Element, "L'élément", _element_utilise)


# ---------- Code du jour (annexe B) : déverrouille la gestion des machines et le calcul des indicateurs ----------

@bp.get("/code-du-jour")
@role_required("admin")
def lire_code_du_jour():
    return jsonify(code=code_du_jour())


@bp.post("/code-du-jour/renouveler")
@role_required("admin")
def renouveler_code_du_jour():
    """Nouveau code tout de suite (code divulgué, par exemple) : l'ancien ne fonctionne plus."""
    code = code_du_jour(renouveler=True)
    journaliser("modification", details="Code du jour renouvelé")
    db.session.commit()
    return jsonify(code=code)


# ---------- Utilisateurs (FND-02) ----------

def _appliquer_utilisateur(u, donnees, creation):
    login = str(donnees.get("login") or "").strip().lower()
    nom = str(donnees.get("nom") or "").strip()
    role = donnees.get("role")
    if creation:
        if not login or len(login) > 64 or " " in login:
            return "Identifiant obligatoire, sans espace (64 caractères au maximum)."
        if Utilisateur.query.filter_by(login=login).first():
            return f"L'identifiant « {login} » existe déjà."
        u.login = login
    if not nom:
        return "Le nom est obligatoire."
    if role not in ROLES:
        return "Choisissez le profil."
    atelier = None
    if role == "operateur" and donnees.get("atelier_id") not in (None, ""):
        try:
            atelier = db.session.get(Atelier, int(donnees["atelier_id"]))
        except (TypeError, ValueError):
            atelier = None
        if not atelier:
            return "Atelier introuvable."
    if u.id == current_user.id and (role != "admin" or donnees.get("actif") is False):
        return "Vous ne pouvez pas retirer vos propres droits d'administrateur ni désactiver votre compte."
    email = None
    if role == "admin":
        email, probleme = verifier_email(donnees.get("email"), u)
        if probleme:
            return probleme
    u.nom = nom[:120]
    u.role = role
    u.email = email
    u.atelier = atelier
    if "actif" in donnees:
        u.actif = bool(donnees["actif"])
    return None


def verifier_email(valeur, utilisateur):
    """Adresse e-mail d'un administrateur : obligatoire, bien formée et propre à un seul compte."""
    email = str(valeur or "").strip().lower()
    if not email:
        return None, "L'adresse e-mail est obligatoire pour un administrateur (elle sert en cas de mot de passe oublié)."
    if len(email) > 255 or not EMAIL.fullmatch(email):
        return None, "L'adresse e-mail n'est pas valide."
    if Utilisateur.query.filter(func.lower(Utilisateur.email) == email, Utilisateur.id != utilisateur.id).first():
        return None, "Cette adresse e-mail est déjà utilisée par un autre compte."
    return email, None


def _mot_de_passe(donnees, role):
    mot_de_passe = donnees.get("password") or ""
    probleme = controler_mot_de_passe(mot_de_passe, role)
    if probleme:
        return None, erreur(probleme, 400)
    return mot_de_passe, None


def _fiche(u):
    return {**u.to_dict(), "actif": u.actif, "email": u.email}


@bp.get("/utilisateurs")
@role_required("admin")
def liste_utilisateurs():
    # Les comptes anonymisés (1er août) ou supprimés ne sont plus des personnes : ils ne sont pas listés
    anciens = Utilisateur.login.like("anonyme-%") | Utilisateur.login.like("supprime-%")
    utilisateurs = Utilisateur.query.filter(~anciens).order_by(Utilisateur.role, Utilisateur.nom).all()
    return jsonify(utilisateurs=[_fiche(u) for u in utilisateurs], anciens=Utilisateur.query.filter(anciens).count())


@bp.post("/utilisateurs")
@role_required("admin")
def creer_utilisateur():
    donnees = request.get_json(silent=True) or {}
    mot_de_passe, err = _mot_de_passe(donnees, donnees.get("role"))
    if err:
        return err
    u = Utilisateur(actif=True)
    probleme = _appliquer_utilisateur(u, donnees, creation=True)
    if probleme:
        db.session.rollback()
        return erreur(probleme, 400)
    u.definir_mot_de_passe(mot_de_passe)
    db.session.add(u)
    db.session.flush()
    journaliser("creation", u, f"{u.login} ({ROLES[u.role]})")
    db.session.commit()
    return jsonify(utilisateur=_fiche(u)), 201


@bp.put("/utilisateurs/<int:utilisateur_id>")
@role_required("admin")
def modifier_utilisateur(utilisateur_id):
    u = db.session.get(Utilisateur, utilisateur_id)
    if not u:
        return erreur("Utilisateur introuvable.", 404)
    etait_actif = u.actif
    probleme = _appliquer_utilisateur(u, request.get_json(silent=True) or {}, creation=False)
    if probleme:
        db.session.rollback()
        return erreur(probleme, 400)
    if etait_actif and not u.actif:
        # Un compte désactivé ne peut plus travailler : son travail en cours repasse « à attribuer »
        from .suppression import liberer_travail

        liberer_travail([u])
    journaliser("modification", u, u.login)
    db.session.commit()
    return jsonify(utilisateur=_fiche(u))


@bp.put("/utilisateurs/<int:utilisateur_id>/mot-de-passe")
@role_required("admin")
def changer_mot_de_passe(utilisateur_id):
    u = db.session.get(Utilisateur, utilisateur_id)
    if not u:
        return erreur("Utilisateur introuvable.", 404)
    mot_de_passe, err = _mot_de_passe(request.get_json(silent=True) or {}, u.role)
    if err:
        return err
    u.definir_mot_de_passe(mot_de_passe)
    journaliser("modification", u, f"Mot de passe de {u.login} réinitialisé")
    db.session.commit()
    return jsonify(ok=True)


# ---------- Mots de passe simples et fiches de connexion ----------

CONSONNES = "bcdfgjkmnprstvz"  # sans l ni q, souvent confondus à la lecture
VOYELLES = "aeiou"


def mot_de_passe_simple(role):
    """Mot de passe facile à lire et à taper, ex. « bafoti42 » : syllabes puis deux chiffres."""
    lettres = max(4, longueur_min_mot_de_passe(role) - 2)
    mot = ""
    while len(mot) < lettres:
        mot += secrets.choice(CONSONNES) + secrets.choice(VOYELLES)
    return f"{mot}{secrets.randbelow(90) + 10}"


@bp.get("/mot-de-passe-propose")
@role_required("admin")
def mot_de_passe_propose():
    role = request.args.get("role") if request.args.get("role") in ROLES else "technicien"
    return jsonify(password=mot_de_passe_simple(role))


@bp.post("/utilisateurs/fiches-connexion")
@role_required("admin")
def fiches_connexion():
    """Les mots de passe sont chiffrés : impossible de les relire. Imprimer une fiche donne donc
    un NOUVEAU mot de passe simple à chaque élève choisi (l'ancien ne marche plus)."""
    ids = (request.get_json(silent=True) or {}).get("ids") or []
    if not isinstance(ids, list) or not ids or not all(isinstance(i, int) for i in ids):
        return erreur("Choisissez au moins un élève.", 400)
    eleves = (
        Utilisateur.query.filter(Utilisateur.id.in_(ids), Utilisateur.role == "technicien", Utilisateur.actif.is_(True))
        .order_by(Utilisateur.nom)
        .all()
    )
    if len(eleves) != len(set(ids)):
        return erreur("Un des comptes choisis n'est pas un élève actif.", 400)
    fiches = []
    for eleve in eleves:
        mot_de_passe = mot_de_passe_simple(eleve.role)
        eleve.definir_mot_de_passe(mot_de_passe)
        journaliser("modification", eleve, f"Nouveau mot de passe imprimé pour {eleve.login}")
        fiches.append({"id": eleve.id, "nom": eleve.nom, "login": eleve.login, "password": mot_de_passe})
    db.session.commit()
    return jsonify(fiches=fiches)


# ---------- Connexion des opérateurs par QR code ----------

def cle_qr(utilisateur_id):
    return f"qr_operateur_{utilisateur_id}"


def _jeton_qr(operateur, renouveler=False):
    param = db.session.get(Parametre, cle_qr(operateur.id))
    if renouveler or not param or not param.valeur:
        param = param or Parametre(cle=cle_qr(operateur.id))
        param.valeur = secrets.token_urlsafe(24)
        db.session.add(param)
    return param.valeur


@bp.get("/qr-operateurs")
@role_required("admin")
def qr_operateurs():
    operateurs = Utilisateur.query.filter_by(role="operateur", actif=True).order_by(Utilisateur.nom).all()
    resultat = [{**o.to_dict(), "jeton": _jeton_qr(o)} for o in operateurs]
    db.session.commit()
    return jsonify(operateurs=resultat)


@bp.post("/qr-operateurs/<int:utilisateur_id>/renouveler")
@role_required("admin")
def renouveler_qr(utilisateur_id):
    """Un QR code perdu ou photographié : on en crée un nouveau, l'ancien ne marche plus."""
    operateur = db.session.get(Utilisateur, utilisateur_id)
    if not operateur or operateur.role != "operateur":
        return erreur("Compte opérateur introuvable.", 404)
    jeton = _jeton_qr(operateur, renouveler=True)
    journaliser("modification", operateur, f"QR code de connexion de {operateur.login} renouvelé")
    db.session.commit()
    return jsonify(operateur={**operateur.to_dict(), "jeton": jeton})


# ---------- Groupes d'élèves ----------

@bp.get("/groupes")
@role_required("admin", "technicien")
def liste_groupes():
    return jsonify(groupes=[g.to_dict() for g in GroupeEleves.query.order_by(GroupeEleves.nom)])


def _appliquer_groupe(groupe, donnees):
    nom = str(donnees.get("nom") or "").strip()
    if not nom:
        return "Le nom du groupe est obligatoire."
    if GroupeEleves.query.filter(func.lower(GroupeEleves.nom) == nom.lower(), GroupeEleves.id != groupe.id).first():
        return f"Le groupe « {nom} » existe déjà."
    ids = donnees.get("membres") or []
    if not isinstance(ids, list) or not all(isinstance(i, int) for i in ids):
        return "Liste d'élèves invalide."
    membres = Utilisateur.query.filter(Utilisateur.id.in_(ids), Utilisateur.role == "technicien").all() if ids else []
    if len(membres) != len(set(ids)):
        return "Un des élèves choisis n'existe pas."
    groupe.nom = nom[:80]
    groupe.membres = membres
    return None


@bp.post("/groupes")
@role_required("admin")
def creer_groupe():
    groupe = GroupeEleves()
    probleme = _appliquer_groupe(groupe, request.get_json(silent=True) or {})
    if probleme:
        return erreur(probleme, 400)
    db.session.add(groupe)
    db.session.flush()
    journaliser("creation", groupe, groupe.nom)
    db.session.commit()
    return jsonify(groupe=groupe.to_dict()), 201


@bp.put("/groupes/<int:groupe_id>")
@role_required("admin")
def modifier_groupe(groupe_id):
    groupe = db.session.get(GroupeEleves, groupe_id)
    if not groupe:
        return erreur("Groupe introuvable.", 404)
    probleme = _appliquer_groupe(groupe, request.get_json(silent=True) or {})
    if probleme:
        db.session.rollback()
        return erreur(probleme, 400)
    journaliser("modification", groupe, groupe.nom)
    db.session.commit()
    return jsonify(groupe=groupe.to_dict())


@bp.delete("/groupes/<int:groupe_id>")
@role_required("admin")
def supprimer_groupe(groupe_id):
    groupe = db.session.get(GroupeEleves, groupe_id)
    if not groupe:
        return erreur("Groupe introuvable.", 404)
    journaliser("suppression", groupe, groupe.nom)
    # Rôles (option) : les roues et les rôles fixes de ce groupe disparaissent avec lui
    from .models import RoleAttribution, Roue

    for roue in Roue.query.filter_by(groupe_id=groupe.id):
        db.session.delete(roue)
    RoleAttribution.query.filter_by(groupe_id=groupe.id).delete()
    db.session.delete(groupe)
    db.session.commit()
    return jsonify(ok=True)
