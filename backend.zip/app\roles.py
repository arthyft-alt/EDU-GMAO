"""Rôles des élèves et roue hebdomadaire (option facultative, demande de Simon du 29/10/2026, choix 1A, 2A et B, 3A, 4A).

- Un rôle (Magasinier, Préparateur, Responsable sécurité, Responsable de l'atelier Fonderie…) peut porter sur un atelier :
  son titulaire voit les bons et le préventif de cet atelier mis en avant.
- Un rôle est soit fixe (confié pour l'année à un élève ou à un groupe), soit dans une roue.
- Une roue tourne pour toute la classe ou pour un groupe : élèves rangés par nom, chaque lundi hors vacances la roue
  avance d'un cran (l'élève n° i a le rôle n° i − semaine, modulo le plus grand des nombres d'élèves et de rôles). En autant
  de semaines, chacun passe une fois par chaque rôle. Un échange peut être forcé pour une semaine (élève absent…).
"""
from datetime import date, timedelta

from flask import Blueprint, jsonify, request
from flask_login import current_user

from . import db, preventif
from .auth import erreur, role_required
from .calendrier import lundi as lundi_de, semaines_de_vacances
from .models import Atelier, GroupeEleves, Role, RoleAttribution, Roue, RoueEchange, RoueRole, Utilisateur, journaliser
from .reglages import reglage

bp = Blueprint("roles", __name__)

EQUIPE = ("admin", "technicien")
SEMAINES_PLANNING = 6


def option_active():
    return reglage("option_roles") == "1"


def _eleves_actifs():
    anciens = Utilisateur.login.like("anonyme-%") | Utilisateur.login.like("supprime-%")
    return Utilisateur.query.filter(Utilisateur.role == "technicien", Utilisateur.actif.is_(True), ~anciens).order_by(Utilisateur.nom, Utilisateur.id).all()


def membres(roue):
    if roue.groupe:
        return sorted((m for m in roue.groupe.membres if m.actif and m.role == "technicien"), key=lambda m: (m.nom, m.id))
    return _eleves_actifs()


def rang(roue, lundi, vacances):
    """Nombre de crans de la roue pour la semaine du lundi donné (None : pas de rôle cette semaine-là)."""
    depart = lundi_de(roue.date_debut)
    if lundi < depart or lundi in vacances:
        return None
    semaines, courant = 0, depart
    while courant < lundi:
        if courant not in vacances:
            semaines += 1
        courant += timedelta(days=7)
    return semaines


def tirage(roue, lundi, vacances, eleves=None):
    """{élève: rôle} pour la semaine, échanges forcés compris."""
    eleves = membres(roue) if eleves is None else eleves
    roles = [rr.role for rr in roue.roles]
    w = rang(roue, lundi, vacances)
    if w is None or not eleves or not roles:
        return {}
    # La roue a autant de crans que le plus grand des deux nombres : s'il y a plus de rôles que d'élèves,
    # un rôle reste libre chaque semaine mais chacun passe quand même par tous les rôles
    n = max(len(eleves), len(roles))
    resultat = {}
    for i, e in enumerate(eleves):
        j = (i - w) % n
        if j < len(roles):
            resultat[e] = roles[j]
    for ech in roue.echanges:
        if ech.lundi == lundi:
            a = next((e for e in eleves if e.id == ech.eleve_a_id), None)
            b = next((e for e in eleves if e.id == ech.eleve_b_id), None)
            if a and b:
                ra, rb = resultat.pop(a, None), resultat.pop(b, None)
                if rb:
                    resultat[a] = rb
                if ra:
                    resultat[b] = ra
    return resultat


def roles_de_la_semaine(lundi=None):
    """{id d'élève: [{role, atelier_id, atelier, origine}]} : rôles fixes et rôles de toutes les roues."""
    if not option_active():
        return {}
    lundi = lundi or lundi_de(preventif.aujourdhui())
    vacances = semaines_de_vacances()
    resultat = {}

    def ajouter(eleve_id, role, origine):
        resultat.setdefault(eleve_id, []).append(
            {"role_id": role.id, "role": role.nom, "atelier_id": role.atelier_id, "atelier": role.atelier.nom if role.atelier else None, "origine": origine}
        )

    for a in RoleAttribution.query.all():
        if a.utilisateur and a.utilisateur.actif:
            ajouter(a.utilisateur.id, a.role, "fixe")
        elif a.groupe:
            for m in a.groupe.membres:
                if m.actif:
                    ajouter(m.id, a.role, f"fixe ({a.groupe.nom})")
    for roue in Roue.query.all():
        for eleve, role in tirage(roue, lundi, vacances).items():
            ajouter(eleve.id, role, roue.nom)
    return resultat


def _roue_dict(roue, lundi, vacances):
    eleves = membres(roue)
    planning = []
    for k in range(SEMAINES_PLANNING):
        semaine = lundi + timedelta(days=7 * k)
        t = tirage(roue, semaine, vacances, eleves)
        planning.append(
            {
                "lundi": semaine.isoformat(),
                "numero": semaine.isocalendar()[1],
                "vacances": semaine in vacances,
                "attributions": [{"eleve_id": e.id, "eleve": e.nom, "role_id": r.id, "role": r.nom} for e, r in sorted(t.items(), key=lambda x: x[1].nom)],
            }
        )
    return {
        "id": roue.id,
        "nom": roue.nom,
        "groupe": {"id": roue.groupe.id, "nom": roue.groupe.nom} if roue.groupe else None,
        "date_debut": roue.date_debut.isoformat(),
        "roles": [{"id": rr.role.id, "nom": rr.role.nom, "atelier": rr.role.atelier.nom if rr.role.atelier else None} for rr in roue.roles],
        "membres": [{"id": e.id, "nom": e.nom} for e in eleves],
        "planning": planning,
        "echanges": [
            {"id": e.id, "lundi": e.lundi.isoformat(), "eleve_a_id": e.eleve_a_id, "eleve_b_id": e.eleve_b_id} for e in sorted(roue.echanges, key=lambda x: x.lundi) if e.lundi >= lundi
        ],
    }


# ---------- Lecture ----------

@bp.get("/roles")
@role_required(*EQUIPE)
def lire():
    """?lundi=AAAA-MM-JJ : semaine affichée (par défaut la semaine en cours) et les suivantes."""
    if not option_active():
        return jsonify(option=False, roles=[], roues=[])
    try:
        lundi = lundi_de(date.fromisoformat(request.args["lundi"])) if request.args.get("lundi") else lundi_de(preventif.aujourdhui())
    except ValueError:
        return erreur("Date invalide.", 400)
    vacances = semaines_de_vacances()
    return jsonify(
        option=True,
        lundi=lundi.isoformat(),
        roles=[r.to_dict() for r in Role.query.order_by(Role.ordre, Role.nom)],
        roues=[_roue_dict(r, lundi, vacances) for r in Roue.query.order_by(Roue.nom)],
    )


@bp.get("/roles/semaine")
@role_required("admin", "technicien", "operateur")
def semaine():
    """Rôles de chaque élève cette semaine (accueil, écran d'atelier, réunion AIC)."""
    return jsonify(option=option_active(), roles={str(k): v for k, v in roles_de_la_semaine().items()})


@bp.get("/roles/moi")
@role_required(*EQUIPE)
def moi():
    roles = roles_de_la_semaine().get(current_user.id, [])
    ateliers = {r["atelier_id"]: r["atelier"] for r in roles if r["atelier_id"]}
    return jsonify(option=option_active(), roles=roles, ateliers=[{"id": i, "nom": n} for i, n in sorted(ateliers.items())])


# ---------- Gestion par l'enseignant ----------

def _appliquer_role(role, d):
    nom = str(d.get("nom") or "").strip()
    if not nom:
        return "Le nom du rôle est obligatoire."
    if Role.query.filter(db.func.lower(Role.nom) == nom.lower(), Role.id != role.id).first():
        return f"Le rôle « {nom} » existe déjà."
    atelier = None
    if d.get("atelier_id") not in (None, ""):
        atelier = db.session.get(Atelier, int(d["atelier_id"])) if str(d["atelier_id"]).isdigit() else None
        if not atelier:
            return "Atelier introuvable."
    attributions = []
    for f in d.get("fixe") or []:
        u = db.session.get(Utilisateur, f.get("utilisateur_id") or 0) if f.get("utilisateur_id") else None
        g = db.session.get(GroupeEleves, f.get("groupe_id") or 0) if f.get("groupe_id") else None
        if bool(u) == bool(g) or (u and u.role != "technicien"):
            return "Chaque attribution fixe désigne un élève ou un groupe."
        attributions.append(RoleAttribution(utilisateur=u, groupe=g))
    role.nom = nom[:80]
    role.description = str(d.get("description") or "").strip()[:300] or None
    role.atelier = atelier
    role.attributions = attributions
    return None


@bp.post("/roles")
@role_required("admin")
def creer_role():
    role = Role(ordre=Role.query.count())
    probleme = _appliquer_role(role, request.get_json(silent=True) or {})
    if probleme:
        db.session.rollback()
        return erreur(probleme, 400)
    db.session.add(role)
    db.session.flush()
    journaliser("creation", role, role.nom)
    db.session.commit()
    return jsonify(role=role.to_dict()), 201


@bp.put("/roles/<int:role_id>")
@role_required("admin")
def modifier_role(role_id):
    role = db.session.get(Role, role_id)
    if not role:
        return erreur("Rôle introuvable.", 404)
    probleme = _appliquer_role(role, request.get_json(silent=True) or {})
    if probleme:
        db.session.rollback()
        return erreur(probleme, 400)
    journaliser("modification", role, role.nom)
    db.session.commit()
    return jsonify(role=role.to_dict())


@bp.delete("/roles/<int:role_id>")
@role_required("admin")
def supprimer_role(role_id):
    role = db.session.get(Role, role_id)
    if not role:
        return erreur("Rôle introuvable.", 404)
    RoueRole.query.filter_by(role_id=role.id).delete()
    journaliser("suppression", role, role.nom)
    db.session.delete(role)
    db.session.commit()
    return jsonify(ok=True)


def _appliquer_roue(roue, d):
    nom = str(d.get("nom") or "").strip()
    if not nom:
        return "Le nom de la roue est obligatoire."
    groupe = None
    if d.get("groupe_id"):
        groupe = db.session.get(GroupeEleves, int(d["groupe_id"])) if str(d["groupe_id"]).isdigit() else None
        if not groupe:
            return "Groupe introuvable."
    try:
        debut = date.fromisoformat(str(d.get("date_debut")))
    except ValueError:
        return "Indiquez la semaine de départ."
    ids = d.get("roles") or []
    if not isinstance(ids, list) or not ids or not all(isinstance(i, int) for i in ids) or len(set(ids)) != len(ids):
        return "Choisissez au moins un rôle (une seule fois chacun)."
    roles = {r.id: r for r in Role.query.filter(Role.id.in_(ids))}
    if len(roles) != len(ids):
        return "Un des rôles n'existe plus."
    if RoleAttribution.query.filter(RoleAttribution.role_id.in_(ids)).count():
        return "Un rôle fixe (confié pour l'année) ne peut pas être dans une roue."
    roue.nom = nom[:80]
    roue.groupe = groupe
    roue.date_debut = lundi_de(debut)
    roue.roles = [RoueRole(role=roles[i], ordre=k) for k, i in enumerate(ids)]
    return None


@bp.post("/roues")
@role_required("admin")
def creer_roue():
    roue = Roue()
    probleme = _appliquer_roue(roue, request.get_json(silent=True) or {})
    if probleme:
        db.session.rollback()
        return erreur(probleme, 400)
    db.session.add(roue)
    db.session.flush()
    journaliser("creation", roue, roue.nom)
    db.session.commit()
    return jsonify(ok=True, id=roue.id), 201


@bp.put("/roues/<int:roue_id>")
@role_required("admin")
def modifier_roue(roue_id):
    roue = db.session.get(Roue, roue_id)
    if not roue:
        return erreur("Roue introuvable.", 404)
    roue.roles = []
    db.session.flush()
    probleme = _appliquer_roue(roue, request.get_json(silent=True) or {})
    if probleme:
        db.session.rollback()
        return erreur(probleme, 400)
    journaliser("modification", roue, roue.nom)
    db.session.commit()
    return jsonify(ok=True)


@bp.delete("/roues/<int:roue_id>")
@role_required("admin")
def supprimer_roue(roue_id):
    roue = db.session.get(Roue, roue_id)
    if not roue:
        return erreur("Roue introuvable.", 404)
    journaliser("suppression", roue, roue.nom)
    db.session.delete(roue)
    db.session.commit()
    return jsonify(ok=True)


@bp.post("/roues/<int:roue_id>/echanges")
@role_required("admin")
def echanger(roue_id):
    """{lundi, eleve_a_id, eleve_b_id} : les deux élèves échangent leurs rôles pour cette semaine seulement."""
    roue = db.session.get(Roue, roue_id)
    if not roue:
        return erreur("Roue introuvable.", 404)
    d = request.get_json(silent=True) or {}
    try:
        lundi = lundi_de(date.fromisoformat(str(d.get("lundi"))))
    except ValueError:
        return erreur("Semaine invalide.", 400)
    ids = {m.id for m in membres(roue)}
    a, b = d.get("eleve_a_id"), d.get("eleve_b_id")
    if a not in ids or b not in ids or a == b:
        return erreur("Choisissez deux élèves différents de cette roue.", 400)
    db.session.add(RoueEchange(roue=roue, lundi=lundi, eleve_a_id=a, eleve_b_id=b))
    journaliser("modification", roue, f"Échange de rôles la semaine du {lundi:%d/%m/%Y}")
    db.session.commit()
    return jsonify(ok=True), 201


@bp.delete("/roues/echanges/<int:echange_id>")
@role_required("admin")
def annuler_echange(echange_id):
    ech = db.session.get(RoueEchange, echange_id)
    if not ech:
        return erreur("Échange introuvable.", 404)
    db.session.delete(ech)
    db.session.commit()
    return jsonify(ok=True)
