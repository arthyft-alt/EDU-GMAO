"""Exemple de référence (novembre 2026, 30 jours = 30/7 semaines) :
machine utilisée 10 h/semaine -> H = 42,857 h ; 2 pannes, temps passés 1,5 h et 0,5 h -> TR = 2 h
MTBF = (42,857 - 2) / 2 = 20,4 h ; MTTR = 1 h ; disponibilité = 40,857 / 42,857 = 95,3 %.
Coûts (taux main-d'œuvre 15 €/h, machine 20 €/h) :
  panne 1 : pièces 9 € + MO 1,5 h × 2 techniciens × 15 = 45 € + immobilisation 1,5 × 20 = 30 € (machine arrêtée)
  panne 2 : MO 0,5 × 1 × 15 = 7,5 €
  préventif coché (30 min estimées) : MO 7,5 €
  amélioration (3 h, hors pannes mais comptée dans les coûts) : MO 45 € (« autres »)
  => pièces 9, MO 105, immobilisation 30, total 144 ; correctif 91,5, préventif 7,5, autres 45.
"""
from datetime import date, datetime

import pytest

from app import db
from app.indicateurs import bornes
from app.models import (
    Atelier,
    BonComposant,
    BonIntervention,
    Element,
    Machine,
    RealisationPreventive,
    TachePreventive,
)

MDP = {"X-Unlock-Password": "1234"}  # code du jour fixé par conftest
NOVEMBRE = "periode=mois&debut=2026-11-10"


@pytest.fixture()
def parc(app):
    maintenance = Atelier.query.filter_by(nom="01. Maintenance").one()
    fonderie = Atelier.query.filter_by(nom="03. Fonderie").one()
    tour = Machine(repere="MAI-01", designation="Tour", atelier=maintenance, utilisation_hebdo_h=10, taux_horaire=20)
    four = Machine(repere="FON-01", designation="Four", atelier=fonderie, utilisation_hebdo_h=20)
    sans = Machine(repere="MAI-02", designation="Perceuse", atelier=maintenance)  # utilisation inconnue
    db.session.add_all([tour, four, sans])
    db.session.flush()
    convertir = Element.query.filter_by(nom="23 Convertir").one()

    def bon(numero, machine, jour, type_travail="depannage", **autres):
        b = BonIntervention(numero=numero, machine=machine, type_travail=type_travail, urgence="normale", statut="termine",
                            demandeur="x", description="x", cree_le=datetime(2026, 11, jour, 9), **autres)
        db.session.add(b)
        return b

    b1 = bon("BI-1", tour, 3, temps_passe_h=1.5, effectif=2, machine_arretee=True,
             remise_en_service=datetime(2026, 11, 3, 15), element=convertir)
    b1.composants = [BonComposant(designation="Roulement", quantite=2, prix_unitaire=4.5)]
    bon("BI-2", tour, 20, temps_passe_h=0.5)
    bon("BI-3", tour, 21, type_travail="amelioration", temps_passe_h=3)  # pas une panne
    bon("BI-4", four, 5, temps_passe_h=4, machine_arretee=True, remise_en_service=datetime(2026, 11, 5, 19))
    db.session.add(BonIntervention(numero="BI-5", machine=tour, type_travail="depannage", urgence="normale", statut="termine",
                                   demandeur="x", description="hors période", cree_le=datetime(2026, 10, 30, 9), temps_passe_h=9))
    tache = TachePreventive(machine=tour, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite="mois",
                            date_debut=date(2026, 11, 2), temps_estime_min=30)
    db.session.add(tache)
    db.session.flush()
    db.session.add(RealisationPreventive(tache=tache, echeance=date(2026, 11, 2)))
    db.session.commit()
    return tour, four, sans


# ---------- Périodes ----------

def test_bornes_des_periodes():
    jour = date(2026, 11, 18)  # mercredi
    assert bornes("semaine", jour) == (date(2026, 11, 16), date(2026, 11, 23))
    assert bornes("mois", jour) == (date(2026, 11, 1), date(2026, 12, 1))
    assert bornes("trimestre", jour) == (date(2026, 10, 1), date(2027, 1, 1))
    assert bornes("annee", jour) == (date(2026, 8, 1), date(2027, 8, 1))
    assert bornes("annee", date(2027, 3, 1)) == (date(2026, 8, 1), date(2027, 8, 1))


# ---------- Calcul automatique ----------

def test_calcul_automatique_protege(client, connecter, parc):
    connecter("tech")
    assert client.get(f"/api/indicateurs/auto?{NOVEMBRE}").status_code == 403
    assert client.get(f"/api/indicateurs/auto?{NOVEMBRE}", headers={"X-Unlock-Password": "faux"}).status_code == 403
    d = client.get(f"/api/indicateurs/auto?{NOVEMBRE}", headers=MDP).get_json()
    assert "couts" not in d["parc"]  # coûts : administrateur seulement
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get(f"/api/indicateurs/auto?{NOVEMBRE}", headers=MDP).status_code == 403


def test_formules_sur_l_exemple_de_reference(client, connecter, parc):
    tour = parc[0]
    connecter("admin")
    d = client.get(f"/api/indicateurs/auto?{NOVEMBRE}&atelier_id={tour.atelier_id}").get_json()
    assert d["periode"] == {"type": "mois", "du": "2026-11-01", "au": "2026-11-30"}
    m = next(x for x in d["machines"] if x["repere"] == "MAI-01")
    assert (m["nb_pannes"], m["temps_reparation_h"], m["heures_utilisation"]) == (2, 2.0, 42.9)
    assert (m["mtbf_h"], m["mttr_h"], m["disponibilite"], m["pastille"]) == (20.4, 1.0, 95.3, "success")
    assert m["temps_arret_h"] == 6.0
    perceuse = next(x for x in d["machines"] if x["repere"] == "MAI-02")
    assert perceuse["disponibilite"] is None and perceuse["pastille"] == "neutral"


def test_couts_detailles(client, connecter, parc):
    connecter("admin")
    tour = parc[0]
    d = client.get(f"/api/indicateurs/auto?{NOVEMBRE}&atelier_id={tour.atelier_id}").get_json()
    c = next(x for x in d["machines"] if x["repere"] == "MAI-01")["couts"]
    # Amélioration BI-3 : 3 h × 1 × 15 = 45 € (comptée dans les coûts, « autres »)
    assert (c["pieces"], c["main_oeuvre"], c["immobilisation"]) == (9.0, 105.0, 30.0)
    assert c["par_type"] == {"correctif": 91.5, "preventif": 7.5, "autres": 45.0}
    assert c["total"] == 144.0


def test_agregation_atelier_et_parc(client, connecter, parc):
    connecter("tech")
    d = client.get(f"/api/indicateurs/auto?{NOVEMBRE}", headers=MDP).get_json()
    maintenance = next(a for a in d["ateliers"] if a["nom"] == "01. Maintenance")
    assert maintenance["machines_sans_utilisation"] == 1 and maintenance["nb_pannes"] == 2
    # Parc : H = (10 + 20) × 30/7 = 128,57 h ; TR = 2 + 4 = 6 h ; 3 pannes
    assert d["parc"]["nb_pannes"] == 3
    assert d["parc"]["mtbf_h"] == round((128.5714 - 6) / 3, 1)
    assert d["parc"]["disponibilite"] == round((128.5714 - 6) / 128.5714 * 100, 1)


def test_seuils_des_pastilles(client, connecter, parc):
    connecter("admin")
    assert client.put("/api/indicateurs/parametres", json={"seuil_dispo_vert": "70", "seuil_dispo_orange": "80"}).status_code == 400
    client.put("/api/indicateurs/parametres", json={"seuil_dispo_vert": "97", "seuil_dispo_orange": "95"})
    d = client.get(f"/api/indicateurs/auto?{NOVEMBRE}&atelier_id={parc[0].atelier_id}").get_json()
    assert next(x for x in d["machines"] if x["repere"] == "MAI-01")["pastille"] == "warning"
    client.post("/api/auth/logout")
    connecter("tech")
    assert client.put("/api/indicateurs/parametres", json={"taux_main_oeuvre": 20}).status_code == 403


def test_evolution(client, connecter, parc):
    connecter("tech")
    points = client.get(f"/api/indicateurs/machines/{parc[0].id}/evolution?{NOVEMBRE}&n=3", headers=MDP).get_json()["points"]
    assert [p["debut"] for p in points] == ["2026-09-01", "2026-10-01", "2026-11-01"]
    assert points[1]["nb_pannes"] == 1 and points[2]["nb_pannes"] == 2


# ---------- Pareto ----------

def test_pareto(client, connecter, parc):
    connecter("tech")
    d = client.get(f"/api/indicateurs/pareto?critere=reparation&{NOVEMBRE}", headers=MDP).get_json()
    assert [(l["nom"], l["valeur"], l["classe"]) for l in d["lignes"]] == [("FON-01 — Four", 4.0, "A"), ("MAI-01 — Tour", 2.0, "A")]  # le Tour commence à 66,7 % du cumul : encore A
    assert d["lignes"][-1]["cumul"] == 100.0
    pannes = client.get(f"/api/indicateurs/pareto?critere=pannes&groupe=element&{NOVEMBRE}", headers=MDP).get_json()
    assert {l["nom"]: l["valeur"] for l in pannes["lignes"]} == {"Élément non renseigné": 2, "23 Convertir": 1}
    assert client.get(f"/api/indicateurs/pareto?critere=couts&{NOVEMBRE}", headers=MDP).status_code == 403
    assert client.get(f"/api/indicateurs/pareto?critere=arret&{NOVEMBRE}").status_code == 403


def test_tableau_des_couts_admin(client, connecter, parc):
    connecter("tech")
    assert client.get(f"/api/indicateurs/couts?{NOVEMBRE}", headers=MDP).status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    d = client.get("/api/indicateurs/couts?periode=annee&debut=2026-11-10").get_json()
    assert len(d["evolution"]) == 12 and d["evolution"][0]["debut"] == "2026-08-01"
    assert d["machines"][0]["repere"] == "MAI-01"
    assert d["parc"]["par_type"]["correctif"] > 0


def test_export(client, connecter, parc):
    connecter("tech")
    texte = client.get(f"/api/indicateurs/export.csv?{NOVEMBRE}", headers=MDP).data.decode("utf-8")
    assert texte.startswith("﻿") and "Coût total" not in texte
    assert "MAI-01;Tour;42,9;2;2;6;20,4;1;95,3" in texte


# ---------- Saisies des élèves ----------

def test_saisie_des_eleves(client, connecter, parc):
    connecter("tech")
    tour = parc[0]
    reponse = client.put("/api/indicateurs/saisies", json={"machine_id": tour.id, "periode": "mois", "debut": "2026-11-17", "mtbf_h": "20,5", "disponibilite": "95"})
    assert reponse.status_code == 200
    s = reponse.get_json()["saisie"]
    assert s["debut"] == "2026-11-01" and s["mtbf_h"] == 20.5 and s["saisi_par"] == "Technicien 1 (démo)"
    # Une seule saisie par machine et par période : la nouvelle remplace l'ancienne
    client.put("/api/indicateurs/saisies", json={"machine_id": tour.id, "periode": "mois", "debut": "2026-11-01", "cout_pieces": "9", "cout_main_oeuvre": "60"})
    saisies = client.get(f"/api/indicateurs/saisies?{NOVEMBRE}").get_json()["saisies"]
    assert len(saisies) == 1 and saisies[0]["cout_total"] == 69.0 and saisies[0]["mtbf_h"] is None
    assert client.put("/api/indicateurs/saisies", json={"machine_id": tour.id, "periode": "mois", "debut": "2026-11-01", "disponibilite": "120"}).status_code == 400
    assert client.put("/api/indicateurs/saisies", json={"machine_id": tour.id, "periode": "mois", "debut": "2026-11-01"}).status_code == 400
    client.post("/api/auth/logout")
    connecter("tech2")
    assert client.delete(f"/api/indicateurs/saisies/{saisies[0]['id']}").status_code == 403


# ---------- Maintenance conditionnelle ----------

def test_releves_conditionnels(client, connecter, parc):
    connecter("tech")
    url = f"/api/machines/{parc[0].id}/releves"
    assert client.post(url, json={"type": "thermique", "resultat": "anormal", "date": "2026-11-02"}).get_json()["releve"]["gravite"] == "alerte"
    assert client.post(url, json={"type": "huile", "resultat": "8"}).get_json()["releve"]["libelle"] == "Classe NAS 8"
    vib = client.post(url, json={"type": "vibratoire", "resultat": "aucun"}).get_json()["releve"]
    assert vib["gravite"] == "ok"
    assert client.post(url, json={"type": "huile", "resultat": "15"}).status_code == 400
    assert client.post(url, json={"type": "acoustique", "resultat": "x"}).status_code == 400
    etat = client.get("/api/conditionnel/etat").get_json()["etat"][str(parc[0].id)]
    assert etat["huile"]["gravite"] == "surveiller" and etat["thermique"]["resultat"] == "anormal"
    assert len(client.get(url).get_json()["releves"]) == 3
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get(url).status_code == 403


def test_element_en_cause_d_un_bon(client, connecter, parc):
    connecter("tech")
    bon = BonIntervention.query.filter_by(numero="BI-2").one()
    bon.statut = "en_cours"
    db.session.commit()
    convertir = Element.query.filter_by(nom="23 Convertir").one().id
    assert client.put(f"/api/bons/{bon.id}", json={"element_id": convertir}).get_json()["bon"]["element"] == "23 Convertir"
    assert client.put(f"/api/bons/{bon.id}", json={"element_id": 999}).status_code == 400


def test_taux_horaire_machine(client, connecter, parc):
    connecter("admin")
    tour = parc[0]
    donnees = {"repere": "MAI-01", "designation": "Tour", "atelier_id": tour.atelier_id, "taux_horaire": "25,5"}
    assert client.put(f"/api/machines/{tour.id}", json=donnees).get_json()["machine"]["taux_horaire"] == 25.5


def test_saisies_regroupees_par_date(client, connecter, parc):
    """Les saisies hebdomadaires comptent dans le mois ; une saisie mensuelle l'emporte sur les semaines qu'elle couvre."""
    connecter("tech")
    tour = parc[0]
    saisir = lambda **d: client.put("/api/indicateurs/saisies", json={"machine_id": tour.id, **d})
    saisir(periode="semaine", debut="2026-11-02", mtbf_h="10", disponibilite="90", cout_pieces="5")
    saisir(periode="semaine", debut="2026-11-09", mtbf_h="20", disponibilite="100", cout_pieces="7")
    mois = client.get(f"/api/indicateurs/saisies/agregees?{NOVEMBRE}").get_json()["machines"][0]
    assert (mois["nb_saisies"], mois["mtbf_h"], mois["disponibilite"], mois["cout_pieces"], mois["cout_total"]) == (2, 15.0, 95.0, 12.0, 12.0)
    # Les deux saisies apparaissent dans la liste du mois, quel que soit leur type
    assert len(client.get(f"/api/indicateurs/saisies?{NOVEMBRE}").get_json()["saisies"]) == 2
    # Une saisie mensuelle couvre les semaines : elle seule est retenue pour le mois
    saisir(periode="mois", debut="2026-11-01", mtbf_h="18", cout_pieces="30")
    mois = client.get(f"/api/indicateurs/saisies/agregees?{NOVEMBRE}").get_json()["machines"][0]
    assert (mois["nb_saisies"], mois["mtbf_h"], mois["cout_total"]) == (1, 18.0, 30.0)
    # L'année scolaire regroupe aussi
    annee = client.get("/api/indicateurs/saisies/agregees?periode=annee&debut=2026-11-10").get_json()["machines"][0]
    assert annee["cout_pieces"] == 30.0
    # Évolution mensuelle de la machine
    points = client.get(f"/api/indicateurs/machines/{tour.id}/saisies-evolution?{NOVEMBRE}&n=2").get_json()["points"]
    assert [p["debut"] for p in points] == ["2026-10-01", "2026-11-01"]
    assert points[0].get("mtbf_h") is None and points[1]["mtbf_h"] == 18.0
