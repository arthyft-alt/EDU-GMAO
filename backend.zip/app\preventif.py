"""Module Maintenance préventive (PRV-01 à PRV-09, EQ-06).

Échéances à dates fixes : date de départ + k × périodicité. Une échéance non réalisée ne se cumule pas :
quand la suivante arrive, elle devient « non réalisée » et seule la nouvelle est à faire.
Vacances : une échéance qui tombe dans une semaine de vacances est reportée au lundi de la rentrée ;
plusieurs échéances reportées au même lundi n'en font qu'une.
Semaines : une échéance est « à faire » toute sa semaine (du lundi au dimanche) et « en retard » ensuite.
"""
import calendar
import uuid
from datetime import date, datetime, timedelta

from flask import Blueprint, current_app, jsonify, request, send_from_directory
from flask_login import current_user, login_required
from sqlalchemy.orm import contains_eager, joinedload

from . import db
from . import referentiels as ref
from .auth import erreur, role_required
from .calendrier import semaines_de_vacances
from .dates import PARIS
from .reglages import liste, reglage
from .models import (
    BonIntervention,
    BonPreventif,
    Machine,
    Pictogramme,
    Piece,
    RealisationPreventive,
    TachePhoto,
    TachePiece,
    TachePreventive,
    Utilisateur,
    journaliser,
    maintenant,
)

bp = Blueprint("preventif", __name__)

EQUIPE = ("admin", "technicien")
TYPES_PHOTO = {"image/jpeg": ".jpg", "image/png": ".png", "image/webp": ".webp"}
PHOTOS_MAX = 4


class Invalide(Exception):
    pass


def aujourdhui():
    return datetime.now(PARIS).date()


# ---------- Calcul des échéances ----------

def _ajouter_mois(jour, mois):
    total = jour.month - 1 + mois
    annee, mois_final = jour.year + total // 12, total % 12 + 1
    return date(annee, mois_final, min(jour.day, calendar.monthrange(annee, mois_final)[1]))


def occurrence(tache, k):
    """k-ième échéance (k = 0 : date de départ)."""
    _, jours, mois = ref.PERIODICITES[tache.periodicite]
    return tache.date_debut + timedelta(days=jours * k) if jours else _ajouter_mois(tache.date_debut, mois * k)


def indice_courant(tache, jour):
    """Indice de la dernière échéance arrivée (≤ jour), ou -1 si la première est à venir."""
    if jour < tache.date_debut:
        return -1
    _, jours, mois = ref.PERIODICITES[tache.periodicite]
    if jours:
        return (jour - tache.date_debut).days // jours
    k = ((jour.year - tache.date_debut.year) * 12 + jour.month - tache.date_debut.month) // mois
    while k > 0 and occurrence(tache, k) > jour:
        k -= 1
    while occurrence(tache, k + 1) <= jour:
        k += 1
    return k


def reporter(echeance, vacances):
    """Échéance dans une semaine de vacances → lundi de la première semaine de cours qui suit."""
    semaine = echeance - timedelta(days=echeance.weekday())
    if semaine not in vacances:
        return echeance
    while semaine in vacances:
        semaine += timedelta(days=7)
    return semaine


def echeance_effective(tache, k, vacances):
    return reporter(occurrence(tache, k), vacances)


def echeances_entre(tache, du, au, vacances=None):
    """Échéances effectives entre du et au inclus, après report des vacances : une seule par semaine
    (la dernière de la semaine, comme etat()), car le préventif est pensé en semaines."""
    vacances = semaines_de_vacances() if vacances is None else vacances
    # Une échéance peut être reportée de toute la durée des grandes vacances : on part d'assez loin avant « du »
    k = max(indice_courant(tache, du - timedelta(days=100)), 0)
    par_semaine = {}
    while (brute := occurrence(tache, k)) <= au + timedelta(days=6 - au.weekday()):
        echeance = reporter(brute, vacances)
        par_semaine[echeance - timedelta(days=echeance.weekday())] = echeance  # la plus tardive l'emporte
        k += 1
    return [e for _, e in sorted(par_semaine.items()) if du <= e <= au]


def _courante_et_prochaine(tache, jour, vacances):
    """Dernière échéance effective arrivée (≤ jour, ou None) et la suivante (> jour)."""
    kc = indice_courant(tache, jour)
    k = kc
    while k >= 0 and echeance_effective(tache, k, vacances) > jour:
        k -= 1
    courante = echeance_effective(tache, k, vacances) if k >= 0 else None
    k = max(kc, 0)
    while echeance_effective(tache, k, vacances) <= jour:
        k += 1
    return courante, echeance_effective(tache, k, vacances)


def fin_de_semaine(jour):
    return jour + timedelta(days=6 - jour.weekday())


def meme_semaine(a, b):
    return a - timedelta(days=a.weekday()) == b - timedelta(days=b.weekday())


def etat(tache, jour=None, realisees=None, vacances=None):
    """Statut de la tâche, pensé en semaines (choix de Simon) : a_faire (échéance dans la semaine en cours,
    quel que soit le jour), en_retard (échéance d'une semaine passée, non réalisée), fait, a_venir."""
    jour = jour or aujourdhui()
    vacances = semaines_de_vacances() if vacances is None else vacances
    if realisees is None:
        realisees = {r.echeance for r in tache.realisations}
    # Une réalisation enregistrée avant le report (date d'origine) vaut pour l'échéance reportée
    realisees = {reporter(r, vacances) for r in realisees}
    # Toute échéance de la semaine en cours est déjà « arrivée » : on raisonne jusqu'au dimanche
    courante, prochaine = _courante_et_prochaine(tache, fin_de_semaine(jour), vacances)
    if courante is None:
        statut, a_faire = "a_venir", prochaine
    elif courante in realisees:
        statut, a_faire = "fait", prochaine
    else:
        statut, a_faire = ("a_faire" if meme_semaine(courante, jour) else "en_retard"), courante
    anticipable = statut in ("fait", "a_venir") and prochaine not in realisees and (prochaine - jour).days <= reglage("anticipation_preventif_jours")
    return {
        "statut": statut,
        "echeance": a_faire.isoformat(),  # échéance à réaliser (ou la prochaine si tout est fait)
        "echeance_courante": courante.isoformat() if courante else None,
        "prochaine_echeance": prochaine.isoformat(),
        "anticipable": anticipable,
    }


FENETRE_REALISATIONS = 800  # jours : assez pour les tâches annuelles et les reports de vacances


def realisations_par_tache(taches, jour=None):
    """Réalisations récentes de plusieurs tâches, lues en UNE requête (au lieu d'une par tâche) :
    {tache_id: [réalisations, de la plus récente à la plus ancienne]}."""
    ids = [t.id for t in taches]
    resultat = {i: [] for i in ids}
    if not ids:
        return resultat
    depuis = (jour or aujourdhui()) - timedelta(days=FENETRE_REALISATIONS)
    for r in (
        RealisationPreventive.query.options(joinedload(RealisationPreventive.par), joinedload(RealisationPreventive.bon))
        .filter(RealisationPreventive.echeance >= depuis)
        .order_by(RealisationPreventive.echeance.desc())
    ):
        if r.tache_id in resultat:
            resultat[r.tache_id].append(r)
    return resultat


def avec_machine(requete):
    """Charge la machine et l'atelier de chaque tâche dans la même requête (la requête joint déjà Machine)."""
    return requete.options(contains_eager(TachePreventive.machine).joinedload(Machine.atelier))


def tache_dict(tache, details=False, jour=None, vacances=None, realisations=None, bons=None):
    """bons : bons de préventif ouverts déjà lus, {(tache_id, echeance): bon} (sinon lus pour cette tâche)."""
    vacances = semaines_de_vacances() if vacances is None else vacances
    if realisations is None:
        realisations = tache.realisations.order_by(RealisationPreventive.echeance.desc()).all()
    d = {
        "id": tache.id,
        "machine": {
            "id": tache.machine.id,
            "repere": tache.machine.repere,
            "designation": tache.machine.designation,
            "atelier_id": tache.machine.atelier_id,
            "atelier": tache.machine.atelier.nom,
        },
        "nom": tache.nom,
        "niveau": tache.niveau,
        "type_preventif": tache.type_preventif,
        "periodicite": tache.periodicite,
        "periodicite_libelle": ref.PERIODICITES[tache.periodicite][0],
        "date_debut": tache.date_debut.isoformat(),
        "temps_estime_min": tache.temps_estime_min,
        "actif": tache.actif,
        "derniere_realisation": realisations[0].to_dict() if realisations else None,
        **etat(tache, jour, {r.echeance for r in realisations}, vacances),
    }
    # L'échéance affichée est-elle déjà confiée ? (seulement cette échéance : la suivante sera de nouveau à prendre)
    if bons is None:
        bons = bons_preventifs_ouverts([tache.id])
    bon = bons.get((tache.id, date.fromisoformat(d["echeance"]))) if d.get("echeance") else None
    d["bon_preventif"] = {"id": bon.id, "techniciens": [{"id": t.id, "nom": t.nom} for t in bon.techniciens]} if bon else None
    if details:
        d.update(
            consignes=tache.consignes,
            operations=tache.operations,
            moyens=tache.moyens,
            redacteur=tache.redacteur,
            date_redaction=tache.date_redaction.isoformat() if tache.date_redaction else None,
            pictogrammes=[p.to_dict() for p in tache.pictogrammes],
            photos=[p.to_dict() for p in tache.photos],
            pieces_prevues=[p.to_dict() for p in tache.pieces_prevues],
            historique=_historique(tache, {reporter(r.echeance, vacances): r for r in realisations}, jour or aujourdhui(), vacances),
        )
    return d


def bons_preventifs_ouverts(tache_ids):
    if not tache_ids:
        return {}
    bons = BonPreventif.query.filter(BonPreventif.tache_id.in_(tache_ids), BonPreventif.termine_le.is_(None))
    return {(b.tache_id, b.echeance): b for b in bons}


def _historique(tache, realisations, jour, vacances, nombre=12):
    """Les dernières échéances passées (après report des vacances) : réalisées ou non réalisées."""
    lignes = []
    k = indice_courant(tache, jour)
    while k >= 0 and len(lignes) < nombre:
        echeance = echeance_effective(tache, k, vacances)
        k -= 1
        if echeance > jour or (lignes and lignes[-1]["echeance"] == echeance.isoformat()):
            continue
        r = realisations.get(echeance)
        lignes.append({"echeance": echeance.isoformat(), "realisation": r.to_dict() if r else None, "en_cours": not lignes})
    return lignes


# ---------- Droits ----------

def _peut_voir(tache):
    """Opérateur : modes opératoires de niveaux 1-2 seulement (ROL-02)."""
    return current_user.role in EQUIPE or tache.niveau <= 2


def _peut_realiser(tache):
    """L'opérateur (compte unique, il choisit son atelier) coche les niveaux 1-2 de n'importe quel atelier."""
    if current_user.role not in EQUIPE and tache.niveau > 2:
        return "Les tâches de niveau 3 et plus sont réalisées par les techniciens."
    return None


def _tache_ou_404(tache_id):
    tache = db.session.get(TachePreventive, tache_id)
    if not tache or not _peut_voir(tache):
        return None, erreur("Tâche préventive introuvable.", 404)
    return tache, None


# ---------- Saisie ----------

def _pieces_prevues(lignes):
    """Pièces prévues (n° 6) : [{piece_id, quantite}] → [(piece_id, quantité)] vérifiées."""
    if not isinstance(lignes, list):
        raise Invalide("Liste de pièces invalide.")
    resultat = {}
    for l in lignes:
        try:
            piece_id, quantite = int(l.get("piece_id")), float(l.get("quantite"))
        except (AttributeError, TypeError, ValueError):
            raise Invalide("Chaque pièce prévue doit avoir une quantité.")
        if not 0 < quantite <= 10000:
            raise Invalide("La quantité d'une pièce prévue doit être positive.")
        resultat[piece_id] = quantite
    if resultat and Piece.query.filter(Piece.id.in_(resultat)).count() != len(resultat):
        raise Invalide("Une des pièces prévues n'existe plus.")
    return list(resultat.items())


def _appliquer(tache, donnees):
    try:
        machine = db.session.get(Machine, int(donnees.get("machine_id")))
    except (TypeError, ValueError):
        machine = None
    if not machine:
        raise Invalide("Choisissez la machine.")
    nom = str(donnees.get("nom") or "").strip()
    if not nom:
        raise Invalide("Le nom de la tâche est obligatoire.")
    try:
        niveau = int(donnees.get("niveau"))
    except (TypeError, ValueError):
        niveau = 0
    if niveau not in ref.NIVEAUX_MAINTENANCE:
        raise Invalide("Choisissez le niveau de maintenance (1 à 5).")
    if donnees.get("type_preventif") not in liste("types_preventif"):
        raise Invalide("Choisissez le type de maintenance préventive.")
    if donnees.get("periodicite") not in ref.PERIODICITES:
        raise Invalide("Choisissez la périodicité.")
    try:
        date_debut = date.fromisoformat(str(donnees.get("date_debut")))
    except ValueError:
        raise Invalide("Indiquez la date de la première échéance.")
    temps = donnees.get("temps_estime_min")
    try:
        temps = int(temps) if temps not in (None, "") else None
    except (TypeError, ValueError):
        raise Invalide("Le temps estimé est un nombre de minutes.")
    if temps is not None and not 0 < temps <= 10000:
        raise Invalide("Le temps estimé doit être compris entre 1 et 10 000 minutes.")
    ids = donnees.get("pictogrammes") or []
    pictogrammes = Pictogramme.query.filter(Pictogramme.id.in_(ids)).all() if ids else []
    pieces = _pieces_prevues(donnees["pieces"]) if "pieces" in donnees else None

    texte = lambda cle: (str(donnees.get(cle) or "").strip() or None)
    tache.machine = machine
    tache.nom = nom[:160]
    tache.niveau = niveau
    tache.type_preventif = donnees["type_preventif"]
    tache.periodicite = donnees["periodicite"]
    tache.date_debut = date_debut
    tache.temps_estime_min = temps
    tache.consignes = texte("consignes")
    tache.operations = texte("operations")
    tache.moyens = texte("moyens")
    tache.pictogrammes = pictogrammes
    if pieces is not None:  # absent (ex. import d'une fiche) : les pièces prévues ne changent pas
        tache.pieces_prevues = [TachePiece(piece_id=piece_id, quantite=quantite) for piece_id, quantite in pieces]
    if "actif" in donnees:
        tache.actif = bool(donnees["actif"])
    # Rédacteur et date de rédaction : mis à jour à chaque modification de la fiche
    tache.redacteur = current_user.nom
    tache.date_redaction = aujourdhui()


# ---------- Routes : tâches ----------

def _filtrer(requete):
    args = request.args
    if args.get("machine_id", type=int):
        requete = requete.filter(TachePreventive.machine_id == args.get("machine_id", type=int))
    if args.get("atelier_id", type=int):
        requete = requete.filter(TachePreventive.machine.has(Machine.atelier_id == args.get("atelier_id", type=int)))
    if args.get("niveau_max", type=int):
        requete = requete.filter(TachePreventive.niveau <= args.get("niveau_max", type=int))
    if args.get("inactives") != "1":
        requete = requete.filter(TachePreventive.actif.is_(True))
    return requete


@bp.get("/preventif/taches")
@login_required
def liste_taches():
    requete = _filtrer(TachePreventive.query.join(Machine))
    if current_user.role not in EQUIPE:
        requete = requete.filter(TachePreventive.niveau <= 2)
    taches = avec_machine(requete).order_by(Machine.repere, TachePreventive.niveau, TachePreventive.nom).all()
    jour, vacances = aujourdhui(), semaines_de_vacances()
    faites = realisations_par_tache(taches, jour)
    bons = bons_preventifs_ouverts([t.id for t in taches])
    return jsonify(taches=[tache_dict(t, jour=jour, vacances=vacances, realisations=faites[t.id], bons=bons) for t in taches])


@bp.get("/preventif/taches/<int:tache_id>")
@login_required
def detail_tache(tache_id):
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    return jsonify(tache=tache_dict(tache, details=True))


@bp.post("/preventif/taches")
@role_required(*EQUIPE)
def creer_tache():
    tache = TachePreventive()
    try:
        _appliquer(tache, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    db.session.add(tache)
    db.session.flush()
    journaliser("creation", tache, f"{tache.machine.repere} — {tache.nom}")
    db.session.commit()
    return jsonify(tache=tache_dict(tache, details=True)), 201


@bp.put("/preventif/taches/<int:tache_id>")
@role_required(*EQUIPE)
def modifier_tache(tache_id):
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    try:
        _appliquer(tache, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    journaliser("modification", tache, f"{tache.machine.repere} — {tache.nom}")
    db.session.commit()
    return jsonify(tache=tache_dict(tache, details=True))


@bp.delete("/preventif/taches/<int:tache_id>")
@role_required("admin")
def supprimer_tache(tache_id):
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    if tache.realisations.count() or BonIntervention.query.filter_by(tache_id=tache.id).count() or BonPreventif.query.filter_by(tache_id=tache.id).count():
        return erreur("Cette tâche a déjà été réalisée : désactivez-la plutôt que de la supprimer.", 409)
    for photo in tache.photos:
        (_dossier_photos() / photo.fichier).unlink(missing_ok=True)
    journaliser("suppression", tache, f"{tache.machine.repere} — {tache.nom}")
    db.session.delete(tache)
    db.session.commit()
    return jsonify(ok=True)


# ---------- Réalisation (cochage) ----------

@bp.post("/preventif/taches/<int:tache_id>/realiser")
@login_required
def realiser(tache_id):
    """Coche l'échéance en cours ; ou la suivante, si elle arrive dans les 7 jours (anticipation)."""
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    refus = _peut_realiser(tache)
    if refus:
        return erreur(refus, 403)
    e = etat(tache)
    if e["statut"] in ("a_faire", "en_retard") or e["anticipable"]:
        echeance = date.fromisoformat(e["echeance"])
    else:
        return erreur(f"Déjà réalisée : prochaine échéance le {date.fromisoformat(e['prochaine_echeance']):%d/%m/%Y}.", 409)
    bon = BonPreventif.query.filter_by(tache_id=tache.id, echeance=echeance, termine_le=None).first()
    if bon and bon.techniciens and current_user.role != "admin" and not any(t.id == current_user.id for t in bon.techniciens):
        return erreur(f"Cette échéance est confiée à {', '.join(t.nom for t in bon.techniciens)} : eux seuls (ou un enseignant) peuvent la valider.", 403)
    refus = _sortir_pieces_prevues(tache, echeance, request.get_json(silent=True) or {})
    if refus:
        db.session.rollback()
        return refus
    db.session.add(RealisationPreventive(tache=tache, echeance=echeance, par_id=current_user.id))
    _clore_bon_preventif(tache.id, echeance)
    journaliser("realisation", tache, f"Échéance du {echeance:%d/%m/%Y}")
    db.session.commit()
    return jsonify(tache=tache_dict(tache)), 201


def _sortir_pieces_prevues(tache, echeance, donnees):
    """« Fait » d'une tâche qui a des pièces prévues (n° 6, choix de Simon) : elles sortent du stock, avec les
    quantités corrigées par l'élève (?pieces=[{piece_id, quantite}]). Stock insuffisant : refus (409, liste des
    manquantes), sauf si l'on force (?forcer) : la tâche est validée mais la pièce manquante ne sort pas du stock.
    Renvoie une réponse d'erreur, ou None si l'on peut continuer."""
    from .stock import mouvementer

    if not tache.pieces_prevues:
        return None
    prevues = {p.piece_id: p for p in tache.pieces_prevues}
    quantites = {pid: p.quantite for pid, p in prevues.items()}
    if donnees.get("pieces") is not None:
        if not isinstance(donnees["pieces"], list):
            return erreur("Liste de pièces invalide.", 400)
        quantites = {}
        for l in donnees["pieces"]:
            try:
                piece_id, quantite = int(l.get("piece_id")), float(l.get("quantite"))
            except (AttributeError, TypeError, ValueError):
                return erreur("Quantité de pièce invalide.", 400)
            if piece_id in prevues and quantite > 0:
                quantites[piece_id] = quantite
    manquantes = {pid for pid, q in quantites.items() if prevues[pid].piece.quantite < q}
    if manquantes and not donnees.get("forcer"):
        reponse = jsonify(
            error="Stock insuffisant pour certaines pièces prévues.",
            manquantes=[
                {"piece_id": pid, "designation": prevues[pid].piece.designation, "reference": prevues[pid].piece.reference,
                 "demande": quantites[pid], "stock": prevues[pid].piece.quantite}
                for pid in sorted(manquantes)
            ],
        )
        return reponse, 409
    motif = f"Préventif : {tache.machine.repere} — {tache.nom} (échéance du {echeance:%d/%m/%Y})"
    for pid, q in quantites.items():
        if pid not in manquantes:
            mouvementer(prevues[pid].piece, "sortie", -q, motif)
    if manquantes:
        noms = ", ".join(prevues[pid].piece.designation for pid in sorted(manquantes))
        journaliser("realisation_forcee", tache, f"Échéance du {echeance:%d/%m/%Y} validée sans sortir du stock : {noms}")
    return None


def _clore_bon_preventif(tache_id, echeance):
    bon = BonPreventif.query.filter_by(tache_id=tache_id, echeance=echeance, termine_le=None).first()
    if bon:
        bon.termine_le, bon.termine_par_id = maintenant(), current_user.id


@bp.delete("/preventif/taches/<int:tache_id>/realiser/<echeance>")
@login_required
def annuler_realisation(tache_id, echeance):
    """Décoche une échéance (erreur de saisie)."""
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    refus = _peut_realiser(tache)
    if refus:
        return erreur(refus, 403)
    try:
        jour = date.fromisoformat(echeance)
    except ValueError:
        return erreur("Échéance invalide.", 400)
    vacances = semaines_de_vacances()
    r = next((x for x in tache.realisations if reporter(x.echeance, vacances) == jour), None)
    if not r:
        return erreur("Cette échéance n'est pas cochée.", 404)
    if r.bon_id:
        return erreur("Cette échéance a été validée par un bon d'intervention : rouvrez plutôt le bon.", 409)
    if current_user.role not in EQUIPE and r.par_id != current_user.id:
        return erreur("Seul le compte qui a coché la tâche (ou un technicien) peut la décocher.", 403)
    db.session.delete(r)
    bon = BonPreventif.query.filter_by(tache_id=tache.id, echeance=r.echeance).first()
    if bon:  # le bon de préventif redevient à faire
        bon.termine_le = bon.termine_par_id = None
    journaliser("annulation_realisation", tache, f"Échéance du {jour:%d/%m/%Y}")
    db.session.commit()
    return jsonify(tache=tache_dict(tache))


def valider_par_bon(bon):
    """Bon d'une tâche confiée terminé : l'échéance est cochée automatiquement (choix 5A)."""
    if not bon.tache_id or not bon.echeance:
        return
    existante = RealisationPreventive.query.filter_by(tache_id=bon.tache_id, echeance=bon.echeance).first()
    if not existante:
        db.session.add(
            RealisationPreventive(tache_id=bon.tache_id, echeance=bon.echeance, par_id=current_user.id, bon_id=bon.id)
        )


# ---------- To-Do et planning ----------

@bp.get("/preventif/a-faire")
@login_required
def a_faire():
    """To-Do : tâches à faire ou en retard, et celles qui arrivent dans les 7 jours (PRV-06, PRV-07).
    Opérateur : niveaux 1-2 de l'atelier choisi (?atelier_id=), sinon de l'atelier proposé par défaut pour son compte."""
    requete = TachePreventive.query.join(Machine).filter(TachePreventive.actif.is_(True), Machine.hors_service.is_(False))
    if current_user.role not in EQUIPE:
        atelier_id = request.args.get("atelier_id", type=int) or current_user.atelier_id
        if not atelier_id:
            return jsonify(taches=[], atelier_id=None, message="Choisissez votre atelier.")
        requete = requete.filter(TachePreventive.niveau <= 2, Machine.atelier_id == atelier_id)
    else:
        atelier_id = None
        requete = _filtrer(requete)
        # ?niveaux=1,3 : niveaux de maintenance choisis ; ?mes=1 : tâches confiées à l'élève (bon d'intervention non terminé)
        niveaux = [int(n) for n in (request.args.get("niveaux") or "").split(",") if n.strip().isdigit()]
        if niveaux:
            requete = requete.filter(TachePreventive.niveau.in_(niveaux))
        if request.args.get("mes") == "1":
            confiees = db.session.query(BonPreventif.tache_id).filter(
                BonPreventif.termine_le.is_(None), BonPreventif.techniciens.any(Utilisateur.id == current_user.id)
            )
            requete = requete.filter(TachePreventive.id.in_(confiees))
    jour = aujourdhui()
    vacances = semaines_de_vacances()
    resultat = []
    taches = avec_machine(requete).order_by(Machine.repere, TachePreventive.nom).all()
    faites = realisations_par_tache(taches, jour)
    bons = bons_preventifs_ouverts([t.id for t in taches])
    for tache in taches:
        d = tache_dict(tache, jour=jour, vacances=vacances, realisations=faites[tache.id], bons=bons)
        if d["statut"] in ("a_faire", "en_retard") or d["anticipable"]:
            resultat.append(d)
    if current_user.role in EQUIPE:
        # Élèves et enseignants : par niveau de maintenance, puis par date d'exécution (choix de Simon)
        resultat.sort(key=lambda d: (d["niveau"], d["echeance"]))
    else:
        ordre = {"en_retard": 0, "a_faire": 1}
        resultat.sort(key=lambda d: (ordre.get(d["statut"], 2), d["echeance"]))
    return jsonify(taches=resultat, atelier_id=atelier_id)


@bp.get("/public/tache-preventive/referentiels")
def referentiels_publics():
    """Outil « Proposer une tâche préventive » de la page de connexion (sans compte) : seulement les listes
    utiles au formulaire. Rien n'est enregistré : la fiche est imprimée ou exportée, puis importée par l'équipe."""
    return jsonify(
        types_preventif=liste("types_preventif"),
        periodicites={code: libelle for code, (libelle, _, _) in ref.PERIODICITES.items()},
        niveaux={str(n): libelle for n, libelle in ref.NIVEAUX_MAINTENANCE.items()},
        pictogrammes=[p.to_dict() for p in Pictogramme.query.filter(Pictogramme.code.isnot(None)).order_by(Pictogramme.categorie, Pictogramme.nom)],
    )


@bp.get("/preventif/retards")
@role_required(*EQUIPE)
def nombre_de_retards():
    """Nombre de tâches préventives en retard (bouton d'alerte de l'accueil, pastille du menu)."""
    jour, vacances = aujourdhui(), semaines_de_vacances()
    taches = avec_machine(
        TachePreventive.query.join(Machine).filter(TachePreventive.actif.is_(True), Machine.hors_service.is_(False))
    ).all()
    faites = realisations_par_tache(taches, jour)
    return jsonify(
        nombre=sum(
            1 for t in taches if etat(t, jour, {r.echeance for r in faites[t.id]}, vacances)["statut"] == "en_retard"
        )
    )


def taches_a_prendre(du, au):
    """Tâches de niveau 3-4 dont l'échéance tombe entre du et au (ou en retard), confiées à personne."""
    resultat = []
    vacances, jour = semaines_de_vacances(), aujourdhui()
    taches = avec_machine(
        TachePreventive.query.join(Machine).filter(
            TachePreventive.actif.is_(True), TachePreventive.niveau.in_((3, 4)), Machine.hors_service.is_(False)
        )
    ).all()
    faites = realisations_par_tache(taches, jour)
    # Échéances déjà confiées (bon de préventif, ou ancien bon d'intervention) : lues en une fois
    confiees = {(t, e) for t, e in db.session.query(BonPreventif.tache_id, BonPreventif.echeance)} | {
        (tache_id, echeance)
        for tache_id, echeance in db.session.query(BonIntervention.tache_id, BonIntervention.echeance).filter(BonIntervention.tache_id.isnot(None))
    }
    for t in taches:
        e = etat(t, jour, {r.echeance for r in faites[t.id]}, vacances)
        echeance = date.fromisoformat(e["echeance"])
        if e["statut"] not in ("a_faire", "en_retard") and not du <= echeance <= au:
            continue
        if e["statut"] == "fait" and echeance > au:
            continue
        if (t.id, echeance) not in confiees:
            resultat.append(tache_dict(t, jour=jour, vacances=vacances, realisations=faites[t.id], bons={}))  # pas encore confiée
    return resultat


@bp.get("/preventif/a-prendre")
@role_required(*EQUIPE)
def a_prendre():
    """Préventif de niveau 3-4 de la semaine en cours (ou en retard) à répartir : un bon est créé quand on le confie."""
    jour = aujourdhui()
    lundi = jour - timedelta(days=jour.weekday())
    return jsonify(taches=taches_a_prendre(lundi, lundi + timedelta(days=6)))


@bp.get("/preventif/planning")
@role_required(*EQUIPE)
def planning():
    """Échéances entre deux dates, pour la vue calendrier et la vue par machine (PRV-05)."""
    try:
        du = date.fromisoformat(request.args["du"])
        au = date.fromisoformat(request.args["au"])
    except (KeyError, ValueError):
        return erreur("Indiquez la période (du, au).", 400)
    if au < du or (au - du).days > 400:
        return erreur("Période invalide (400 jours au maximum).", 400)
    jour = aujourdhui()
    vacances = semaines_de_vacances()
    occurrences = []
    taches = avec_machine(_filtrer(TachePreventive.query.join(Machine))).all()
    # Réalisations des tâches, en une requête (toute la période affichée, plus la marge des reports)
    faites = {t.id: set() for t in taches}
    for tache_id, echeance in db.session.query(RealisationPreventive.tache_id, RealisationPreventive.echeance).filter(
        RealisationPreventive.echeance >= du - timedelta(days=FENETRE_REALISATIONS)
    ):
        if tache_id in faites:
            faites[tache_id].add(echeance)
    for tache in taches:
        realisees = {reporter(e, vacances) for e in faites[tache.id]}
        courante, _ = _courante_et_prochaine(tache, fin_de_semaine(jour), vacances)
        for echeance in echeances_entre(tache, du, au, vacances):
            if echeance in realisees:
                statut = "fait"
            elif courante and echeance < courante:
                statut = "non_realisee"
            elif echeance == courante:
                statut = "a_faire" if meme_semaine(echeance, jour) else "en_retard"
            else:
                statut = "a_venir"
            occurrences.append(
                {
                    "tache_id": tache.id,
                    "nom": tache.nom,
                    "niveau": tache.niveau,
                    "machine": {"id": tache.machine.id, "repere": tache.machine.repere, "designation": tache.machine.designation},
                    "echeance": echeance.isoformat(),
                    "statut": statut,
                    "temps_estime_min": tache.temps_estime_min,
                }
            )
    occurrences.sort(key=lambda o: (o["echeance"], o["machine"]["repere"]))
    return jsonify(occurrences=occurrences)


@bp.get("/machines/<int:machine_id>/preventif")
@login_required
def resume_machine(machine_id):
    """Pour l'onglet « Suivi » de la fiche machine : retards et prochaine échéance."""
    taches = TachePreventive.query.filter_by(machine_id=machine_id, actif=True).all()
    vacances = semaines_de_vacances()
    etats = [etat(t, vacances=vacances) for t in taches]
    a_venir = sorted(e["echeance"] for e in etats if e["statut"] in ("fait", "a_venir"))
    return jsonify(
        en_retard=sum(1 for e in etats if e["statut"] == "en_retard"),
        a_faire=sum(1 for e in etats if e["statut"] == "a_faire"),
        prochaine_echeance=a_venir[0] if a_venir else None,
    )


# ---------- Tâche confiée ponctuellement (niveaux 3-4) ----------

def _eleves(ids):
    if not isinstance(ids, list) or not all(isinstance(i, int) for i in ids):
        raise Invalide("Liste d'élèves invalide.")
    eleves = Utilisateur.query.filter(Utilisateur.id.in_(ids), Utilisateur.role == "technicien", Utilisateur.actif.is_(True)).all() if ids else []
    if len(eleves) != len(set(ids)):
        raise Invalide("Un des élèves choisis n'existe pas ou n'est plus actif.")
    return eleves


@bp.post("/preventif/taches/<int:tache_id>/confier")
@role_required(*EQUIPE)
def confier(tache_id):
    """Confie l'échéance à faire d'une tâche de niveau 3-4 à des élèves : crée un bon de préventif (PRV-08).
    Ce n'est pas un bon d'intervention : pas de compte-rendu, le mode opératoire et un bouton « Fait »."""
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    if tache.niveau not in (3, 4):
        return erreur("Seules les tâches de niveau 3 ou 4 se confient par un bon de préventif.", 400)
    echeance = date.fromisoformat(etat(tache)["echeance"])
    if BonPreventif.query.filter_by(tache_id=tache.id, echeance=echeance).first():
        return erreur(f"L'échéance du {echeance:%d/%m/%Y} de cette tâche est déjà confiée.", 409)
    try:
        eleves = _eleves((request.get_json(silent=True) or {}).get("ids") or [])
    except Invalide as e:
        return erreur(str(e), 400)
    bon = BonPreventif(tache=tache, echeance=echeance, cree_par_id=current_user.id, techniciens=eleves)
    db.session.add(bon)
    db.session.flush()
    journaliser("creation", bon, f"Préventif confié : {tache.machine.repere} — {tache.nom} ({echeance:%d/%m/%Y})")
    db.session.commit()
    return jsonify(bon=bon.to_dict()), 201


# ---------- Bons de préventif ----------

def _bon_preventif_ou_404(bon_id):
    bon = db.session.get(BonPreventif, bon_id)
    if not bon:
        return None, erreur("Bon de préventif introuvable.", 404)
    return bon, None


@bp.get("/preventif/bons")
@role_required(*EQUIPE)
def liste_bons_preventifs():
    """?ouverts=1 : pas encore faits ; ?technicien_id= : ceux d'un élève."""
    requete = BonPreventif.query
    if request.args.get("ouverts") == "1":
        requete = requete.filter(BonPreventif.termine_le.is_(None))
    technicien = request.args.get("technicien_id", type=int)
    if technicien:
        requete = requete.filter(BonPreventif.techniciens.any(Utilisateur.id == technicien))
    return jsonify(bons=[b.to_dict() for b in requete.order_by(BonPreventif.echeance).all()])


@bp.put("/preventif/bons/<int:bon_id>/techniciens")
@role_required(*EQUIPE)
def affecter_bon_preventif(bon_id):
    """Élèves du bon (glisser-déposer dans la répartition) ; liste vide : le bon revient « à attribuer »."""
    bon, err = _bon_preventif_ou_404(bon_id)
    if err:
        return err
    try:
        bon.techniciens = _eleves((request.get_json(silent=True) or {}).get("ids") or [])
    except Invalide as e:
        return erreur(str(e), 400)
    journaliser("affectation", bon, ", ".join(t.nom for t in bon.techniciens) or "aucun élève")
    db.session.commit()
    return jsonify(bon=bon.to_dict())


@bp.post("/preventif/bons/<int:bon_id>/fait")
@role_required(*EQUIPE)
def bon_preventif_fait(bon_id):
    """« Fait » en un clic (choix de Simon) : l'échéance est cochée et le bon clôturé.
    Réservé aux élèves du bon et à l'enseignant."""
    bon, err = _bon_preventif_ou_404(bon_id)
    if err:
        return err
    if current_user.role != "admin" and not any(t.id == current_user.id for t in bon.techniciens):
        return erreur("Seuls les élèves à qui ce préventif est confié (ou un enseignant) peuvent le valider.", 403)
    if bon.termine_le:
        return erreur("Ce préventif est déjà fait.", 409)
    if not RealisationPreventive.query.filter_by(tache_id=bon.tache_id, echeance=bon.echeance).first():
        refus = _sortir_pieces_prevues(bon.tache, bon.echeance, request.get_json(silent=True) or {})
        if refus:
            db.session.rollback()
            return refus
        db.session.add(RealisationPreventive(tache_id=bon.tache_id, echeance=bon.echeance, par_id=current_user.id))
    bon.termine_le, bon.termine_par_id = maintenant(), current_user.id
    journaliser("realisation", bon.tache, f"Préventif fait : échéance du {bon.echeance:%d/%m/%Y}")
    db.session.commit()
    return jsonify(bon=bon.to_dict())


# ---------- Photos du mode opératoire ----------

def _dossier_photos():
    dossier = current_app.config["UPLOAD_DIR"] / "preventif"
    dossier.mkdir(parents=True, exist_ok=True)
    return dossier


@bp.post("/preventif/taches/<int:tache_id>/photos")
@role_required(*EQUIPE)
def ajouter_photo(tache_id):
    tache, err = _tache_ou_404(tache_id)
    if err:
        return err
    if len(tache.photos) >= PHOTOS_MAX:
        return erreur(f"{PHOTOS_MAX} photos au maximum par mode opératoire (pour tenir sur une page A4).", 400)
    fichier = request.files.get("photo")
    extension = TYPES_PHOTO.get(fichier.mimetype) if fichier else None
    if not extension:
        return erreur("Envoyez une photo (JPEG, PNG ou WebP).", 400)
    nom = f"{tache.id}_{uuid.uuid4().hex[:12]}{extension}"
    fichier.save(_dossier_photos() / nom)
    photo = TachePhoto(tache=tache, fichier=nom, legende=(request.form.get("legende") or "").strip()[:160] or None)
    db.session.add(photo)
    journaliser("modification", tache, "Photo ajoutée")
    db.session.commit()
    return jsonify(tache=tache_dict(tache, details=True)), 201


@bp.get("/preventif/photos/<int:photo_id>")
@login_required
def voir_photo(photo_id):
    photo = db.session.get(TachePhoto, photo_id)
    if not photo or not _peut_voir(photo.tache):
        return erreur("Photo introuvable.", 404)
    return send_from_directory(_dossier_photos(), photo.fichier, max_age=3600)


@bp.delete("/preventif/photos/<int:photo_id>")
@role_required(*EQUIPE)
def supprimer_photo(photo_id):
    photo = db.session.get(TachePhoto, photo_id)
    if not photo:
        return erreur("Photo introuvable.", 404)
    tache = photo.tache
    (_dossier_photos() / photo.fichier).unlink(missing_ok=True)
    db.session.delete(photo)
    journaliser("modification", tache, "Photo supprimée")
    db.session.commit()
    return jsonify(tache=tache_dict(tache, details=True))


# ---------- Pictogrammes ----------

def _dossier_pictos():
    dossier = current_app.config["UPLOAD_DIR"] / "pictogrammes"
    dossier.mkdir(parents=True, exist_ok=True)
    return dossier


@bp.get("/pictogrammes")
@login_required
def liste_pictogrammes():
    return jsonify(pictogrammes=[p.to_dict() for p in Pictogramme.query.order_by(Pictogramme.categorie, Pictogramme.nom)])


@bp.get("/pictogrammes/<int:picto_id>/image")
@login_required
def image_pictogramme(picto_id):
    picto = db.session.get(Pictogramme, picto_id)
    if not picto or not picto.image:
        return erreur("Image introuvable.", 404)
    return send_from_directory(_dossier_pictos(), picto.image, max_age=86400)


@bp.post("/pictogrammes")
@role_required("admin")
def ajouter_pictogramme():
    nom = (request.form.get("nom") or "").strip()
    categorie = request.form.get("categorie")
    fichier = request.files.get("image")
    types = {**TYPES_PHOTO, "image/svg+xml": ".svg"}
    if not nom:
        return erreur("Donnez un nom au pictogramme.", 400)
    if categorie not in ("obligation", "danger", "interdiction"):
        return erreur("Choisissez la catégorie : obligation, danger ou interdiction.", 400)
    if not fichier or fichier.mimetype not in types:
        return erreur("Envoyez l'image du pictogramme (PNG, JPEG, WebP ou SVG).", 400)
    picto = Pictogramme(nom=nom[:120], categorie=categorie, image=f"picto_{uuid.uuid4().hex[:12]}{types[fichier.mimetype]}")
    fichier.save(_dossier_pictos() / picto.image)
    db.session.add(picto)
    db.session.flush()
    journaliser("creation", picto, picto.nom)
    db.session.commit()
    return jsonify(pictogramme=picto.to_dict()), 201


@bp.delete("/pictogrammes/<int:picto_id>")
@role_required("admin")
def supprimer_pictogramme(picto_id):
    picto = db.session.get(Pictogramme, picto_id)
    if not picto:
        return erreur("Pictogramme introuvable.", 404)
    if picto.code:
        return erreur("Les pictogrammes intégrés ne peuvent pas être supprimés.", 409)
    if TachePreventive.query.filter(TachePreventive.pictogrammes.any(Pictogramme.id == picto.id)).count():
        return erreur("Ce pictogramme est utilisé dans des modes opératoires.", 409)
    from .models import IpsMachine

    if IpsMachine.query.filter(IpsMachine.pictogrammes.any(Pictogramme.id == picto.id)).count():
        return erreur("Ce pictogramme est utilisé dans des fiches de sécurité (IPS) de machines.", 409)
    (_dossier_pictos() / picto.image).unlink(missing_ok=True)
    journaliser("suppression", picto, picto.nom)
    db.session.delete(picto)
    db.session.commit()
    return jsonify(ok=True)
