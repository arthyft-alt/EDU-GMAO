import csv
import io
from datetime import date

import pytest

from app import db
from app.cli import reset_annuel
from app.models import Atelier, Element, Fournisseur, Machine, Mouvement, PanierLigne, Piece, ZoneMagasin


@pytest.fixture()
def fournisseur(app):
    f = Fournisseur(nom="Roulements Express")
    db.session.add(f)
    db.session.commit()
    return f


@pytest.fixture()
def machine(app):
    m = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.filter_by(nom="01. Maintenance").one())
    db.session.add(m)
    db.session.commit()
    return m


def zone(code):
    """Zone du magasin A1, B3… (créée si besoin)."""
    etagere, etage = code[0], int(code[1:])
    z = ZoneMagasin.query.filter_by(etagere=etagere, etage=etage).first()
    if not z:
        z = ZoneMagasin(etagere=etagere, etage=etage, description=f"Zone {code}")
        db.session.add(z)
        db.session.commit()
    return z.id


def element(nom="23 Convertir"):
    return Element.query.filter_by(nom=nom).one()


def creer_piece(client, emplacement="A1", **autres):
    donnees = {"designation": "Roulement 6204 2RS", "categorie": "Mécanique", "prix_unitaire": "4,50", **autres}
    donnees["zone_id"] = zone(emplacement) if emplacement else None
    return client.post("/api/pieces", json=donnees)


# ---------- Fournisseurs ----------

def test_fournisseurs(client, connecter):
    connecter("tech")
    reponse = client.post("/api/fournisseurs", json={"nom": "Brico Pro", "site_web": "bricopro.fr", "adresse": "1 rue X\n18100 Vierzon"})
    assert reponse.status_code == 201
    f = reponse.get_json()["fournisseur"]
    assert f["site_web"] == "https://bricopro.fr"
    assert client.post("/api/fournisseurs", json={"nom": "brico pro"}).status_code == 400
    assert client.delete(f"/api/fournisseurs/{f['id']}").status_code == 403  # suppression : admin seulement
    client.post("/api/auth/logout")
    connecter("admin")
    assert client.delete(f"/api/fournisseurs/{f['id']}").status_code == 200


def test_operateur_n_a_pas_acces_au_stock(client, connecter):
    connecter("operateur")
    for url in ("/api/pieces", "/api/fournisseurs", "/api/panier", "/api/commandes", "/api/zones", "/api/mouvements"):
        assert client.get(url).status_code == 403, url


# ---------- Pièces ----------

def test_creation_reference_automatique_et_stock_initial(client, connecter, fournisseur):
    connecter("tech")
    p1 = creer_piece(client, fournisseur_id=fournisseur.id, quantite_initiale="10").get_json()["piece"]
    p2 = creer_piece(client, designation="Courroie SPZ 1000").get_json()["piece"]
    assert (p1["reference"], p2["reference"]) == ("00001", "00002")
    assert p1["emplacement"] == "A1"
    assert p1["quantite"] == 10 and p1["prix_unitaire"] == 4.5
    m = Mouvement.query.one()
    assert (m.type, m.quantite, m.motif) == ("inventaire", 10, "Stock initial")


@pytest.mark.parametrize("designation", ["roulement 6204 2rs", "  Roulement   6204 2RS ", "Roulément 6204 2RS"])
def test_anti_doublon_designation(client, connecter, designation):
    connecter("tech")
    creer_piece(client)
    reponse = creer_piece(client, designation=designation)
    assert reponse.status_code == 400
    assert "Doublon" in reponse.get_json()["error"]


def test_anti_doublon_reference_fournisseur(client, connecter, fournisseur):
    connecter("tech")
    creer_piece(client, fournisseur_id=fournisseur.id, reference_fournisseur="SKF-6204")
    reponse = creer_piece(client, designation="Autre nom", fournisseur_id=fournisseur.id, reference_fournisseur="skf-6204")
    assert reponse.status_code == 400


@pytest.mark.parametrize(
    "champs,message",
    [({"designation": ""}, "Désignation"), ({"categorie": "Bois"}, "catégorie"),
     ({"prix_unitaire": "-2"}, "Prix"), ({"fournisseur_id": 999}, "Fournisseur")],
)
def test_piece_invalide(client, connecter, champs, message):
    connecter("tech")
    reponse = creer_piece(client, **champs)
    assert reponse.status_code == 400
    assert message in reponse.get_json()["error"]
    assert Piece.query.count() == 0


def test_recherche_et_filtres(client, connecter, fournisseur, machine):
    connecter("tech")
    p = creer_piece(client, fournisseur_id=fournisseur.id).get_json()["piece"]
    creer_piece(client, designation="Fusible 2A", categorie="Électrique", emplacement="B3")
    client.put(f"/api/pieces/{p['id']}/affectations", json={"affectations": [{"machine_id": machine.id, "element_id": element().id}]})
    reference = lambda url: [x["reference"] for x in client.get(url).get_json()["pieces"]]
    assert reference("/api/pieces?q=6204") == ["00001"]
    assert reference("/api/pieces?q=00002") == ["00002"]
    assert reference("/api/pieces?categorie=Électrique") == ["00002"]
    assert reference(f"/api/pieces?zone_id={zone('B3')}") == ["00002"]
    assert reference("/api/pieces?q=b3") == ["00002"]  # recherche par emplacement
    assert reference("/api/pieces?etagere=b") == ["00002"]
    assert reference(f"/api/pieces?fournisseur_id={fournisseur.id}") == ["00001"]
    assert reference(f"/api/pieces?machine_id={machine.id}") == ["00001"]
    assert reference(f"/api/pieces?machine_id={machine.id}&element_id={element().id}") == ["00001"]
    assert reference(f"/api/pieces?machine_id={machine.id}&element_id={element('21 Alimenter').id}") == []


def test_code_douchette(client, connecter):
    connecter("tech")
    creer_piece(client)
    assert client.get("/api/pieces/code/00001").get_json()["piece"]["designation"] == "Roulement 6204 2RS"
    assert client.get("/api/pieces/code/1").status_code == 200
    assert client.get("/api/pieces/code/00099").status_code == 404
    assert client.get("/api/pieces/code/abc").status_code == 404


def test_affectations(client, connecter, machine):
    connecter("tech")
    p = creer_piece(client).get_json()["piece"]
    url = f"/api/pieces/{p['id']}/affectations"
    ligne = {"machine_id": machine.id, "element_id": element().id}
    affectations = client.put(url, json={"affectations": [ligne]}).get_json()["piece"]["affectations"]
    assert affectations[0]["machine_repere"] == "MAI-01" and affectations[0]["element"] == "23 Convertir"
    assert client.put(url, json={"affectations": [ligne, ligne]}).status_code == 400
    assert client.put(url, json={"affectations": [{"machine_id": machine.id}]}).status_code == 400


def test_suppression_piece(client, connecter):
    connecter("admin")
    vierge = creer_piece(client, designation="Pièce vierge").get_json()["piece"]
    utilisee = creer_piece(client, quantite_initiale="3").get_json()["piece"]
    assert client.delete(f"/api/pieces/{vierge['id']}").status_code == 200
    assert client.delete(f"/api/pieces/{utilisee['id']}").status_code == 409


def test_element_avec_pieces_non_supprimable(client, connecter, machine):
    connecter("admin")
    p = creer_piece(client).get_json()["piece"]
    client.put(f"/api/pieces/{p['id']}/affectations", json={"affectations": [{"machine_id": machine.id, "element_id": element().id}]})
    assert client.delete(f"/api/admin/elements/{element().id}").status_code == 409


# ---------- Mouvements et alertes ----------

def test_entree_sortie_inventaire(client, connecter):
    connecter("tech")
    p = creer_piece(client, stock_securite="2").get_json()["piece"]
    mouvement = lambda **d: client.post("/api/mouvements", json={"piece_id": p["id"], **d})
    assert mouvement(type="entree", quantite="5").get_json()["piece"]["quantite"] == 5
    assert mouvement(type="sortie", quantite="3", motif="Essai").get_json()["piece"]["en_alerte"] is True
    reponse = mouvement(type="sortie", quantite="4")
    assert reponse.status_code == 409 and "Stock insuffisant" in reponse.get_json()["error"]
    assert mouvement(type="inventaire", quantite="7").get_json()["piece"]["quantite"] == 7
    assert mouvement(type="sortie", quantite="0").status_code == 400
    assert mouvement(type="vol", quantite="1").status_code == 400
    historique = client.get(f"/api/mouvements?piece_id={p['id']}").get_json()["mouvements"]
    assert [(m["type"], m["quantite"], m["stock_apres"]) for m in historique] == [("inventaire", 5, 7), ("sortie", -3, 2), ("entree", 5, 5)]
    assert historique[0]["utilisateur"] == "Technicien 1 (démo)"
    assert [x["reference"] for x in client.get("/api/pieces?alerte=1").get_json()["pieces"]] == []


def test_zone_invalide_refusee_pour_une_piece(client, connecter):
    connecter("tech")
    reponse = client.post("/api/pieces", json={"designation": "X", "categorie": "Mécanique", "zone_id": 999})
    assert reponse.status_code == 400 and "Zone" in reponse.get_json()["error"]


def test_zones_du_magasin(client, connecter):
    connecter("tech")
    creer_piece(client, emplacement="B2")
    creer_piece(client, designation="Vis", emplacement="A10", stock_securite="1")
    creer_piece(client, designation="Écrou", emplacement="A2")
    creer_piece(client, designation="Sans place", emplacement=None)
    d = client.get("/api/zones").get_json()
    assert [z["code"] for z in d["zones"]] == ["A2", "A10", "B2"]  # rangées par étagère puis étage
    assert d["zones"][1]["nb_alertes"] == 1 and d["zones"][1]["description"] == "Zone A10"
    assert d["sans_emplacement"] == 1
    piece = client.get("/api/pieces?q=Vis").get_json()["pieces"][0]
    assert (piece["emplacement"], piece["zone_description"]) == ("A10", "Zone A10")


def test_gestion_des_zones_reservee_admin(client, connecter):
    connecter("tech")
    assert client.post("/api/zones", json={"etagere": "C", "etage": 1}).status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    z = client.post("/api/zones", json={"etagere": "c", "etage": "1", "description": "Courroies"}).get_json()["zone"]
    assert (z["code"], z["description"]) == ("C1", "Courroies")
    assert client.post("/api/zones", json={"etagere": "C", "etage": 1}).status_code == 400  # doublon
    assert client.post("/api/zones", json={"etagere": "CC", "etage": 1}).status_code == 400
    assert client.post("/api/zones", json={"etagere": "C", "etage": "haut"}).status_code == 400
    assert client.put(f"/api/zones/{z['id']}", json={"etagere": "C", "etage": 2, "description": "Courroies"}).get_json()["zone"]["code"] == "C2"
    creer_piece(client, emplacement=None, zone_id=None)
    piece = Piece.query.one()
    piece.zone_id = z["id"]
    db.session.commit()
    assert client.delete(f"/api/zones/{z['id']}").status_code == 409  # contient une pièce
    piece.zone_id = None
    db.session.commit()
    assert client.delete(f"/api/zones/{z['id']}").status_code == 200


# ---------- Panier et commandes ----------

def test_panier_commandes_reception(client, connecter, fournisseur):
    connecter("tech")
    autre = Fournisseur(nom="Électro Plus")
    db.session.add(autre)
    db.session.commit()
    p1 = creer_piece(client, fournisseur_id=fournisseur.id, quantite_min_commande="10").get_json()["piece"]
    p2 = creer_piece(client, designation="Fusible 2A", categorie="Électrique", fournisseur_id=autre.id, prix_unitaire="1").get_json()["piece"]
    # Ajout au panier : quantité minimale de commande par défaut, puis cumul
    l1 = client.post("/api/panier", json={"piece_id": p1["id"]}).get_json()["ligne"]
    assert l1["quantite"] == 10
    client.post("/api/panier", json={"piece_id": p1["id"], "quantite": "2"})
    l2 = client.post("/api/panier", json={"piece_id": p2["id"], "quantite": "5"}).get_json()["ligne"]
    assert [l["quantite"] for l in client.get("/api/panier").get_json()["lignes"]] == [12, 5]

    # Un bon de commande par fournisseur, panier vidé des lignes commandées
    commandes = client.post("/api/commandes", json={"lignes": [l1["id"], l2["id"]]}).get_json()["commandes"]
    assert len(commandes) == 2
    assert sorted(c["numero"][-3:] for c in commandes) == ["001", "002"]
    assert PanierLigne.query.count() == 0
    bc = next(c for c in commandes if c["fournisseur"]["nom"] == "Roulements Express")
    detail = client.get(f"/api/commandes/{bc['id']}").get_json()["commande"]
    assert detail["total"] == 54.0 and detail["lignes"][0]["designation"] == "Roulement 6204 2RS"
    assert client.get(f"/api/pieces/{p1['id']}").get_json()["piece"]["quantite_en_commande"] == 12

    # Réception partielle : les manquants restent en commande
    ligne_id = str(detail["lignes"][0]["id"])
    url = f"/api/commandes/{bc['id']}/reception"
    assert client.post(url, json={"lignes": {ligne_id: "20"}}).status_code == 400  # plus que commandé
    partielle = client.post(url, json={"lignes": {ligne_id: "8"}}).get_json()["commande"]
    assert partielle["statut"] == "partielle" and partielle["lignes"][0]["manquant"] == 4
    piece = client.get(f"/api/pieces/{p1['id']}").get_json()["piece"]
    assert piece["quantite"] == 8 and piece["quantite_en_commande"] == 4
    soldee = client.post(url, json={"lignes": {ligne_id: "4"}}).get_json()["commande"]
    assert soldee["statut"] == "recue" and soldee["recue_le"]
    assert client.post(url, json={"lignes": {ligne_id: "1"}}).status_code == 409


def test_commande_refusee_sans_fournisseur(client, connecter):
    connecter("tech")
    p = creer_piece(client).get_json()["piece"]
    ligne = client.post("/api/panier", json={"piece_id": p["id"]}).get_json()["ligne"]
    reponse = client.post("/api/commandes", json={"lignes": [ligne["id"]]})
    assert reponse.status_code == 400 and "fournisseur" in reponse.get_json()["error"]


def test_annulation_commande_admin(client, connecter, fournisseur):
    connecter("admin")
    p = creer_piece(client, fournisseur_id=fournisseur.id).get_json()["piece"]
    ligne = client.post("/api/panier", json={"piece_id": p["id"]}).get_json()["ligne"]
    bc = client.post("/api/commandes", json={"lignes": [ligne["id"]]}).get_json()["commandes"][0]
    assert client.post(f"/api/commandes/{bc['id']}/annuler").get_json()["commande"]["statut"] == "annulee"


# ---------- Composants des bons d'intervention ----------

def test_composants_du_bon_sortis_du_stock(client, connecter, machine):
    connecter("tech")
    p = creer_piece(client, quantite_initiale="10").get_json()["piece"]
    bon = client.post(
        "/api/bons", json={"machine_id": machine.id, "type_travail": "depannage", "description": "Bruit"}
    ).get_json()["bon"]
    url = f"/api/bons/{bon['id']}"
    stock = lambda: client.get(f"/api/pieces/{p['id']}").get_json()["piece"]["quantite"]

    resultat = client.put(url, json={"composants": [{"piece_id": p["id"], "quantite": "3"}, {"designation": "Achat local", "prix_unitaire": "12"}]})
    composants = resultat.get_json()["bon"]["composants"]
    assert composants[0]["designation"] == "Roulement 6204 2RS" and composants[0]["prix_unitaire"] == 4.5
    assert composants[1]["piece_id"] is None  # ligne libre : pas de stock
    assert stock() == 7
    client.put(url, json={"composants": [{"piece_id": p["id"], "quantite": "1"}]})  # 2 remis en stock
    assert stock() == 9
    reponse = client.put(url, json={"composants": [{"piece_id": p["id"], "quantite": "50"}]})
    assert reponse.status_code == 400 and "Stock insuffisant" in reponse.get_json()["error"]
    assert stock() == 9
    client.put(url, json={"composants": []})
    assert stock() == 10
    motifs = [m["motif"] for m in client.get(f"/api/mouvements?piece_id={p['id']}").get_json()["mouvements"]]
    assert motifs[0].startswith("Retour en stock (intervention BI-")


# ---------- 1er août et exports ----------

def test_reset_annuel_remet_les_seuils_a_zero(client, connecter):
    connecter("tech")
    creer_piece(client, stock_securite="2", quantite_min_commande="10")
    assert "seuils de stock remis à zéro sur 1 pièce" in reset_annuel(date(2027, 8, 1))
    piece = Piece.query.one()
    assert piece.stock_securite is None and piece.quantite_min_commande is None


def test_exports(client, connecter):
    connecter("tech")
    creer_piece(client, quantite_initiale="4")
    lignes = list(csv.reader(io.StringIO(client.get("/api/pieces/export.csv").data.decode("utf-8")[1:]), delimiter=";"))
    assert lignes[1][:5] == ["00001", "Roulement 6204 2RS", "Mécanique", "A1", "4"]
    assert lignes[1][8] == "18"  # valeur du stock : 4 × 4,50
    texte = client.get("/api/mouvements/export.csv").data.decode("utf-8")
    assert "Stock initial" in texte


# ---------- Articles hors magasin (retour de Simon du 28/10) ----------

def test_article_hors_magasin_bon_divers_sans_stock(client, connecter, fournisseur):
    connecter("tech")
    assert client.post("/api/panier/libre", json={"designation": "", "quantite": 1, "fournisseur": "X"}).status_code == 400
    assert client.post("/api/panier/libre", json={"designation": "Clé", "quantite": 1, "fournisseur": ""}).status_code == 400
    libre = client.post("/api/panier/libre", json={"designation": "Clé dynamométrique", "quantite": "2", "prix_unitaire": "45,90",
                                                    "lien": "outillage.fr/cle", "fournisseur": "Outillage Pro"}).get_json()["ligne"]
    assert libre["piece"] is None and libre["libre"]["lien"] == "https://outillage.fr/cle" and libre["libre"]["prix_unitaire"] == 45.9
    piece = creer_piece(client, fournisseur_id=fournisseur.id).get_json()["piece"]
    normale = client.post("/api/panier", json={"piece_id": piece["id"], "quantite": 3}).get_json()["ligne"]

    commandes = client.post("/api/commandes", json={"lignes": [libre["id"], normale["id"]]}).get_json()["commandes"]
    assert sorted(c["fournisseur"]["nom"] for c in commandes) == sorted([fournisseur.nom, "Divers (articles hors magasin)"])
    divers = next(c for c in commandes if c["fournisseur"]["id"] is None)
    detail = client.get(f"/api/commandes/{divers['id']}").get_json()["commande"]
    ligne = detail["lignes"][0]
    assert ligne["piece_id"] is None and ligne["fournisseur_libre"] == "Outillage Pro" and detail["total"] == 91.8
    # Réception : aucune entrée en stock pour un article hors magasin
    recue = client.post(f"/api/commandes/{divers['id']}/reception", json={"lignes": {str(ligne["id"]): 2}}).get_json()["commande"]
    assert recue["statut"] == "recue"


def test_suppression_d_un_bon_de_commande_par_l_admin(client, connecter, fournisseur):
    connecter("tech")
    piece = creer_piece(client, fournisseur_id=fournisseur.id).get_json()["piece"]
    lignes = [client.post("/api/panier", json={"piece_id": piece["id"], "quantite": 2}).get_json()["ligne"]["id"]]
    commande = client.post("/api/commandes", json={"lignes": lignes}).get_json()["commandes"][0]
    assert client.delete(f"/api/commandes/{commande['id']}").status_code == 403  # admin seulement
    connecter("admin")
    assert client.delete(f"/api/commandes/{commande['id']}").status_code == 200
    assert client.get(f"/api/commandes/{commande['id']}").status_code == 404

    # Un bon déjà (partiellement) reçu ne peut plus être supprimé : le stock garde sa trace
    lignes = [client.post("/api/panier", json={"piece_id": piece["id"], "quantite": 2}).get_json()["ligne"]["id"]]
    commande = client.post("/api/commandes", json={"lignes": lignes}).get_json()["commandes"][0]
    detail = client.get(f"/api/commandes/{commande['id']}").get_json()["commande"]
    client.post(f"/api/commandes/{commande['id']}/reception", json={"lignes": {str(detail["lignes"][0]["id"]): 1}})
    reponse = client.delete(f"/api/commandes/{commande['id']}")
    assert reponse.status_code == 409 and "déjà été reçus" in reponse.get_json()["error"]


def test_reperes_de_schema(client, connecter):
    from app.models import Atelier, Element, Machine, Piece, PieceMachine

    machine = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.first())
    contacteur = Piece(reference="00001", designation="Contacteur 9 A", categorie="Électrique")
    db.session.add_all([machine, contacteur])
    db.session.flush()
    element = Element.query.first()
    db.session.add(PieceMachine(piece_id=contacteur.id, machine_id=machine.id, element_id=element.id))
    db.session.commit()
    connecter("tech")
    # Saisie depuis la fiche machine : majuscules, sans doublon
    reponse = client.put(f"/api/pieces/{contacteur.id}/machines/{machine.id}/repere", json={"repere_schema": "km1; km2 KM1"})
    assert reponse.status_code == 200 and reponse.get_json()["lien"]["repere_schema"] == "KM1, KM2"
    # Recherche par repère, dans le stock et sur la machine
    trouve = client.get("/api/pieces?q=KM2").get_json()["pieces"]
    assert [p["reference"] for p in trouve] == ["00001"] and trouve[0]["reperes"] == [{"machine_id": machine.id, "machine_repere": "MAI-01", "repere_schema": "KM1, KM2"}]
    assert client.get(f"/api/pieces?machine_id={machine.id}&q=km1").get_json()["pieces"][0]["designation"] == "Contacteur 9 A"
    # Saisie depuis la fiche pièce (machines d'utilisation)
    reponse = client.put(f"/api/pieces/{contacteur.id}/affectations", json={"affectations": [{"machine_id": machine.id, "element_id": element.id, "repere_schema": "q1"}]})
    assert reponse.get_json()["piece"]["affectations"][0]["repere_schema"] == "Q1"
    assert client.put(f"/api/pieces/{contacteur.id}/machines/999/repere", json={"repere_schema": "X"}).status_code == 404
