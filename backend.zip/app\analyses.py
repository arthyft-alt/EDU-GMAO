"""Analyses graphiques (fonction n° 20 retenue par Simon le 29/10/2026, inspirée de la GMAO Accéder).

Une année scolaire (1er août → 31 juillet), découpée par mois ou par semaine. Huit séries de données :
correctif par période, par atelier, par machine ; activité des élèves ; arrêts machine ; préventif prévu
et réalisé ; part de chaque type de travail ; coûts (pièces consommées, commandes passées).
Mêmes règles que le tableau de bord : un bon compte à sa date de création (heure de Paris).
"""
from collections import defaultdict
from datetime import date, timedelta, timezone

from flask import Blueprint, jsonify, request
from flask_login import current_user
from sqlalchemy import func
from sqlalchemy.orm import joinedload, selectinload

from . import db, preventif
from .auth import erreur, role_required
from .calendrier import annee_scolaire, lundi, semaines_de_vacances
from .dates import PARIS, debut_jour_paris
from .models import (
    BonComposant,
    BonIntervention,
    Commande,
    Machine,
    Mouvement,
    Piece,
    RealisationPreventive,
    SaisieIndicateurs,
    TachePreventive,
    maintenant,
)
from .reglages import types_travaux

bp = Blueprint("analyses", __name__)

MOIS = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."]
CLASSEMENT = 10  # machines affichées dans les classements


def jour_paris(moment):
    """UTC sans fuseau → date à Paris."""
    return moment.replace(tzinfo=timezone.utc).astimezone(PARIS).date()


def _periodes(annee, pas, aujourdhui, vacances):
    """Découpage de l'année scolaire : [{debut, fin (exclue), libelle, vacances, futur}]."""
    debut_annee, fin_annee = date(annee, 8, 1), date(annee + 1, 8, 1)
    periodes = []
    if pas == "mois":
        for i in range(12):
            a, m = annee + (7 + i) // 12, (7 + i) % 12 + 1
            debut = date(a, m, 1)
            fin = date(a + (m == 12), m % 12 + 1, 1)
            periodes.append({"debut": debut, "fin": fin, "libelle": MOIS[m - 1], "vacances": False})
    else:
        semaine = lundi(debut_annee)
        while semaine < fin_annee:
            periodes.append(
                {"debut": semaine, "fin": semaine + timedelta(days=7), "libelle": f"S{semaine.isocalendar()[1]}", "vacances": semaine in vacances}
            )
            semaine += timedelta(days=7)
    for p in periodes:
        p["futur"] = p["debut"] > aujourdhui
    return periodes


def _indice(periodes):
    """Fonction jour → numéro de la période (ou None hors de l'année)."""
    def indice(jour):
        for i, p in enumerate(periodes):
            if p["debut"] <= jour < p["fin"]:
                return i
        return None

    return indice


def _classement(groupes, limite=None):
    lignes = [{"nom": nom, "nombre": v["nombre"], "heures": round(v["heures"], 2)} for nom, v in groupes.items()]
    lignes.sort(key=lambda l: (-l["heures"], -l["nombre"], l["nom"]))
    return lignes[:limite] if limite else lignes


def calculer(annee, pas, aujourdhui=None):
    aujourdhui = aujourdhui or preventif.aujourdhui()
    vacances = semaines_de_vacances()
    periodes = _periodes(annee, pas, aujourdhui, vacances)
    indice = _indice(periodes)
    n = len(periodes)
    du, au = periodes[0]["debut"], periodes[-1]["fin"]
    debut_utc, fin_utc = debut_jour_paris(du), debut_jour_paris(au)
    libelles_types = types_travaux()

    # ---------- Bons d'intervention de l'année (a, b, c, d, e, g) ----------
    bons = (
        BonIntervention.query.filter(BonIntervention.cree_le >= debut_utc, BonIntervention.cree_le < fin_utc)
        .options(joinedload(BonIntervention.machine).joinedload(Machine.atelier), selectinload(BonIntervention.techniciens))
        .all()
    )
    correctif_nombre, correctif_heures = [0] * n, [0.0] * n
    par_atelier, par_machine, par_eleve, arrets, types = (defaultdict(lambda: {"nombre": 0, "heures": 0.0}) for _ in range(5))
    for b in bons:
        i = indice(jour_paris(b.cree_le))
        if i is None:
            continue
        heures = b.temps_passe_h or 0
        machine = f"{b.machine.repere} — {b.machine.designation}"
        types[b.type_travail]["nombre"] += 1
        types[b.type_travail]["heures"] += heures
        for t in b.techniciens:
            par_eleve[t.nom]["nombre"] += 1
            par_eleve[t.nom]["heures"] += heures
        if b.duree_arret_h:
            arrets[machine]["nombre"] += 1
            arrets[machine]["heures"] += b.duree_arret_h
        if b.type_travail == "depannage":
            correctif_nombre[i] += 1
            correctif_heures[i] += heures
            par_atelier[b.machine.atelier.nom]["nombre"] += 1
            par_atelier[b.machine.atelier.nom]["heures"] += heures
            par_machine[machine]["nombre"] += 1
            par_machine[machine]["heures"] += heures

    # ---------- Préventif prévu / réalisé (f), échéance par échéance ----------
    faites = {
        (r.tache_id, preventif.reporter(r.echeance, vacances))
        for r in RealisationPreventive.query.filter(RealisationPreventive.echeance >= du - timedelta(days=100), RealisationPreventive.echeance < au)
    }
    # Le taux ne compte que les échéances déjà arrivées : celles de la fin du mois en cours ne le font pas baisser
    prevues, echues, realisees = [0] * n, [0] * n, [0] * n
    prevues_h, realisees_h = [0.0] * n, [0.0] * n
    for t in TachePreventive.query.filter(TachePreventive.actif.is_(True)).all():
        heures = (t.temps_estime_min or 0) / 60
        for e in preventif.echeances_entre(t, du, au - timedelta(days=1), vacances):
            i = indice(e)
            if i is None:
                continue
            prevues[i] += 1
            prevues_h[i] += heures
            echues[i] += e <= aujourdhui
            if (t.id, e) in faites:
                realisees[i] += 1
                realisees_h[i] += heures
    taux = [None if periodes[i]["futur"] or not echues[i] else min(round(realisees[i] / echues[i] * 100), 100) for i in range(n)]
    total_prevues, total_realisees = sum(echues), sum(realisees)

    # Part de chaque type de travail (g) : bons d'intervention + préventif du plan réalisé
    parts = [
        {"cle": cle, "nom": libelles_types.get(cle, cle), "nombre": v["nombre"], "heures": round(v["heures"], 2)}
        for cle, v in types.items()
    ]
    if total_realisees:
        parts.append({"cle": "plan", "nom": "Préventif du plan", "nombre": total_realisees, "heures": round(sum(realisees_h), 2)})
    parts.sort(key=lambda p: (-p["heures"], -p["nombre"]))

    # ---------- Coûts par période (h) ----------
    pieces, commandes = [0.0] * n, [0.0] * n
    sorties = (
        Mouvement.query.filter(Mouvement.type == "sortie", Mouvement.date >= debut_utc, Mouvement.date < fin_utc)
        .options(joinedload(Mouvement.piece))
        .all()
    )
    for m in sorties:
        i = indice(jour_paris(m.date))
        if i is not None:
            pieces[i] += abs(m.quantite) * (m.piece.prix_unitaire or 0)
    # Lignes libres des bons (pièce hors magasin) : pas de mouvement de stock, comptées à la date du bon
    libres = (
        BonComposant.query.join(BonIntervention)
        .filter(BonComposant.piece_id.is_(None), BonIntervention.cree_le >= debut_utc, BonIntervention.cree_le < fin_utc)
        .options(joinedload(BonComposant.bon))
        .all()
    )
    for c in libres:
        i = indice(jour_paris(c.bon.cree_le))
        if i is not None:
            pieces[i] += (c.quantite or 0) * (c.prix_unitaire or 0)
    for c in Commande.query.filter(Commande.statut != "annulee", Commande.cree_le >= debut_utc, Commande.cree_le < fin_utc).options(
        selectinload(Commande.lignes)
    ):
        i = indice(jour_paris(c.cree_le))
        if i is not None:
            commandes[i] += sum((l.quantite or 0) * (l.prix_unitaire or 0) for l in c.lignes)

    arrondi = lambda liste: [round(v, 2) for v in liste]  # noqa: E731
    return {
        "annee": annee,
        "libelle": f"{annee}-{annee + 1}",
        "pas": pas,
        "periodes": [
            {"debut": p["debut"].isoformat(), "libelle": p["libelle"], "vacances": p["vacances"], "futur": p["futur"]} for p in periodes
        ],
        "correctif": {"nombre": correctif_nombre, "heures": arrondi(correctif_heures)},
        "par_atelier": _classement(par_atelier),
        "par_machine": _classement(par_machine, CLASSEMENT),
        "par_eleve": _classement(par_eleve),
        "arrets": _classement(arrets, CLASSEMENT),
        "preventif": {
            "prevues": prevues,
            "realisees": [None if periodes[i]["futur"] else realisees[i] for i in range(n)],
            "prevues_h": arrondi(prevues_h),
            "realisees_h": [None if periodes[i]["futur"] else round(realisees_h[i], 2) for i in range(n)],
            "taux": taux,
            "taux_annee": round(total_realisees / total_prevues * 100) if total_prevues else None,
            "echeances_prevues": total_prevues,
            "echeances_realisees": total_realisees,
        },
        "types": parts,
        "couts": {"pieces": arrondi(pieces), "commandes": arrondi(commandes)},
    }


@bp.get("/analyses")
@role_required("admin", "technicien")
def analyses():
    """?annee=2026 (année scolaire 2026-2027, par défaut l'année en cours) ; ?pas=mois|semaine."""
    pas = request.args.get("pas", "mois")
    if pas not in ("mois", "semaine"):
        return erreur("Choisissez « mois » ou « semaine ».", 400)
    courante = annee_scolaire(preventif.aujourdhui())
    annee = request.args.get("annee", type=int) or courante
    if not 2000 <= annee <= courante + 1:
        return erreur("Année scolaire invalide.", 400)
    # Années proposées : de la plus ancienne donnée à l'année en cours
    premier = BonIntervention.query.order_by(BonIntervention.cree_le).first()
    depuis = min(annee_scolaire(jour_paris(premier.cree_le)), courante) if premier else courante
    return jsonify(**calculer(annee, pas), annees=list(range(courante, depuis - 1, -1)))


@bp.get("/analyses/stock")
@role_required("admin", "technicien")
def stock():
    """Valorisation du stock à l'instant (n° 15) : valeur totale, par catégorie et par étagère ; pièces « dormantes »
    (en stock, mais sans aucune sortie depuis ?mois=12, et créées avant cette date)."""
    mois = request.args.get("mois", 12, type=int)
    if mois not in (6, 12, 24):
        return erreur("Choisissez 6, 12 ou 24 mois.", 400)
    depuis = maintenant() - timedelta(days=round(mois * 30.44))
    pieces = Piece.query.options(joinedload(Piece.zone)).all()
    derniere_sortie = dict(
        db.session.query(Mouvement.piece_id, func.max(Mouvement.date)).filter(Mouvement.type == "sortie").group_by(Mouvement.piece_id).all()
    )
    par_categorie, par_etagere = defaultdict(lambda: {"nombre": 0, "valeur": 0.0}), defaultdict(lambda: {"nombre": 0, "valeur": 0.0})
    total = quantite = 0.0
    sans_prix = 0
    dormantes = []
    for p in pieces:
        if p.quantite <= 0:
            continue
        valeur = p.quantite * (p.prix_unitaire or 0)
        sans_prix += p.prix_unitaire is None
        total += valeur
        quantite += p.quantite
        par_categorie[p.categorie]["nombre"] += 1
        par_categorie[p.categorie]["valeur"] += valeur
        etagere = f"Étagère {p.zone.etagere}" if p.zone else "Sans emplacement"
        par_etagere[etagere]["nombre"] += 1
        par_etagere[etagere]["valeur"] += valeur
        sortie = derniere_sortie.get(p.id)
        if p.cree_le < depuis and (sortie is None or sortie < depuis):
            dormantes.append(
                {
                    "id": p.id,
                    "reference": p.reference,
                    "designation": p.designation,
                    "categorie": p.categorie,
                    "emplacement": p.zone.code if p.zone else None,
                    "quantite": p.quantite,
                    "valeur": round(valeur, 2),
                    "derniere_sortie": sortie.replace(tzinfo=timezone.utc).isoformat() if sortie else None,
                }
            )
    dormantes.sort(key=lambda d: (-d["valeur"], d["reference"]))
    classe = lambda groupes: sorted(  # noqa: E731
        ({"nom": nom, "nombre": v["nombre"], "valeur": round(v["valeur"], 2)} for nom, v in groupes.items()), key=lambda l: (-l["valeur"], l["nom"])
    )
    return jsonify(
        valeur_totale=round(total, 2),
        references=sum(v["nombre"] for v in par_categorie.values()),
        quantite_totale=quantite,
        sans_prix=sans_prix,
        par_categorie=classe(par_categorie),
        par_etagere=classe(par_etagere),
        mois=mois,
        dormantes=dormantes,
        valeur_dormante=round(sum(d["valeur"] for d in dormantes), 2),
    )


# ---------- Coûts dans le temps (demande de Simon du 29/10/2026, choix 1A) ----------

@bp.get("/analyses/couts")
@role_required("admin", "technicien")
def couts_dans_le_temps():
    """Coûts de l'année scolaire par mois ou semaine. ?source=auto : calcul automatique (enseignant seulement, il sert à
    la correction) ; ?source=saisies : coûts calculés et saisis par les élèves (onglet Saisie des élèves)."""
    from .indicateurs import parametre

    source = request.args.get("source", "saisies")
    if source not in ("auto", "saisies"):
        return erreur("Source inconnue.", 400)
    if source == "auto" and current_user.role != "admin":
        return erreur("Le calcul automatique des coûts est réservé à l'enseignant.", 403)
    pas = request.args.get("pas", "mois")
    if pas not in ("mois", "semaine"):
        return erreur("Choisissez « mois » ou « semaine ».", 400)
    courante = annee_scolaire(preventif.aujourdhui())
    annee = request.args.get("annee", type=int) or courante
    vacances = semaines_de_vacances()
    periodes = _periodes(annee, pas, preventif.aujourdhui(), vacances)
    indice = _indice(periodes)
    n = len(periodes)
    du, au = periodes[0]["debut"], periodes[-1]["fin"]
    natures = {cle: [0.0] * n for cle in ("pieces", "main_oeuvre", "immobilisation")}
    par_type = {cle: [0.0] * n for cle in ("correctif", "preventif", "amelioration")}
    par_machine, par_atelier = defaultdict(lambda: defaultdict(float)), defaultdict(lambda: defaultdict(float))

    def ajouter(i, machine, type_travail=None, pieces=0.0, mo=0.0, immo=0.0):
        for cle, v in (("pieces", pieces), ("main_oeuvre", mo), ("immobilisation", immo)):
            natures[cle][i] += v
            par_machine[f"{machine.repere} — {machine.designation}"][cle] += v
            par_atelier[machine.atelier.nom][cle] += v
        if type_travail:
            cle = {"depannage": "correctif", "preventif": "preventif"}.get(type_travail, "amelioration")
            par_type[cle][i] += pieces + mo + immo

    if source == "auto":
        taux_mo = parametre("taux_main_oeuvre")
        bons = (
            BonIntervention.query.filter(BonIntervention.cree_le >= debut_jour_paris(du), BonIntervention.cree_le < debut_jour_paris(au))
            .options(joinedload(BonIntervention.machine).joinedload(Machine.atelier), selectinload(BonIntervention.composants))
            .all()
        )
        for b in bons:
            i = indice(jour_paris(b.cree_le))
            if i is None:
                continue
            heures = b.temps_passe_h or 0
            ajouter(i, b.machine, b.type_travail, pieces=b.cout_composants, mo=heures * (b.effectif or 1) * taux_mo,
                    immo=heures * (b.machine.taux_horaire or 0) if b.machine_arretee else 0)
        # Préventif coché sans bon : temps estimé × taux de main-d'œuvre (même règle que l'onglet Coûts)
        for r in RealisationPreventive.query.filter(RealisationPreventive.echeance >= du, RealisationPreventive.echeance < au, RealisationPreventive.bon_id.is_(None)):
            i = indice(r.echeance)
            if i is not None:
                ajouter(i, r.tache.machine, "preventif", mo=(r.tache.temps_estime_min or 0) / 60 * taux_mo)
    else:
        for sa in SaisieIndicateurs.query.filter(SaisieIndicateurs.debut >= du, SaisieIndicateurs.debut < au):
            i = indice(sa.debut)
            if i is not None:
                ajouter(i, sa.machine, pieces=sa.cout_pieces or 0, mo=sa.cout_main_oeuvre or 0, immo=sa.cout_immobilisation or 0)

    def classement(groupes, limite=None):
        lignes = [{"nom": nom, **{k: round(v, 2) for k, v in c.items()}, "total": round(sum(c.values()), 2)} for nom, c in groupes.items()]
        lignes = [l for l in lignes if l["total"] > 0]
        lignes.sort(key=lambda l: (-l["total"], l["nom"]))
        return lignes[:limite] if limite else lignes

    arrondi = lambda liste: [round(v, 2) for v in liste]  # noqa: E731
    return jsonify(
        annee=annee,
        libelle=f"{annee}-{annee + 1}",
        pas=pas,
        source=source,
        periodes=[{"debut": p["debut"].isoformat(), "libelle": p["libelle"], "vacances": p["vacances"], "futur": p["futur"]} for p in periodes],
        natures={k: arrondi(v) for k, v in natures.items()},
        par_type={k: arrondi(v) for k, v in par_type.items()} if source == "auto" else None,
        par_machine=classement(par_machine, CLASSEMENT),
        par_atelier=classement(par_atelier),
        total=round(sum(sum(v) for v in natures.values()), 2),
    )


# ---------- Simulateur d'étude de coût : valeurs d'une machine réelle (choix 3A) ----------

@bp.get("/analyses/simulateur/machines/<int:machine_id>")
@role_required("admin", "technicien")
def donnees_simulateur(machine_id):
    """Valeurs de départ du simulateur, tirées des 12 derniers mois de la machine. Tout reste modifiable à l'écran."""
    from . import referentiels as ref
    from .indicateurs import parametre

    machine = db.session.get(Machine, machine_id)
    if not machine:
        return erreur("Machine introuvable.", 404)
    depuis = maintenant() - timedelta(days=365)
    pannes = BonIntervention.query.filter(
        BonIntervention.machine_id == machine.id, BonIntervention.type_travail == "depannage", BonIntervention.cree_le >= depuis
    ).all()
    moyenne = lambda valeurs: round(sum(valeurs) / len(valeurs), 2) if valeurs else None  # noqa: E731
    arrets = [b.duree_arret_h for b in pannes if b.duree_arret_h]
    # Préventif actuel de la machine : interventions par an et durée moyenne
    par_an = {code: (365 / jours if jours else 12 / mois) for code, (_, jours, mois) in ref.PERIODICITES.items()}
    taches = machine.taches_preventives.filter_by(actif=True).all()
    interventions = sum(par_an.get(t.periodicite, 0) for t in taches)
    duree = sum(par_an.get(t.periodicite, 0) * (t.temps_estime_min or 0) / 60 for t in taches)
    pieces_prev = sum(par_an.get(t.periodicite, 0) * sum(p.quantite * (p.piece.prix_unitaire or 0) for p in t.pieces_prevues) for t in taches)
    return jsonify(
        machine={"id": machine.id, "repere": machine.repere, "designation": machine.designation},
        taux_main_oeuvre=parametre("taux_main_oeuvre"),
        cout_arret_h=machine.taux_horaire,
        correctif={
            "pannes_par_an": len(pannes),
            "duree_reparation_h": moyenne([b.temps_passe_h for b in pannes if b.temps_passe_h]),
            "techniciens": moyenne([b.effectif for b in pannes if b.effectif]),
            "pieces_par_panne": moyenne([b.cout_composants for b in pannes]),
            "arret_par_panne_h": moyenne(arrets),
        },
        preventif={
            "interventions_par_an": round(interventions, 1) if taches else None,
            "duree_h": round(duree / interventions, 2) if interventions else None,
            "pieces_par_intervention": round(pieces_prev / interventions, 2) if interventions and pieces_prev else None,
        },
    )
