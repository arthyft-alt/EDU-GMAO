from datetime import date, datetime

import pytest

from app import db
from app.models import Atelier, BonIntervention, Chantier, ChantierAffectation, Machine, Projet, TacheProjet, Utilisateur

LUNDI = date(2026, 10, 5)
PENDANT = datetime(2026, 10, 7, 10)  # mercredi, en UTC
AVANT, APRES = datetime(2026, 9, 28, 10), datetime(2026, 10, 14, 10)


@pytest.fixture()
def semaine_chargee(app):
    tech = Utilisateur.query.filter_by(login="tech").one()
    machine = Machine(repere="M-01", designation="Tour", atelier=Atelier.query.first())
    bon = dict(machine=machine, type_travail="depannage", demandeur="x", description="Fuite")
    chantier = Chantier(titre="Rangement", cree_le=AVANT, statut="en_cours")
    projet = Projet(nom="GMAO", date_debut=LUNDI)
    db.session.add_all(
        [
            machine,
            BonIntervention(numero="BI-1", cree_le=AVANT, termine_le=PENDANT, statut="termine", techniciens=[tech],
                            travaux="Joint changé", cause="Usure", temps_passe_h=1.5, **bon),
            BonIntervention(numero="BI-2", cree_le=PENDANT, statut="en_cours", techniciens=[tech], **bon),
            BonIntervention(numero="BI-3", cree_le=AVANT, termine_le=AVANT, statut="termine", techniciens=[tech], **bon),  # fini avant
            BonIntervention(numero="BI-4", cree_le=PENDANT, statut="demande", **bon),  # confié à personne
            chantier,
            ChantierAffectation(chantier=chantier, utilisateur=tech, termine_le=PENDANT),
            projet,
            TacheProjet(projet=projet, nom="Inventaire", duree_semaines=1, techniciens=[tech]),
        ]
    )
    db.session.commit()
    return tech


def test_bilan_de_la_semaine(client, connecter, semaine_chargee):
    connecter("admin")
    d = client.get("/api/eleve/bilan-semaine?debut=2026-10-07").get_json()
    assert d["semaine"]["lundi"] == "2026-10-05" and d["semaine"]["numero"] == 41
    tech = next(e for e in d["eleves"] if e["eleve"]["nom"] == "Technicien 1 (démo)")
    titres = {a["titre"]: a for a in tech["activites"]}
    assert set(titres) == {"BI-1 · M-01 Tour", "BI-2 · M-01 Tour", "Rangement", "GMAO : Inventaire"}
    assert titres["BI-1 · M-01 Tour"]["commentaire"] == {"travaux": "Joint changé", "cause": "Usure"}
    assert titres["BI-2 · M-01 Tour"]["statut"] == "En cours" and not titres["BI-2 · M-01 Tour"]["realise"]
    assert (tech["realisees"], tech["affectees"], tech["taux"]) == (2, 4, 50)
    assert tech["temps_h"] == 1.5
    autre = next(e for e in d["eleves"] if e["eleve"]["nom"] == "Technicien 2 (démo)")
    assert autre["affectees"] == 0 and autre["taux"] is None
    assert d["classe"] == {"affectees": 4, "realisees": 2, "taux": 50, "pastille": "danger"}


def test_absences(client, connecter, semaine_chargee):
    connecter("admin")
    for i in range(5):
        jour = f"2026-10-0{5 + i}"
        assert client.put("/api/eleve/absences", json={"technicien_id": semaine_chargee.id, "jour": jour, "absent": True}).status_code == 200
    client.put("/api/eleve/absences", json={"technicien_id": semaine_chargee.id, "jour": "2026-10-05", "absent": True})  # pas de doublon
    tech = next(e for e in client.get("/api/eleve/bilan-semaine?debut=2026-10-05").get_json()["eleves"] if e["eleve"]["id"] == semaine_chargee.id)
    assert len(tech["absences"]) == 5 and tech["absent_toute_la_semaine"]
    client.put("/api/eleve/absences", json={"technicien_id": semaine_chargee.id, "jour": "2026-10-07", "absent": False})
    tech = next(e for e in client.get("/api/eleve/bilan-semaine?debut=2026-10-05").get_json()["eleves"] if e["eleve"]["id"] == semaine_chargee.id)
    assert tech["absences"] == ["2026-10-05", "2026-10-06", "2026-10-08", "2026-10-09"] and not tech["absent_toute_la_semaine"]


@pytest.mark.parametrize("login", ["tech", "operateur"])
def test_bilan_reserve_a_l_enseignant(client, connecter, login):
    connecter(login)
    assert client.get("/api/eleve/bilan-semaine").status_code == 403
    assert client.put("/api/eleve/absences", json={}).status_code == 403
