"""Export tableur de l'historique d'une machine (demande de Simon du 29/10/2026, choix 5A) : un classeur .xlsx
avec un onglet « Machine » (fiche), « Correctif » (tous les bons) et « Préventif » (chaque échéance passée :
faite ou non, par qui). Pour l'analyse dans un tableur (Pareto, MTBF à la main…).
"""
import io
from datetime import date, timezone

from flask import Blueprint, Response, request
from openpyxl import Workbook
from openpyxl.styles import Alignment, Font, PatternFill

from . import db, preventif
from . import referentiels as ref
from .auth import erreur, role_required
from .calendrier import semaines_de_vacances
from .dates import PARIS, debut_jour_paris, fin_jour_paris
from .models import BonIntervention, Machine
from .reglages import types_travaux

bp = Blueprint("export_machine", __name__)


def _paris(moment):
    """UTC sans fuseau → date et heure de Paris sans fuseau (Excel ne connaît pas les fuseaux)."""
    return moment.replace(tzinfo=timezone.utc).astimezone(PARIS).replace(tzinfo=None) if moment else None


def _feuille(classeur, titre, entetes, lignes, formats=None):
    f = classeur.create_sheet(titre)
    f.append(entetes)
    for cellule in f[1]:
        cellule.font, cellule.fill = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="17808E")
        cellule.alignment = Alignment(wrap_text=True, vertical="top")
    for ligne in lignes:
        f.append(ligne)
    for i, entete in enumerate(entetes, start=1):
        lettre = f.cell(1, i).column_letter
        f.column_dimensions[lettre].width = min(max(len(entete) + 2, 12), 45)
        for format_cellule, colonnes in (formats or {}).items():
            if entete in colonnes:
                for cellule in f[lettre][1:]:
                    cellule.number_format = format_cellule
    f.freeze_panes = "A2"
    f.auto_filter.ref = f.dimensions
    return f


@bp.get("/machines/<int:machine_id>/historique.xlsx")
@role_required("admin", "technicien")
def historique(machine_id):
    """?du=AAAA-MM-JJ&au=AAAA-MM-JJ (facultatifs : tout l'historique par défaut)."""
    machine = db.session.get(Machine, machine_id)
    if not machine:
        return erreur("Machine introuvable.", 404)
    try:
        du = date.fromisoformat(request.args["du"]) if request.args.get("du") else None
        au = date.fromisoformat(request.args["au"]) if request.args.get("au") else None
    except ValueError:
        return erreur("Date invalide.", 400)
    aujourdhui = preventif.aujourdhui()
    libelles_types = types_travaux()

    classeur = Workbook()
    fiche = classeur.active
    fiche.title = "Machine"
    for libelle, valeur in (
        ("Repère", machine.repere),
        ("Désignation", machine.designation),
        ("Atelier", machine.atelier.nom),
        ("Marque", machine.marque),
        ("Modèle", machine.modele),
        ("N° de série", machine.numero_serie),
        ("Année de mise en service", machine.annee_mise_en_service),
        ("Utilisation (h par semaine)", machine.utilisation_hebdo_h),
        ("Taux horaire d'immobilisation (€/h)", machine.taux_horaire),
        ("Période exportée", f"du {du:%d/%m/%Y}" if du else "depuis le début"),
        ("", f"au {au:%d/%m/%Y}" if au else f"au {aujourdhui:%d/%m/%Y}"),
        ("Exporté le", f"{aujourdhui:%d/%m/%Y}"),
    ):
        fiche.append([libelle, valeur])
    for cellule in fiche["A"]:
        cellule.font = Font(bold=True)
    fiche.column_dimensions["A"].width = 36
    fiche.column_dimensions["B"].width = 40

    # ---------- Correctif : tous les bons d'intervention de la machine ----------
    requete = BonIntervention.query.filter_by(machine_id=machine.id)
    if du:
        requete = requete.filter(BonIntervention.cree_le >= debut_jour_paris(du))
    if au:
        requete = requete.filter(BonIntervention.cree_le < fin_jour_paris(au))
    lignes = []
    for b in requete.order_by(BonIntervention.cree_le):
        lignes.append([
            b.numero,
            _paris(b.cree_le),
            libelles_types.get(b.type_travail, b.type_travail),
            ref.URGENCES.get(b.urgence, b.urgence),
            ref.STATUTS_BI.get(b.statut, b.statut),
            b.demandeur,
            b.description,
            ", ".join(t.nom for t in b.techniciens),
            b.travaux,
            b.element.nom if b.element else None,
            b.cause,
            b.temps_passe_h,
            b.effectif,
            "Oui" if b.machine_arretee else "Non",
            _paris(b.remise_en_service),
            b.duree_arret_h,
            _paris(b.termine_le),
            "; ".join(f"{c.quantite:g} × {c.designation}" for c in b.composants),
            b.cout_composants,
        ])
    _feuille(
        classeur,
        "Correctif",
        ["N° du bon", "Créé le", "Type de travail", "Urgence", "Statut", "Demandeur", "Constat", "Élèves", "Travaux réalisés",
         "Élément", "Cause", "Temps passé (h)", "Effectif", "Machine à l'arrêt", "Remise en service", "Durée d'arrêt (h)",
         "Terminé le", "Pièces", "Coût des pièces (€)"],
        lignes,
        {"dd/mm/yyyy hh:mm": {"Créé le", "Remise en service", "Terminé le"}, "0.00": {"Temps passé (h)", "Durée d'arrêt (h)"}, "#,##0.00 €": {"Coût des pièces (€)"}},
    )

    # ---------- Préventif : chaque échéance passée, faite ou non ----------
    vacances = semaines_de_vacances()
    lignes = []
    fin = min(au, aujourdhui) if au else aujourdhui
    for t in machine.taches_preventives.order_by("niveau", "nom"):
        faites = {preventif.reporter(r.echeance, vacances): r for r in t.realisations}
        debut = max(du, t.date_debut) if du else t.date_debut
        if debut > fin:
            continue
        for e in preventif.echeances_entre(t, debut, fin, vacances):
            r = faites.get(e)
            lignes.append([
                t.nom,
                t.niveau,
                t.type_preventif,
                ref.PERIODICITES[t.periodicite][0],
                e,
                "Oui" if r else ("En cours" if preventif.meme_semaine(e, aujourdhui) else "Non"),
                _paris(r.realise_le) if r else None,
                r.par.nom if r and r.par else None,
                (t.temps_estime_min or 0) / 60 if t.temps_estime_min else None,
            ])
    lignes.sort(key=lambda l: (l[4], l[0]))
    _feuille(
        classeur,
        "Préventif",
        ["Tâche", "Niveau", "Type", "Périodicité", "Échéance", "Réalisée", "Réalisée le", "Par", "Temps estimé (h)"],
        lignes,
        {"dd/mm/yyyy": {"Échéance"}, "dd/mm/yyyy hh:mm": {"Réalisée le"}, "0.00": {"Temps estimé (h)"}},
    )

    sortie = io.BytesIO()
    classeur.save(sortie)
    return Response(
        sortie.getvalue(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": f"attachment; filename=historique-{machine.repere}.xlsx"},
    )
