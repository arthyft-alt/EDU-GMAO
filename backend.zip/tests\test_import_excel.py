import io

import pytest
from openpyxl import Workbook, load_workbook

from app import db
from app.models import Atelier, Fournisseur, Machine, Mouvement, Piece, PieceMachine, ZoneMagasin


CODE = "1234"


def classeur(machines=(), pieces=()):
    wb = Workbook()
    m = wb.active
    m.title = "Machines"
    m.append(["Repère *", "Désignation *", "Atelier *", "Marque", "Année de mise en service"])
    for ligne in machines:
        m.append(list(ligne))
    p = wb.create_sheet("Pièces")
    p.append(["Désignation *", "Catégorie *", "Fournisseur", "Prix unitaire HT (€)", "Quantité en stock", "Emplacement", "Machine(s)", "Élément", "Repère schéma"])
    for ligne in pieces:
        p.append(list(ligne))
    sortie = io.BytesIO()
    wb.save(sortie)
    return sortie.getvalue()


def envoyer(client, url, contenu, code=None):
    return client.post(url, data={"fichier": (io.BytesIO(contenu), "import.xlsx")}, content_type="multipart/form-data",
                       headers={"X-Unlock-Password": code} if code else {})


@pytest.fixture()
def tour(app):
    tour = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.filter_by(nom="01. Maintenance").one())
    db.session.add_all([tour, Piece(reference="00007", designation="Courroie A42", categorie="Mécanique")])
    db.session.commit()
    return tour


def test_modele_telechargeable(client, connecter):
    connecter("tech")
    reponse = client.get("/api/import/modele.xlsx")
    assert reponse.status_code == 200
    wb = load_workbook(io.BytesIO(reponse.data))
    assert wb.sheetnames == ["Machines", "Pièces", "Aide"]
    assert wb["Machines"]["A1"].value == "Repère *" and wb["Pièces"]["A1"].value == "Désignation *"


def test_apercu_puis_import(client, connecter, tour):
    connecter("admin")
    contenu = classeur(
        machines=[("fon-04", "Four à induction", "03. Fonderie", "Inductotherm", 2015), ("MAI-02", "Fraiseuse", "1", None, None)],
        pieces=[
            ("Roulement 6204 2RS", "Mécanique", "Roulements Service", "6,5", 12, "a1", "MAI-01, FON-04", "Non défini", "m1"),
            ("Contacteur 9 A", "Électrique", None, 32, None, None, None, None, None),
        ],
    )
    apercu = envoyer(client, "/api/import/apercu", contenu).get_json()
    assert apercu["nb_erreurs"] == 0 and len(apercu["machines"]) == 2 and len(apercu["pieces"]) == 2
    assert "Nouveau fournisseur créé : Roulements Service." in apercu["pieces"][0]["avertissements"]
    assert Machine.query.count() == 1  # l'aperçu n'enregistre rien
    reponse = envoyer(client, "/api/import/valider", contenu)
    assert reponse.status_code == 201 and reponse.get_json() == {"machines": 2, "pieces": 2}
    four = Machine.query.filter_by(repere="FON-04").one()
    assert four.atelier.nom == "03. Fonderie" and four.annee_mise_en_service == 2015
    assert Machine.query.filter_by(repere="MAI-02").one().atelier.nom == "01. Maintenance"  # « 1 » suffit
    roulement = Piece.query.filter_by(designation="Roulement 6204 2RS").one()
    assert roulement.reference == "00008" and roulement.prix_unitaire == 6.5 and roulement.quantite == 12
    assert roulement.zone.code == "A1" and roulement.fournisseur.nom == "Roulements Service"
    assert sorted(a.machine.repere for a in roulement.affectations) == ["FON-04", "MAI-01"] and roulement.affectations[0].repere_schema == "M1"
    assert Mouvement.query.filter_by(piece_id=roulement.id).one().motif == "Stock initial (import Excel)"


def test_erreurs_rien_n_est_enregistre(client, connecter, tour):
    connecter("admin")
    contenu = classeur(
        machines=[("MAI-01", "Doublon", "01. Maintenance"), ("X-1", None, "Atelier inconnu")],
        pieces=[("courroie a42", "Mécanique"), ("Joint", "Inconnue", None, "abc", None, "12", "ZZZ-9")],
    )
    apercu = envoyer(client, "/api/import/apercu", contenu).get_json()
    erreurs = [e for l in apercu["machines"] + apercu["pieces"] for e in l["erreurs"]]
    assert any("existe déjà" in e for e in erreurs) and any("Atelier obligatoire" in e for e in erreurs)
    assert any("Cette pièce existe déjà" in e for e in erreurs) and any("Catégorie" in e for e in erreurs)
    assert any("ZZZ-9 introuvable" in e for e in erreurs) and any("Emplacement" in e for e in erreurs)
    reponse = envoyer(client, "/api/import/valider", contenu)
    assert reponse.status_code == 400 and Machine.query.count() == 1 and Piece.query.count() == 1
    assert Fournisseur.query.count() == 0 and ZoneMagasin.query.count() == 0


def test_droits_et_code_du_jour(client, connecter, tour):
    contenu = classeur(machines=[("MAI-09", "Perceuse", "01. Maintenance")])
    connecter("tech")
    assert envoyer(client, "/api/import/apercu", contenu).status_code == 403  # sans le code du jour
    assert envoyer(client, "/api/import/valider", contenu, CODE).status_code == 201
    client.post("/api/auth/logout")
    connecter("operateur")
    assert envoyer(client, "/api/import/apercu", contenu, CODE).status_code == 403
    assert client.post("/api/import/apercu", data={}, content_type="multipart/form-data").status_code in (400, 403)
