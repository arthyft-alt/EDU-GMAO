from datetime import date, timedelta

import pytest

from app import db
from app.cli import reset_annuel
from app.models import Chantier, Projet, Utilisateur

LUNDI = date(2026, 9, 7)  # rentrée


def tech(login):
    return Utilisateur.query.filter_by(login=login).one().id


# ---------- Calendrier ----------

def test_calendrier_par_semaines(client, connecter):
    connecter("tech")
    assert client.put("/api/calendrier/semaines", json={"lundis": ["2026-10-19"], "type": "vacances"}).status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    # Toussaint 2026 : semaines 43 et 44 ; une semaine d'apprentissage en novembre
    assert client.put("/api/calendrier/semaines", json={"lundis": ["2026-10-19", "2026-10-28"], "type": "vacances"}).status_code == 200
    client.put("/api/calendrier/semaines", json={"lundis": ["2026-11-09"], "type": "apprentissage"})
    cal = client.get("/api/calendrier?annee=2026").get_json()
    types = {s["lundi"]: (s["numero"], s["type"]) for s in cal["semaines"]}
    assert types["2026-10-19"] == (43, "vacances") and types["2026-10-26"] == (44, "vacances")
    assert types["2026-11-09"][1] == "apprentissage" and types["2026-09-07"][1] == "cours"
    assert cal["semaines"][0]["lundi"] == "2026-07-27"  # semaine du 1er août
    # Retour en semaine de cours
    client.put("/api/calendrier/semaines", json={"lundis": ["2026-11-09"], "type": "cours"})
    assert {s["lundi"]: s["type"] for s in client.get("/api/calendrier?annee=2026").get_json()["semaines"]}["2026-11-09"] == "cours"


def test_evenements(client, connecter):
    connecter("admin")
    e = client.post("/api/calendrier/evenements", json={"date": "2027-05-18", "titre": "Épreuve E4", "type": "examen"})
    assert e.status_code == 201
    assert client.post("/api/calendrier/evenements", json={"date": "2027-05-18", "titre": "", "type": "examen"}).status_code == 400
    assert client.get("/api/calendrier?annee=2026").get_json()["evenements"][0]["titre"] == "Épreuve E4"
    assert client.delete(f"/api/calendrier/evenements/{e.get_json()['evenement']['id']}").status_code == 200


# ---------- Chantiers ----------

def test_chantiers_crees_et_attribues_par_l_enseignant(client, connecter):
    connecter("tech")
    assert client.post("/api/chantiers", json={"titre": "Ranger le magasin"}).status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    c = client.post("/api/chantiers", json={"titre": "Ranger le magasin", "type": "organisation"}).get_json()["chantier"]
    assert c["statut"] == "a_faire" and c["techniciens"] == []
    affecte = client.put(f"/api/chantiers/{c['id']}/techniciens", json={"ids": [tech("tech")]}).get_json()["chantier"]
    assert [t["nom"] for t in affecte["techniciens"]] == ["Technicien 1 (démo)"]
    assert client.post("/api/chantiers", json={"titre": ""}).status_code == 400
    assert client.post("/api/chantiers", json={"titre": "x", "mode": "solo"}).status_code == 400


def test_chantier_en_equipe(client, connecter):
    connecter("admin")
    c = client.post("/api/chantiers", json={"titre": "Peindre les allées", "ids": [tech("tech"), tech("tech2")]}).get_json()["chantier"]
    client.post("/api/auth/logout")
    connecter("tech")
    assert client.post(f"/api/chantiers/{c['id']}/statut", json={"statut": "termine"}).get_json()["chantier"]["statut"] == "termine"
    assert client.put(f"/api/chantiers/{c['id']}/techniciens", json={"ids": []}).status_code == 200  # un élève peut attribuer (choix de Simon du 28/10)


def test_chantier_individuel(client, connecter):
    connecter("admin")
    c = client.post("/api/chantiers", json={"titre": "Fiche sécurité perceuse", "mode": "individuel", "ids": [tech("tech"), tech("tech2")]}).get_json()["chantier"]
    client.post("/api/auth/logout")
    connecter("tech")
    apres = client.post(f"/api/chantiers/{c['id']}/statut", json={"statut": "termine"}).get_json()["chantier"]
    assert apres["statut"] == "en_cours"  # tech2 n'a pas encore terminé
    client.post("/api/auth/logout")
    connecter("tech2")
    assert client.post(f"/api/chantiers/{c['id']}/statut", json={"statut": "termine"}).get_json()["chantier"]["statut"] == "termine"
    # Un élève qui n'est pas affecté ne peut pas agir
    client.post("/api/auth/logout")
    connecter("admin")
    autre = client.post("/api/chantiers", json={"titre": "Autre", "ids": [tech("tech")]}).get_json()["chantier"]
    client.post("/api/auth/logout")
    connecter("tech2")
    assert client.post(f"/api/chantiers/{autre['id']}/statut", json={"statut": "en_cours"}).status_code == 403


# ---------- Projets et Gantt ----------

@pytest.fixture()
def projet(client, connecter):
    connecter("admin")
    p = client.post("/api/projets", json={"nom": "Mise en place de la GMAO", "date_debut": "2026-09-07", "membres": [tech("tech"), tech("tech2")]})
    assert p.status_code == 201, p.get_json()
    return p.get_json()["projet"]


def ajouter(client, projet, **donnees):
    r = client.post(f"/api/projets/{projet['id']}/taches", json=donnees)
    assert r.status_code == 201, r.get_json()
    return r.get_json()["tache"]


def test_gantt_saute_vacances_et_apprentissage(client, connecter, projet):
    client.put("/api/calendrier/semaines", json={"lundis": ["2026-09-21"], "type": "apprentissage"})
    client.put("/api/calendrier/semaines", json={"lundis": ["2026-10-19", "2026-10-26"], "type": "vacances"})
    inventaire = ajouter(client, projet, nom="Inventaire du parc", duree_semaines=3)
    codif = ajouter(client, projet, nom="Codification", duree_semaines=2, predecesseurs=[inventaire["id"]])
    revue = ajouter(client, projet, nom="Revue de projet", jalon=True, predecesseurs=[codif["id"]])
    tardive = ajouter(client, projet, nom="Formation", duree_semaines=1, debut_au_plus_tot="2026-10-21")
    d = client.get(f"/api/projets/{projet['id']}").get_json()["projet"]
    plan = {t["nom"]: (t["debut"], t["fin"]) for t in d["taches"]}
    # 3 semaines de cours : 7/9, 14/9, (21/9 apprentissage), 28/9
    assert plan["Inventaire du parc"] == ("2026-09-07", "2026-09-28")
    assert plan["Codification"] == ("2026-10-05", "2026-10-12")
    assert plan["Revue de projet"] == ("2026-11-02", "2026-11-02")  # après les vacances de la Toussaint
    assert plan["Formation"] == ("2026-11-02", "2026-11-02")  # « au plus tôt » tombe en vacances
    assert any(s["lundi"] == "2026-10-19" and s["non_travaillee"] for s in d["semaines"])


def test_boucle_de_predecesseurs_refusee(client, connecter, projet):
    a = ajouter(client, projet, nom="A")
    b = ajouter(client, projet, nom="B", predecesseurs=[a["id"]])
    reponse = client.put(f"/api/projets/taches/{a['id']}", json={"nom": "A", "predecesseurs": [b["id"]]})
    assert reponse.status_code == 400 and "Boucle" in reponse.get_json()["error"]
    assert client.put(f"/api/projets/taches/{a['id']}", json={"nom": "A", "predecesseurs": [a["id"]]}).status_code == 400


def test_eleves_planifient_et_repartissent(client, connecter, projet):
    t = ajouter(client, projet, nom="Inventaire", duree_semaines=2)
    client.post("/api/auth/logout")
    connecter("tech")
    # Les élèves modifient durée, avancement et prédécesseurs, et répartissent les tâches
    modifiee = client.put(f"/api/projets/taches/{t['id']}", json={"nom": "Inventaire", "duree_semaines": 4, "avancement": 50}).get_json()["tache"]
    assert (modifiee["duree_semaines"], modifiee["statut"]) == (4, "en_cours")
    assert client.put(f"/api/projets/taches/{t['id']}/techniciens", json={"ids": [tech("tech")]}).status_code == 200
    ouvertes = client.get(f"/api/projets/taches?technicien_id={tech('tech')}").get_json()["taches"]
    assert [x["nom"] for x in ouvertes] == ["Inventaire"] and ouvertes[0]["debut"] == "2026-09-07"
    # Mais seul l'enseignant crée ou supprime un projet
    assert client.post("/api/projets", json={"nom": "x", "date_debut": "2026-09-07"}).status_code == 403
    assert client.put(f"/api/projets/taches/{t['id']}", json={"nom": "Inventaire", "avancement": 100}).get_json()["tache"]["statut"] == "termine"
    assert client.get("/api/projets/taches").get_json()["taches"] == []


def test_avancement_et_projets_paralleles(client, connecter, projet):
    ajouter(client, projet, nom="A", duree_semaines=1, avancement=100)
    ajouter(client, projet, nom="B", duree_semaines=3)
    autre = client.post("/api/projets", json={"nom": "Projet groupe 2", "date_debut": "2026-09-07"}).get_json()["projet"]
    liste = {p["nom"]: p for p in client.get("/api/projets").get_json()["projets"]}
    assert liste["Mise en place de la GMAO"]["avancement"] == 25 and autre["id"] in [p["id"] for p in liste.values()]


def test_1er_aout_archive_les_projets(client, connecter, projet):
    assert "1 projet(s) archivé(s)" in reset_annuel(date(2027, 8, 1))
    assert client.get("/api/projets").get_json()["projets"] == []
    assert len(client.get("/api/projets?archives=1").get_json()["projets"]) == 1


# ---------- Groupes, chantiers types, projet principal (PERT) ----------

def test_groupes_d_eleves(client, connecter):
    connecter("tech")
    assert client.post("/api/admin/groupes", json={"nom": "Groupe A", "membres": []}).status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    g = client.post("/api/admin/groupes", json={"nom": "Groupe A", "membres": [tech("tech"), tech("tech2")]}).get_json()["groupe"]
    assert [m["nom"] for m in g["membres"]] == ["Technicien 1 (démo)", "Technicien 2 (démo)"]
    assert client.post("/api/admin/groupes", json={"nom": "groupe a", "membres": []}).status_code == 400
    assert client.post("/api/admin/groupes", json={"nom": "B", "membres": [tech("operateur")]}).status_code == 400
    client.post("/api/auth/logout")
    connecter("tech")
    assert len(client.get("/api/admin/groupes").get_json()["groupes"]) == 1  # visibles pour attribuer


def test_chantiers_types(client, connecter):
    connecter("admin")
    t = client.post("/api/chantiers/types", json={"titre": "Nettoyage fin de séance", "type": "organisation", "duree_estimee_h": "0,5"}).get_json()["type"]
    assert (t["type"], t["duree_estimee_h"]) == ("organisation", 0.5)
    assert client.post("/api/chantiers/types", json={"titre": ""}).status_code == 400
    client.post("/api/auth/logout")
    connecter("tech")
    assert len(client.get("/api/chantiers/types").get_json()["types"]) == 1
    assert client.delete(f"/api/chantiers/types/{t['id']}").status_code == 403


def test_projet_principal_unique_pour_toute_la_classe(client, connecter):
    connecter("admin")
    assert client.get("/api/projets/principal").get_json()["projet"] is None
    p = client.post("/api/projets", json={"nom": "Déploiement de la GMAO", "date_debut": "2026-09-07", "principal": True})
    assert p.status_code == 201
    principal = client.get("/api/projets/principal").get_json()["projet"]
    assert {m["nom"] for m in principal["membres"]} == {"Technicien 1 (démo)", "Technicien 2 (démo)"}
    assert client.post("/api/projets", json={"nom": "Doublon", "date_debut": "2026-09-07", "principal": True}).status_code == 409
    assert client.get("/api/projets").get_json()["projets"] == []  # pas dans « Autres projets »


def test_pert_chemin_critique(client, connecter):
    connecter("admin")
    p = client.post("/api/projets", json={"nom": "Déploiement de la GMAO", "date_debut": "2026-09-07", "principal": True}).get_json()["projet"]
    a = ajouter(client, p, nom="A", duree_semaines=3)
    b = ajouter(client, p, nom="B", duree_semaines=1)
    c = ajouter(client, p, nom="C", duree_semaines=2, predecesseurs=[a["id"], b["id"]])
    fin = ajouter(client, p, nom="Fin", jalon=True, predecesseurs=[c["id"]])
    reseau = client.get("/api/projets/principal").get_json()["projet"]["pert"]
    n = {int(k): v for k, v in reseau["noeuds"].items()}
    assert reseau["duree_totale"] == 5
    assert (n[a["id"]]["critique"], n[b["id"]]["critique"], n[c["id"]]["critique"], n[fin["id"]]["critique"]) == (True, False, True, True)
    assert (n[b["id"]]["debut_tot"], n[b["id"]]["debut_tard"], n[b["id"]]["marge"]) == (0, 2, 2)
    assert (n[c["id"]]["debut_tot"], n[c["id"]]["niveau"]) == (3, 1)


def test_repartition_ne_montre_que_les_taches_de_la_semaine(client, connecter, projet, monkeypatch):
    class Fausse(__import__("datetime").datetime):
        @classmethod
        def now(cls, tz=None):
            return __import__("datetime").datetime(2026, 9, 16, 10, tzinfo=tz)

    monkeypatch.setattr("app.projets.datetime", Fausse)
    ajouter(client, projet, nom="En cours", duree_semaines=3)  # 7/9 → 21/9 : contient la semaine du 14/9
    ajouter(client, projet, nom="Plus tard", duree_semaines=1, debut_au_plus_tot="2026-10-05")
    noms = [t["nom"] for t in client.get("/api/projets/taches?semaine=1").get_json()["taches"]]
    assert noms == ["En cours"]
    assert len(client.get("/api/projets/taches").get_json()["taches"]) == 2


def test_un_eleve_peut_attribuer_un_chantier(client, connecter):
    from app.models import Utilisateur

    connecter("admin")
    chantier = client.post("/api/chantiers", json={"titre": "Ranger le magasin"}).get_json()["chantier"]
    tech2 = Utilisateur.query.filter_by(login="tech2").one().id
    connecter("tech")
    reponse = client.put(f"/api/chantiers/{chantier['id']}/techniciens", json={"ids": [tech2]})
    assert reponse.status_code == 200 and [t["nom"] for t in reponse.get_json()["chantier"]["techniciens"]] == ["Technicien 2 (démo)"]
    assert client.put(f"/api/chantiers/{chantier['id']}", json={"titre": "X"}).status_code == 403  # modifier : enseignant
