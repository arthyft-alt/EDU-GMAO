import io
from datetime import date, datetime

import pytest
from openpyxl import load_workbook

from app import db
from app.models import Atelier, BonComposant, BonIntervention, Machine, RealisationPreventive, TachePreventive, Utilisateur

AUJOURDHUI = date(2026, 11, 18)


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: AUJOURDHUI)


@pytest.fixture()
def tour(app):
    tech = Utilisateur.query.filter_by(login="tech").one()
    tour = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.filter_by(nom="01. Maintenance").one())
    tache = TachePreventive(machine=tour, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite="semaine",
                            date_debut=date(2026, 11, 2), temps_estime_min=30)
    bon = BonIntervention(numero="BI-1", machine=tour, type_travail="depannage", demandeur="Opérateur", description="Bruit broche",
                          cree_le=datetime(2026, 11, 3, 9), statut="termine", termine_le=datetime(2026, 11, 3, 12), temps_passe_h=2.5,
                          travaux="Roulement changé", techniciens=[tech])
    db.session.add_all([tour, tache, bon])
    db.session.flush()
    db.session.add_all([
        BonComposant(bon=bon, designation="Roulement", quantite=1, prix_unitaire=6.5),
        RealisationPreventive(tache=tache, echeance=date(2026, 11, 2), par_id=tech.id),
    ])
    db.session.commit()
    return tour


def test_export_historique(client, connecter, tour):
    connecter("tech")
    reponse = client.get(f"/api/machines/{tour.id}/historique.xlsx")
    assert reponse.status_code == 200 and "historique-MAI-01.xlsx" in reponse.headers["Content-Disposition"]
    wb = load_workbook(io.BytesIO(reponse.data))
    assert wb.sheetnames == ["Machine", "Correctif", "Préventif"]
    correctif = list(wb["Correctif"].values)
    assert correctif[1][0] == "BI-1" and correctif[1][2] == "Dépannage" and correctif[1][11] == 2.5 and correctif[1][18] == 6.5
    assert correctif[1][1] == datetime(2026, 11, 3, 10)  # heure de Paris
    preventif = list(wb["Préventif"].values)
    # Échéances des 2, 9 et 16 novembre : la 1re faite, la 2e non, la 3e en cours (semaine actuelle)
    assert [(l[4].date(), l[5]) for l in preventif[1:]] == [(date(2026, 11, 2), "Oui"), (date(2026, 11, 9), "Non"), (date(2026, 11, 16), "En cours")]
    assert preventif[1][7] == "Technicien 1 (démo)"


def test_export_par_periode_et_droits(client, connecter, tour):
    connecter("tech")
    wb = load_workbook(io.BytesIO(client.get(f"/api/machines/{tour.id}/historique.xlsx?du=2026-11-05").data))
    assert len(list(wb["Correctif"].values)) == 1 and len(list(wb["Préventif"].values)) == 3
    assert client.get(f"/api/machines/{tour.id}/historique.xlsx?du=hier").status_code == 400
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get(f"/api/machines/{tour.id}/historique.xlsx").status_code == 403
