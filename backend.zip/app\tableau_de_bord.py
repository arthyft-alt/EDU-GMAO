"""Page d'accueil de l'administrateur : chiffres clés de l'atelier et taux de performance (rafraîchis toutes les 30 s)."""
from datetime import timedelta

from flask import Blueprint, jsonify
from sqlalchemy import func

from . import db
from .auth import role_required
from .dates import debut_jour_paris
from .indicateurs import pastille
from .models import BonIntervention, Chantier, Commande, Machine, Piece, Projet, TachePreventive
from .calendrier import semaines_de_vacances
from . import preventif
from .preventif import echeances_entre, etat, realisations_par_tache, reporter


def aujourdhui():
    # Lu à chaque appel (et non copié au chargement du module) : une date figée par un test ne reste pas collée
    return preventif.aujourdhui()
from .projets import Invalide, planifier

bp = Blueprint("tableau_de_bord", __name__)


def chiffres_cles():
    ouverts = BonIntervention.query.filter(BonIntervention.statut != "termine")
    machines_arretees = (
        db.session.query(func.count(func.distinct(BonIntervention.machine_id)))
        .filter(BonIntervention.machine_arretee.is_(True), BonIntervention.remise_en_service.is_(None), BonIntervention.statut != "termine")
        .scalar()
    )
    taches = TachePreventive.query.join(Machine).filter(TachePreventive.actif.is_(True), Machine.hors_service.is_(False)).all()
    vacances, jour = semaines_de_vacances(), aujourdhui()
    faites = realisations_par_tache(taches, jour)
    return {
        "bons_ouverts": ouverts.count(),
        "bons_critiques": ouverts.filter(BonIntervention.urgence == "critique").count(),
        "bons_a_cloturer": BonIntervention.query.filter_by(statut="a_cloturer").count(),
        "machines_arretees": machines_arretees,
        "preventif_en_retard": sum(
            1 for t in taches if etat(t, jour, {r.echeance for r in faites[t.id]}, vacances)["statut"] == "en_retard"
        ),
        "pieces_sous_seuil": sum(1 for p in Piece.query.filter(Piece.stock_securite.isnot(None)) if p.en_alerte),
        "commandes_en_attente": Commande.query.filter(Commande.statut.in_(("en_commande", "partielle"))).count(),
    }


def _preventif(lundi, dimanche):
    """Échéances préventives de la semaine (après report des vacances), et celles qui ont été réalisées."""
    prevues = realisees = 0
    vacances = semaines_de_vacances()
    taches = TachePreventive.query.join(Machine).filter(TachePreventive.actif.is_(True), Machine.hors_service.is_(False)).all()
    toutes = realisations_par_tache(taches, dimanche)
    for tache in taches:
        faites = {reporter(r.echeance, vacances) for r in toutes[tache.id]}
        for echeance in echeances_entre(tache, lundi, dimanche, vacances):
            prevues += 1
            realisees += echeance in faites
    return prevues, realisees


def _ouverts_pendant(objets, debut, fin):
    """Objets à traiter pendant la semaine (créés avant sa fin, pas terminés avant son début) et ceux terminés dans la semaine."""
    a_faire = [o for o in objets if o.cree_le < fin and (o.termine_le is None or o.termine_le >= debut)]
    return len(a_faire), sum(1 for o in a_faire if o.termine_le is not None and o.termine_le < fin)


def _projet(lundi, debut, fin):
    """Tâches de projet prévues cette semaine au Gantt, ou en retard et pas encore terminées."""
    prevues = realisees = 0
    for projet in Projet.query.filter_by(actif=True):
        try:
            plan = planifier(projet)
        except Invalide:
            continue
        for t in projet.taches:
            if t.jalon or t.id not in plan:
                continue
            if t.statut == "termine" and (t.termine_le is None or t.termine_le < debut):
                continue  # terminée avant la semaine
            premiere = plan[t.id][0]
            if premiere > lundi:
                continue  # pas encore commencée au planning
            prevues += 1
            realisees += t.termine_le is not None and t.termine_le < fin
    return prevues, realisees


def taux_performance(lundi):
    """Taux de performance d'une semaine : post-it réalisés / post-it à faire, en %.
    Les 4 sortes de post-it de la répartition : interventions, préventif, chantiers, tâches de projet.
    Les bons créés depuis une tâche préventive sont comptés une seule fois, dans le préventif."""
    dimanche = lundi + timedelta(days=6)
    debut, fin = debut_jour_paris(lundi), debut_jour_paris(lundi + timedelta(days=7))
    bons = BonIntervention.query.filter(BonIntervention.tache_id.is_(None), BonIntervention.cree_le < fin).all()
    chantiers = Chantier.query.filter(Chantier.cree_le < fin).all()
    detail = {
        "interventions": _ouverts_pendant(bons, debut, fin),
        "preventif": _preventif(lundi, dimanche),
        "chantiers": _ouverts_pendant(chantiers, debut, fin),
        "projet": _projet(lundi, debut, fin),
    }
    prevues = sum(p for p, _ in detail.values())
    realisees = sum(r for _, r in detail.values())
    taux = round(realisees / prevues * 100) if prevues else None
    return {
        "lundi": lundi.isoformat(),
        "numero": lundi.isocalendar()[1],
        "prevues": prevues,
        "realisees": realisees,
        "taux": taux,
        "pastille": pastille(taux),
        "detail": {cle: {"prevues": p, "realisees": r} for cle, (p, r) in detail.items()},
    }


@bp.get("/tableau-de-bord")
@role_required("admin")
def tableau_de_bord():
    """Chiffres du moment, et taux de performance de la dernière semaine de cours terminée
    (comparé à la semaine de cours d'avant) : les semaines de vacances sont sautées."""
    vacances = semaines_de_vacances()

    def semaine_de_cours_avant(jour):
        jour -= timedelta(days=7)
        for _ in range(60):  # garde-fou si tout le calendrier était en vacances
            if jour not in vacances:
                break
            jour -= timedelta(days=7)
        return jour

    derniere = semaine_de_cours_avant(aujourdhui() - timedelta(days=aujourdhui().weekday()))
    return jsonify(
        chiffres=chiffres_cles(),
        performance=taux_performance(derniere),
        performance_avant=taux_performance(semaine_de_cours_avant(derniere)),
    )
