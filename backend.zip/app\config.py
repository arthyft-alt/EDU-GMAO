"""Configuration lue dans le fichier .env (voir .env.example)."""
import os
from pathlib import Path

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parent.parent
INSTANCE_DIR = BACKEND_DIR / "instance"

load_dotenv(BACKEND_DIR / ".env", encoding="utf-8")


def _bool(nom, defaut=False):
    valeur = os.environ.get(nom)
    if valeur is None or valeur == "":
        return defaut
    return valeur.strip().lower() in ("1", "true", "oui", "yes", "on")


CLE_PAR_DEFAUT = "dev-seulement-a-changer"
VERSION = "1.0"  # version de la GMAO (affichée en bas de l'écran et dans /api/health)


class Config:
    SECRET_KEY = os.environ.get("SECRET_KEY") or CLE_PAR_DEFAUT

    # Base de données : vide = fichier SQLite local ; en production, une adresse MySQL
    # du type mysql+pymysql://utilisateur:motdepasse@localhost/nom_base?charset=utf8mb4
    SQLALCHEMY_DATABASE_URI = os.environ.get("DATABASE_URL") or (
        "sqlite:///" + (INSTANCE_DIR / "gmao.db").as_posix()
    )
    SQLALCHEMY_ENGINE_OPTIONS = {"pool_pre_ping": True, "pool_recycle": 280}

    UPLOAD_DIR = Path(os.environ.get("UPLOAD_DIR") or INSTANCE_DIR / "uploads")
    SAUVEGARDE_DIR = Path(os.environ.get("SAUVEGARDE_DIR") or INSTANCE_DIR / "sauvegardes")  # copies de sécurité automatiques
    MAX_CONTENT_LENGTH = 20 * 1024 * 1024  # taille maximale d'un fichier envoyé : 20 Mo

    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = _bool("SESSION_COOKIE_SECURE")
    REMEMBER_COOKIE_SECURE = SESSION_COOKIE_SECURE
    REMEMBER_COOKIE_SAMESITE = "Lax"
    REMEMBER_COOKIE_HTTPONLY = True
    PERMANENT_SESSION_LIFETIME = 60 * 60 * 12  # 12 heures

    JSON_SORT_KEYS = False

    # Envoi d'e-mails (mot de passe oublié des administrateurs) : boîte mail créée dans cPanel.
    # Sans MAIL_SERVER, l'envoi est désactivé.
    MAIL_SERVER = os.environ.get("MAIL_SERVER", "")
    MAIL_PORT = int(os.environ.get("MAIL_PORT") or 465)
    MAIL_USERNAME = os.environ.get("MAIL_USERNAME", "")
    MAIL_PASSWORD = os.environ.get("MAIL_PASSWORD", "")
    MAIL_FROM = os.environ.get("MAIL_FROM") or os.environ.get("MAIL_USERNAME", "")
    # Adresse publique du site, pour le lien envoyé par e-mail (ex. https://gmao.mon-lycee.fr)
    PUBLIC_URL = os.environ.get("PUBLIC_URL", "")
