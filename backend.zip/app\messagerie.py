"""Messagerie interne (ADM-04) entre élèves (techniciens) et enseignants (administrateurs).

- Conversation « directe » : deux élèves entre eux, ou deux enseignants.
- Conversation « enseignants » : un élève et tous les administrateurs (chaque enseignant peut répondre).
- Conversations « groupe » et « classe » : ouvertes par un enseignant, chaque membre peut répondre.
Le compte opérateur (partagé) n'a pas de messagerie. Pas de temps réel sur cPanel : l'écran interroge
le serveur toutes les 10 à 15 s. Les messages sont conservés ; l'administrateur peut supprimer n'importe lequel.
"""
from flask import Blueprint, jsonify, request
from flask_login import current_user
from sqlalchemy import func

from . import db
from .auth import erreur, role_required
from .models import (
    Conversation,
    GroupeEleves,
    LectureConversation,
    Message,
    Utilisateur,
    iso,
    journaliser,
    maintenant,
)

bp = Blueprint("messagerie", __name__, url_prefix="/messagerie")

EQUIPE = ("admin", "technicien")
LONGUEUR_MAX = 2000


def peut_acceder(conv, u):
    if u.role == "admin" and conv.type in ("enseignants", "groupe", "classe"):
        return True
    if conv.type == "directe":
        return any(p.id == u.id for p in conv.participants)
    if conv.type == "enseignants":
        return conv.eleve_id == u.id
    if conv.type == "groupe":
        return bool(conv.groupe) and any(m.id == u.id for m in conv.groupe.membres)
    if conv.type == "classe":
        return u.role == "technicien"
    return False


def _conversations_visibles(u):
    directes = Conversation.query.filter(
        Conversation.type == "directe", Conversation.participants.any(Utilisateur.id == u.id)
    ).all()
    if u.role == "admin":
        autres = Conversation.query.filter(Conversation.type.in_(("enseignants", "groupe", "classe"))).all()
    else:
        groupes = [g.id for g in GroupeEleves.query.filter(GroupeEleves.membres.any(Utilisateur.id == u.id))]
        autres = Conversation.query.filter(
            ((Conversation.type == "enseignants") & (Conversation.eleve_id == u.id))
            | ((Conversation.type == "groupe") & Conversation.groupe_id.in_(groupes or [0]))
            | (Conversation.type == "classe")
        ).all()
    return directes + autres


def titre(conv, u):
    if conv.type == "directe":
        autre = next((p for p in conv.participants if p.id != u.id), None)
        return autre.nom if autre else "Conversation"
    if conv.type == "enseignants":
        return "Enseignants" if u.id == conv.eleve_id else conv.eleve.nom
    if conv.type == "groupe":
        return f"Groupe « {conv.groupe.nom} »" if conv.groupe else "Groupe supprimé"
    return "Toute la classe"


def _dernier_lu(conv, u):
    lecture = db.session.get(LectureConversation, (conv.id, u.id))
    return lecture.dernier_lu_id if lecture else 0


def non_lus(conv, u):
    return conv.messages.filter(Message.id > _dernier_lu(conv, u), Message.auteur_id != u.id).count()


def _marquer_lu(conv, u):
    dernier = db.session.query(func.max(Message.id)).filter(Message.conversation_id == conv.id).scalar() or 0
    lecture = db.session.get(LectureConversation, (conv.id, u.id)) or LectureConversation(conversation_id=conv.id, utilisateur_id=u.id)
    lecture.dernier_lu_id = max(lecture.dernier_lu_id or 0, dernier)
    db.session.add(lecture)


def conversation_dict(conv, u):
    dernier = conv.messages.order_by(Message.id.desc()).first()
    return {
        "id": conv.id,
        "type": conv.type,
        "titre": titre(conv, u),
        "non_lus": non_lus(conv, u),
        "dernier_message": (
            {"texte": dernier.texte[:120], "auteur": dernier.auteur.nom, "cree_le": iso(dernier.cree_le)} if dernier else None
        ),
        "dernier_message_le": iso(conv.dernier_message_le),
    }


def _conversation_ou_erreur(conversation_id):
    conv = db.session.get(Conversation, conversation_id)
    if not conv or not peut_acceder(conv, current_user):
        return None, erreur("Conversation introuvable.", 404)
    return conv, None


# ---------- Routes ----------

@bp.get("/non-lus")
@role_required(*EQUIPE)
def total_non_lus():
    """Interrogé toutes les 15 s par la barre du haut (pastille rouge)."""
    return jsonify(total=sum(non_lus(c, current_user) for c in _conversations_visibles(current_user)))


@bp.get("/conversations")
@role_required(*EQUIPE)
def conversations():
    # Les fils sans aucun message (ouverts puis abandonnés) ne sont pas listés
    liste = [c for c in _conversations_visibles(current_user) if c.dernier_message_le]
    liste.sort(key=lambda c: c.dernier_message_le, reverse=True)
    return jsonify(conversations=[conversation_dict(c, current_user) for c in liste])


@bp.get("/destinataires")
@role_required(*EQUIPE)
def destinataires():
    """À qui l'utilisateur peut-il écrire ? Chaque choix renvoie le {type, id} à passer pour ouvrir le fil."""
    eleves = Utilisateur.query.filter(Utilisateur.role == "technicien", Utilisateur.actif.is_(True), Utilisateur.id != current_user.id)
    eleves = [{"type": "enseignants" if current_user.role == "admin" else "directe", "id": e.id, "nom": e.nom} for e in eleves.order_by(Utilisateur.nom)]
    if current_user.role == "technicien":
        return jsonify(collectifs=[{"type": "enseignants", "id": None, "nom": "Les enseignants"}], personnes=eleves)
    admins = Utilisateur.query.filter(Utilisateur.role == "admin", Utilisateur.actif.is_(True), Utilisateur.id != current_user.id)
    collectifs = [{"type": "classe", "id": None, "nom": "Toute la classe"}] + [
        {"type": "groupe", "id": g.id, "nom": f"Groupe « {g.nom} »"} for g in GroupeEleves.query.order_by(GroupeEleves.nom)
    ]
    personnes = eleves + [{"type": "directe", "id": a.id, "nom": f"{a.nom} (enseignant)"} for a in admins.order_by(Utilisateur.nom)]
    return jsonify(collectifs=collectifs, personnes=personnes)


@bp.post("/conversations")
@role_required(*EQUIPE)
def ouvrir_conversation():
    """Retrouve (ou crée) le fil correspondant au destinataire choisi."""
    donnees = request.get_json(silent=True) or {}
    type_conv, cible = donnees.get("type"), donnees.get("id")
    moi = current_user
    if type_conv == "enseignants":
        eleve = moi if moi.role == "technicien" else db.session.get(Utilisateur, cible or 0)
        if not eleve or eleve.role != "technicien":
            return erreur("Choisissez un élève.", 400)
        conv = Conversation.query.filter_by(type="enseignants", eleve_id=eleve.id).first() or Conversation(type="enseignants", eleve=eleve)
    elif type_conv == "directe":
        autre = db.session.get(Utilisateur, cible or 0)
        # Un élève écrit à un autre élève ; un enseignant à un autre enseignant (aux élèves : fil « enseignants »)
        role_attendu = "technicien" if moi.role == "technicien" else "admin"
        if not autre or autre.id == moi.id or autre.role != role_attendu or not autre.actif:
            return erreur("Destinataire invalide.", 400)
        conv = (
            Conversation.query.filter(Conversation.type == "directe")
            .filter(Conversation.participants.any(Utilisateur.id == moi.id))
            .filter(Conversation.participants.any(Utilisateur.id == autre.id))
            .first()
        ) or Conversation(type="directe", participants=[moi, autre])
    elif type_conv in ("groupe", "classe"):
        if moi.role != "admin":
            return erreur("Seul un enseignant peut écrire à un groupe ou à la classe.", 403)
        if type_conv == "groupe":
            groupe = db.session.get(GroupeEleves, cible or 0)
            if not groupe:
                return erreur("Groupe introuvable.", 404)
            conv = Conversation.query.filter_by(type="groupe", groupe_id=groupe.id).first() or Conversation(type="groupe", groupe=groupe)
        else:
            conv = Conversation.query.filter_by(type="classe").first() or Conversation(type="classe")
    else:
        return erreur("Type de conversation inconnu.", 400)
    db.session.add(conv)
    db.session.commit()
    return jsonify(conversation=conversation_dict(conv, moi))


@bp.get("/conversations/<int:conversation_id>/messages")
@role_required(*EQUIPE)
def messages(conversation_id):
    """Les 200 derniers messages ; ?apres=<id> pour ne recevoir que les nouveaux. Ouvrir le fil le marque comme lu."""
    conv, err = _conversation_ou_erreur(conversation_id)
    if err:
        return err
    requete = conv.messages
    apres = request.args.get("apres", type=int)
    if apres:
        liste = requete.filter(Message.id > apres).order_by(Message.id).all()
    else:
        liste = list(reversed(requete.order_by(Message.id.desc()).limit(200).all()))
    _marquer_lu(conv, current_user)
    db.session.commit()
    return jsonify(conversation=conversation_dict(conv, current_user), messages=[m.to_dict() for m in liste])


@bp.post("/conversations/<int:conversation_id>/messages")
@role_required(*EQUIPE)
def envoyer(conversation_id):
    conv, err = _conversation_ou_erreur(conversation_id)
    if err:
        return err
    texte = str((request.get_json(silent=True) or {}).get("texte") or "").strip()
    if not texte:
        return erreur("Le message est vide.", 400)
    if len(texte) > LONGUEUR_MAX:
        return erreur(f"Le message ne doit pas dépasser {LONGUEUR_MAX} caractères.", 400)
    message = Message(conversation=conv, auteur_id=current_user.id, texte=texte)
    conv.dernier_message_le = maintenant()
    db.session.add(message)
    db.session.flush()
    _marquer_lu(conv, current_user)
    db.session.commit()
    return jsonify(message=message.to_dict()), 201


@bp.delete("/messages/<int:message_id>")
@role_required("admin")
def supprimer(message_id):
    """L'administrateur peut supprimer n'importe quel message (modération)."""
    message = db.session.get(Message, message_id)
    if not message:
        return erreur("Message introuvable.", 404)
    journaliser("suppression", message, f"Message de {message.auteur.nom} : « {message.texte[:80]} »")
    db.session.delete(message)
    db.session.commit()
    return jsonify(ok=True)
