"""Bilan de la semaine de la classe (suivi des élèves par l'enseignant), fiche synthétique imprimable.

Pour chaque élève : les activités qui lui étaient affectées pendant la semaine (mêmes règles que le taux
de performance), celles qu'il a réalisées, ses commentaires de clôture des bons et ses jours d'absence.
"""
from datetime import date, timedelta

from flask import Blueprint, jsonify, request

from . import db
from . import referentiels as ref
from .auth import erreur, role_required
from .calendrier import lundi as lundi_de, semaines_de_vacances
from .dates import debut_jour_paris
from .indicateurs import pastille
from .models import AbsenceEleve, BonIntervention, BonPreventif, ChantierAffectation, Projet, RealisationPreventive, TacheProjet, Utilisateur, journaliser
from . import preventif
from .projets import Invalide, planifier

bp = Blueprint("bilan_semaine", __name__)

JOURS_DE_COURS = 5  # du lundi au vendredi


def _dans(moment, debut, fin):
    return moment is not None and debut <= moment < fin


def _bons(eleve, debut, fin):
    """Bons confiés à l'élève et ouverts pendant la semaine (les bons de préventif comptent comme « Préventif »)."""
    activites = []
    bons = BonIntervention.query.filter(
        BonIntervention.techniciens.any(Utilisateur.id == eleve.id),
        BonIntervention.cree_le < fin,
        (BonIntervention.termine_le.is_(None)) | (BonIntervention.termine_le >= debut),
    ).order_by(BonIntervention.cree_le)
    for b in bons:
        realise = _dans(b.termine_le, debut, fin)
        activites.append(
            {
                "type": "preventif" if b.tache_id else "intervention",
                "titre": f"{b.numero} · {b.machine.repere} {b.machine.designation}",
                "detail": b.description,
                "realise": realise,
                "statut": "Réalisé" if realise else ref.STATUTS_BI.get(b.statut, b.statut),
                "temps_h": b.temps_passe_h if realise else None,
                "commentaire": {"travaux": b.travaux, "cause": b.cause} if realise and (b.travaux or b.cause) else None,
            }
        )
    return activites


def _bons_preventifs(eleve, debut, fin):
    """Bons de préventif confiés à l'élève et ouverts pendant la semaine."""
    activites = []
    bons = BonPreventif.query.filter(
        BonPreventif.techniciens.any(Utilisateur.id == eleve.id),
        BonPreventif.cree_le < fin,
        (BonPreventif.termine_le.is_(None)) | (BonPreventif.termine_le >= debut),
    ).order_by(BonPreventif.cree_le)
    for b in bons:
        realise = _dans(b.termine_le, debut, fin)
        machine = b.tache.machine
        activites.append(
            {
                "type": "preventif",
                "titre": f"{machine.repere} {machine.designation} : {b.tache.nom}",
                "detail": f"Échéance du {b.echeance:%d/%m/%Y}",
                "realise": realise,
                "statut": "Réalisé" if realise else "À faire",
                "temps_h": None,
                "commentaire": None,
            }
        )
    return activites


def _chantiers(eleve, debut, fin):
    activites = []
    affectations = ChantierAffectation.query.filter(ChantierAffectation.utilisateur_id == eleve.id).all()
    for a in affectations:
        c = a.chantier
        fini = a.termine_le or (c.termine_le if c.statut == "termine" else None)
        if c.cree_le >= fin or (fini is not None and fini < debut):
            continue
        realise = _dans(fini, debut, fin)
        activites.append(
            {
                "type": "chantier",
                "titre": c.titre,
                "detail": c.description,
                "realise": realise,
                "statut": "Réalisé" if realise else ("En cours" if c.statut == "en_cours" else "À faire"),
                "temps_h": None,
                "commentaire": None,
            }
        )
    return activites


def _taches_projet(eleve, lundi, debut, fin, plans):
    activites = []
    dimanche = lundi + timedelta(days=6)
    taches = TacheProjet.query.join(Projet).filter(
        Projet.actif.is_(True), TacheProjet.jalon.is_(False), TacheProjet.techniciens.any(Utilisateur.id == eleve.id)
    )
    for t in taches:
        if t.projet_id not in plans:
            try:
                plans[t.projet_id] = planifier(t.projet)
            except Invalide:
                plans[t.projet_id] = {}
        if t.id not in plans[t.projet_id]:
            continue
        premiere, derniere, _ = plans[t.projet_id][t.id]
        termine_avant = t.statut == "termine" and (t.termine_le is None or t.termine_le < debut)
        # Prévue cette semaine au Gantt, ou en retard (prévue avant et pas encore terminée)
        if termine_avant or premiere > dimanche:
            continue
        realise = _dans(t.termine_le, debut, fin)
        activites.append(
            {
                "type": "projet",
                "titre": f"{t.projet.nom} : {t.nom}",
                "detail": None,
                "realise": realise,
                "statut": "Réalisé" if realise else (f"{t.avancement} %" if t.avancement else "À faire"),
                "temps_h": None,
                "commentaire": None,
            }
        )
    return activites


def _preventif_coche(eleve, debut, fin):
    """Préventif coché par l'élève sans bon (check-lists) : travaux en plus, non comptés dans le taux."""
    realisations = RealisationPreventive.query.filter(
        RealisationPreventive.par_id == eleve.id,
        RealisationPreventive.bon_id.is_(None),
        RealisationPreventive.realise_le >= debut,
        RealisationPreventive.realise_le < fin,
    )
    confiees = {(t, e) for t, e in db.session.query(BonPreventif.tache_id, BonPreventif.echeance)}
    return [f"{r.tache.machine.repere} : {r.tache.nom}" for r in realisations if (r.tache_id, r.echeance) not in confiees]


def bilan_eleve(eleve, lundi, plans):
    debut, fin = debut_jour_paris(lundi), debut_jour_paris(lundi + timedelta(days=7))
    activites = _bons(eleve, debut, fin) + _bons_preventifs(eleve, debut, fin) + _chantiers(eleve, debut, fin) + _taches_projet(eleve, lundi, debut, fin, plans)
    realisees = sum(1 for a in activites if a["realise"])
    taux = round(realisees / len(activites) * 100) if activites else None
    absences = sorted(
        a.jour for a in AbsenceEleve.query.filter(
            AbsenceEleve.utilisateur_id == eleve.id, AbsenceEleve.jour >= lundi, AbsenceEleve.jour < lundi + timedelta(days=7)
        )
    )
    jours_de_cours = {lundi + timedelta(days=i) for i in range(JOURS_DE_COURS)}
    return {
        "eleve": {"id": eleve.id, "nom": eleve.nom},
        "absences": [j.isoformat() for j in absences],
        "absent_toute_la_semaine": jours_de_cours <= set(absences),
        "activites": activites,
        "autres": _preventif_coche(eleve, debut, fin),
        "affectees": len(activites),
        "realisees": realisees,
        "taux": taux,
        "pastille": pastille(taux),
        "temps_h": round(sum(a["temps_h"] or 0 for a in activites), 2),
    }


def _semaine_par_defaut():
    """La semaine en cours si c'est une semaine de cours, sinon la dernière semaine de cours."""
    vacances = semaines_de_vacances()
    lundi = lundi_de(preventif.aujourdhui())
    for _ in range(60):
        if lundi not in vacances:
            break
        lundi -= timedelta(days=7)
    return lundi


@bp.get("/eleve/bilan-semaine")
@role_required("admin")
def bilan_semaine():
    try:
        lundi = lundi_de(date.fromisoformat(request.args["debut"])) if request.args.get("debut") else _semaine_par_defaut()
    except ValueError:
        return erreur("Date invalide.", 400)
    plans = {}
    eleves = Utilisateur.query.filter_by(role="technicien", actif=True).order_by(Utilisateur.nom).all()
    bilans = [bilan_eleve(e, lundi, plans) for e in eleves]
    affectees = sum(b["affectees"] for b in bilans)
    realisees = sum(b["realisees"] for b in bilans)
    taux = round(realisees / affectees * 100) if affectees else None
    return jsonify(
        semaine={
            "lundi": lundi.isoformat(),
            "vendredi": (lundi + timedelta(days=4)).isoformat(),
            "numero": lundi.isocalendar()[1],
            "vacances": lundi in semaines_de_vacances(),
        },
        classe={"affectees": affectees, "realisees": realisees, "taux": taux, "pastille": pastille(taux)},
        eleves=bilans,
    )


@bp.get("/eleve/absences")
@role_required("admin")
def absences_du_jour():
    """Élèves absents un jour donné (?jour=AAAA-MM-JJ, aujourd'hui par défaut) : pour la réunion AIC."""
    try:
        jour = date.fromisoformat(request.args["jour"]) if request.args.get("jour") else preventif.aujourdhui()
    except ValueError:
        return erreur("Date invalide.", 400)
    return jsonify(jour=jour.isoformat(), absents=[a.utilisateur_id for a in AbsenceEleve.query.filter_by(jour=jour)])


@bp.put("/eleve/absences")
@role_required("admin")
def changer_absence():
    """Marque (ou retire) l'absence d'un élève un jour donné : {technicien_id, jour, absent}."""
    donnees = request.get_json(silent=True) or {}
    eleve = db.session.get(Utilisateur, donnees.get("technicien_id") or 0)
    if not eleve or eleve.role != "technicien":
        return erreur("Choisissez un élève.", 400)
    try:
        jour = date.fromisoformat(str(donnees.get("jour")))
    except ValueError:
        return erreur("Date invalide.", 400)
    absence = AbsenceEleve.query.filter_by(utilisateur_id=eleve.id, jour=jour).first()
    if donnees.get("absent") and not absence:
        db.session.add(AbsenceEleve(utilisateur_id=eleve.id, jour=jour))
        journaliser("modification", eleve, f"Absent le {jour:%d/%m/%Y}")
    elif not donnees.get("absent") and absence:
        db.session.delete(absence)
        journaliser("modification", eleve, f"Présent le {jour:%d/%m/%Y} (absence retirée)")
    db.session.commit()
    return jsonify(ok=True)
