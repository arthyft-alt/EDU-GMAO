"""Commandes en ligne : flask --app app <commande>."""
import secrets
from datetime import datetime
from zoneinfo import ZoneInfo

import click

from . import db
from . import referentiels as ref
from .auth import code_du_jour
from .models import Atelier, Element, Parametre, Pictogramme, Piece, Utilisateur, journaliser

PARIS = ZoneInfo("Europe/Paris")

COMPTES_DEMO = [
    ("admin", "admin", "Administrateur (démo)", "admin"),
    ("tech", "tech", "Technicien 1 (démo)", "technicien"),
    ("tech2", "tech2", "Technicien 2 (démo)", "technicien"),
    ("operateur", "operateur", "Opérateur (démo)", "operateur"),
]

PARAMETRES_DEFAUT = {"duree_aic_minutes": "10"}


def _parametre(cle):
    param = db.session.get(Parametre, cle)
    return param.valeur if param else None


def _definir_parametre(cle, valeur):
    param = db.session.get(Parametre, cle) or Parametre(cle=cle)
    param.valeur = valeur
    db.session.add(param)


def seed(demo=True):
    """Remplit la base avec les données de départ. Peut être relancé sans créer de doublons."""
    for i, nom in enumerate(ref.ATELIERS, start=1):
        if not Atelier.query.filter_by(nom=nom).first():
            db.session.add(Atelier(nom=nom, ordre=i))
    for i, nom in enumerate(ref.ELEMENTS, start=1):
        if not Element.query.filter_by(nom=nom).first():
            db.session.add(Element(nom=nom, ordre=i))
    for code, (nom, categorie) in ref.PICTOGRAMMES.items():
        if not Pictogramme.query.filter_by(code=code).first():
            db.session.add(Pictogramme(code=code, nom=nom, categorie=categorie))
    for cle, valeur in PARAMETRES_DEFAUT.items():
        if _parametre(cle) is None:
            _definir_parametre(cle, valeur)

    if demo:
        for login, mot_de_passe, nom, role in COMPTES_DEMO:
            if not Utilisateur.query.filter_by(login=login).first():
                u = Utilisateur(login=login, nom=nom, role=role)
                u.definir_mot_de_passe(mot_de_passe)
                db.session.add(u)
        demo = Utilisateur.query.filter_by(login="operateur", role="operateur").first()
        if demo and not demo.atelier_id:
            demo.atelier = Atelier.query.filter_by(nom=ref.ATELIERS[0]).first()
    db.session.commit()


def changement_annee(jour, eleves):
    """Ce qui change d'une année à l'autre (annexe A) : utilisé le 1er août (Cron) et par le bouton
    « Clôturer l'année » (Administration › Classe et promotion). Renvoie le bilan ; le commit est fait par l'appelant."""
    from .suppression import liberer_travail

    # Travail encore en cours des élèves qui partent : il repasse « à attribuer » ; ils quittent aussi leurs groupes
    travaux = liberer_travail(eleves)
    # Anonymisation RGPD (ADM-03, choix de Simon) : nom et identifiant remplacés, compte désactivé, mot de passe
    # brouillé ; l'historique reste, sans nom. Les nouveaux comptes sont créés à la rentrée.
    for eleve in eleves:
        eleve.nom = f"Élève anonyme {eleve.id}"
        eleve.login = f"anonyme-{eleve.id}"
        eleve.email = None
        eleve.actif = False
        eleve.position_atelier_id = None
        eleve.position_le = None
        eleve.definir_mot_de_passe(secrets.token_urlsafe(24))
    # Seuils de stock saisis par les élèves (STK-07)
    nb_seuils = Piece.query.filter(
        (Piece.stock_securite.isnot(None)) | (Piece.quantite_min_commande.isnot(None))
    ).update({"stock_securite": None, "quantite_min_commande": None}, synchronize_session=False)
    # Projets et Gantt de l'année : archivés (CHA-06)
    from .projets import archiver_projets

    nb_projets = archiver_projets()
    # Croix Sécurité : couleurs effacées, record conservé (AIC-05)
    from .aic import remettre_croix_a_zero

    remettre_croix_a_zero(jour)
    bilan = (
        f"{len(eleves)} élève(s) anonymisé(s), {travaux} travail(aux) en cours remis « à attribuer », "
        f"seuils de stock remis à zéro sur {nb_seuils} pièce(s), {nb_projets} projet(s) archivé(s)"
    )
    journaliser("reinitialisation_annuelle", details=bilan)
    return bilan


def reset_annuel(jour):
    """Réinitialisations du 1er août (annexe A), une seule fois par an.
    Rattrapage : si le Cron n'a pas tourné le 1er août (serveur en panne…), elle est faite au premier
    passage suivant du mois d'août, pour que l'anonymisation RGPD ne soit jamais oubliée.
    Sans effet de septembre à juillet. Renvoie un message décrivant ce qui a été fait."""
    if jour.month != 8:
        return f"Nous sommes le {jour:%d/%m/%Y} : rien à faire (la réinitialisation a lieu le 1er août)."
    if _parametre("dernier_reset_annuel") == str(jour.year):
        return f"La réinitialisation {jour.year} a déjà été faite."

    # Anonymisation RGPD de tous les comptes élèves (ADM-03, choix de Simon) : nom et identifiant remplacés,
    # compte désactivé, mot de passe brouillé ; l'historique reste, sans nom. Nouveaux comptes à la rentrée.
    # Seulement les comptes de l'année écoulée : ceux créés pour la rentrée pendant un rattrapage restent intacts
    eleves = Utilisateur.query.filter(
        Utilisateur.role == "technicien",
        ~Utilisateur.login.like("anonyme-%"),
        ~Utilisateur.login.like("supprime-%"),
        Utilisateur.cree_le < datetime(jour.year, 8, 1),
    ).all()
    bilan = changement_annee(jour, eleves)
    _definir_parametre("dernier_reset_annuel", str(jour.year))
    db.session.commit()
    return f"Réinitialisation {jour.year} effectuée : {bilan}."


def enregistrer(app):
    @app.cli.command("seed")
    @click.option("--no-demo", is_flag=True, help="Ne crée aucun compte de démonstration (production).")
    def seed_cmd(no_demo):
        """Données de départ : ateliers, éléments, paramètres (et comptes de démo)."""
        seed(demo=not no_demo)
        click.echo("Données de départ en place." + ("" if no_demo else " Comptes de démo : admin, tech, tech2, operateur."))

    @app.cli.command("creer-utilisateur")
    @click.argument("login")
    @click.option("--nom", required=True, help="Nom affiché, ex. \"Simon Dupont\".")
    @click.option("--role", required=True, type=click.Choice(list(ref.ROLES)))
    @click.option("--email", default=None, help="Adresse e-mail (obligatoire pour un administrateur en ligne).")
    @click.password_option("--mot-de-passe", prompt="Mot de passe", confirmation_prompt="Confirmer le mot de passe")
    def creer_utilisateur(login, nom, role, email, mot_de_passe):
        """Crée un compte (le mot de passe est demandé au clavier)."""
        login = login.strip().lower()
        if Utilisateur.query.filter_by(login=login).first():
            raise click.ClickException(f"L'identifiant « {login} » existe déjà.")
        u = Utilisateur(login=login, nom=nom, role=role, email=(email or "").strip().lower() or None)
        u.definir_mot_de_passe(mot_de_passe)
        db.session.add(u)
        db.session.commit()
        click.echo(f"Compte « {login} » créé ({ref.ROLES[role]}).")

    @app.cli.command("code-du-jour")
    @click.option("--nouveau", is_flag=True, help="Tirer un nouveau code (l'ancien ne fonctionne plus).")
    def code_du_jour_cmd(nouveau):
        """Affiche le code du jour à 4 chiffres (gestion des machines, calcul des indicateurs)."""
        click.echo(f"Code du jour : {code_du_jour(renouveler=nouveau)}")

    @app.cli.command("reset-annuel")
    @click.option("--date", "jour", type=click.DateTime(formats=["%Y-%m-%d"]), help="Simuler une date (AAAA-MM-JJ).")
    def reset_annuel_cmd(jour):
        """Réinitialisation annuelle du 1er août (à lancer chaque jour par le Cron de cPanel)."""
        jour = jour.date() if jour else datetime.now(PARIS).date()
        click.echo(reset_annuel(jour))
