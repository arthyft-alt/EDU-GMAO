"""Module Documentation technique (DOC-01 à DOC-04) : PDF rattachés aux machines.
Réservé aux techniciens et à l'administrateur (l'opérateur n'a que les modes opératoires du préventif)."""
import json
import uuid

from flask import Blueprint, current_app, jsonify, request, send_from_directory
from flask_login import current_user
from sqlalchemy import or_

from . import db
from . import referentiels as ref
from .auth import erreur, role_required, unlock_required
from .models import Document, DocumentMachine, Element, Machine, journaliser
from .reglages import liste

bp = Blueprint("documentation", __name__)

EQUIPE = ("admin", "technicien")


class Invalide(Exception):
    pass


def _dossier():
    dossier = current_app.config["UPLOAD_DIR"] / "documents"
    dossier.mkdir(parents=True, exist_ok=True)
    return dossier


def _verifier_pdf(fichier):
    """Seuls les PDF sont acceptés (choix 1B) : on vérifie aussi le contenu, pas seulement le nom."""
    if not fichier or not fichier.filename:
        raise Invalide("Choisissez le fichier PDF.")
    debut = fichier.stream.read(5)
    fichier.stream.seek(0)
    if debut != b"%PDF-":
        raise Invalide("Le fichier n'est pas un PDF.")


def _enregistrer_fichier(document, fichier):
    nom = f"doc_{uuid.uuid4().hex[:16]}.pdf"
    chemin = _dossier() / nom
    fichier.save(chemin)
    ancien = document.fichier
    document.fichier = nom
    document.nom_original = (fichier.filename or "document.pdf")[:255]
    document.taille = chemin.stat().st_size
    return ancien


def _appliquer(document, donnees):
    titre = str(donnees.get("titre") or "").strip()
    if not titre:
        raise Invalide("Le titre est obligatoire.")
    if donnees.get("categorie") not in liste("categories_documents"):
        raise Invalide("Choisissez la catégorie du document.")
    affectations = donnees.get("affectations")
    if isinstance(affectations, str):  # envoyé dans un formulaire avec le fichier
        try:
            affectations = json.loads(affectations or "[]")
        except ValueError:
            affectations = None
    if not isinstance(affectations, list) or not affectations:
        raise Invalide("Rattachez le document à au moins une machine.")
    nouvelles, vues = [], set()
    for ligne in affectations:
        try:
            machine = db.session.get(Machine, int(ligne.get("machine_id")))
        except (TypeError, ValueError, AttributeError):
            machine = None
        if not machine:
            raise Invalide("Machine introuvable.")
        if machine.id in vues:
            raise Invalide(f"La machine {machine.repere} apparaît deux fois.")
        vues.add(machine.id)
        element = None
        if ligne.get("element_id") not in (None, ""):
            try:
                element = db.session.get(Element, int(ligne["element_id"]))
            except (TypeError, ValueError):
                element = None
            if not element:
                raise Invalide("Élément introuvable.")
        nouvelles.append(DocumentMachine(machine=machine, element=element))
    document.titre = titre[:200]
    document.categorie = donnees["categorie"]
    document.remarques = str(donnees.get("remarques") or "").strip() or None
    document.affectations = nouvelles


def _document_ou_404(document_id):
    document = db.session.get(Document, document_id)
    if not document:
        return None, erreur("Document introuvable.", 404)
    return document, None


@bp.get("/documents")
@role_required(*EQUIPE)
def liste_documents():
    requete = Document.query
    args = request.args
    recherche = (args.get("q") or "").strip()
    if recherche:
        motif = f"%{recherche}%"
        requete = requete.filter(
            or_(Document.titre.ilike(motif), Document.remarques.ilike(motif), Document.nom_original.ilike(motif))
        )
    if args.get("categorie"):
        requete = requete.filter(Document.categorie == args["categorie"])
    if args.get("machine_id", type=int):
        condition = DocumentMachine.machine_id == args.get("machine_id", type=int)
        if args.get("element_id", type=int):
            condition = condition & (DocumentMachine.element_id == args.get("element_id", type=int))
        requete = requete.filter(Document.affectations.any(condition))
    elif args.get("atelier_id", type=int):
        requete = requete.filter(
            Document.affectations.any(DocumentMachine.machine.has(Machine.atelier_id == args.get("atelier_id", type=int)))
        )
    documents = requete.order_by(Document.categorie, Document.titre).limit(1000).all()
    return jsonify(documents=[d.to_dict() for d in documents])


@bp.get("/documents/<int:document_id>")
@role_required(*EQUIPE)
def detail_document(document_id):
    document, err = _document_ou_404(document_id)
    if err:
        return err
    return jsonify(document=document.to_dict())


@bp.get("/documents/<int:document_id>/fichier")
@role_required(*EQUIPE)
def fichier_document(document_id):
    """Le PDF lui-même, affiché dans le navigateur (DOC-03). ?telecharger=1 pour l'enregistrer."""
    document, err = _document_ou_404(document_id)
    if err:
        return err
    return send_from_directory(
        _dossier(),
        document.fichier,
        mimetype="application/pdf",
        as_attachment=request.args.get("telecharger") == "1",
        download_name=document.nom_original,
        max_age=600,
    )


@bp.post("/documents")
@role_required(*EQUIPE)
@unlock_required("machines")
def deposer_document():
    document = Document(depose_par_id=current_user.id)
    try:
        _appliquer(document, request.form)
        _verifier_pdf(request.files.get("fichier"))
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    _enregistrer_fichier(document, request.files["fichier"])
    db.session.add(document)
    db.session.flush()
    journaliser("creation", document, document.titre)
    db.session.commit()
    return jsonify(document=document.to_dict()), 201


@bp.put("/documents/<int:document_id>")
@role_required(*EQUIPE)
@unlock_required("machines")
def modifier_document(document_id):
    document, err = _document_ou_404(document_id)
    if err:
        return err
    try:
        _appliquer(document, request.get_json(silent=True) or {})
    except Invalide as e:
        db.session.rollback()
        return erreur(str(e), 400)
    journaliser("modification", document, document.titre)
    db.session.commit()
    return jsonify(document=document.to_dict())


@bp.post("/documents/<int:document_id>/fichier")
@role_required(*EQUIPE)
@unlock_required("machines")
def remplacer_fichier(document_id):
    """Nouvelle version du PDF (ex. notice mise à jour) : l'ancienne est remplacée."""
    document, err = _document_ou_404(document_id)
    if err:
        return err
    try:
        _verifier_pdf(request.files.get("fichier"))
    except Invalide as e:
        return erreur(str(e), 400)
    ancien = _enregistrer_fichier(document, request.files["fichier"])
    journaliser("modification", document, "Nouvelle version du fichier")
    db.session.commit()
    (_dossier() / ancien).unlink(missing_ok=True)
    return jsonify(document=document.to_dict())


@bp.delete("/documents/<int:document_id>")
@role_required("admin")
def supprimer_document(document_id):
    document, err = _document_ou_404(document_id)
    if err:
        return err
    fichier = document.fichier
    journaliser("suppression", document, document.titre)
    db.session.delete(document)
    db.session.commit()
    (_dossier() / fichier).unlink(missing_ok=True)
    return jsonify(ok=True)
