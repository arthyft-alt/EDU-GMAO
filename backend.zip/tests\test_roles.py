from datetime import date

import pytest

from app import db
from app.models import Atelier, GroupeEleves, Parametre, Role, RoleAttribution, Roue, SemaineCalendrier, Utilisateur

LUNDI = date(2026, 11, 16)


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: LUNDI)


@pytest.fixture()
def classe(app):
    # Trois élèves (tech, tech2 + un troisième), option activée
    db.session.add(Utilisateur(login="tech3", nom="Technicien 3 (démo)", role="technicien", actif=True, mot_de_passe_hash="x"))
    db.session.add(Parametre(cle="option_roles", valeur="1"))
    db.session.commit()


def roles_de(client, lundi):
    d = client.get(f"/api/roles?lundi={lundi}").get_json()
    return {a["eleve"]: a["role"] for a in d["roues"][0]["planning"][0]["attributions"]}


def test_option_desactivee(client, connecter):
    connecter("tech")
    assert client.get("/api/roles").get_json() == {"option": False, "roles": [], "roues": []}
    assert client.get("/api/roles/moi").get_json()["roles"] == []


def test_la_roue_tourne_chaque_semaine(client, connecter, classe):
    connecter("admin")
    ids = [client.post("/api/roles", json={"nom": nom}).get_json()["role"]["id"] for nom in ("Magasinier", "Préparateur")]
    assert client.post("/api/roles", json={"nom": "magasinier"}).status_code == 400  # doublon
    assert client.post("/api/roues", json={"nom": "Classe", "date_debut": "2026-11-18", "roles": ids}).status_code == 201
    db.session.add(SemaineCalendrier(lundi=date(2026, 11, 30), type="vacances"))
    db.session.commit()
    # 3 élèves (par ordre alphabétique), 2 rôles : chacun passe par chaque rôle, une semaine sans rôle
    s1 = roles_de(client, "2026-11-16")
    assert s1 == {"Technicien 1 (démo)": "Magasinier", "Technicien 2 (démo)": "Préparateur"}
    s2 = roles_de(client, "2026-11-23")
    assert s2 == {"Technicien 2 (démo)": "Magasinier", "Technicien 3 (démo)": "Préparateur"}
    assert roles_de(client, "2026-11-30") == {}  # vacances : la roue ne tourne pas
    s3 = roles_de(client, "2026-12-07")
    assert s3 == {"Technicien 3 (démo)": "Magasinier", "Technicien 1 (démo)": "Préparateur"}
    assert roles_de(client, "2026-12-14") == s1  # retour au départ après 3 semaines de cours
    # Échange forcé pour une semaine
    roue = client.get("/api/roles").get_json()["roues"][0]
    t1, t2 = (next(m["id"] for m in roue["membres"] if m["nom"] == n) for n in ("Technicien 1 (démo)", "Technicien 2 (démo)"))
    assert client.post(f"/api/roues/{roue['id']}/echanges", json={"lundi": "2026-11-16", "eleve_a_id": t1, "eleve_b_id": t2}).status_code == 201
    assert roles_de(client, "2026-11-16") == {"Technicien 1 (démo)": "Préparateur", "Technicien 2 (démo)": "Magasinier"}
    assert roles_de(client, "2026-11-23") == s2  # seulement cette semaine-là
    # L'élève voit son rôle de la semaine
    client.post("/api/auth/logout")
    connecter("tech2")
    assert [r["role"] for r in client.get("/api/roles/moi").get_json()["roles"]] == ["Magasinier"]


def test_role_fixe_d_atelier_et_roue_de_groupe(client, connecter, classe):
    connecter("admin")
    fonderie = Atelier.query.filter_by(nom="03. Fonderie").one()
    tech = Utilisateur.query.filter_by(login="tech").one()
    reponse = client.post("/api/roles", json={"nom": "Responsable Fonderie", "atelier_id": fonderie.id, "fixe": [{"utilisateur_id": tech.id}]})
    assert reponse.status_code == 201
    groupe = GroupeEleves(nom="Groupe A", membres=Utilisateur.query.filter(Utilisateur.login.in_(["tech2", "tech3"])).all())
    db.session.add(groupe)
    db.session.commit()
    secu = client.post("/api/roles", json={"nom": "Sécurité"}).get_json()["role"]["id"]
    assert client.post("/api/roues", json={"nom": "Groupe A", "groupe_id": groupe.id, "date_debut": "2026-11-16", "roles": [secu]}).status_code == 201
    fixe = Role.query.filter_by(nom="Responsable Fonderie").one().id
    assert client.post("/api/roues", json={"nom": "X", "date_debut": "2026-11-16", "roles": [fixe]}).status_code == 400  # rôle fixe
    semaine = client.get("/api/roles/semaine").get_json()["roles"]
    assert semaine[str(tech.id)][0]["atelier"] == "03. Fonderie" and semaine[str(tech.id)][0]["origine"] == "fixe"
    assert sum(1 for v in semaine.values() for r in v if r["role"] == "Sécurité") == 1
    client.post("/api/auth/logout")
    connecter("tech")
    assert client.get("/api/roles/moi").get_json()["ateliers"] == [{"id": fonderie.id, "nom": "03. Fonderie"}]
    assert client.post("/api/roles", json={"nom": "Pirate"}).status_code == 403
    # Écran d'atelier : le rôle s'affiche à côté de l'élève
    equipe = {e["nom"]: e for e in client.get("/api/ecran-atelier").get_json()["equipe"]}
    assert equipe["Technicien 1 (démo)"]["roles"] == ["Responsable Fonderie"]


def test_changement_d_annee_et_suppression_du_groupe(client, connecter, classe):
    connecter("admin")
    tech = Utilisateur.query.filter_by(login="tech").one()
    client.post("/api/roles", json={"nom": "Magasinier", "fixe": [{"utilisateur_id": tech.id}]})
    groupe = GroupeEleves(nom="Groupe B", membres=[tech])
    db.session.add(groupe)
    db.session.commit()
    secu = client.post("/api/roles", json={"nom": "Sécurité"}).get_json()["role"]["id"]
    client.post("/api/roues", json={"nom": "Groupe B", "groupe_id": groupe.id, "date_debut": "2026-11-16", "roles": [secu]})
    assert client.delete(f"/api/admin/groupes/{groupe.id}").status_code == 200
    assert Roue.query.count() == 0
    assert client.post("/api/admin/promotion/cloturer", json={"confirmation": "CLOTURER"}).status_code == 200
    assert RoleAttribution.query.count() == 0 and Role.query.count() == 2  # les rôles restent pour la classe suivante


def test_plus_de_roles_que_d_eleves(client, connecter, app):
    db.session.add(Parametre(cle="option_roles", valeur="1"))
    db.session.commit()
    connecter("admin")
    ids = [client.post("/api/roles", json={"nom": nom}).get_json()["role"]["id"] for nom in ("A", "B", "C")]
    client.post("/api/roues", json={"nom": "Classe", "date_debut": "2026-11-16", "roles": ids})
    # 2 élèves, 3 rôles : en 3 semaines, chacun a tenu les 3 rôles
    vus = {"Technicien 1 (démo)": set(), "Technicien 2 (démo)": set()}
    for lundi in ("2026-11-16", "2026-11-23", "2026-11-30"):
        for eleve, role in roles_de(client, lundi).items():
            vus[eleve].add(role)
    assert vus == {"Technicien 1 (démo)": {"A", "B", "C"}, "Technicien 2 (démo)": {"A", "B", "C"}}
