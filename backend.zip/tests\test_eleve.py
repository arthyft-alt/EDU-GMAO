from datetime import date, datetime

import pytest

from app import db
from app.models import (
    Atelier,
    BonIntervention,
    Chantier,
    ChantierAffectation,
    Machine,
    Projet,
    RealisationPreventive,
    TacheProjet,
    TachePreventive,
    Utilisateur,
)

SEMAINE = "debut=2026-11-18"  # semaine du lundi 16 novembre 2026


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: date(2026, 11, 18))


def eleve(login):
    return Utilisateur.query.filter_by(login=login).one()


@pytest.fixture()
def travail(app):
    tech, tech2 = eleve("tech"), eleve("tech2")
    machine = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.filter_by(nom="01. Maintenance").one())
    db.session.add(machine)
    db.session.flush()

    def bon(numero, statut, techniciens, **autres):
        b = BonIntervention(numero=numero, machine=machine, type_travail="depannage", urgence="normale", statut=statut,
                            demandeur="x", description="x", **autres)
        b.techniciens = techniciens
        db.session.add(b)

    bon("BI-1", "en_cours", [tech])
    bon("BI-2", "demande", [tech2])
    bon("BI-3", "termine", [tech], temps_passe_h=1.5, termine_le=datetime(2026, 11, 17, 10))
    db.session.add(Chantier(titre="Ranger", affectations=[ChantierAffectation(utilisateur=tech)]))
    perso = Chantier(titre="Fiche sécurité", mode="individuel",
                     affectations=[ChantierAffectation(utilisateur=tech, termine_le=datetime(2026, 11, 16, 9)), ChantierAffectation(utilisateur=tech2)])
    db.session.add(perso)
    projet = Projet(nom="Déploiement", date_debut=date(2026, 11, 2), principal=True)
    db.session.add(projet)
    db.session.flush()
    t1 = TacheProjet(projet=projet, nom="Cette semaine", ordre=1, duree_semaines=3)
    t1.techniciens = [tech]
    t2 = TacheProjet(projet=projet, nom="Plus tard", ordre=2, duree_semaines=1, debut_au_plus_tot=date(2027, 1, 4))
    t2.techniciens = [tech]
    db.session.add_all([t1, t2])
    # Préventif niveau 3 dû cette semaine, confié à personne ; niveau 1 : pas pour cette rubrique
    db.session.add(TachePreventive(machine=machine, nom="Contrôle des jeux", niveau=3, type_preventif="Inspection",
                                   periodicite="mois", date_debut=date(2026, 11, 19)))
    db.session.add(TachePreventive(machine=machine, nom="Graissage", niveau=1, type_preventif="Lubrification",
                                   periodicite="semaine", date_debut=date(2026, 11, 16)))
    db.session.commit()


def test_semaine_de_l_eleve(client, connecter, travail):
    connecter("tech")
    d = client.get(f"/api/eleve/semaine?{SEMAINE}").get_json()
    assert d["semaine"] == {"lundi": "2026-11-16", "dimanche": "2026-11-22", "numero": 47, "type": "cours"}
    assert [b["numero"] for b in d["bons"]] == ["BI-1"]
    assert [c["titre"] for c in d["chantiers"]] == ["Ranger"]  # sa part de « Fiche sécurité » est terminée
    assert [t["nom"] for t in d["taches_projet"]] == ["Cette semaine"]
    assert [t["nom"] for t in d["preventif_a_prendre"]] == ["Contrôle des jeux"]
    assert d["bilan"]["semaine"] == {"bons_termines": 1, "temps_passe_h": 1.5, "chantiers_termines": 1, "preventif_realise": 0}


def test_eleve_ne_voit_que_sa_semaine(client, connecter, travail):
    connecter("tech")
    d = client.get(f"/api/eleve/semaine?{SEMAINE}&technicien_id={eleve('tech2').id}").get_json()
    assert d["eleve"]["nom"] == "Technicien 1 (démo)"
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get(f"/api/eleve/semaine?{SEMAINE}").status_code == 403


def test_enseignant_choisit_l_eleve(client, connecter, travail):
    connecter("admin")
    assert client.get(f"/api/eleve/semaine?{SEMAINE}").status_code == 400
    d = client.get(f"/api/eleve/semaine?{SEMAINE}&technicien_id={eleve('tech2').id}").get_json()
    assert [b["numero"] for b in d["bons"]] == ["BI-2"] and [c["titre"] for c in d["chantiers"]] == ["Fiche sécurité"]


def test_preventif_confie_sort_de_a_prendre(client, connecter, travail):
    connecter("tech")
    tache = TachePreventive.query.filter_by(niveau=3).one()
    client.post(f"/api/preventif/taches/{tache.id}/confier", json={"ids": [eleve("tech").id]})
    d = client.get(f"/api/eleve/semaine?{SEMAINE}").get_json()
    assert d["preventif_a_prendre"] == [] and d["bons_preventifs"][0]["tache"]["id"] == tache.id


def test_position_des_eleves(client, connecter):
    connecter("tech")
    position = client.get("/api/eleve/position").get_json()["position"]
    assert (position["atelier"]["nom"], position["par_defaut"]) == ("02. ATN Maintenance", True)
    fonderie = Atelier.query.filter_by(nom="03. Fonderie").one().id
    assert client.put("/api/eleve/position", json={"atelier_id": fonderie}).get_json()["position"]["atelier"]["nom"] == "03. Fonderie"
    assert client.put("/api/eleve/position", json={"atelier_id": 999}).status_code == 400
    assert client.get("/api/eleve/positions").status_code == 403  # tableau réservé à l'enseignant
    client.post("/api/auth/logout")
    connecter("admin")
    tableau = {p["eleve"]["nom"]: p["atelier"]["nom"] for p in client.get("/api/eleve/positions").get_json()["positions"]}
    assert tableau == {"Technicien 1 (démo)": "03. Fonderie", "Technicien 2 (démo)": "02. ATN Maintenance"}
    # L'enseignant peut corriger la position d'un élève
    tech2 = eleve("tech2").id
    assert client.put("/api/eleve/position", json={"technicien_id": tech2, "atelier_id": fonderie}).status_code == 200
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get("/api/eleve/position").status_code == 403


def test_preventif_a_prendre_pour_la_repartition(client, connecter, travail):
    connecter("tech")
    assert [t["nom"] for t in client.get("/api/preventif/a-prendre").get_json()["taches"]] == ["Contrôle des jeux"]
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get("/api/preventif/a-prendre").status_code == 403
