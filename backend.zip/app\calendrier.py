"""Calendrier scolaire (FND-04) : semaines de vacances et d'apprentissage, dates d'examen et de formation."""
from datetime import date, datetime, timedelta

from flask import Blueprint, jsonify, request
from flask_login import login_required

from . import db
from .auth import erreur, role_required
from .dates import PARIS
from .models import EvenementCalendrier, SemaineCalendrier, journaliser

bp = Blueprint("calendrier", __name__)

TYPES_SEMAINE = ("cours", "vacances", "apprentissage")
TYPES_EVENEMENT = {"examen": "Examen", "formation": "Formation", "autre": "Autre"}


def lundi(jour):
    return jour - timedelta(days=jour.weekday())


def annee_scolaire(jour=None):
    """Année de début de l'année scolaire (du 1er août au 31 juillet)."""
    jour = jour or datetime.now(PARIS).date()
    return jour.year if jour >= date(jour.year, 8, 1) else jour.year - 1


def semaines_non_travaillees():
    """Lundis des semaines sans élèves au lycée (vacances et apprentissage) : sautées par le Gantt."""
    return {s.lundi for s in SemaineCalendrier.query.all()}


def semaines_de_vacances():
    """Lundis des semaines de vacances : aucune échéance préventive n'y tombe, et elles ne comptent pas
    dans le temps de fonctionnement des machines (indicateurs)."""
    return {s.lundi for s in SemaineCalendrier.query.filter_by(type="vacances")}


def jours_hors_vacances(du, au, vacances=None):
    """Nombre de jours de [du, au[ qui ne sont pas dans une semaine de vacances."""
    vacances = semaines_de_vacances() if vacances is None else vacances
    return sum(1 for i in range((au - du).days) if lundi(du + timedelta(days=i)) not in vacances)


@bp.get("/calendrier")
@login_required
def calendrier():
    """Semaines de l'année scolaire (numéro, type) et événements."""
    try:
        debut_annee = int(request.args.get("annee") or annee_scolaire())
    except ValueError:
        return erreur("Année invalide.", 400)
    premier = lundi(date(debut_annee, 8, 1))
    dernier = date(debut_annee + 1, 7, 31)
    types = {s.lundi: s.type for s in SemaineCalendrier.query.filter(SemaineCalendrier.lundi.between(premier, dernier))}
    semaines = []
    jour = premier
    while jour <= dernier:
        semaines.append({"lundi": jour.isoformat(), "numero": jour.isocalendar()[1], "type": types.get(jour, "cours")})
        jour += timedelta(days=7)
    evenements = EvenementCalendrier.query.filter(EvenementCalendrier.date.between(premier, dernier)).order_by(EvenementCalendrier.date)
    return jsonify(annee=debut_annee, semaines=semaines, evenements=[e.to_dict() for e in evenements], types_evenements=TYPES_EVENEMENT)


@bp.put("/calendrier/semaines")
@role_required("admin")
def changer_semaines():
    """Type d'une ou plusieurs semaines : {"lundis": ["2026-10-19", …], "type": "vacances"}."""
    donnees = request.get_json(silent=True) or {}
    type_semaine = donnees.get("type")
    if type_semaine not in TYPES_SEMAINE:
        return erreur("Type de semaine inconnu.", 400)
    try:
        lundis = {lundi(date.fromisoformat(str(j))) for j in donnees.get("lundis") or []}
    except ValueError:
        return erreur("Date invalide.", 400)
    for jour in lundis:
        semaine = SemaineCalendrier.query.filter_by(lundi=jour).first()
        if type_semaine == "cours":
            if semaine:
                db.session.delete(semaine)
        elif semaine:
            semaine.type = type_semaine
        else:
            db.session.add(SemaineCalendrier(lundi=jour, type=type_semaine))
    journaliser("modification", details=f"Calendrier : {len(lundis)} semaine(s) en « {type_semaine} »")
    db.session.commit()
    return jsonify(ok=True)


@bp.post("/calendrier/evenements")
@role_required("admin")
def ajouter_evenement():
    donnees = request.get_json(silent=True) or {}
    titre = str(donnees.get("titre") or "").strip()
    if not titre:
        return erreur("Donnez un titre à l'événement (ex. : épreuve E4).", 400)
    if donnees.get("type") not in TYPES_EVENEMENT:
        return erreur("Choisissez le type : examen, formation ou autre.", 400)
    try:
        jour = date.fromisoformat(str(donnees.get("date")))
    except ValueError:
        return erreur("Indiquez la date.", 400)
    evenement = EvenementCalendrier(date=jour, titre=titre[:160], type=donnees["type"])
    db.session.add(evenement)
    db.session.flush()
    journaliser("creation", evenement, titre)
    db.session.commit()
    return jsonify(evenement=evenement.to_dict()), 201


@bp.delete("/calendrier/evenements/<int:evenement_id>")
@role_required("admin")
def supprimer_evenement(evenement_id):
    evenement = db.session.get(EvenementCalendrier, evenement_id)
    if not evenement:
        return erreur("Événement introuvable.", 404)
    journaliser("suppression", evenement, evenement.titre)
    db.session.delete(evenement)
    db.session.commit()
    return jsonify(ok=True)
