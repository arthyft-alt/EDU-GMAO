import io
from datetime import date, timedelta

import pytest

from app import db
from app.models import Atelier, BonIntervention, Machine, Pictogramme, RealisationPreventive, TachePreventive, Utilisateur
from app.preventif import etat, indice_courant, occurrence

AUJOURDHUI = date(2026, 11, 16)  # un lundi


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: AUJOURDHUI)


@pytest.fixture()
def machines(app):
    maintenance = Atelier.query.filter_by(nom="01. Maintenance").one()
    fonderie = Atelier.query.filter_by(nom="03. Fonderie").one()
    m1 = Machine(repere="MAI-01", designation="Tour", atelier=maintenance)
    m2 = Machine(repere="FON-01", designation="Four", atelier=fonderie)
    db.session.add_all([m1, m2])
    db.session.commit()
    return m1, m2


def donnees_tache(machine, **autres):
    return {
        "machine_id": machine.id,
        "nom": "Graissage des glissières",
        "niveau": 1,
        "type_preventif": "Lubrification",
        "periodicite": "semaine",
        "date_debut": "2026-11-02",
        "temps_estime_min": "15",
        "operations": "Nettoyer\nGraisser",
        **autres,
    }


def creer(client, machine, **autres):
    reponse = client.post("/api/preventif/taches", json=donnees_tache(machine, **autres))
    assert reponse.status_code == 201, reponse.get_json()
    return reponse.get_json()["tache"]


# ---------- Calcul des échéances (dates fixes, sans cumul) ----------

def tache(periodicite, debut):
    return TachePreventive(periodicite=periodicite, date_debut=debut)


def test_echeances_hebdomadaires():
    t = tache("semaine", date(2026, 11, 2))
    assert [occurrence(t, k) for k in range(3)] == [date(2026, 11, 2), date(2026, 11, 9), date(2026, 11, 16)]
    assert indice_courant(t, date(2026, 11, 1)) == -1
    assert indice_courant(t, date(2026, 11, 15)) == 1
    assert indice_courant(t, date(2026, 11, 16)) == 2


def test_echeances_mensuelles_fin_de_mois():
    t = tache("mois", date(2026, 1, 31))
    assert [occurrence(t, k) for k in range(4)] == [date(2026, 1, 31), date(2026, 2, 28), date(2026, 3, 31), date(2026, 4, 30)]
    assert indice_courant(t, date(2026, 3, 30)) == 1
    assert indice_courant(t, date(2026, 3, 31)) == 2
    assert occurrence(tache("an", date(2024, 2, 29)), 1) == date(2025, 2, 28)


def test_echeance_manquee_ne_se_cumule_pas(app):
    t = tache("semaine", date(2026, 11, 2))
    # Rien n'a été fait les 2 et 9 novembre : le 16, une seule tâche est à faire (celle du 16)
    e = etat(t, AUJOURDHUI, realisees=set())
    assert (e["statut"], e["echeance"]) == ("a_faire", "2026-11-16")
    # Le 18, même semaine : toujours « à faire » (le préventif est pensé en semaines)
    e = etat(t, date(2026, 11, 18), realisees=set())
    assert (e["statut"], e["echeance"], e["prochaine_echeance"]) == ("a_faire", "2026-11-16", "2026-11-23")


def test_en_retard_seulement_la_semaine_suivante(app):
    t = tache("mois", date(2026, 11, 20))  # vendredi
    assert etat(t, date(2026, 11, 16), realisees=set())["statut"] == "a_faire"  # lundi de la même semaine
    assert etat(t, date(2026, 11, 22), realisees=set())["statut"] == "a_faire"  # dimanche
    e = etat(t, date(2026, 11, 23), realisees=set())  # lundi suivant
    assert (e["statut"], e["echeance"]) == ("en_retard", "2026-11-20")
    assert etat(t, date(2026, 11, 23), realisees={date(2026, 11, 20)})["statut"] == "fait"


def test_dates_fixes_meme_si_realisee_en_retard(app):
    t = tache("semaine", date(2026, 11, 2))
    e = etat(t, date(2026, 11, 20), realisees={date(2026, 11, 16)})
    assert (e["statut"], e["prochaine_echeance"]) == ("fait", "2026-11-23")  # pas décalée au 27


# ---------- Création et droits de rédaction ----------

def test_technicien_redige_une_tache(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0])
    assert t["statut"] == "a_faire" and t["echeance"] == "2026-11-16"
    detail = client.get(f"/api/preventif/taches/{t['id']}").get_json()["tache"]
    assert detail["redacteur"] == "Technicien 1 (démo)" and detail["date_redaction"] == "2026-11-16"
    assert detail["periodicite_libelle"] == "Semaine"


@pytest.mark.parametrize(
    "champs,message",
    [({"nom": ""}, "nom"), ({"niveau": 7}, "niveau"), ({"type_preventif": "Peinture"}, "type"),
     ({"periodicite": "jour"}, "périodicité"), ({"date_debut": ""}, "date"), ({"temps_estime_min": "abc"}, "minutes")],
)
def test_tache_invalide(client, connecter, machines, champs, message):
    connecter("tech")
    reponse = client.post("/api/preventif/taches", json=donnees_tache(machines[0], **champs))
    assert reponse.status_code == 400 and message in reponse.get_json()["error"]


def test_operateur_ne_redige_pas(client, connecter, machines):
    connecter("operateur")
    assert client.post("/api/preventif/taches", json=donnees_tache(machines[0])).status_code == 403


def test_suppression_admin_seulement_et_sans_historique(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0])
    assert client.delete(f"/api/preventif/taches/{t['id']}").status_code == 403
    client.post(f"/api/preventif/taches/{t['id']}/realiser")
    client.post("/api/auth/logout")
    connecter("admin")
    assert client.delete(f"/api/preventif/taches/{t['id']}").status_code == 409
    assert client.put(f"/api/preventif/taches/{t['id']}", json=donnees_tache(machines[0], actif=False)).status_code == 200
    assert client.get("/api/preventif/taches").get_json()["taches"] == []
    assert len(client.get("/api/preventif/taches?inactives=1").get_json()["taches"]) == 1


# ---------- Cochage ----------

def test_cochage_et_anticipation(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0])
    url = f"/api/preventif/taches/{t['id']}/realiser"
    fait = client.post(url).get_json()["tache"]
    assert fait["statut"] == "fait" and fait["derniere_realisation"]["echeance"] == "2026-11-16"
    # L'échéance suivante (23/11) arrive dans 7 jours : elle peut être faite en avance
    assert fait["anticipable"] is True
    assert client.post(url).get_json()["tache"]["derniere_realisation"]["echeance"] == "2026-11-23"
    reponse = client.post(url)
    assert reponse.status_code == 409 and "prochaine échéance" in reponse.get_json()["error"]
    # Décocher
    assert client.delete(f"{url}/2026-11-23").status_code == 200
    assert client.delete(f"{url}/2026-11-23").status_code == 404


def test_operateur_coche_les_niveaux_1_2_de_tous_les_ateliers(client, connecter, machines):
    connecter("tech")
    n1 = creer(client, machines[0])
    n3 = creer(client, machines[0], nom="Contrôle des jeux", niveau=3)
    autre_atelier = creer(client, machines[1], nom="Nettoyage du four", niveau=2)
    client.post("/api/auth/logout")
    connecter("operateur")  # compte unique : l'opérateur choisit son atelier
    assert client.post(f"/api/preventif/taches/{n1['id']}/realiser").status_code == 201
    assert client.post(f"/api/preventif/taches/{n3['id']}/realiser").status_code == 404  # niveau 3 : invisible
    assert client.post(f"/api/preventif/taches/{autre_atelier['id']}/realiser").status_code == 201


def test_operateur_choisit_son_atelier(client, connecter, machines):
    connecter("tech")
    maintenance = creer(client, machines[0])
    fonderie = creer(client, machines[1], nom="Nettoyage du four")
    Utilisateur.query.filter_by(login="operateur").one().atelier_id = None
    db.session.commit()
    client.post("/api/auth/logout")
    connecter("operateur")
    reponse = client.get("/api/preventif/a-faire").get_json()
    assert reponse["taches"] == [] and "Choisissez" in reponse["message"]
    a_faire = client.get(f"/api/preventif/a-faire?atelier_id={machines[1].atelier_id}").get_json()
    assert [t["id"] for t in a_faire["taches"]] == [fonderie["id"]] and a_faire["atelier_id"] == machines[1].atelier_id
    assert [t["id"] for t in client.get(f"/api/preventif/taches?atelier_id={machines[0].atelier_id}").get_json()["taches"]] == [maintenance["id"]]


# ---------- To-Do et planning ----------

def test_to_do_de_l_operateur(client, connecter, machines):
    connecter("tech")
    a_faire = creer(client, machines[0])
    creer(client, machines[0], nom="Vidange", periodicite="mois", date_debut="2026-12-20")  # lointaine
    creer(client, machines[0], nom="Contrôle", niveau=3)
    creer(client, machines[1], nom="Nettoyage du four")
    client.post("/api/auth/logout")
    connecter("operateur")
    assert [t["id"] for t in client.get("/api/preventif/a-faire").get_json()["taches"]] == [a_faire["id"]]


def test_to_do_technicien_retards_en_premier(client, connecter, machines):
    connecter("tech")
    du_jour = creer(client, machines[0], nom="A", date_debut="2026-11-16", periodicite="mois")
    retard = creer(client, machines[0], nom="B", date_debut="2026-11-10", periodicite="mois")
    bientot = creer(client, machines[0], nom="C", date_debut="2026-11-20", periodicite="mois")
    ids = [t["id"] for t in client.get("/api/preventif/a-faire").get_json()["taches"]]
    assert ids == [retard["id"], du_jour["id"], bientot["id"]]


def test_planning(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0])
    client.post(f"/api/preventif/taches/{t['id']}/realiser")
    occurrences = client.get("/api/preventif/planning?du=2026-11-01&au=2026-11-30").get_json()["occurrences"]
    assert [(o["echeance"], o["statut"]) for o in occurrences] == [
        ("2026-11-02", "non_realisee"), ("2026-11-09", "non_realisee"), ("2026-11-16", "fait"),
        ("2026-11-23", "a_venir"), ("2026-11-30", "a_venir"),
    ]
    assert client.get("/api/preventif/planning?du=2026-01-01&au=2028-01-01").status_code == 400


def test_historique_et_resume_machine(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0])
    creer(client, machines[0], nom="Retard", date_debut="2026-11-10", periodicite="mois")
    client.post(f"/api/preventif/taches/{t['id']}/realiser")
    historique = client.get(f"/api/preventif/taches/{t['id']}").get_json()["tache"]["historique"]
    assert [(h["echeance"], h["realisation"] is not None) for h in historique] == [
        ("2026-11-16", True), ("2026-11-09", False), ("2026-11-02", False)
    ]
    resume = client.get(f"/api/machines/{machines[0].id}/preventif").get_json()
    assert resume == {"en_retard": 1, "a_faire": 0, "prochaine_echeance": "2026-11-23"}


# ---------- Tâche confiée (niveaux 3-4) ----------

def test_tache_confiee_cree_un_bon_de_preventif(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0], nom="Contrôle des jeux", niveau=3)
    tech2 = Utilisateur.query.filter_by(login="tech2").one().id
    reponse = client.post(f"/api/preventif/taches/{t['id']}/confier", json={"ids": [tech2]})
    assert reponse.status_code == 201
    bon = reponse.get_json()["bon"]
    assert bon["echeance"] == "2026-11-16" and bon["tache"]["nom"] == "Contrôle des jeux" and bon["machine"]["repere"] == "MAI-01"
    assert [x["nom"] for x in bon["techniciens"]] == ["Technicien 2 (démo)"]
    assert BonIntervention.query.count() == 0  # pas de bon d'intervention
    assert client.post(f"/api/preventif/taches/{t['id']}/confier", json={}).status_code == 409  # déjà confiée
    assert [b["id"] for b in client.get("/api/preventif/bons?ouverts=1").get_json()["bons"]] == [bon["id"]]
    assert client.get(f"/api/preventif/bons?technicien_id={tech2}").get_json()["bons"][0]["id"] == bon["id"]
    # L'échéance confiée n'est plus « à prendre »
    assert client.get("/api/eleve/semaine?debut=2026-11-16").get_json()["preventif_a_prendre"] == []


def test_fait_en_un_clic_reserve_aux_eleves_du_bon(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0], nom="Contrôle des jeux", niveau=3)
    tech2 = Utilisateur.query.filter_by(login="tech2").one().id
    bon = client.post(f"/api/preventif/taches/{t['id']}/confier", json={"ids": [tech2]}).get_json()["bon"]
    assert client.post(f"/api/preventif/bons/{bon['id']}/fait").status_code == 403  # tech n'est pas sur le bon
    client.post("/api/auth/logout")
    connecter("tech2")
    assert client.get("/api/eleve/semaine?debut=2026-11-16").get_json()["bons_preventifs"][0]["id"] == bon["id"]
    reponse = client.post(f"/api/preventif/bons/{bon['id']}/fait")
    assert reponse.status_code == 200 and reponse.get_json()["bon"]["termine_le"]
    assert client.post(f"/api/preventif/bons/{bon['id']}/fait").status_code == 409  # déjà fait
    r = RealisationPreventive.query.one()
    assert r.echeance == date(2026, 11, 16) and r.par_id == tech2
    assert client.get("/api/preventif/bons?ouverts=1").get_json()["bons"] == []
    assert client.get("/api/eleve/semaine").get_json()["bilan"]["semaine"]["preventif_realise"] == 1  # fait aujourd'hui


def test_enseignant_valide_et_decocher_rouvre_le_bon(client, connecter, machines):
    connecter("admin")
    t = creer(client, machines[0], nom="Contrôle des jeux", niveau=4)
    bon = client.post(f"/api/preventif/taches/{t['id']}/confier", json={}).get_json()["bon"]
    tech = Utilisateur.query.filter_by(login="tech").one().id
    assert client.put(f"/api/preventif/bons/{bon['id']}/techniciens", json={"ids": [tech]}).get_json()["bon"]["techniciens"][0]["id"] == tech
    assert client.put(f"/api/preventif/bons/{bon['id']}/techniciens", json={"ids": [9999]}).status_code == 400
    # Cocher l'échéance dans le plan clôt le bon ; la décocher le rouvre
    assert client.post(f"/api/preventif/taches/{t['id']}/realiser", json={"echeance": "2026-11-16"}).status_code == 201
    assert client.get("/api/preventif/bons?ouverts=1").get_json()["bons"] == []
    assert client.delete(f"/api/preventif/taches/{t['id']}/realiser/2026-11-16").status_code == 200
    assert len(client.get("/api/preventif/bons?ouverts=1").get_json()["bons"]) == 1
    assert client.post(f"/api/preventif/bons/{bon['id']}/fait").status_code == 200  # l'enseignant peut valider
    assert client.delete(f"/api/preventif/taches/{t['id']}").status_code == 409  # la tâche a un historique


def test_seule_l_echeance_en_cours_est_confiee(client, connecter, machines):
    connecter("admin")
    t = creer(client, machines[0], nom="Graissage", niveau=3, periodicite="semaine")
    assert client.get(f"/api/preventif/taches/{t['id']}").get_json()["tache"]["bon_preventif"] is None
    tech = Utilisateur.query.filter_by(login="tech").one().id
    tech2 = Utilisateur.query.filter_by(login="tech2").one().id
    bon = client.post(f"/api/preventif/taches/{t['id']}/confier", json={"ids": [tech]}).get_json()["bon"]
    fiche = client.get(f"/api/preventif/taches/{t['id']}").get_json()["tache"]
    assert fiche["bon_preventif"] == {"id": bon["id"], "techniciens": [{"id": tech, "nom": "Technicien 1 (démo)"}]}
    a_faire = client.get("/api/preventif/a-faire").get_json()["taches"]
    assert a_faire[0]["bon_preventif"]["id"] == bon["id"]
    # Un autre élève ne coche pas une échéance confiée à quelqu'un d'autre
    client.post("/api/auth/logout")
    connecter("tech2")
    assert client.post(f"/api/preventif/taches/{t['id']}/realiser").status_code == 403
    client.post("/api/auth/logout")
    connecter("tech")
    assert client.post(f"/api/preventif/taches/{t['id']}/realiser").status_code == 201
    # L'échéance suivante n'est confiée à personne : elle peut aller à un autre élève
    fiche = client.get(f"/api/preventif/taches/{t['id']}").get_json()["tache"]
    assert fiche["echeance"] == "2026-11-23" and fiche["bon_preventif"] is None
    suivant = client.post(f"/api/preventif/taches/{t['id']}/confier", json={"ids": [tech2]})
    assert suivant.status_code == 201 and suivant.get_json()["bon"]["echeance"] == "2026-11-23"


def test_operateur_sans_acces_aux_bons_de_preventif(client, connecter):
    connecter("operateur")
    assert client.get("/api/preventif/bons").status_code == 403


def test_seuls_les_niveaux_3_4_se_confient(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0])
    assert client.post(f"/api/preventif/taches/{t['id']}/confier", json={}).status_code == 400


def test_machine_avec_plan_non_supprimable(client, connecter, machines):
    connecter("admin")
    creer(client, machines[0])
    assert client.delete(f"/api/machines/{machines[0].id}").status_code == 409


# ---------- Photos et pictogrammes ----------

def test_photos(client, connecter, machines):
    connecter("tech")
    t = creer(client, machines[0])
    url = f"/api/preventif/taches/{t['id']}/photos"
    image = lambda: (io.BytesIO(b"\xff\xd8\xff photo"), "p.jpg", "image/jpeg")
    for _ in range(4):
        assert client.post(url, data={"photo": image(), "legende": "Graisseur"}, content_type="multipart/form-data").status_code == 201
    assert client.post(url, data={"photo": image()}, content_type="multipart/form-data").status_code == 400  # 4 maximum
    photos = client.get(f"/api/preventif/taches/{t['id']}").get_json()["tache"]["photos"]
    assert photos[0]["legende"] == "Graisseur"
    client.post("/api/auth/logout")
    connecter("operateur")  # niveau 1 : l'opérateur voit le mode opératoire et ses photos
    assert client.get(f"/api/preventif/photos/{photos[0]['id']}").data.startswith(b"\xff\xd8\xff")


def test_pictogrammes(client, connecter, machines):
    connecter("tech")
    integres = client.get("/api/pictogrammes").get_json()["pictogrammes"]
    assert len(integres) == 18
    gants = next(p for p in integres if p["code"] == "epi_gants")
    t = creer(client, machines[0], pictogrammes=[gants["id"]])
    assert [p["code"] for p in client.get(f"/api/preventif/taches/{t['id']}").get_json()["tache"]["pictogrammes"]] == ["epi_gants"]
    assert client.post("/api/pictogrammes", data={}, content_type="multipart/form-data").status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    assert client.delete(f"/api/pictogrammes/{gants['id']}").status_code == 409  # intégré
    image = (io.BytesIO(b"<svg xmlns='http://www.w3.org/2000/svg'/>"), "laser.svg", "image/svg+xml")
    nouveau = client.post("/api/pictogrammes", data={"nom": "Danger laser", "categorie": "danger", "image": image}, content_type="multipart/form-data")
    assert nouveau.status_code == 201
    picto_id = nouveau.get_json()["pictogramme"]["id"]
    assert client.get(f"/api/pictogrammes/{picto_id}/image").status_code == 200
    assert client.delete(f"/api/pictogrammes/{picto_id}").status_code == 200


# ---------- Utilisateurs ----------

def test_gestion_des_utilisateurs(client, connecter):
    connecter("tech")
    assert client.get("/api/admin/utilisateurs").status_code == 403
    client.post("/api/auth/logout")
    connecter("admin")
    fonderie = Atelier.query.filter_by(nom="03. Fonderie").one().id
    reponse = client.post("/api/admin/utilisateurs", json={"login": "Op-Fonderie", "nom": "Opérateur fonderie", "role": "operateur", "atelier_id": fonderie, "password": "fonte"})
    assert reponse.status_code == 201
    u = reponse.get_json()["utilisateur"]
    assert (u["login"], u["atelier"]) == ("op-fonderie", "03. Fonderie")
    assert client.post("/api/admin/utilisateurs", json={"login": "op-fonderie", "nom": "x", "role": "operateur", "password": "abcd"}).status_code == 400
    assert client.post("/api/admin/utilisateurs", json={"login": "x", "nom": "x", "role": "operateur", "password": "ab"}).status_code == 400
    assert client.put(f"/api/admin/utilisateurs/{u['id']}/mot-de-passe", json={"password": "nouveau"}).status_code == 200
    client.put(f"/api/admin/utilisateurs/{u['id']}", json={"nom": "Op. fonderie", "role": "operateur", "atelier_id": fonderie, "actif": False})
    client.post("/api/auth/logout")
    assert client.post("/api/auth/login", json={"login": "op-fonderie", "password": "nouveau"}).status_code == 403  # désactivé


def test_admin_ne_peut_pas_se_retirer_ses_droits(client, connecter):
    connecter("admin")
    moi = Utilisateur.query.filter_by(login="admin").one().id
    reponse = client.put(f"/api/admin/utilisateurs/{moi}", json={"nom": "Admin", "role": "technicien"})
    assert reponse.status_code == 400


# ---------- Retours de Simon du 28/10 ----------

def test_a_faire_par_niveaux_et_mes_taches(client, connecter, machines):
    from app.models import BonPreventif

    tech = Utilisateur.query.filter_by(login="tech").one()
    n1 = TachePreventive(machine=machines[0], nom="Nettoyage", niveau=1, type_preventif="Nettoyage", periodicite="semaine", date_debut=AUJOURDHUI)
    n4 = TachePreventive(machine=machines[0], nom="Révision", niveau=4, type_preventif="Inspection", periodicite="mois", date_debut=AUJOURDHUI - timedelta(days=14))
    db.session.add_all([n1, n4])
    db.session.flush()
    db.session.add(BonPreventif(tache_id=n4.id, echeance=AUJOURDHUI - timedelta(days=14), techniciens=[tech]))
    db.session.commit()
    connecter("tech")
    toutes = client.get("/api/preventif/a-faire").get_json()["taches"]
    assert [t["nom"] for t in toutes] == ["Nettoyage", "Révision"]  # tri par niveau
    assert [t["nom"] for t in client.get("/api/preventif/a-faire?niveaux=3,4").get_json()["taches"]] == ["Révision"]
    assert [t["nom"] for t in client.get("/api/preventif/a-faire?mes=1").get_json()["taches"]] == ["Révision"]
    assert client.get("/api/preventif/retards").get_json()["nombre"] == 1
    connecter("tech2")
    assert client.get("/api/preventif/a-faire?mes=1").get_json()["taches"] == []


def test_referentiels_publics_sans_connexion(client):
    d = client.get("/api/public/tache-preventive/referentiels").get_json()
    assert d["types_preventif"] and "semaine" in d["periodicites"] and d["niveaux"]["1"]
    assert all(p["code"] for p in d["pictogrammes"])  # seulement les pictogrammes intégrés
    assert client.get("/api/preventif/retards").status_code == 401
