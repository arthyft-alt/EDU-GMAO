import re

import pytest

from app import db
from app.models import Utilisateur


def test_mot_de_passe_propose_simple_et_assez_long(client, connecter):
    connecter("admin")
    eleve = client.get("/api/admin/mot-de-passe-propose?role=technicien").get_json()["password"]
    admin = client.get("/api/admin/mot-de-passe-propose?role=admin").get_json()["password"]
    assert re.fullmatch(r"[a-z]{4,}\d\d", eleve) and len(admin) >= 8
    assert "l" not in eleve


def test_fiches_de_connexion_donnent_de_nouveaux_mots_de_passe(client, connecter):
    connecter("admin")
    ids = [u.id for u in Utilisateur.query.filter(Utilisateur.login.in_(["tech", "tech2"]))]
    fiches = client.post("/api/admin/utilisateurs/fiches-connexion", json={"ids": ids}).get_json()["fiches"]
    assert {f["login"] for f in fiches} == {"tech", "tech2"}
    client.post("/api/auth/logout")
    assert client.post("/api/auth/login", json={"login": "tech", "password": "tech"}).status_code == 401
    fiche = next(f for f in fiches if f["login"] == "tech")
    assert client.post("/api/auth/login", json={"login": "tech", "password": fiche["password"]}).status_code == 200


def test_fiches_de_connexion_eleves_seulement(client, connecter):
    connecter("admin")
    admin = Utilisateur.query.filter_by(login="admin").one()
    assert client.post("/api/admin/utilisateurs/fiches-connexion", json={"ids": [admin.id]}).status_code == 400
    assert client.post("/api/admin/utilisateurs/fiches-connexion", json={"ids": []}).status_code == 400
    connecter("tech")
    assert client.post("/api/admin/utilisateurs/fiches-connexion", json={"ids": [admin.id]}).status_code == 403


def test_connexion_operateur_par_qr_code(client, connecter):
    connecter("admin")
    op = client.get("/api/admin/qr-operateurs").get_json()["operateurs"][0]
    assert op["login"] == "operateur" and len(op["jeton"]) > 20
    assert client.get("/api/admin/qr-operateurs").get_json()["operateurs"][0]["jeton"] == op["jeton"]  # stable
    client.post("/api/auth/logout")

    assert client.post("/api/auth/qr", json={"jeton": "faux"}).status_code == 401
    reponse = client.post("/api/auth/qr", json={"jeton": op["jeton"]})
    assert reponse.status_code == 200 and reponse.get_json()["utilisateur"]["role"] == "operateur"

    # Renouveler : l'ancien QR code ne marche plus
    connecter("admin")
    nouveau = client.post(f"/api/admin/qr-operateurs/{op['id']}/renouveler").get_json()["operateur"]["jeton"]
    client.post("/api/auth/logout")
    assert client.post("/api/auth/qr", json={"jeton": op["jeton"]}).status_code == 401
    assert client.post("/api/auth/qr", json={"jeton": nouveau}).status_code == 200


def test_qr_code_compte_desactive(client, connecter):
    connecter("admin")
    op = client.get("/api/admin/qr-operateurs").get_json()["operateurs"][0]
    db.session.get(Utilisateur, op["id"]).actif = False
    db.session.commit()
    client.post("/api/auth/logout")
    assert client.post("/api/auth/qr", json={"jeton": op["jeton"]}).status_code == 403


@pytest.mark.parametrize("login", ["tech", "operateur"])
def test_qr_reserve_a_l_admin(client, connecter, login):
    connecter(login)
    assert client.get("/api/admin/qr-operateurs").status_code == 403
