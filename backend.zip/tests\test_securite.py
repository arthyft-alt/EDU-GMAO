import pytest

from app import db
from app.models import Atelier, Machine, Pictogramme


@pytest.fixture()
def machine(app):
    m = Machine(repere="FON-03", designation="Presse", marque="Bêta", modele="P200", annee_mise_en_service=2004,
                numero_serie="X123", atelier=Atelier.query.first())
    db.session.add(m)
    db.session.commit()
    return m


def ips_complete():
    lunettes = Pictogramme.query.filter_by(code="epi_lunettes").one()
    return {
        "conformite": "oui",
        "accessibilite": "conditions",
        "pictogrammes": [lunettes.id],
        "risques": ["Écrasement des mains", "  ", "Projection d'huile"],
        "consignes": ["Ne jamais neutraliser le carter"],
    }


def test_redaction_avec_mot_de_passe_machines(client, connecter, machine):
    connecter("tech")
    vide = client.get(f"/api/machines/{machine.id}/ips").get_json()["ips"]
    assert vide["existe"] is False and vide["machine"]["type"] == "P200" and vide["machine"]["annee"] == 2004
    assert client.put(f"/api/machines/{machine.id}/ips", json=ips_complete()).status_code == 403  # sans mot de passe
    reponse = client.put(f"/api/machines/{machine.id}/ips", json=ips_complete(), headers={"X-Unlock-Password": "1234"})
    assert reponse.status_code == 200, reponse.get_json()
    ips = reponse.get_json()["ips"]
    assert ips["risques"] == ["Écrasement des mains", "Projection d'huile"]
    assert ips["modifie_par"] == "Technicien 1 (démo)" and ips["valide_le"] is None
    assert client.post(f"/api/machines/{machine.id}/ips/valider").status_code == 403  # visa : enseignant seulement


def test_valeurs_invalides(client, connecter, machine):
    connecter("admin")
    assert client.put(f"/api/machines/{machine.id}/ips", json={"conformite": "peut-etre"}).status_code == 400
    assert client.put(f"/api/machines/{machine.id}/ips", json={"accessibilite": "libre"}).status_code == 400
    assert client.put(f"/api/machines/{machine.id}/ips", json={"pictogrammes": [9999]}).status_code == 400
    assert client.post(f"/api/machines/{machine.id}/ips/valider").status_code == 409  # rien à valider


def test_visa_retire_a_la_modification_et_acces_public(client, connecter, machine):
    connecter("admin")
    jeton = client.put(f"/api/machines/{machine.id}/ips", json=ips_complete()).get_json()["ips"]["jeton"]
    client.post("/api/auth/logout")
    assert client.get(f"/api/public/ips/{jeton}").status_code == 404  # pas encore validée

    connecter("admin")
    valide = client.post(f"/api/machines/{machine.id}/ips/valider").get_json()["ips"]
    assert valide["valide_par"] == "Administrateur (démo)" and valide["valide_le"]
    client.post("/api/auth/logout")
    publique = client.get(f"/api/public/ips/{jeton}").get_json()["ips"]
    assert publique["machine"]["repere"] == "FON-03" and "jeton" not in publique
    assert client.get("/api/public/ips/devine").status_code == 404

    # Une modification retire le visa : la fiche publique n'est plus visible
    connecter("admin")
    client.put(f"/api/machines/{machine.id}/ips", json={**ips_complete(), "consignes": ["Nouvelle consigne"]})
    client.post("/api/auth/logout")
    assert client.get(f"/api/public/ips/{jeton}").status_code == 404


def test_renouveler_le_qr_code(client, connecter, machine):
    connecter("admin")
    ancien = client.put(f"/api/machines/{machine.id}/ips", json=ips_complete()).get_json()["ips"]["jeton"]
    client.post(f"/api/machines/{machine.id}/ips/valider")
    nouveau = client.post(f"/api/machines/{machine.id}/ips/renouveler-qr").get_json()["ips"]["jeton"]
    assert nouveau != ancien
    client.post("/api/auth/logout")
    assert client.get(f"/api/public/ips/{ancien}").status_code == 404
    assert client.get(f"/api/public/ips/{nouveau}").status_code == 200


def test_operateur_sans_acces(client, connecter, machine):
    connecter("operateur")
    assert client.get(f"/api/machines/{machine.id}/ips").status_code == 403
