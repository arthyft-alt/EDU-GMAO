from datetime import date, datetime

import pytest

from app import db
from app.models import (
    Atelier,
    BonComposant,
    BonIntervention,
    BonPreventif,
    Chantier,
    ChantierAffectation,
    Commande,
    CommandeLigne,
    Document,
    DocumentMachine,
    Element,
    GroupeEleves,
    IpsMachine,
    JournalAction,
    Machine,
    Mouvement,
    PanierLigne,
    Parametre,
    Piece,
    PieceMachine,
    RealisationPreventive,
    TachePhoto,
    TachePiece,
    TachePreventive,
    Utilisateur,
)

AUJOURDHUI = date(2026, 7, 6)  # fin d'année scolaire


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: AUJOURDHUI)


@pytest.fixture()
def atelier(app):
    tech, tech2 = (Utilisateur.query.filter_by(login=l).one() for l in ("tech", "tech2"))
    tour = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.filter_by(nom="01. Maintenance").one(), photo="1_tour.jpg")
    roulement = Piece(reference="00001", designation="Roulement", categorie="Mécanique", quantite=10, prix_unitaire=6)
    doc = Document(titre="Notice", categorie="Notice", fichier="notice.pdf", nom_original="notice.pdf", taille=10)
    tache = TachePreventive(machine=tour, nom="Graissage", niveau=3, type_preventif="Lubrification", periodicite="mois", date_debut=date(2026, 1, 5))
    bon_ouvert = BonIntervention(numero="BI-1", machine=tour, type_travail="depannage", demandeur="x", description="Bruit", statut="en_cours", techniciens=[tech])
    bon_fini = BonIntervention(numero="BI-2", machine=tour, type_travail="depannage", demandeur="x", description="Fuite", statut="termine",
                               termine_le=datetime(2026, 3, 1), techniciens=[tech, tech2])
    chantier = Chantier(titre="Carter", machine=tour, statut="en_cours")
    db.session.add_all([tour, roulement, doc, tache, bon_ouvert, bon_fini, chantier])
    db.session.flush()
    composant = BonComposant(bon=bon_fini, piece_id=roulement.id, designation="Roulement", quantite=2, prix_unitaire=6)
    db.session.add_all([
        composant,
        Mouvement(piece=roulement, type="sortie", quantite=-2, stock_apres=8, bon=bon_fini),
        PieceMachine(piece=roulement, machine=tour, element=Element.query.first()),
        DocumentMachine(document_id=doc.id, machine_id=tour.id),
        TachePhoto(tache_id=tache.id, fichier="1_photo.jpg"),
        TachePiece(tache_id=tache.id, piece_id=roulement.id, quantite=1),
        RealisationPreventive(tache=tache, echeance=date(2026, 2, 2), par_id=tech.id),
        BonPreventif(tache=tache, echeance=date(2026, 7, 6), techniciens=[tech2]),
        IpsMachine(machine=tour, jeton="abc"),
        ChantierAffectation(chantier=chantier, utilisateur=tech),
        PanierLigne(piece_id=roulement.id, quantite=3),
    ])
    db.session.commit()
    for dossier, nom in (("machines", "1_tour.jpg"), ("preventif", "1_photo.jpg")):
        (app.config["UPLOAD_DIR"] / dossier).mkdir(parents=True, exist_ok=True)
        (app.config["UPLOAD_DIR"] / dossier / nom).write_bytes(b"x")
    return tour, roulement, composant


def test_supprimer_une_machine_et_tout_ce_qui_en_depend(client, connecter, atelier, app):
    tour, roulement, _ = atelier
    connecter("admin")
    apercu = client.get(f"/api/admin/suppression/machine/{tour.id}").get_json()
    assert apercu["titre"] == "la machine MAI-01 — Tour"
    assert "2 bons d'intervention" in apercu["effaces"] and "1 tâche préventive" in apercu["effaces"]
    assert "1 échéance préventive cochée" in apercu["effaces"] and "1 IPS (consignes de sécurité)" in apercu["effaces"]
    assert any("mouvement de stock" in g for g in apercu["gardes"]) and any("chantier" in g for g in apercu["gardes"])
    assert client.delete(f"/api/admin/suppression/machine/{tour.id}", json={"confirmation": "oui"}).status_code == 400
    reponse = client.delete(f"/api/admin/suppression/machine/{tour.id}", json={"confirmation": "supprimer"})
    assert reponse.status_code == 200
    db.session.expire_all()
    assert Machine.query.count() == 0 and BonIntervention.query.count() == 0 and TachePreventive.query.count() == 0
    assert BonPreventif.query.count() == 0 and RealisationPreventive.query.count() == 0 and IpsMachine.query.count() == 0
    # Gardés : la pièce, le document, le chantier (sans machine), le mouvement de stock (sans bon)
    assert db.session.get(Piece, roulement.id).quantite == 10 and Document.query.count() == 1
    assert Chantier.query.one().machine_id is None and Mouvement.query.one().bon_id is None
    assert PieceMachine.query.count() == 0 and DocumentMachine.query.count() == 0 and TachePiece.query.count() == 0
    # Les fichiers sont effacés, une copie de sécurité est faite, et c'est noté dans le journal
    assert not (app.config["UPLOAD_DIR"] / "machines" / "1_tour.jpg").exists()
    assert not (app.config["UPLOAD_DIR"] / "preventif" / "1_photo.jpg").exists()
    assert (app.config["SAUVEGARDE_DIR"] / reponse.get_json()["sauvegarde"]).exists()
    assert JournalAction.query.filter_by(action="suppression").count() == 1


def test_retirer_un_composant_le_remet_en_stock(client, connecter, atelier):
    _, roulement, composant = atelier
    connecter("admin")
    assert any("remise(s) en stock" in g for g in client.get(f"/api/admin/suppression/composant/{composant.id}").get_json()["gardes"])
    assert client.delete(f"/api/admin/suppression/composant/{composant.id}", json={"confirmation": "SUPPRIMER"}).status_code == 200
    assert db.session.get(Piece, roulement.id).quantite == 12 and BonComposant.query.count() == 0


def test_supprimer_une_piece(client, connecter, atelier):
    _, roulement, _ = atelier
    commande = Commande(numero="BC-1")
    commande.lignes.append(CommandeLigne(piece_id=roulement.id, designation="Roulement", quantite=4))
    db.session.add(commande)
    db.session.commit()
    connecter("admin")
    assert client.delete(f"/api/admin/suppression/piece/{roulement.id}", json={"confirmation": "SUPPRIMER"}).status_code == 200
    db.session.expire_all()
    assert Piece.query.count() == 0 and Mouvement.query.count() == 0 and PanierLigne.query.count() == 0
    # Le bon et la commande gardent la ligne, avec sa désignation
    assert BonComposant.query.one().piece_id is None and CommandeLigne.query.one().designation == "Roulement"


def test_supprimer_un_compte_garde_son_travail(client, connecter, atelier):
    connecter("admin")
    tech = Utilisateur.query.filter_by(login="tech").one()
    apercu = client.get(f"/api/admin/suppression/utilisateur/{tech.id}").get_json()
    assert apercu["refus"] is None and any("à attribuer" in g for g in apercu["gardes"])
    assert client.delete(f"/api/admin/suppression/utilisateur/{tech.id}", json={"confirmation": "SUPPRIMER"}).status_code == 200
    db.session.expire_all()
    tech = db.session.get(Utilisateur, tech.id)
    assert (tech.nom, tech.login, tech.actif) == ("Élève supprimé", f"supprime-{tech.id}", False)
    assert BonIntervention.query.filter_by(numero="BI-1").one().techniciens == []  # en cours : à attribuer
    assert tech in BonIntervention.query.filter_by(numero="BI-2").one().techniciens  # terminé : l'historique reste
    assert ChantierAffectation.query.filter_by(utilisateur_id=tech.id).count() == 0
    assert "supprime-" not in str(client.get("/api/admin/utilisateurs").get_json()["utilisateurs"])
    assert client.post("/api/auth/login", json={"login": "tech", "password": "tech"}).status_code == 401
    # Refus : son propre compte, et un compte déjà supprimé
    moi = Utilisateur.query.filter_by(login="admin").one().id
    assert client.delete(f"/api/admin/suppression/utilisateur/{moi}", json={"confirmation": "SUPPRIMER"}).status_code == 409
    assert client.delete(f"/api/admin/suppression/utilisateur/{tech.id}", json={"confirmation": "SUPPRIMER"}).status_code == 409


def test_reserve_a_l_enseignant(client, connecter, atelier):
    tour = atelier[0]
    connecter("tech")
    assert client.get(f"/api/admin/suppression/machine/{tour.id}").status_code == 403
    assert client.delete(f"/api/admin/suppression/machine/{tour.id}", json={"confirmation": "SUPPRIMER"}).status_code == 403
    assert client.post("/api/admin/promotion/cloturer", json={"confirmation": "CLOTURER"}).status_code == 403


def test_desactiver_un_eleve_libere_son_travail(client, connecter, atelier):
    connecter("admin")
    tech = Utilisateur.query.filter_by(login="tech").one()
    assert client.put(f"/api/admin/utilisateurs/{tech.id}", json={"nom": tech.nom, "role": "technicien", "actif": False}).status_code == 200
    assert BonIntervention.query.filter_by(numero="BI-1").one().techniciens == []


def test_creer_la_classe_puis_cloturer_l_annee(client, connecter, atelier, app):
    connecter("admin")
    groupe = GroupeEleves(nom="Groupe A", membres=Utilisateur.query.filter_by(role="technicien").all())
    db.session.add(groupe)
    db.session.commit()
    # Clôture : copie de sécurité, élèves anonymisés, travail en cours à attribuer, groupes vidés
    assert client.post("/api/admin/promotion/cloturer", json={"confirmation": "non"}).status_code == 400
    reponse = client.post("/api/admin/promotion/cloturer", json={"confirmation": "cloturer"})
    assert reponse.status_code == 200 and "2 élève(s) anonymisé(s)" in reponse.get_json()["bilan"]
    assert (app.config["SAUVEGARDE_DIR"] / reponse.get_json()["sauvegarde"]).exists()
    db.session.expire_all()
    assert Utilisateur.query.filter_by(role="technicien", actif=True).count() == 0
    assert BonIntervention.query.filter_by(numero="BI-1").one().techniciens == [] and GroupeEleves.query.one().membres == []
    assert BonPreventif.query.one().techniciens == []
    assert len(BonIntervention.query.filter_by(numero="BI-2").one().techniciens) == 2  # l'historique garde ses élèves (anonymes)
    assert db.session.get(Parametre, "dernier_reset_annuel").valeur == "2026"
    assert client.post("/api/admin/promotion/cloturer", json={"confirmation": "CLOTURER"}).status_code == 409  # déjà fait

    # Nouvelle classe : une liste collée depuis un tableur (tabulations, doublon, ligne vide)
    texte = "DUPONT\tJean\nMartin Léa\n\nmartin léa\nDupont Jean\nMartin Lea\n"
    fiches = client.post("/api/admin/promotion/eleves", json={"texte": texte}).get_json()["fiches"]
    # Doublons retirés (« Dupont Jean », « martin léa ») ; même identifiant pour deux noms différents : suffixe 2
    assert [(f["nom"], f["login"]) for f in fiches] == [("DUPONT Jean", "dupont.jean"), ("Martin Léa", "martin.lea"), ("Martin Lea", "martin.lea2")]
    assert all(len(f["password"]) >= 6 for f in fiches)
    assert client.post("/api/auth/logout").status_code == 200
    assert client.post("/api/auth/login", json={"login": "martin.lea", "password": fiches[1]["password"]}).status_code == 200
    client.post("/api/auth/logout")
    connecter("admin")
    etat = client.get("/api/admin/promotion").get_json()
    assert len(etat["eleves"]) == 3 and etat["anciens"] == 2

    # Le passage automatique du 1er août ne touche pas la nouvelle classe (année déjà clôturée)
    from app.cli import reset_annuel

    assert "déjà été faite" in reset_annuel(date(2026, 8, 1))
    assert Utilisateur.query.filter_by(role="technicien", actif=True).count() == 3


@pytest.mark.parametrize("type_objet", ["bon", "tache", "document", "chantier", "projet", "fournisseur", "commande"])
def test_chaque_type_se_supprime(client, connecter, atelier, type_objet):
    from app.models import Fournisseur, Projet, TacheProjet

    tour, roulement, _ = atelier
    fournisseur = Fournisseur(nom="Roulements Service")
    projet = Projet(nom="GMAO", date_debut=date(2026, 1, 5), membres=[Utilisateur.query.filter_by(login="tech").one()])
    db.session.add_all([fournisseur, projet, TacheProjet(projet=projet, nom="Inventaire", duree_semaines=2)])
    roulement.fournisseur = fournisseur
    commande = Commande(numero="BC-9", fournisseur=fournisseur)
    commande.lignes.append(CommandeLigne(piece_id=roulement.id, designation="Roulement", quantite=1))
    db.session.add(commande)
    db.session.commit()
    objets = {
        "bon": BonIntervention.query.filter_by(numero="BI-2").one(),
        "tache": TachePreventive.query.one(),
        "document": Document.query.one(),
        "chantier": Chantier.query.one(),
        "projet": projet,
        "fournisseur": fournisseur,
        "commande": commande,
    }
    modele, objet_id = type(objets[type_objet]), objets[type_objet].id
    connecter("admin")
    assert client.get(f"/api/admin/suppression/{type_objet}/{objet_id}").status_code == 200
    assert client.delete(f"/api/admin/suppression/{type_objet}/{objet_id}", json={"confirmation": "SUPPRIMER"}).status_code == 200
    db.session.expire_all()
    assert db.session.get(modele, objet_id) is None
    assert db.session.get(Machine, tour.id) is not None and db.session.get(Piece, roulement.id) is not None
