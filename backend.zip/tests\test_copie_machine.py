from datetime import date

import pytest

from app import db
from app.models import (
    Atelier,
    Document,
    DocumentMachine,
    Element,
    IpsMachine,
    Machine,
    Pictogramme,
    Piece,
    PieceMachine,
    TachePhoto,
    TachePreventive,
)

AUJOURDHUI = date(2026, 11, 18)


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: AUJOURDHUI)


@pytest.fixture()
def tour(app):
    dossier = app.config["UPLOAD_DIR"] / "preventif"
    dossier.mkdir(parents=True, exist_ok=True)
    (dossier / "1_photo.jpg").write_bytes(b"\xff\xd8\xff photo")
    tour = Machine(repere="MAI-01", designation="Tour", marque="Cazeneuve", modele="HB 500", numero_serie="S123", compteur_heures=1200,
                   atelier=Atelier.query.filter_by(nom="01. Maintenance").one())
    piece = Piece(reference="00001", designation="Roulement", categorie="Mécanique")
    document = Document(titre="Notice", categorie="Notice", fichier="notice.pdf", nom_original="notice.pdf", taille=10)
    tache = TachePreventive(machine=tour, nom="Graissage", niveau=1, type_preventif="Lubrification", periodicite="semaine",
                            date_debut=date(2026, 9, 7), operations="Graisser", pictogrammes=[Pictogramme.query.first()])
    db.session.add_all([tour, piece, document, tache])
    db.session.flush()
    element = Element.query.first()
    db.session.add_all([
        PieceMachine(piece_id=piece.id, machine_id=tour.id, element_id=element.id),
        DocumentMachine(document_id=document.id, machine_id=tour.id),
        TachePhoto(tache_id=tache.id, fichier="1_photo.jpg", legende="Graisseur"),
        IpsMachine(machine=tour, jeton="abc", risques="Coupure"),
    ])
    db.session.commit()
    return tour


def test_copier_une_machine(client, connecter, tour, app):
    connecter("admin")
    reponse = client.post(f"/api/machines/{tour.id}/copier", json={"repere": "mai-02"})
    assert reponse.status_code == 201
    copie = db.session.get(Machine, reponse.get_json()["machine"]["id"])
    assert (copie.repere, copie.designation, copie.marque, copie.modele) == ("MAI-02", "Tour", "Cazeneuve", "HB 500")
    assert copie.numero_serie is None and copie.compteur_heures is None
    assert PieceMachine.query.filter_by(machine_id=copie.id).count() == 1
    assert DocumentMachine.query.filter_by(machine_id=copie.id).count() == 1
    assert IpsMachine.query.filter_by(machine_id=copie.id).count() == 0  # l'IPS n'est pas copiée
    tache = copie.taches_preventives.one()
    assert tache.operations == "Graisser" and len(tache.pictogrammes) == 1
    assert tache.date_debut > AUJOURDHUI  # démarre à la prochaine échéance : pas de retard
    photo = tache.photos[0]
    assert photo.legende == "Graisseur" and photo.fichier != "1_photo.jpg"
    assert (app.config["UPLOAD_DIR"] / "preventif" / photo.fichier).read_bytes() == b"\xff\xd8\xff photo"
    detail = client.get(f"/api/preventif/taches/{tache.id}").get_json()["tache"]
    assert detail["statut"] == "a_venir"


def test_copie_refusee(client, connecter, tour):
    connecter("admin")
    assert client.post(f"/api/machines/{tour.id}/copier", json={}).status_code == 400  # même repère
    assert client.post("/api/machines/999/copier", json={"repere": "X"}).status_code == 404
    client.post("/api/auth/logout")
    connecter("tech")  # choix de Simon : les enseignants seulement
    assert client.post(f"/api/machines/{tour.id}/copier", json={"repere": "MAI-03"}).status_code == 403


def test_etiquettes_disponibles(client, connecter, tour):
    from datetime import datetime

    from app.models import IpsMachine

    connecter("tech")
    m = next(x for x in client.get("/api/etiquettes/machines").get_json()["machines"] if x["repere"] == "MAI-01")
    assert m["ips"] is None and m["taches"] == 1 and [d["titre"] for d in m["documents"]] == ["Notice"]  # IPS non validée
    IpsMachine.query.filter_by(machine_id=tour.id).one().valide_le = datetime(2026, 11, 1)
    db.session.commit()
    m = next(x for x in client.get("/api/etiquettes/machines").get_json()["machines"] if x["repere"] == "MAI-01")
    assert m["ips"] == "abc"
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get("/api/etiquettes/machines").status_code == 403
