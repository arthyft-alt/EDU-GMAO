import csv
import io
from datetime import timedelta

import pytest

from app import db
from app.models import Atelier, BonIntervention, Machine, Utilisateur


@pytest.fixture()
def machine(app):
    m = Machine(repere="FON-01", designation="Four de fusion", atelier=Atelier.query.filter_by(nom="03. Fonderie").one())
    db.session.add(m)
    db.session.commit()
    return m


def nouveau_bon(client, machine, **autres):
    donnees = {
        "machine_id": machine.id,
        "type_travail": "depannage",
        "urgence": "normale",
        "demandeur": "Martin",
        "description": "Bruit anormal au démarrage",
        **autres,
    }
    return client.post("/api/bons", json=donnees)


def tech_id(login):
    return Utilisateur.query.filter_by(login=login).one().id


# ---------- Création ----------

def test_operateur_cree_un_bon(client, connecter, machine):
    connecter("operateur")
    reponse = nouveau_bon(client, machine)
    assert reponse.status_code == 201
    bon = reponse.get_json()["bon"]
    assert bon["numero"].startswith("BI-") and bon["numero"].endswith("-0001")
    assert bon["statut"] == "demande"
    assert bon["demandeur"] == "Martin"
    assert bon["techniciens"] == []


def test_numeros_successifs(client, connecter, machine):
    connecter("tech")
    nouveau_bon(client, machine)
    assert nouveau_bon(client, machine).get_json()["bon"]["numero"].endswith("-0002")


def test_bon_critique_reste_en_statut_demande(client, connecter, machine):
    connecter("operateur")
    bon = nouveau_bon(client, machine, urgence="critique").get_json()["bon"]
    assert (bon["urgence"], bon["statut"]) == ("critique", "demande")


def test_statut_urgent_supprime(client, connecter, machine):
    connecter("tech")
    bon = nouveau_bon(client, machine).get_json()["bon"]
    assert client.put(f"/api/bons/{bon['id']}", json={"statut": "urgent"}).status_code == 400


def test_operateur_doit_donner_son_nom(client, connecter, machine):
    connecter("operateur")
    reponse = nouveau_bon(client, machine, demandeur="")
    assert reponse.status_code == 400
    assert "Votre nom" in reponse.get_json()["error"]


def test_technicien_demandeur_par_defaut(client, connecter, machine):
    connecter("tech")
    assert nouveau_bon(client, machine, demandeur="").get_json()["bon"]["demandeur"] == "Technicien 1 (démo)"


@pytest.mark.parametrize(
    "champs,message",
    [({"description": ""}, "constaté"), ({"type_travail": "x"}, "type de travail"), ({"urgence": "haute"}, "urgence"), ({"machine_id": 999}, "machine")],
)
def test_creation_invalide(client, connecter, machine, champs, message):
    connecter("tech")
    reponse = nouveau_bon(client, machine, **champs)
    assert reponse.status_code == 400
    assert message in reponse.get_json()["error"]
    assert BonIntervention.query.count() == 0


def test_machine_hors_service_refusee(client, connecter, machine):
    machine.hors_service = True
    db.session.commit()
    connecter("tech")
    assert nouveau_bon(client, machine).status_code == 400


# ---------- Visibilité ----------

def test_operateur_consulte_l_historique_sans_rien_modifier(client, connecter, machine):
    connecter("tech")
    bon_tech = nouveau_bon(client, machine).get_json()["bon"]
    client.post("/api/auth/logout")
    connecter("operateur")
    bon_op = nouveau_bon(client, machine).get_json()["bon"]
    # Historique complet en consultation
    assert len(client.get("/api/bons").get_json()["bons"]) == 2
    assert client.get(f"/api/bons/{bon_tech['id']}").status_code == 200
    # « Mes demandes » : seulement les bons créés depuis ce compte
    assert [b["id"] for b in client.get("/api/bons?mes=1").get_json()["bons"]] == [bon_op["id"]]
    # Aucune modification possible
    assert client.put(f"/api/bons/{bon_tech['id']}", json={"statut": "en_cours"}).status_code == 403
    assert client.put(f"/api/bons/{bon_tech['id']}/techniciens", json={"ids": []}).status_code == 403
    assert client.post("/api/bons/repartition-auto").status_code == 403
    assert client.get("/api/techniciens").status_code == 403
    assert client.get("/api/bons/export.csv").status_code == 403


def test_technicien_voit_tous_les_bons(client, connecter, machine):
    connecter("operateur")
    nouveau_bon(client, machine)
    client.post("/api/auth/logout")
    connecter("tech")
    assert len(client.get("/api/bons").get_json()["bons"]) == 1


# ---------- Répartition ----------

def test_affectation_multiple_et_retrait(client, connecter, machine):
    connecter("tech")
    bon = nouveau_bon(client, machine).get_json()["bon"]
    ids = [tech_id("tech"), tech_id("tech2")]
    reponse = client.put(f"/api/bons/{bon['id']}/techniciens", json={"ids": ids})
    assert sorted(t["id"] for t in reponse.get_json()["bon"]["techniciens"]) == sorted(ids)
    techs = {t["id"]: t["bons_ouverts"] for t in client.get("/api/techniciens").get_json()["techniciens"]}
    assert techs[ids[0]] == 1 and techs[ids[1]] == 1
    assert client.get("/api/bons?technicien_id=aucun").get_json()["bons"] == []
    client.put(f"/api/bons/{bon['id']}/techniciens", json={"ids": []})
    assert len(client.get("/api/bons?technicien_id=aucun").get_json()["bons"]) == 1


def test_affectation_refusee_a_un_non_technicien(client, connecter, machine):
    connecter("tech")
    bon = nouveau_bon(client, machine).get_json()["bon"]
    assert client.put(f"/api/bons/{bon['id']}/techniciens", json={"ids": [tech_id("operateur")]}).status_code == 400
    assert client.put(f"/api/bons/{bon['id']}/techniciens", json={"ids": "1"}).status_code == 400


def test_repartition_auto_reservee_admin(client, connecter, machine):
    connecter("tech")
    assert client.post("/api/bons/repartition-auto").status_code == 403


def test_repartition_auto_a_tour_de_role_urgents_d_abord(client, connecter, machine):
    connecter("admin")
    normal = nouveau_bon(client, machine).get_json()["bon"]
    critique = nouveau_bon(client, machine, urgence="critique").get_json()["bon"]
    troisieme = nouveau_bon(client, machine).get_json()["bon"]
    assert client.post("/api/bons/repartition-auto").get_json()["nb_bons"] == 3
    nom = lambda b: [t["nom"] for t in client.get(f"/api/bons/{b['id']}").get_json()["bon"]["techniciens"]]
    # Ordre des techniciens : par nom (Technicien 1, Technicien 2) ; le critique est servi en premier
    assert nom(critique) == ["Technicien 1 (démo)"]
    assert nom(normal) == ["Technicien 2 (démo)"]
    assert nom(troisieme) == ["Technicien 1 (démo)"]
    # La répartition suivante reprend après le dernier servi
    quatrieme = nouveau_bon(client, machine).get_json()["bon"]
    client.post("/api/bons/repartition-auto")
    assert nom(quatrieme) == ["Technicien 2 (démo)"]


# ---------- Compte-rendu et clôture ----------

def test_terminer_exige_un_compte_rendu(client, connecter, machine):
    connecter("tech")
    bon = nouveau_bon(client, machine, machine_arretee=True).get_json()["bon"]
    url = f"/api/bons/{bon['id']}"
    assert "travaux" in client.put(url, json={"statut": "termine"}).get_json()["error"]
    assert "temps passé" in client.put(url, json={"statut": "termine", "travaux": "Remplacement du thermocouple"}).get_json()["error"]
    assert "remise en service" in client.put(url, json={"statut": "termine", "travaux": "x", "temps_passe_h": "1,5"}).get_json()["error"]
    assert db.session.get(BonIntervention, bon["id"]).statut == "demande"  # rien n'a été enregistré


def test_cloture_par_technicien_et_duree_d_arret(client, connecter, machine):
    connecter("tech")
    bon = nouveau_bon(client, machine, machine_arretee=True).get_json()["bon"]
    objet = db.session.get(BonIntervention, bon["id"])
    remise = (objet.cree_le + timedelta(hours=3)).isoformat() + "Z"
    reponse = client.put(
        f"/api/bons/{bon['id']}",
        json={"statut": "termine", "travaux": "Remplacement du thermocouple", "cause": "Usure", "temps_passe_h": "1,5", "effectif": 2, "remise_en_service": remise},
    )
    assert reponse.status_code == 200, reponse.get_json()
    resultat = reponse.get_json()["bon"]
    assert resultat["statut"] == "termine" and resultat["termine_le"]
    assert resultat["temps_passe_h"] == 1.5
    assert resultat["duree_arret_h"] == 3.0
    # Un technicien ne peut plus modifier un bon terminé
    assert client.put(f"/api/bons/{bon['id']}", json={"statut": "en_cours"}).status_code == 403


def test_remise_en_service_avant_creation_refusee(client, connecter, machine):
    connecter("tech")
    bon = nouveau_bon(client, machine, machine_arretee=True).get_json()["bon"]
    reponse = client.put(f"/api/bons/{bon['id']}", json={"remise_en_service": "2000-01-01T10:00:00Z"})
    assert reponse.status_code == 400


def test_admin_rouvre_un_bon(client, connecter, machine):
    connecter("admin")
    bon = nouveau_bon(client, machine).get_json()["bon"]
    client.put(f"/api/bons/{bon['id']}", json={"statut": "termine", "travaux": "x", "temps_passe_h": 1})
    reponse = client.put(f"/api/bons/{bon['id']}", json={"statut": "en_cours"})
    assert reponse.get_json()["bon"]["statut"] == "en_cours"
    assert reponse.get_json()["bon"]["termine_le"] is None


# ---------- Historique, export, machine ----------

def test_filtres(client, connecter, machine):
    connecter("tech")
    nouveau_bon(client, machine, type_travail="amelioration", description="Ajouter un éclairage")
    bon = nouveau_bon(client, machine).get_json()["bon"]
    client.put(f"/api/bons/{bon['id']}", json={"statut": "termine", "travaux": "x", "temps_passe_h": 1})
    assert len(client.get("/api/bons?statut=ouverts").get_json()["bons"]) == 1
    assert len(client.get("/api/bons?type=amelioration").get_json()["bons"]) == 1
    assert len(client.get("/api/bons?q=éclairage").get_json()["bons"]) == 1
    assert len(client.get(f"/api/bons?machine_id={machine.id}").get_json()["bons"]) == 2
    assert client.get("/api/bons?du=2000-01-01&au=2000-12-31").get_json()["bons"] == []
    assert client.get("/api/bons?du=pas-une-date").status_code == 400


def test_export_csv_pour_excel(client, connecter, machine):
    connecter("tech")
    bon = nouveau_bon(client, machine).get_json()["bon"]
    client.put(f"/api/bons/{bon['id']}", json={"statut": "termine", "travaux": "Réglage", "temps_passe_h": "0,75"})
    reponse = client.get("/api/bons/export.csv")
    texte = reponse.data.decode("utf-8")
    assert texte.startswith("﻿")
    lignes = list(csv.reader(io.StringIO(texte[1:]), delimiter=";"))
    assert lignes[0][0] == "Numéro"
    assert lignes[1][3] == "FON-01" and lignes[1][13] == "0,75"
    client.post("/api/auth/logout")
    connecter("operateur")
    assert client.get("/api/bons/export.csv").status_code == 403


def test_machine_avec_bon_non_supprimable(client, connecter, machine):
    connecter("admin")
    nouveau_bon(client, machine)
    assert client.delete(f"/api/machines/{machine.id}").status_code == 409


def test_suivi_machine(client, connecter, machine):
    connecter("tech")
    nouveau_bon(client, machine)
    nouveau_bon(client, machine, type_travail="amelioration")
    suivi = client.get(f"/api/machines/{machine.id}/suivi").get_json()
    assert suivi == {"bons_ouverts": 2, "pannes_12_mois": 1}


# ---------- Composants utilisés ----------

def test_composants_du_compte_rendu(client, connecter, machine):
    connecter("tech")
    bon = nouveau_bon(client, machine).get_json()["bon"]
    url = f"/api/bons/{bon['id']}"
    composants = [
        {"designation": "Roulement 6204", "reference": "6204-2RS", "quantite": "2", "prix_unitaire": "4,50"},
        {"designation": "Graisse", "quantite": "0,5"},
    ]
    resultat = client.put(url, json={"composants": composants}).get_json()["bon"]
    assert [c["designation"] for c in resultat["composants"]] == ["Roulement 6204", "Graisse"]
    assert resultat["composants"][0]["cout"] == 9.0
    assert resultat["composants"][1]["cout"] is None  # prix inconnu
    assert resultat["cout_composants"] == 9.0
    # La liste envoyée remplace la précédente
    assert client.put(url, json={"composants": composants[:1]}).get_json()["bon"]["cout_composants"] == 9.0
    assert len(client.get(url).get_json()["bon"]["composants"]) == 1
    texte = client.get("/api/bons/export.csv").data.decode("utf-8")
    assert texte.splitlines()[1].endswith("2 × Roulement 6204;9")


@pytest.mark.parametrize(
    "composants,message",
    [([{"designation": ""}], "désignation"), ([{"designation": "x", "quantite": "0"}], "Quantité"), ("x", "invalide"), ([{"designation": "x", "prix_unitaire": "-1"}], "Prix")],
)
def test_composants_invalides(client, connecter, machine, composants, message):
    connecter("tech")
    bon = nouveau_bon(client, machine).get_json()["bon"]
    reponse = client.put(f"/api/bons/{bon['id']}", json={"composants": composants})
    assert reponse.status_code == 400
    assert message in reponse.get_json()["error"]
