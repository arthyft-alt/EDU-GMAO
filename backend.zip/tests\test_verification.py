"""Corrections de la vérification du 28/10/2026 : sessions, essais limités, sauvegardes lourdes,
1er août rattrapé, exports CSV protégés, pictogrammes des IPS."""
import io
import json
import os
import zipfile
from datetime import date, datetime

from flask import g

from app import db
from app.cli import reset_annuel
from app.models import Atelier, Machine, Pictogramme, Utilisateur
from app.tableur import cellule


def _nouvelle_requete():
    """Les tests gardent le même contexte d'application d'une requête à l'autre : Flask-Login y garde
    l'utilisateur déjà chargé. En vrai, chaque requête relit le compte (comme ici après ce nettoyage)."""
    g.pop("_login_user", None)


def _machine():
    m = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.first())
    db.session.add(m)
    db.session.commit()
    return m


# ---------- Sessions ----------

def test_compte_desactive_deconnecte_aussitot(app, client, connecter):
    connecter("tech")
    assert client.get("/api/auth/me").get_json()["utilisateur"]["login"] == "tech"
    tech = Utilisateur.query.filter_by(login="tech").one()
    tech.actif = False
    db.session.commit()
    _nouvelle_requete()
    assert client.get("/api/auth/me").get_json()["utilisateur"] is None


def test_mot_de_passe_reinitialise_ferme_les_autres_connexions(app, client, connecter):
    connecter("tech")
    admin = app.test_client()
    admin.post("/api/auth/login", json={"login": "admin", "password": "admin"})
    tech = Utilisateur.query.filter_by(login="tech").one()
    assert admin.put(f"/api/admin/utilisateurs/{tech.id}/mot-de-passe", json={"password": "nouveau1"}).status_code == 200
    _nouvelle_requete()
    assert client.get("/api/auth/me").get_json()["utilisateur"] is None


def test_changer_son_mot_de_passe_garde_cet_appareil_connecte(app, client, connecter):
    connecter("tech")
    autre = app.test_client()
    autre.post("/api/auth/login", json={"login": "tech", "password": "tech"})
    assert client.put("/api/auth/mot-de-passe", json={"ancien": "tech", "nouveau": "tech-2026"}).status_code == 200
    assert client.get("/api/auth/me").get_json()["utilisateur"]["login"] == "tech"
    _nouvelle_requete()
    assert autre.get("/api/auth/me").get_json()["utilisateur"] is None


def test_qr_code_renouvele_deconnecte_le_telephone(app, client, connecter):
    admin = app.test_client()
    admin.post("/api/auth/login", json={"login": "admin", "password": "admin"})
    operateur = admin.get("/api/admin/qr-operateurs").get_json()["operateurs"][0]
    assert client.post("/api/auth/qr", json={"jeton": operateur["jeton"]}).status_code == 200
    assert client.get("/api/auth/me").get_json()["utilisateur"]["role"] == "operateur"
    _nouvelle_requete()
    assert admin.post(f"/api/admin/qr-operateurs/{operateur['id']}/renouveler").status_code == 200
    _nouvelle_requete()
    assert client.get("/api/auth/me").get_json()["utilisateur"] is None


# ---------- Essais limités ----------

def test_code_du_jour_bloque_apres_cinq_erreurs(client, connecter):
    connecter("tech")
    for _ in range(5):
        assert client.post("/api/auth/verifier-verrou/machines", json={"password": "0000"}).status_code == 403
    bloque = client.post("/api/auth/verifier-verrou/machines", json={"password": "1234"})
    assert bloque.status_code == 403 and "Trop de codes faux" in bloque.get_json()["error"]
    # L'en-tête des actions protégées est soumis au même blocage
    assert client.post("/api/machines", json={}, headers={"X-Unlock-Password": "1234"}).status_code == 403


def test_code_du_jour_bon_remet_le_compteur_a_zero(client, connecter):
    connecter("tech")
    for _ in range(4):
        client.post("/api/auth/verifier-verrou/machines", json={"password": "0000"})
    assert client.post("/api/auth/verifier-verrou/machines", json={"password": "1234"}).status_code == 200
    for _ in range(4):
        client.post("/api/auth/verifier-verrou/machines", json={"password": "0000"})
    assert client.post("/api/auth/verifier-verrou/machines", json={"password": "1234"}).status_code == 200


def test_connexion_bloquee_apres_dix_erreurs(client):
    for _ in range(10):
        assert client.post("/api/auth/login", json={"login": "tech", "password": "faux"}).status_code == 401
    assert client.post("/api/auth/login", json={"login": "tech", "password": "tech"}).status_code == 429
    # Les autres comptes ne sont pas gênés
    assert client.post("/api/auth/login", json={"login": "tech2", "password": "tech2"}).status_code == 200


# ---------- Sauvegarde lourde (plus de 20 Mo) ----------

def test_chargement_d_une_sauvegarde_de_plus_de_20_mo(client, connecter):
    _machine()
    connecter("admin")
    contenu = client.get("/api/admin/sauvegarde").data
    source = zipfile.ZipFile(io.BytesIO(contenu))
    tampon = io.BytesIO()
    with zipfile.ZipFile(tampon, "w", zipfile.ZIP_STORED) as z:
        for nom in source.namelist():
            z.writestr(nom, source.read(nom))
        z.writestr("fichiers/documents/gros.pdf", b"%PDF-" + os.urandom(21 * 1024 * 1024))
    assert len(tampon.getvalue()) > 20 * 1024 * 1024
    charge = client.post("/api/admin/sauvegarde", data={"fichier": (io.BytesIO(tampon.getvalue()), "s.zip")}, content_type="multipart/form-data")
    assert charge.status_code == 200, charge.get_json()


def test_les_autres_envois_restent_limites_a_20_mo(client, connecter):
    m = _machine()
    connecter("admin")
    gros = io.BytesIO(b"\xff\xd8\xff" + bytes(21 * 1024 * 1024))
    reponse = client.post(f"/api/machines/{m.id}/photo", data={"photo": (gros, "p.jpg", "image/jpeg")}, content_type="multipart/form-data")
    assert reponse.status_code == 413


# ---------- 1er août ----------

def test_reinitialisation_rattrapee_en_aout(app):
    assert "rien à faire" in reset_annuel(date(2027, 9, 1))
    rentree = Utilisateur(login="nouveau", nom="Élève de la rentrée", role="technicien", cree_le=datetime(2027, 8, 20))
    rentree.definir_mot_de_passe("abcd")
    db.session.add(rentree)
    db.session.commit()
    assert "2 élève(s) anonymisé(s)" in reset_annuel(date(2027, 8, 25))  # le Cron n'a pas tourné le 1er
    assert db.session.get(Utilisateur, rentree.id).nom == "Élève de la rentrée"
    assert "déjà été faite" in reset_annuel(date(2027, 8, 26))


# ---------- Exports CSV ----------

def test_cellule_csv_protegee_contre_les_formules():
    assert cellule("=LIEN_HYPERTEXTE(1)") == "'=LIEN_HYPERTEXTE(1)"
    assert cellule("+33 6 12") == "'+33 6 12"
    assert cellule("-3") == "-3" and cellule("-1,5") == "-1,5"  # nombres négatifs intacts
    assert cellule("Graissage") == "Graissage" and cellule(12) == 12


def test_export_des_bons_neutralise_une_formule(client, connecter):
    m = _machine()
    connecter("tech")
    client.post("/api/bons", json={"machine_id": m.id, "type_travail": "depannage", "description": "=1+1"})
    texte = client.get("/api/bons/export.csv").data.decode("utf-8")
    assert ";'=1+1;" in texte


# ---------- Pictogrammes ----------

def test_pictogramme_d_une_ips_non_supprimable(client, connecter):
    m = _machine()
    connecter("admin")
    reponse = client.post("/api/pictogrammes", data={"nom": "Laser", "categorie": "danger", "image": (io.BytesIO(b"\x89PNG"), "l.png", "image/png")},
                          content_type="multipart/form-data")
    picto = reponse.get_json()["pictogramme"]
    client.put(f"/api/machines/{m.id}/ips", json={"pictogrammes": [picto["id"]]})
    refus = client.delete(f"/api/pictogrammes/{picto['id']}")
    assert refus.status_code == 409 and "IPS" in refus.get_json()["error"]
    assert db.session.get(Pictogramme, picto["id"]) is not None


def test_entetes_de_securite(client):
    reponse = client.get("/api/health")
    assert reponse.headers["X-Content-Type-Options"] == "nosniff"
    assert reponse.headers["Cache-Control"] == "no-store"
    assert json.loads(reponse.data)["status"] == "ok"
