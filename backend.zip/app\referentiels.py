"""Listes de référence de l'annexe C du cahier des charges.

Les ateliers et les éléments sont enregistrés en base (modifiables par l'administrateur).
Les autres listes restent ici en attendant leur édition par l'administrateur.
"""

ROLES = {
    "admin": "Administrateur",
    "technicien": "Technicien de maintenance",
    "operateur": "Opérateur",
}

ATELIERS = [
    "01. Maintenance",
    "02. ATN Maintenance",
    "03. Fonderie",
    "04. Modelage",
    "05. Céramique",
    "06. ATN STI2D",
    "07. ATN CPRP",
    "08. ATN TU",
]

ELEMENTS = [
    "Ensemble",
    "Non défini",
    "11 Acquérir",
    "12 Traiter",
    "13 Communiquer",
    "21 Alimenter",
    "22 Distribuer",
    "23 Convertir",
    "24 Transmettre",
    "25 Action",
]

# Types de travaux : code -> libellé. Seul « depannage » compte comme une panne dans les indicateurs.
TYPES_TRAVAUX = {
    "depannage": "Dépannage",
    "preventif": "Préventif",
    "amelioration": "Amélioration",
    "autre": "Autre",
}

# Niveaux d'urgence d'un bon d'intervention (annexe E, point 1)
URGENCES = {"faible": "Faible", "normale": "Normale", "critique": "Critique"}

# Périodicités préventives : code -> (libellé, nombre de jours, nombre de mois). Une seule des deux durées est utilisée.
PERIODICITES = {
    "semaine": ("Semaine", 7, 0),
    "15_jours": ("15 jours", 14, 0),
    "3_semaines": ("3 semaines", 21, 0),
    "mois": ("Mois", 0, 1),
    "2_mois": ("2 mois", 0, 2),
    "3_mois": ("3 mois", 0, 3),
    "6_mois": ("6 mois", 0, 6),
    "an": ("An", 0, 12),
}

# Statuts d'un bon d'intervention (ordre d'affichage). L'urgence est portée par le champ « urgence », pas par un statut.
STATUTS_BI = {
    "demande": "Demande",
    "preparation": "Préparation",
    "en_cours": "En cours",
    "a_cloturer": "À clôturer",
    "termine": "Terminé",
    "autre": "Autre",
}

TYPES_PREVENTIF = ["Nettoyage", "Lubrification", "Inspection", "Réglage", "Remplacement de pièces d'usure"]

# Pictogrammes de sécurité intégrés (PRV-03, FND-06) : code -> (nom, catégorie).
# Le dessin de chaque code est défini dans l'affichage ; l'administrateur peut en ajouter avec sa propre image.
PICTOGRAMMES = {
    "epi_lunettes": ("Lunettes de protection obligatoires", "obligation"),
    "epi_gants": ("Gants de protection obligatoires", "obligation"),
    "epi_casque": ("Casque obligatoire", "obligation"),
    "epi_chaussures": ("Chaussures de sécurité obligatoires", "obligation"),
    "epi_auditif": ("Protection auditive obligatoire", "obligation"),
    "epi_masque": ("Masque respiratoire obligatoire", "obligation"),
    "epi_blouse": ("Vêtement de protection obligatoire", "obligation"),
    "consignation": ("Consignation obligatoire avant intervention", "obligation"),
    "danger_electrique": ("Danger électrique", "danger"),
    "danger_chaleur": ("Surface chaude", "danger"),
    "danger_coupure": ("Risque de coupure", "danger"),
    "danger_ecrasement": ("Risque d'écrasement", "danger"),
    "danger_mouvement": ("Pièces en mouvement", "danger"),
    "danger_chimique": ("Produit chimique", "danger"),
    "danger_pression": ("Pression", "danger"),
    "danger_bruit": ("Bruit", "danger"),
    "interdit_toucher": ("Ne pas toucher", "interdiction"),
    "interdit_fumer": ("Interdiction de fumer", "interdiction"),
}

CATEGORIES_PIECES = ["Mécanique", "Électrique", "Pneumatique", "Hydraulique", "Automatisme", "Autre"]

CATEGORIES_DOCUMENTS = [
    "Notice d'utilisation",
    "Notice de maintenance",
    "Schéma électrique",
    "Schéma pneumatique / hydraulique",
    "Dossier technique",
    "Consignes de sécurité",
    "Autre",
]

# Maintenance conditionnelle (ANA-04) : résultats qualitatifs, avec leur gravité (ok / surveiller / alerte)
ETATS_THERMIQUES = {
    "normal": ("Normal", "ok"),
    "a_surveiller": ("À surveiller", "surveiller"),
    "anormal": ("Anormal (point chaud)", "alerte"),
}
DEFAUTS_VIBRATOIRES = {
    "aucun": ("Aucun défaut", "ok"),
    "balourd": ("Balourd", "alerte"),
    "desalignement": ("Désalignement", "alerte"),
    "roulement": ("Défaut de roulement", "alerte"),
    "jeu": ("Jeu mécanique / desserrage", "alerte"),
    "engrenement": ("Défaut d'engrènement", "alerte"),
    "courroie": ("Défaut de courroie", "alerte"),
    "resonance": ("Résonance", "alerte"),
    "autre": ("Autre défaut", "alerte"),
}
# Classes de pollution NAS 1638 (0 = très propre, 12 = très pollué). Seuils PROVISOIRES.
CLASSES_HUILE = list(range(0, 13))
HUILE_SURVEILLER, HUILE_ALERTE = 7, 10

# Périodes d'analyse (tableaux de bord, saisies des élèves)
PERIODES_ANALYSE = {"semaine": "Semaine", "mois": "Mois", "trimestre": "Trimestre", "annee": "Année scolaire"}

NIVEAUX_MAINTENANCE = {
    1: "Opérateur",
    2: "Opérateur",
    3: "Technicien",
    4: "Technicien",
    5: "Prestataire / constructeur",
}

COULEURS_CROIX_SECURITE = ["vert", "orange", "rouge", "gris", "aucune"]

# Mots de passe de déverrouillage (annexe B)
VERROUS = {
    "machines": "Gestion des machines",
    "indicateurs": "Calcul automatique des indicateurs",
}
