"""Import Excel des machines et des pièces (fonction n° 8, choix de Simon le 29/10/2026).

Un modèle .xlsx à remplir (onglets « Machines », « Pièces » et « Aide »), un aperçu ligne par ligne avant
d'enregistrer, puis la création de tout en une fois (rien n'est enregistré s'il reste une erreur).
Enseignants, et élèves avec le code du jour (comme la création d'une machine).
Une machine dont le repère existe déjà, ou une pièce dont la désignation existe déjà, est refusée (pas de doublon).
"""
import io
import re
import unicodedata

from flask import Blueprint, Response, jsonify, request
from openpyxl import Workbook, load_workbook
from openpyxl.styles import Font, PatternFill
from openpyxl.worksheet.datavalidation import DataValidation

from . import db
from .auth import erreur, role_required, unlock_required
from .models import Atelier, Element, Fournisseur, Machine, Piece, PieceMachine, ZoneMagasin, journaliser
from .reglages import liste
from .stock import CODE_ZONE, Invalide, _nouvelle_reference, _normaliser, mouvementer, nombre, normaliser_reperes

bp = Blueprint("import_excel", __name__)

TAILLE_MAX = 5 * 1024 * 1024
LIGNES_MAX = 5000

# (clé, titre de colonne, obligatoire, explication) — l'ordre est celui du modèle
COLONNES_MACHINES = [
    ("repere", "Repère", True, "Unique, 20 caractères maximum. Ex. FON-03"),
    ("designation", "Désignation", True, "Ex. Presse hydraulique"),
    ("atelier", "Atelier", True, "Nom de l'atelier, tel qu'il est écrit dans la GMAO (liste dans l'onglet Aide)"),
    ("marque", "Marque", False, ""),
    ("modele", "Modèle", False, ""),
    ("numero_serie", "N° de série", False, ""),
    ("annee_mise_en_service", "Année de mise en service", False, "Ex. 2015"),
    ("utilisation_hebdo_h", "Utilisation (h par semaine)", False, "Temps moyen d'utilisation par semaine"),
    ("taux_horaire", "Taux horaire (€/h)", False, "Coût d'immobilisation de la machine"),
    ("remarques", "Remarques", False, ""),
]
COLONNES_PIECES = [
    ("designation", "Désignation", True, "Unique dans le magasin. Ex. Roulement 6204 2RS"),
    ("categorie", "Catégorie", True, "Liste dans l'onglet Aide"),
    ("fournisseur", "Fournisseur", False, "Nom du fournisseur ; il est créé s'il n'existe pas"),
    ("reference_fournisseur", "Réf. fournisseur", False, ""),
    ("prix_unitaire", "Prix unitaire HT (€)", False, "Ex. 6,50"),
    ("quantite", "Quantité en stock", False, "Stock de départ (0 si vide)"),
    ("stock_securite", "Stock de sécurité", False, ""),
    ("emplacement", "Emplacement", False, "Étagère + étage. Ex. A1 ; créé s'il n'existe pas"),
    ("machines", "Machine(s)", False, "Repère(s) de machine, séparés par des virgules (machines de la GMAO ou de l'onglet Machines)"),
    ("element", "Élément", False, "Élément de la machine (liste dans l'onglet Aide) ; « Non défini » si vide"),
    ("repere_schema", "Repère schéma", False, "Repères du schéma de la machine. Ex. KM1, KM2"),
    ("commentaires", "Commentaires", False, ""),
]


def _cle(texte):
    sans_accents = unicodedata.normalize("NFKD", str(texte or "")).encode("ascii", "ignore").decode()
    return re.sub(r"[^a-z0-9]", "", sans_accents.lower())


def _texte(valeur, longueur=None):
    if valeur is None:
        return None
    if isinstance(valeur, float) and valeur.is_integer():
        valeur = int(valeur)
    texte = " ".join(str(valeur).split())
    if longueur and len(texte) > longueur:
        raise Invalide(f"{longueur} caractères maximum.")
    return texte or None


# ---------- Modèle à remplir ----------

@bp.get("/import/modele.xlsx")
@role_required("admin", "technicien")
def modele():
    classeur = Workbook()
    gras, fond = Font(bold=True, color="FFFFFF"), PatternFill("solid", fgColor="17808E")
    aide = classeur.active
    aide.title = "Aide"
    ateliers = [a.nom for a in Atelier.query.order_by(Atelier.nom)]
    categories = liste("categories_pieces")
    elements = [e.nom for e in Element.query.order_by(Element.ordre, Element.nom)]
    aide.append(["Import des machines et des pièces dans la GMAO"])
    aide["A1"].font = Font(bold=True, size=14)
    aide.append(["Remplissez les onglets « Machines » et « Pièces » (une ligne par machine ou par pièce), puis importez le fichier dans Équipements › Import Excel."])
    aide.append(["Les colonnes marquées * sont obligatoires. La référence magasin des pièces (00001…) est attribuée automatiquement."])
    aide.append(["Un aperçu montre chaque ligne avant d'enregistrer : rien n'est enregistré tant qu'il reste une erreur."])
    aide.append([])
    for titre, feuille_colonnes in (("Onglet Machines", COLONNES_MACHINES), ("Onglet Pièces", COLONNES_PIECES)):
        aide.append([titre])
        aide.cell(aide.max_row, 1).font = Font(bold=True)
        for _, nom, obligatoire, explication in feuille_colonnes:
            aide.append([nom + (" *" if obligatoire else ""), explication])
        aide.append([])
    debut_listes = aide.max_row + 1
    aide.append(["Ateliers", "Catégories de pièces", "Éléments"])
    for cellule in aide[debut_listes]:
        cellule.font = Font(bold=True)
    for i in range(max(len(ateliers), len(categories), len(elements))):
        aide.append([ateliers[i] if i < len(ateliers) else None, categories[i] if i < len(categories) else None, elements[i] if i < len(elements) else None])
    aide.column_dimensions["A"].width = 34
    aide.column_dimensions["B"].width = 90
    aide.column_dimensions["C"].width = 34

    def feuille(titre, colonnes, listes):
        f = classeur.create_sheet(titre)
        f.append([nom + (" *" if obligatoire else "") for _, nom, obligatoire, _ in colonnes])
        for i, cellule in enumerate(f[1], start=1):
            cellule.font, cellule.fill = gras, fond
            f.column_dimensions[cellule.column_letter].width = max(14, len(str(cellule.value)) + 4)
        f.freeze_panes = "A2"
        # Listes de choix (ateliers, catégories, éléments) reprises de l'onglet Aide
        for cle, colonne_aide, nombre_valeurs in listes:
            if not nombre_valeurs:
                continue
            index = [c[0] for c in colonnes].index(cle) + 1
            lettre = f.cell(1, index).column_letter
            plage = f"Aide!${colonne_aide}${debut_listes + 1}:${colonne_aide}${debut_listes + nombre_valeurs}"
            validation = DataValidation(type="list", formula1=plage, allow_blank=True)
            f.add_data_validation(validation)
            validation.add(f"{lettre}2:{lettre}{LIGNES_MAX + 1}")
        return f

    feuille("Machines", COLONNES_MACHINES, [("atelier", "A", len(ateliers))])
    feuille("Pièces", COLONNES_PIECES, [("categorie", "B", len(categories)), ("element", "C", len(elements))])
    classeur.move_sheet("Aide", offset=2)
    classeur.active = 0
    sortie = io.BytesIO()
    classeur.save(sortie)
    return Response(
        sortie.getvalue(),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        headers={"Content-Disposition": "attachment; filename=modele-import-gmao.xlsx"},
    )


# ---------- Lecture et contrôle ----------

def _lire_feuille(classeur, noms, colonnes):
    """Lignes d'un onglet sous forme de dictionnaires {clé: valeur}, avec leur numéro de ligne Excel."""
    feuille = next((classeur[n] for n in classeur.sheetnames if _cle(n) in noms), None)
    if feuille is None:
        return []
    lignes = feuille.iter_rows(values_only=True)
    entete = next(lignes, None) or []
    titres = {_cle(nom): cle for cle, nom, _, _ in colonnes}
    titres.update({_cle(cle): cle for cle, _, _, _ in colonnes})
    index = {i: titres[_cle(t)] for i, t in enumerate(entete) if _cle(t) in titres}
    resultat = []
    for numero, valeurs in enumerate(lignes, start=2):
        donnees = {cle: valeurs[i] if i < len(valeurs) else None for i, cle in index.items()}
        if all(v is None or str(v).strip() == "" for v in donnees.values()):
            continue
        if len(resultat) >= LIGNES_MAX:
            raise Invalide(f"{LIGNES_MAX} lignes maximum par onglet.")
        resultat.append((numero, donnees))
    return resultat


def analyser(fichier):
    """Contrôle tout le fichier sans rien enregistrer : (rapport, plan de création)."""
    try:
        classeur = load_workbook(io.BytesIO(fichier), read_only=True, data_only=True)
    except Exception:
        raise Invalide("Ce fichier n'est pas un classeur Excel (.xlsx) lisible. Partez du modèle à télécharger.")
    machines_lues = _lire_feuille(classeur, {"machines", "machine"}, COLONNES_MACHINES)
    pieces_lues = _lire_feuille(classeur, {"pieces", "piece"}, COLONNES_PIECES)
    if not machines_lues and not pieces_lues:
        raise Invalide("Aucune ligne à importer : remplissez l'onglet « Machines » ou « Pièces » du modèle.")

    ateliers = {_cle(a.nom): a for a in Atelier.query}
    reperes_base = {m.repere.upper(): m for m in Machine.query}
    elements = {_cle(e.nom): e for e in Element.query}
    categories = {_cle(c): c for c in liste("categories_pieces")}
    designations_base = {_normaliser(p.designation): p.reference for p in Piece.query}
    fournisseurs = {_normaliser(f.nom): f for f in Fournisseur.query}
    zones = {z.code: z for z in ZoneMagasin.query}

    rapport_machines, plan_machines, reperes_fichier = [], [], {}
    for ligne, d in machines_lues:
        erreurs, avertissements, m = [], [], {}
        try:
            m["repere"] = (_texte(d.get("repere"), 20) or "").upper()
            if not m["repere"]:
                erreurs.append("Repère obligatoire.")
            elif m["repere"] in reperes_base:
                erreurs.append(f"Le repère {m['repere']} existe déjà dans la GMAO.")
            elif m["repere"] in reperes_fichier:
                erreurs.append(f"Repère en double (déjà ligne {reperes_fichier[m['repere']]}).")
        except Invalide as e:
            erreurs.append(f"Repère : {e}")
        try:
            m["designation"] = _texte(d.get("designation"), 160)
            if not m["designation"]:
                erreurs.append("Désignation obligatoire.")
        except Invalide as e:
            erreurs.append(f"Désignation : {e}")
        atelier = ateliers.get(_cle(d.get("atelier")))
        if not atelier and d.get("atelier") not in (None, ""):
            # « 01 » ou « 1 » : le numéro de l'atelier suffit
            numero = re.match(r"^\s*0*(\d+)", str(d.get("atelier")))
            if numero:
                atelier = next((a for a in ateliers.values() if re.match(rf"^0*{numero[1]}\b", a.nom)), None)
        if not atelier:
            erreurs.append("Atelier obligatoire : il doit exister dans la GMAO (liste dans l'onglet Aide).")
        m["atelier"] = atelier
        for cle, longueur in (("marque", 80), ("modele", 80), ("numero_serie", 80), ("remarques", 5000)):
            try:
                m[cle] = _texte(d.get(cle), longueur)
            except Invalide as e:
                erreurs.append(f"{cle.capitalize()} : {e}")
        for cle, libelle, mini, maxi in (
            ("annee_mise_en_service", "Année de mise en service", 1900, 2100),
            ("utilisation_hebdo_h", "Utilisation par semaine", 0, 168),
            ("taux_horaire", "Taux horaire", 0, 100_000),
        ):
            try:
                m[cle] = nombre(d.get(cle), libelle, mini, maxi)
            except Invalide as e:
                erreurs.append(str(e))
        if m.get("annee_mise_en_service") is not None:
            m["annee_mise_en_service"] = int(m["annee_mise_en_service"])
        if m.get("repere") and m["repere"] not in reperes_fichier:
            reperes_fichier[m["repere"]] = ligne
        rapport_machines.append({"ligne": ligne, "repere": m.get("repere"), "designation": m.get("designation"), "erreurs": erreurs, "avertissements": avertissements})
        plan_machines.append(m)

    rapport_pieces, plan_pieces, designations_fichier = [], [], {}
    nouveaux_fournisseurs, nouvelles_zones = set(), set()
    for ligne, d in pieces_lues:
        erreurs, avertissements, p = [], [], {}
        try:
            p["designation"] = _texte(d.get("designation"), 160)
        except Invalide as e:
            erreurs.append(f"Désignation : {e}")
        cle_designation = _normaliser(p.get("designation"))
        if not p.get("designation"):
            erreurs.append("Désignation obligatoire.")
        elif cle_designation in designations_base:
            erreurs.append(f"Cette pièce existe déjà dans le magasin ({designations_base[cle_designation]}).")
        elif cle_designation in designations_fichier:
            erreurs.append(f"Pièce en double (déjà ligne {designations_fichier[cle_designation]}).")
        else:
            designations_fichier[cle_designation] = ligne
        p["categorie"] = categories.get(_cle(d.get("categorie")))
        if not p["categorie"]:
            erreurs.append("Catégorie obligatoire, choisie dans la liste (onglet Aide).")
        try:
            nom_fournisseur = _texte(d.get("fournisseur"), 120)
            p["reference_fournisseur"] = _texte(d.get("reference_fournisseur"), 80)
            p["commentaires"] = _texte(d.get("commentaires"), 5000)
        except Invalide as e:
            erreurs.append(str(e))
            nom_fournisseur = None
        p["fournisseur"] = nom_fournisseur
        if nom_fournisseur and _normaliser(nom_fournisseur) not in fournisseurs and _normaliser(nom_fournisseur) not in nouveaux_fournisseurs:
            avertissements.append(f"Nouveau fournisseur créé : {nom_fournisseur}.")
            nouveaux_fournisseurs.add(_normaliser(nom_fournisseur))
        for cle, libelle in (("prix_unitaire", "Prix unitaire"), ("quantite", "Quantité en stock"), ("stock_securite", "Stock de sécurité")):
            try:
                p[cle] = nombre(d.get(cle), libelle)
            except Invalide as e:
                erreurs.append(str(e))
        emplacement = str(d.get("emplacement") or "").strip().upper()
        p["emplacement"] = None
        if emplacement:
            code = CODE_ZONE.match(emplacement)
            if not code:
                erreurs.append(f"Emplacement « {emplacement} » : une lettre puis un chiffre, ex. A1.")
            else:
                p["emplacement"] = (code[1].upper(), int(code[2]))
                cle_zone = f"{code[1].upper()}{int(code[2])}"
                if cle_zone not in zones and cle_zone not in nouvelles_zones:
                    avertissements.append(f"Nouvel emplacement créé : {cle_zone}.")
                    nouvelles_zones.add(cle_zone)
        p["machines"] = []
        for repere in re.split(r"[,;]+", str(d.get("machines") or "")):
            repere = repere.strip().upper()
            if not repere:
                continue
            if repere not in reperes_base and repere not in reperes_fichier:
                erreurs.append(f"Machine {repere} introuvable (ni dans la GMAO, ni dans l'onglet Machines).")
            elif repere not in p["machines"]:
                p["machines"].append(repere)
        p["element"] = elements.get(_cle(d.get("element"))) if d.get("element") not in (None, "") else elements.get(_cle("Non défini"))
        if p["machines"] and not p["element"]:
            erreurs.append("Élément inconnu (liste dans l'onglet Aide).")
        try:
            p["repere_schema"] = normaliser_reperes(d.get("repere_schema"))
        except ValueError as e:
            erreurs.append(str(e))
        if p.get("repere_schema") and not p["machines"]:
            avertissements.append("Repère de schéma ignoré : aucune machine indiquée.")
        rapport_pieces.append({"ligne": ligne, "designation": p.get("designation"), "erreurs": erreurs, "avertissements": avertissements})
        plan_pieces.append(p)

    rapport = {
        "machines": rapport_machines,
        "pieces": rapport_pieces,
        "nb_erreurs": sum(len(l["erreurs"]) for l in rapport_machines + rapport_pieces),
    }
    return rapport, (plan_machines, plan_pieces)


def _fichier_recu():
    fichier = request.files.get("fichier")
    if not fichier or not fichier.filename:
        raise Invalide("Choisissez le fichier Excel à importer.")
    contenu = fichier.read(TAILLE_MAX + 1)
    if len(contenu) > TAILLE_MAX:
        raise Invalide("Fichier trop gros (5 Mo maximum).")
    return contenu


@bp.post("/import/apercu")
@role_required("admin", "technicien")
@unlock_required("machines")
def apercu():
    try:
        rapport, _ = analyser(_fichier_recu())
    except Invalide as e:
        return erreur(str(e), 400)
    return jsonify(rapport)


@bp.post("/import/valider")
@role_required("admin", "technicien")
@unlock_required("machines")
def valider():
    """Crée tout en une fois ; refusé (400, avec le rapport) s'il reste une erreur."""
    try:
        rapport, (plan_machines, plan_pieces) = analyser(_fichier_recu())
    except Invalide as e:
        return erreur(str(e), 400)
    if rapport["nb_erreurs"]:
        return jsonify(error="Le fichier contient encore des erreurs : corrigez-les puis recommencez.", **rapport), 400

    machines = {m.repere.upper(): m for m in Machine.query}
    for m in plan_machines:
        machine = Machine(
            repere=m["repere"], designation=m["designation"], atelier=m["atelier"], marque=m["marque"], modele=m["modele"],
            numero_serie=m["numero_serie"], annee_mise_en_service=m["annee_mise_en_service"],
            utilisation_hebdo_h=m["utilisation_hebdo_h"], taux_horaire=m["taux_horaire"], remarques=m["remarques"],
        )
        db.session.add(machine)
        machines[machine.repere] = machine
    db.session.flush()

    fournisseurs = {_normaliser(f.nom): f for f in Fournisseur.query}
    zones = {(z.etagere, z.etage): z for z in ZoneMagasin.query}
    reference = int(_nouvelle_reference())
    for p in plan_pieces:
        fournisseur = None
        if p["fournisseur"]:
            fournisseur = fournisseurs.get(_normaliser(p["fournisseur"]))
            if not fournisseur:
                fournisseur = fournisseurs[_normaliser(p["fournisseur"])] = Fournisseur(nom=p["fournisseur"])
                db.session.add(fournisseur)
        zone = None
        if p["emplacement"]:
            zone = zones.get(p["emplacement"])
            if not zone:
                zone = zones[p["emplacement"]] = ZoneMagasin(etagere=p["emplacement"][0], etage=p["emplacement"][1])
                db.session.add(zone)
        if reference > 99999:
            db.session.rollback()
            return erreur("Plus de référence disponible (99999 atteint).", 400)
        piece = Piece(
            reference=f"{reference:05d}", designation=p["designation"], categorie=p["categorie"], fournisseur=fournisseur,
            reference_fournisseur=p["reference_fournisseur"], prix_unitaire=p["prix_unitaire"], stock_securite=p["stock_securite"],
            zone=zone, commentaires=p["commentaires"], quantite=0,
        )
        reference += 1
        db.session.add(piece)
        db.session.flush()
        for repere in p["machines"]:
            db.session.add(PieceMachine(piece=piece, machine=machines[repere], element=p["element"], repere_schema=p["repere_schema"]))
        if p["quantite"]:
            mouvementer(piece, "inventaire", p["quantite"], "Stock initial (import Excel)")

    journaliser("import", details=f"Import Excel : {len(plan_machines)} machine(s), {len(plan_pieces)} pièce(s)")
    db.session.commit()
    return jsonify(machines=len(plan_machines), pieces=len(plan_pieces)), 201
