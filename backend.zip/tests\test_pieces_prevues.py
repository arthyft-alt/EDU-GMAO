from datetime import date

import pytest

from app import db
from app.models import Atelier, Machine, Mouvement, Piece, RealisationPreventive, TachePreventive, Utilisateur

AUJOURDHUI = date(2026, 11, 16)  # un lundi


@pytest.fixture(autouse=True)
def date_fixe(monkeypatch):
    monkeypatch.setattr("app.preventif.aujourdhui", lambda: AUJOURDHUI)


@pytest.fixture()
def stock(app):
    tour = Machine(repere="MAI-01", designation="Tour", atelier=Atelier.query.filter_by(nom="01. Maintenance").one())
    filtre = Piece(reference="00001", designation="Filtre à huile", categorie="Mécanique", quantite=3)
    huile = Piece(reference="00002", designation="Huile 5 L", categorie="Mécanique", quantite=1)
    db.session.add_all([tour, filtre, huile])
    db.session.commit()
    return tour, filtre, huile


def creer(client, tour, filtre, huile, niveau=3):
    reponse = client.post("/api/preventif/taches", json={
        "machine_id": tour.id, "nom": "Vidange", "niveau": niveau, "type_preventif": "Lubrification", "periodicite": "mois",
        "date_debut": "2026-11-16", "pieces": [{"piece_id": filtre.id, "quantite": 1}, {"piece_id": huile.id, "quantite": 2}],
    })
    assert reponse.status_code == 201, reponse.get_json()
    return reponse.get_json()["tache"]["id"]


def test_pieces_prevues_enregistrees(client, connecter, stock):
    tour, filtre, huile = stock
    connecter("tech")
    tache_id = creer(client, *stock)
    pieces = client.get(f"/api/preventif/taches/{tache_id}").get_json()["tache"]["pieces_prevues"]
    assert [(p["designation"], p["quantite"], p["stock"]) for p in pieces] == [("Filtre à huile", 1, 3), ("Huile 5 L", 2, 1)]
    # Une modification sans « pieces » ne les efface pas
    t = db.session.get(TachePreventive, tache_id)
    assert client.put(f"/api/preventif/taches/{tache_id}", json={
        "machine_id": tour.id, "nom": "Vidange complète", "niveau": 3, "type_preventif": "Lubrification", "periodicite": "mois", "date_debut": "2026-11-16",
    }).status_code == 200
    assert len(t.pieces_prevues) == 2
    assert client.post("/api/preventif/taches", json={
        "machine_id": tour.id, "nom": "X", "niveau": 1, "type_preventif": "Lubrification", "periodicite": "mois", "date_debut": "2026-11-16",
        "pieces": [{"piece_id": 999, "quantite": 1}],
    }).status_code == 400


def test_fait_refuse_puis_force(client, connecter, stock):
    tour, filtre, huile = stock
    connecter("tech")
    tache_id = creer(client, *stock)
    # Stock insuffisant (2 huiles prévues, 1 en stock) : refus avec la liste des manquantes, rien n'est sorti
    reponse = client.post(f"/api/preventif/taches/{tache_id}/realiser", json={})
    assert reponse.status_code == 409 and [m["designation"] for m in reponse.get_json()["manquantes"]] == ["Huile 5 L"]
    assert RealisationPreventive.query.count() == 0 and db.session.get(Piece, filtre.id).quantite == 3
    # Forcer : la tâche est validée, le filtre sort, l'huile manquante ne sort pas
    assert client.post(f"/api/preventif/taches/{tache_id}/realiser", json={"forcer": True}).status_code == 201
    assert db.session.get(Piece, filtre.id).quantite == 2 and db.session.get(Piece, huile.id).quantite == 1
    sortie = Mouvement.query.one()
    assert sortie.quantite == -1 and sortie.motif.startswith("Préventif : MAI-01 — Vidange")


def test_fait_avec_quantites_corrigees(client, connecter, stock):
    tour, filtre, huile = stock
    connecter("tech")
    tache_id = creer(client, *stock)
    reponse = client.post(f"/api/preventif/taches/{tache_id}/realiser",
                          json={"pieces": [{"piece_id": filtre.id, "quantite": 2}, {"piece_id": huile.id, "quantite": 1}]})
    assert reponse.status_code == 201
    assert db.session.get(Piece, filtre.id).quantite == 1 and db.session.get(Piece, huile.id).quantite == 0


def test_bon_de_preventif_sort_les_pieces(client, connecter, stock):
    tour, filtre, huile = stock
    connecter("admin")
    tache_id = creer(client, *stock)
    tech = Utilisateur.query.filter_by(login="tech").one().id
    bon = client.post(f"/api/preventif/taches/{tache_id}/confier", json={"ids": [tech]}).get_json()["bon"]
    client.post("/api/auth/logout")
    connecter("tech")
    assert client.post(f"/api/preventif/bons/{bon['id']}/fait", json={}).status_code == 409
    assert client.post(f"/api/preventif/bons/{bon['id']}/fait", json={"pieces": [{"piece_id": filtre.id, "quantite": 1}]}).status_code == 200
    assert db.session.get(Piece, filtre.id).quantite == 2 and db.session.get(Piece, huile.id).quantite == 1


def test_suppression_piece_prevue(client, connecter, stock):
    tour, filtre, huile = stock
    connecter("admin")
    tache_id = creer(client, *stock)
    assert client.delete(f"/api/pieces/{huile.id}").status_code == 200
    assert [p["designation"] for p in client.get(f"/api/preventif/taches/{tache_id}").get_json()["tache"]["pieces_prevues"]] == ["Filtre à huile"]
